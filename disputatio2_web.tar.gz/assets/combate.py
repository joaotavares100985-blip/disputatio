# -*- coding: utf-8 -*-
"""Combate por turnos (960x540), estilo Final Fantasy: cena larga, 5 botoes redondos, cartoes de habilidade,
objecoes em 3 cartoes, animacoes por categoria (feixe/geometria, livro+cruz de luz, corte, brilho dourado)."""
import math
import random

import pygame

import audio
import estado as E
from desenho import *
from arte_heroi import HERO_ANCHOR
from arte_fx_arg import desenhar_fx as desenhar_fx_arg
from textos import curto_txt, obj_curto, obj_opcoes, obj_expl, fala_curta
from ui import (Cena, Cartao, GradeRolavel, clamp, barra_icone, desenhar_item, desenhar_cartoes_resposta, desenhar_feedback,
                desenhar_dica, carta_hab, lh_max, CMD_ICONES, BARRA_HP, BARRA_TINTA, mais_item)

CAT_ATR = {"ratio": "razao", "auctoritas": "autoridade", "apoio": "humildade", "retorica": "eloquencia"}
HERO_POS = (190, 336)
HERO_POS2 = [(120, 312), (225, 376)]      # coop: os dois herois, um atras do outro
FX_DUR = {"ratio": 0.72, "auctoritas": 0.66, "distinguo": 0.6, "apoio": 0.95, "retorica": 0.55}
CAT_COR.setdefault("retorica", (226, 98, 98))
CAT_NOME.setdefault("retorica", "Retórica")
CAT_ICONE.setdefault("retorica", "galo")
_herosc = {}

# ---- taticas x temperamento (dados em conteudo.py; sem eles, cai na fraqueza simples de antes)
TEMP_NOMES = {"racional": "Racional", "dogmatico": "Dogmático", "sofista": "Sofista", "arrogante": "Arrogante",
              "emotivo": "Emotivo", "heretico": "Herege"}


def mult_tatica(cat, temp, fraqueza=None):
    """Multiplicador de dano da tatica `cat` contra o temperamento `temp` (0,5 a 2,2)."""
    mat = E.g("MATRIZ_TATICAS", None) or {}
    m = (mat.get(cat) or {}).get(temp) if temp else None
    base = float(m) if m is not None else 1.0
    if cat and cat == fraqueza:
        base *= 1.3 if m is not None else 1.5
    return max(0.5, min(2.2, base))


def avaliar_golpe(cat, temp, fraqueza=None):
    """-> (mult, tipo, rotulo, razao). tipo: muito | bom | neutro | pouco | falacia."""
    m = mult_tatica(cat, temp, fraqueza)
    mat = E.g("MATRIZ_TATICAS", None) or {}
    if not (mat.get(cat) or {}).get(temp):
        return m, ("muito" if m >= 1.4 else "neutro"), ("Fraco!" if m >= 1.4 else ""), ""
    razao = (E.g("MATRIZ_RAZOES", {}) or {}).get("%s:%s" % (cat, temp), "")
    if cat == "retorica" and m < 0.95:
        riso = (E.g("TEMPERAMENTOS", {}).get(temp) or {}).get("riso", "")
        return m, "falacia", ("Falácia! " + riso).strip(), razao
    if m >= 1.4:
        return m, "muito", "Muito eficaz!", razao
    if m >= 1.1:
        return m, "bom", "Eficaz", razao
    if m < 0.95:
        return m, "pouco", "Pouco eficaz", razao
    return m, "neutro", "", razao


def hero_scaled(which):
    if which not in _herosc:
        s = hero_sprite(which)
        _herosc[which] = cvt(pygame.transform.smoothscale(s, (int(s.get_width() * 1.2), int(s.get_height() * 1.2))))
    return _herosc[which]


def _lerp(a, b, t):
    return a + (b - a) * t


def _icone_rot(S, iid, x, y, size, ang, cor=None):
    tmp = pygame.Surface((size + 12, size + 12), pygame.SRCALPHA)
    desenhar_icone(tmp, iid, ((size + 12) // 2, (size + 12) // 2), size, cor)
    im = pygame.transform.rotozoom(tmp, ang, 1.0)
    S.blit(im, im.get_rect(center=(int(x), int(y))))


def _por_heroi(nome):
    """atributo guardado por heroi (coop); o `Combate` le/escreve o do heroi da vez (self.hi)"""
    return property(lambda s: s.hst[s.hi][nome], lambda s, v: s.hst[s.hi].__setitem__(nome, v))


class Combate(Cena):
    guard = _por_heroi("guard")
    ward = _por_heroi("ward")
    replica = _por_heroi("replica")
    hero_anim = _por_heroi("anim")
    hero_flash = _por_heroi("flash")

    def __init__(self, game, ids, boss, cb):
        super().__init__(game)
        self.run = game.run
        self.hs = list(self.run.herois)          # coop: 2 herois; solo: 1
        self.coop = len(self.hs) > 1
        self.hi = 0
        self.run.foco = 0
        self.hst = [dict(guard=False, ward=False, replica=False, anim=("", 0.0), flash=0.0) for _ in self.hs]
        self.j = self.hs[0]
        self.boss = boss
        self.cb = cb
        self.parts = Particulas(150)
        self.fl = Flutuantes()
        self.stage = pygame.Surface((W, H))
        dados = self.run.andar.dados
        cf, cp = dados.get("cor_fundo", (80, 60, 46)), dados.get("cor_piso", (100, 80, 60))
        try:
            import arte_salas
            s_ = self.run.sala()
            self.bg = arte_salas.fundo_combate(s_.tipo, self.run.andar_i, boss, self.run.pos)
        except Exception:
            self.bg = make_hall_combate(cf, cp, boss)
        self.en = []
        for iid in ids:
            d = E.CHEFES.get(iid) or E.INIM.get(iid)
            if not d:
                continue
            self.en.append(dict(id=iid, d=d, nome=d.get("nome", "Oponente"), hp=d.get("hp", 20), hpmax=d.get("hp", 20),
                                ataque=d.get("ataque", 6), defesa=d.get("defesa", 1), fraqueza=d.get("fraqueza"), temp=d.get("temperamento"),
                                forma=d.get("forma", "capuz"), cor=tuple(d.get("cor", (120, 80, 150))), objs=d.get("objecoes", []),
                                alive=True, fade=1.0, shake=0.0, flash=0.0, lunge=-1.0, split=-1.0, obs=False, rage=0, fases=set(),
                                ph=random.uniform(0, 6), boss=iid in E.CHEFES))
        n = len(self.en)
        pos = {1: [(700, 338)], 2: [(610, 326), (800, 346)], 3: [(540, 318), (700, 346), (860, 320)]}.get(n, [(700, 338)])
        for e, (x, y) in zip(self.en, pos):
            e["x"], e["y"] = x, y
            e["h"] = 240 if e["boss"] else {1: 200, 2: 180, 3: 150}.get(n, 150)
        self.state = "seq"
        self.q = []
        self.wait = 0.0
        self.shake = 0.0
        self.flashc = None
        self.flasht = 0.0
        self.guard = False
        self.ward = False
        self.replica = False
        self._res = None
        self.turno = 1
        self.hero_anim = ("", 0.0)
        self.hero_flash = 0.0
        self.balao = None
        self.chip = None
        self.dica = None
        self.cat_cor = None
        self.target_fn = None
        self.fila = []
        self.obj = None
        self.splash = None
        self.vit = None
        self.lst = None
        self.fx = []
        self.ator = "h"
        self.t = 0.0
        self.hab_ids = []
        self.item_ids = []
        e0 = self.en[0] if self.en else None
        fala = None
        if e0:
            fala = e0["d"].get("fala_entrada")
        if fala and e0:
            self.seq(0.5, lambda: self.falar(e0, fala, 2.6), 2.7, lambda: self.set_state("cmd"))
        else:
            self.seq(0.6, lambda: self.set_state("cmd"))

    # ---- coop: heroi da vez
    @property
    def HP(self):
        return self.pos_heroi(self.hi)

    def pos_heroi(self, i):
        return HERO_POS2[i] if self.coop else HERO_POS

    def escolhe_heroi(self, i):
        self.hi = i
        self.j = self.hs[i]
        self.run.foco = i

    def primeiro_vivo(self):
        return next((i for i, h in enumerate(self.hs) if h.hp > 0), 0)

    def passa_turno(self):
        """fim da acao de um heroi: proximo heroi vivo ou turno dos inimigos"""
        if self.coop:
            for i in range(self.hi + 1, len(self.hs)):
                if self.hs[i].hp > 0:
                    self.escolhe_heroi(i)
                    self.seq(0.3, lambda: self.set_state("cmd"))
                    return
        self.turno_inimigos()

    def dono(self):
        """coop: quem pode agir (0 anfitriao, 1 convidado)"""
        if self.coop and self.state in ("cmd", "skills", "items", "target", "objecao", "objres"):
            return (self.run.foco,)
        return (0, 1)

    def enter(self):
        g = self.game
        audio.musica("chefe" if self.boss else "combate")
        if "combate" not in g.seen:
            g.seen.add("combate")
            self.dica = ["Toque no inimigo: veja a que argumento ele cede.", 0.0]

    # ----------------------------------------------------- utilidades
    def say(self, s):
        pass

    def seq(self, *steps):
        self.q.extend(steps)
        self.state = "seq"

    def set_state(self, s):
        self.state = s
        self._st_t = self.t
        self.pid = None
        if s == "cmd":
            self.cat_cor = None
            self.ator = "h"

    def vivos(self):
        return [e for e in self.en if e["alive"]]

    def falar(self, e, texto, dur=2.0):
        self.balao = dict(text=fala_curta(texto, 78), e=e, t=0.0, dur=dur)

    def mostrar_chip(self, icone, texto, cor=GOLD_L):
        self.chip = dict(icone=icone, texto=curto_txt(texto, 26), t=0.0, cor=cor)

    def tap_skip(self):
        if self.state == "seq" and self.wait > 0.12 and not self.fx:
            self.wait = 0.05

    # ----------------------------------------------------------- loop
    def update(self, dt):
        self.t += dt
        self.shake = max(0, self.shake - dt)
        self.flasht = max(0, self.flasht - dt)
        for h_ in self.hst:
            h_["flash"] = max(0, h_["flash"] - dt)
        if self.dica:
            self.dica[1] += dt
            if self.dica[1] > 4.0:
                self.dica = None
        if self.chip:
            self.chip["t"] += dt
            if self.chip["t"] > 1.5:
                self.chip = None
        for h_ in self.hst:
            a, k = h_["anim"]
            if a:
                k += dt
                h_["anim"] = (a, k) if k < 0.95 else ("", 0.0)
        for e in self.en:
            e["shake"] = max(0, e["shake"] - dt)
            e["flash"] = max(0, e["flash"] - dt)
            if e["lunge"] >= 0:
                e["lunge"] += dt
                if e["lunge"] > 0.6:
                    e["lunge"] = -1
            if e["split"] >= 0:
                e["split"] += dt
                if e["split"] > 0.9:
                    e["split"] = -1
            if not e["alive"]:
                e["fade"] = max(0, e["fade"] - dt * 1.4)
        if self.balao:
            self.balao["t"] += dt
            if self.balao["t"] > self.balao["dur"]:
                self.balao = None
        if self.splash:
            self.splash["t"] += dt
            if self.splash["t"] > 1.0:
                self.splash = None
        if self.obj:
            self.obj["t"] = self.obj.get("t", 0) + dt
        for f in self.fx:
            f["t"] += dt
        self.fx = [f for f in self.fx if f["t"] < f["dur"]]
        self.parts.update(dt)
        self.fl.update(dt)
        if self.state == "seq":
            if self.wait > 0:
                self.wait -= dt
            while self.wait <= 0 and self.q and self.state == "seq":
                s = self.q.pop(0)
                if callable(s):
                    s()
                else:
                    self.wait = s

    def ok(self):
        if self.state == "seq":
            self.tap_skip()
            return
        super().ok()

    def key(self, k):
        if self.state == "cmd":
            m = {pygame.K_1: self.cmd_argumentar, pygame.K_2: self.cmd_autoridade, pygame.K_3: self.cmd_item,
                 pygame.K_4: self.cmd_defender, pygame.K_5: self.cmd_fugir}
            if k in m:
                m[k]()
        elif self.state in ("skills", "items", "target") and k == pygame.K_ESCAPE:
            self._back()

    # ------------------------------------------------------- acoes do jogador
    def cmd_argumentar(self):
        self.state = "skills"
        self.hab_ids = list(self.j.habilidades)
        self.lst = GradeRolavel((32, 380, 896, 150), len(self.hab_ids), 4, 70, 10, self.row_hab, self.tap_hab)
        self.lists = [self.lst]

    def row_hab(self, S, r, i):
        h = E.HAB.get(self.hab_ids[i], {})
        cat = h.get("categoria", "ratio")
        ok = self.j.tinta >= h.get("custo_tinta", 0)
        marca = any(e["alive"] and e["obs"] and cat != "apoio" and mult_tatica(cat, e.get("temp"), e["fraqueza"]) >= 1.4
                    for e in self.en)
        carta_hab(S, r, h, ok, self.t, marca, self.hab_ids[i])

    def tap_hab(self, i):
        hid = self.hab_ids[i]
        h = E.HAB.get(hid, {})
        if self.j.tinta < h.get("custo_tinta", 0):
            self.fl.add("Sem tinta!", 190, 220, (140, 170, 255))
            audio.sfx("erro")
            return
        cat = h.get("categoria", "ratio")
        self.lists = []
        if cat == "apoio":
            self.acao_habilidade(hid, None)
        else:
            self.escolher_alvo(lambda e: self.acao_habilidade(hid, e))

    def escolher_alvo(self, fn):
        v = self.vivos()
        if len(v) == 1:
            fn(v[0])
        else:
            self.target_fn = fn
            self.state = "target"
            self.lists = []

    def tap_inimigo(self, e):
        if self.state == "target" and e["alive"]:
            fn, self.target_fn = self.target_fn, None
            self.lists = []
            fn(e)
        elif self.state == "cmd" and e["alive"]:
            e["obs"] = True
            fr = e["fraqueza"]
            tp = e.get("temp")
            if tp and E.g("MATRIZ_TATICAS", None):
                mat = E.g("MATRIZ_TATICAS", {})
                cats = [c for c in mat]
                ms = {c: mult_tatica(c, tp, fr) for c in cats}
                bom = max(cats, key=lambda c: ms[c])
                mau = min(cats, key=lambda c: ms[c])
                txt = "%s: use %s; evite %s." % (TEMP_NOMES.get(tp, tp), CAT_NOME.get(bom, bom), CAT_NOME.get(mau, mau))
                self.dica = [txt, 0.0]
                self.fl.add(TEMP_NOMES.get(tp, tp), e["x"], e["y"] - e["h"] - 10, CAT_COR.get(bom, GOLD_L))
            elif fr:
                self.fl.add("Fraco: " + CAT_NOME.get(fr, fr), e["x"], e["y"] - e["h"] - 10, CAT_COR.get(fr, GOLD_L))

    def dano_jogador(self, poder, atr, e, cat):
        j = self.j
        raw = poder + atr * 0.9 + j.nivel - e["defesa"] * 0.6
        raw = max(1.0, raw) * random.uniform(0.9, 1.1)
        m, tipo, rot, razao = avaliar_golpe(cat, e.get("temp"), e["fraqueza"])
        raw *= m
        fraco = bool(cat and cat == e["fraqueza"])
        usou_replica = self.replica
        if usou_replica:
            raw *= 1.5
            self.replica = False
        self._res = dict(m=m, tipo=tipo, rot=rot, razao=razao, cat=cat, replica=usou_replica)
        crit = random.random() < 0.05 + j.atr("eloquencia") * 0.012 + j.bonus("bonus_critico_pct") / 100.0
        if crit:
            raw *= 1.6
        raw *= 1 + j.bonus("bonus_dano_pct") / 100.0
        return max(1, int(round(raw))), fraco, crit

    def acao_habilidade(self, hid, e):
        j = self.j
        h = E.HAB.get(hid, {})
        cat = h.get("categoria", "ratio")
        j.tinta = max(0, j.tinta - h.get("custo_tinta", 0))
        self.lists = []
        self.cat_cor = CAT_COR.get(cat, GOLD)
        self.cat = cat
        self.ator = "h"
        self.mostrar_chip(E.icone_hab(h), h.get("nome", ""), self.cat_cor)
        if cat == "apoio":
            heal = int(h.get("poder", 8) + j.atr("humildade") * 0.8)
            self.seq(lambda: self.set_anim("cast"), 0.25, lambda: self.fx_launch("apoio", None), 0.5, lambda: self.curar(heal), 0.9, self.fim_acao)
            return
        if cat == "distinguo":
            atr = (j.atr("razao") + j.atr("eloquencia")) / 2.0
        else:
            atr = j.atr(CAT_ATR.get(cat, "razao"))
        dmg, fraco, crit = self.dano_jogador(h.get("poder", 8), atr, e, cat)
        self.seq(lambda: (self.set_anim("lunge"), self.fala_jogador(cat)), 0.3, lambda: self.fx_launch(cat, e), FX_DUR.get(cat, 0.5),
                 lambda: self.aplicar_dano(e, dmg, fraco, crit, self.cat_cor, cat), 0.7, lambda: self.depois_dano(e), self.fim_acao)

    def fala_jogador(self, cat):
        v = (E.g("FALAS_JOGADOR", {}) or {}).get(cat)
        if v:
            self.fl.add(random.choice(v), self.HP[0] + 40, self.HP[1] - 215, CAT_COR.get(cat, GOLD_L))

    def acao_autoridade(self, e):
        j = self.j
        j.tinta = max(0, j.tinta - 2)
        self.cat_cor = CAT_COR["auctoritas"]
        self.cat = "auctoritas"
        self.ator = "h"
        self.mostrar_chip("pergaminho", "Autoridade", self.cat_cor)
        dmg, fraco, crit = self.dano_jogador(j.atr("autoridade") * 0.55 + 2, j.atr("autoridade") * 0.7, e, "auctoritas")
        self.seq(lambda: (self.set_anim("lunge"), self.fala_jogador("auctoritas")), 0.3, lambda: self.fx_launch("auctoritas", e), FX_DUR["auctoritas"],
                 lambda: self.aplicar_dano(e, dmg, fraco, crit, self.cat_cor, "auctoritas"), 0.7, lambda: self.depois_dano(e), self.fim_acao)

    def set_anim(self, nome):
        self.hero_anim = (nome, 0.0)

    def hero_dx(self, i=None):
        a, k = self.hero_anim if i is None else self.hst[i]["anim"]
        if a == "lunge":
            if k < 0.28:
                return 170 * math.sin(k / 0.28 * math.pi / 2)
            if k < 0.5:
                return 170
            return 170 * (1 - clamp((k - 0.5) / 0.4, 0, 1)) ** 1.5
        if a == "cast":
            return 24 * math.sin(clamp(k / 0.8, 0, 1) * math.pi)
        return 0

    def fx_launch(self, kind, e):
        hx = self.HP[0] + self.hero_dx() + 80
        hy = self.HP[1] - 130
        if e is not None:
            tx, ty = e["x"], e["y"] - e["h"] * 0.5
        else:
            tx, ty = self.HP[0], self.HP[1] - 100
        audio.sfx("golpe_" + kind)
        self.fx.append(dict(kind=kind, t=0.0, dur=FX_DUR[kind], sx=hx, sy=hy, tx=tx, ty=ty, cor=CAT_COR[kind], flip=random.random() < 0.5))
        if kind != "apoio":
            self.parts.burst(hx, hy, 10, [CAT_COR[kind], (255, 255, 255)], v=(30, 120), g=0, up=0, life=(.3, .6))

    def curar(self, n):
        j = self.j
        n = min(n, j.hp_max - j.hp)
        j.hp += n
        audio.sfx("cura")
        self.ward = True
        self.fl.add("+%d" % n, self.HP[0], self.HP[1] - 190, (120, 240, 140), True)
        self.parts.burst(self.HP[0], self.HP[1] - 100, 22, [(120, 240, 150), (255, 230, 140), (255, 255, 255)], up=140)

    def aplicar_dano(self, e, dmg, fraco, crit, cor, cat=None):
        e["hp"] = max(0, e["hp"] - dmg)
        audio.sfx("critico" if crit else "acerto")
        e["shake"] = 0.4
        e["flash"] = 0.35
        if cat == "distinguo":
            e["split"] = 0.0
        self.shake = 0.18 + (0.15 if crit else 0)
        self.fl.add(str(dmg), e["x"], e["y"] - e["h"] * .6, (255, 90, 80) if crit else (255, 255, 255), crit)
        r = self._res or {}
        rot = r.get("rot") or ("Fraco!" if fraco else "")
        if rot:
            ruim = r.get("tipo") in ("pouco", "falacia")
            self.fl.add(rot, e["x"], e["y"] - e["h"] * .6 + 56, (150, 170, 220) if r.get("tipo") == "pouco" else
                        ((255, 130, 120) if ruim else (255, 210, 90)))
            if r.get("razao") and r.get("tipo") in ("muito", "pouco", "falacia"):
                self.fl.add(r["razao"], e["x"], e["y"] - e["h"] * .6 + 92, (240, 230, 200))
            if r.get("tipo") in ("muito", "pouco", "falacia") or fraco:
                e["obs"] = True
        if r.get("replica"):
            self.fl.add("Réplica!", e["x"], e["y"] - e["h"] * .6 - 96, (160, 220, 255))
        if r.get("tipo") == "falacia" and r.get("m", 1) <= 0.6 and self.j.hp > 3:
            self.j.hp -= 2
            self.fl.add("-2 Ânimo", self.HP[0], self.HP[1] - 190, (255, 130, 120))
        if crit:
            self.fl.add("Crítico!", e["x"], e["y"] - e["h"] * .6 - 60, (255, 160, 60))
        self.parts.burst(e["x"], e["y"] - e["h"] * .5, 18 + (10 if crit else 0), [cor, (255, 255, 255)])
        self.flasht = 0.25
        self.flashc = cor

    def depois_dano(self, e):
        passos = []
        r, self._res = self._res, None
        if r and e["hp"] > 0 and r.get("tipo") in ("muito", "pouco", "falacia"):
            fr = ((E.g("FALAS_REACAO", {}) or {}).get(e.get("temp")) or {}).get(r["tipo"])
            if fr:
                tx = random.choice(fr)
                passos += [lambda: self.falar(e, tx, 1.7), 1.8]
        if e["hp"] > 0 and e["boss"]:
            pct = 100.0 * e["hp"] / max(1, e["hpmax"])
            fases = sorted(e["d"].get("fases", []), key=lambda f: -f.get("hp_abaixo_pct", 0))
            for idx, f in enumerate(fases):
                if idx not in e["fases"] and pct <= f.get("hp_abaixo_pct", 0):
                    e["fases"].add(idx)
                    e["rage"] += 1
                    passos += [lambda f=f: (self.falar(e, f.get("fala", "..."), 2.6), self.shake_big()), 2.7]
                    break
        if e["hp"] <= 0:
            e["alive"] = False
            self.parts.burst(e["x"], e["y"] - e["h"] * .4, 30, [e["cor"], (255, 255, 255), GOLD_L])
            fd = e["d"].get("fala_derrota")
            if fd:
                passos += [lambda: self.falar(e, fd, 1.9), 2.0]
            else:
                passos += [0.6]
        if passos:
            self.q = passos + self.q
            self.state = "seq"

    def shake_big(self):
        self.shake = 0.5
        self.flasht = 0.3
        self.flashc = (200, 40, 30)

    def fim_acao(self):
        if not self.vivos():
            self.vitoria()
            return
        self.passa_turno()

    # ---------------------------------------------------- outros comandos
    def cmd_autoridade(self):
        if self.j.tinta < 2:
            self.fl.add("Sem tinta!", 190, 220, (140, 170, 255))
            return
        self.escolher_alvo(self.acao_autoridade)

    def cmd_item(self):
        j = self.j
        if not j.consumiveis:
            self.fl.add("Sem itens", 190, 220, (230, 220, 180))
            return
        self.state = "items"
        self.item_ids = list(j.consumiveis)
        self.lst = GradeRolavel((32, 380, 896, 150), len(self.item_ids), 4, 70, 10, self.row_item, self.tap_item)
        self.lists = [self.lst]

    def row_item(self, S, r, i):
        iid = self.item_ids[i]
        it = E.ITENS.get(iid, {})
        pygame.draw.rect(S, (0, 0, 0), r.move(2, 4), 0, 14)
        pygame.draw.rect(S, (250, 238, 208), r, 0, 14)
        pygame.draw.rect(S, (120, 84, 24), r, 4, 14)
        desenhar_item(S, r.x + 36, r.centery, it, 46)
        sz, lines, lh = fit_text(it.get("nome", iid), r.w - 110, lh_max(24) * 2, 24, 22, True)
        draw_lines(S, lines[:2], 22, INK, r.x + 66, r.y + 10, lh, bold=True)
        draw_text(S, "x%d" % self.j.consumiveis.get(iid, 0), 26, (110, 70, 20), (r.right - 12, r.bottom - 16), anchor="midright", bold=True, shadow=None)
        ef = it.get("efeito", {}) or {}
        ic = "animo" if "cura_hp" in ef else ("tinta" if "cura_tinta" in ef else "estrela")
        desenhar_icone(S, ic, (r.x + 80, r.bottom - 18), 24)

    def tap_item(self, i):
        j = self.j
        iid = self.item_ids[i]
        ef = E.ITENS.get(iid, {}).get("efeito", {})
        util = ("cura_hp" in ef and j.hp < j.hp_max) or ("cura_tinta" in ef and j.tinta < j.tinta_max) or \
               any(k.startswith("bonus_") or k in ("hp_max", "tinta_max") for k in ef)
        if not util:
            self.fl.add("Sem efeito agora", 190, 220, (230, 220, 180))
            return
        self.lists = []
        it = E.ITENS[iid]
        self.mostrar_chip("frasco", it.get("nome", iid))

        def usar():
            r = j.usar(iid)
            self.fl.add(r or "", self.HP[0], self.HP[1] - 190, (120, 240, 140))
            self.parts.burst(self.HP[0], self.HP[1] - 100, 20, [(120, 240, 150), (255, 255, 255)], up=140)
        self.seq(lambda: self.set_anim("cast"), 0.3, usar, 0.9, self.fim_acao)

    def cmd_defender(self):
        j = self.j
        self.guard = True
        n = min(j.tinta_max - j.tinta, 3 + j.atr("humildade") // 2)
        j.tinta += n
        self.hero_anim = ("guard", 0.0)
        self.mostrar_chip("escudo", "Defender", (130, 170, 255))
        self.seq(0.2, lambda: self.fl.add("+%d" % n, self.HP[0], self.HP[1] - 190, (130, 170, 255)), 0.9, self.fim_acao)

    def cmd_fugir(self):
        if self.boss:
            self.fl.add("Sem fuga!", self.HP[0], self.HP[1] - 190, (255, 140, 120), True)
            return
        ch = 0.5 + self.j.atr("humildade") * 0.02
        if random.random() < ch:
            self.seq(0.2, lambda: self.fl.add("Fuga!", self.HP[0], self.HP[1] - 190, (255, 255, 255)), 0.8, lambda: self.sair("fugiu"))
        else:
            self.fl.add("Falhou!", self.HP[0], self.HP[1] - 190, (255, 140, 120))
            self.seq(0.6, self.passa_turno)

    # -------------------------------------------------- turno dos inimigos
    def turno_inimigos(self):
        self.fila = list(self.vivos())
        self.proximo_inimigo()

    def proximo_inimigo(self):
        if not self.fila:
            for h_ in self.hst:
                h_["guard"] = h_["ward"] = False
            self.turno += 1
            self.escolhe_heroi(self.primeiro_vivo())
            self.set_state("cmd")
            return
        e = self.fila.pop(0)
        if not e["alive"]:
            self.proximo_inimigo()
            return
        self.ator = e
        if self.coop:                       # a objecao mira um heroi vivo; o dono dele responde
            self.escolhe_heroi(random.choice([i for i, h in enumerate(self.hs) if h.hp > 0]))
        oid, o = self.run.proxima_objecao(e["objs"])
        self.atual = e
        if o is None:
            self.seq(0.3, lambda: self.golpe(e, self.dano_inimigo(e)))
            return
        cur = obj_opcoes(o)
        ops = list(enumerate(o.get("opcoes", ["", "", ""])))
        random.shuffle(ops)
        self.obj = dict(e=e, o=o, ops=[(cur[i], i == o.get("correta", 0)) for i, _ in ops], esc=None, dano=self.dano_inimigo(e),
                        t=0.0, curto=obj_curto(o))
        self.splash = dict(t=0.0, text="OBJEÇÃO!")
        e["lunge"] = 0.0
        self.seq(0.9, lambda: self.set_state("objecao"))

    def dano_inimigo(self, e):
        j = self.j
        d = e["ataque"] * random.uniform(0.85, 1.15) * (1 + 0.12 * e["rage"])
        d *= 1 - min(60, j.bonus("reduz_dano_pct")) / 100.0
        d -= j.atr("humildade") * 0.25
        if self.guard:
            d *= 0.5
        if self.ward:
            d *= 0.7
        return max(1, int(round(d)))

    def responder(self, i):
        ob = self.obj
        if ob["esc"] is not None:
            return
        ob["esc"] = i
        ob["ok"] = ob["ops"][i][1]
        ob["t"] = 0.0
        audio.sfx("certa" if ob["ok"] else "errada")
        st = self.run.stats
        ob["extras"] = []
        if ob["ok"]:
            st["acertos"] += 1
            n = min(2, self.j.tinta_max - self.j.tinta)
            self.j.tinta += n
            ob["extras"] = [("escudo", "Sem dano", GOLD_L)] + ([("tinta", "+%d" % n, (130, 170, 255))] if n else [])
            self.fl.add("Refutado!", self.HP[0] + 60, self.HP[1] - 220, GOLD_L)
            self.replica = True
            self.fl.add("Réplica: próximo golpe +50%", self.HP[0] + 60, self.HP[1] - 260, (160, 220, 255))
            self.parts.burst(self.HP[0] + 40, self.HP[1] - 120, 24, [GOLD_L, GOLD, (255, 255, 255)], up=140)
        else:
            st["erros"] += 1
            ob["extras"] = [("animo", "-%d" % ob["dano"], (255, 130, 120))]
        self.state = "objres"

    def saber_mais(self):
        ob = self.obj
        o = ob["o"]
        s = o.get("explicacao", "")
        if o.get("ref"):
            s += "\nFonte: " + o["ref"]
        self.game.push(Cartao(self.game, "Saber mais", ob["e"]["nome"], s, icone="pergaminho", longo=True))

    def fim_objecao(self):
        ob = self.obj
        self.obj = None
        e = ob["e"]
        if ob["ok"]:
            self.proximo_inimigo()
        else:
            self.seq(0.1, lambda: self.golpe(e, ob["dano"]))

    def golpe(self, e, dano):
        j = self.j
        e["lunge"] = 0.0

        def bate():
            j.hp = max(0, j.hp - dano)
            audio.sfx("dano")
            self.hero_flash = 0.4
            self.shake = 0.35
            self.fl.add("-%d" % dano, self.HP[0], self.HP[1] - 190, (255, 90, 80), True)
            self.parts.burst(self.HP[0], self.HP[1] - 110, 16, [(255, 90, 80), (255, 200, 120)])
            self.flasht = 0.3
            self.flashc = (200, 30, 20)

        def depois():
            if j.hp <= 0 and not any(h.hp > 0 for h in self.hs):
                self.derrota()
            else:
                self.proximo_inimigo()
        self.seq(0.3, bate, 0.8, depois)

    # --------------------------------------------------------- fim
    def vitoria(self):
        for h in self.hs:                   # heroi caido revive com metade do Animo
            if h.hp <= 0:
                h.hp = max(1, h.hp_max // 2)
        j = self.hs[0]
        xp = sum(e["d"].get("xp", 0) for e in self.en)
        fl = sum(e["d"].get("florins", 0) for e in self.en)
        fl = int(round(fl * (1 + j.bonus("bonus_florins_pct") / 100.0)))
        j.florins += fl
        self.run.stats["florins"] += fl
        subidas = j.ganhar_xp(xp)
        for h in self.hs[1:]:               # XP e florins para o outro heroi tambem
            h.florins += int(round(sum(e["d"].get("florins", 0) for e in self.en) * (1 + h.bonus("bonus_florins_pct") / 100.0)))
            h.ganhar_xp(xp)
        linhas = [("estrela", "+%d XP" % xp, PARCH), ("florim", "+%d florins" % fl, GOLD_L)]
        for s in subidas:
            linhas.append(("estrela", "NÍVEL %d  %s" % (s["nivel"], s["titulo"]), (255, 220, 110)))
            if s["novas"]:
                linhas.append(("livro", curto_txt("Novo: " + ", ".join(E.HAB[h].get("nome", h) for h in s["novas"]), 40), (160, 200, 255)))
        self.vit = dict(linhas=linhas[:6], boss=self.boss)
        audio.sfx("levelup" if subidas else "vitoria")
        self.parts.burst(480, 260, 40, [GOLD_L, GOLD, (255, 255, 255)], up=160)
        self.ator = "h"
        self.seq(0.9, lambda: self.set_state("vitoria"))

    def derrota(self):
        audio.sfx("derrota")
        audio.musica(None)
        self.seq(0.6, lambda: self.set_state("derrota"))

    def sair(self, res):
        self.game.pop(self)
        self.cb(res)

    # --------------------------------------------------------- entrada
    def hit_inimigo(self, pos):
        for e in self.en:
            if e["alive"] and abs(pos[0] - e["x"]) < max(60, e["h"] * 0.5) and e["y"] - e["h"] - 40 < pos[1] < e["y"] + 24:
                return e
        return None

    def up(self, i, pos):
        if self.state in ("target", "cmd") and self.dpos is not None and i == self.pid and \
                math.hypot(pos[0] - self.dpos[0], pos[1] - self.dpos[1]) < 24:
            e = self.hit_inimigo(pos)
            if e is not None and not any(r.collidepoint(pos) for r, _ in self.hits):
                super().up(i, pos)
                self.tap_inimigo(e)
                return
        if self.state == "seq":
            self.tap_skip()
        super().up(i, pos)

    # ----------------------------------------------------------- desenho
    def foco_inicial(self, cs):
        if self.state == "target":
            for c in cs:
                if c[0][0] == "e":
                    return c
        return cs[0]

    def draw(self, S):
        self.hits = []
        self.foco_extra = []
        self.draw_stage()
        sx = sy = 0
        if self.shake > 0:
            sx = int(math.sin(self.t * 70) * 10 * self.shake * 2.2)
            sy = int(math.cos(self.t * 53) * 5 * self.shake * 2.2)
        if sx or sy:
            S.fill((10, 6, 3))
        S.blit(self.stage, (sx, sy))
        self.draw_status(S)
        self.draw_turnos(S)
        if self.chip:
            self.draw_chip(S)
        st = self.state
        if st in ("cmd", "seq", "target"):
            self.draw_cmd(S)
        elif st == "skills":
            self.draw_lista(S, "Argumentar", "tinta", "%d/%d" % (self.j.tinta, self.j.tinta_max))
        elif st == "items":
            self.draw_lista(S, "Itens", "animo", "%d/%d" % (self.j.hp, self.j.hp_max))
        elif st == "objecao" or st == "objres":
            self.draw_obj(S)
        elif st == "vitoria":
            self.draw_vit(S)
        elif st == "derrota":
            self.draw_der(S)
        if self.splash:
            k = self.splash["t"]
            sc = 1 + 0.9 * max(0, 1 - k * 5)
            img = outlined_surf(self.splash["text"], 96, (255, 110, 100), 5, (255, 255, 255))
            img = pygame.transform.rotozoom(img, -5, sc)
            img.set_alpha(int(255 * min(1, (1.0 - k) * 4)))
            S.blit(img, img.get_rect(center=(480, 262)))
        if self.dica:
            desenhar_dica(S, self.dica[0], self.dica[1], 356)

    def draw_stage(self):
        S = self.stage
        t = self.t
        S.blit(self.bg, (0, 0))
        alvo = self.state == "target"
        for e in sorted(self.en, key=lambda e: e["y"]):
            if e["fade"] <= 0:
                continue
            bob = math.sin(t * 2.2 + e["ph"]) * 3
            dx = 0
            if e["shake"] > 0:
                dx += math.sin(t * 60) * 8 * e["shake"] * 2
            if e["lunge"] >= 0:
                dx -= math.sin(min(1, e["lunge"] / 0.6) * math.pi) * 160
            hh = int(e["h"] * escala_inimigo(e["d"]))
            if not e["alive"]:
                spr = sprite_inimigo(e["id"], (1 - e["fade"]) / 1.4, "morte", hh, e["rage"])
            elif e["flash"] > 0:
                spr = sprite_inimigo(e["id"], 0.35 - e["flash"], "dano", hh, e["rage"])
            elif e["lunge"] >= 0:
                spr = sprite_inimigo(e["id"], e["lunge"], "ataque", hh, e["rage"])
            else:
                spr = sprite_inimigo(e["id"], t + e["ph"], "idle", hh, e["rage"])
            if alvo and e["alive"]:
                pr = 1 + .08 * math.sin(t * 8)
                pygame.draw.ellipse(S, (255, 230, 120), (e["x"] - 80 * pr, e["y"] - 10, 160 * pr, 26), 3)
            rect = spr.get_rect(midbottom=(int(e["x"] + dx), int(e["y"] + e["h"] * 0.075 + bob)))
            if e["split"] >= 0:
                k = min(1.0, e["split"] / 0.9)
                d = int(40 * math.sin(k * math.pi))
                half = rect.w // 2
                old = S.get_clip()
                S.set_clip(pygame.Rect(rect.x - 80, rect.y, half + 80, rect.h))
                S.blit(spr, rect.move(-d, 0))
                S.set_clip(pygame.Rect(rect.x + half, rect.y, half + 80, rect.h))
                S.blit(spr, rect.move(d, 0))
                S.set_clip(old)
                if d > 2:
                    pygame.draw.line(S, (255, 255, 255), (rect.centerx, rect.y - 6), (rect.centerx, rect.bottom), max(2, d // 5))
            else:
                S.blit(spr, rect)
            if e["alive"] and not (self.state in ("objecao", "objres") and self.obj and self.obj["e"] is e):
                self.draw_plate(S, e, bob)
                if alvo:
                    ay = e["y"] - e["h"] - 70 + math.sin(t * 8) * 7
                    draw_arrow(S, int(e["x"]), int(ay), "d", (255, 230, 120), 16)
        # herois (1 no solo, 2 no coop)
        cat = getattr(self, "cat", "ratio")
        for hi_ in sorted(range(len(self.hs)), key=lambda i: self.pos_heroi(i)[1]):
            st_ = self.hst[hi_]
            hx, hy = self.pos_heroi(hi_)
            a, k = st_["anim"]
            fl_ = st_["flash"]
            dx = self.hero_dx(hi_)
            sh = math.sin(t * 60) * 7 * fl_ * 2 if fl_ > 0 else 0
            nv = self.hs[hi_].nivel
            if self.state == "derrota" or (self.coop and self.hs[hi_].hp <= 0):
                hs = hero_combate(nv, "derrota", (t - getattr(self, "_st_t", t)) if self.state == "derrota" else 4.0)
            elif self.state == "vitoria":
                hs = hero_combate(nv, "vitoria", t - getattr(self, "_st_t", t))
            elif fl_ > 0:
                hs = hero_combate(nv, "dano", 0.4 - fl_, 2 if int(t * 28) % 2 == 0 else 0)
            elif a == "lunge":
                hs = hero_combate(nv, {"ratio": "dedo", "auctoritas": "livro", "distinguo": "pergaminho"}.get(cat, "dedo"), k)
            elif a == "cast":
                hs = hero_combate(nv, "bencao", k)
            elif st_["guard"]:
                hs = hero_combate(nv, "guarda", 1.0)
            else:
                hs = hero_combate(nv, "idle", t)
            S.blit(hs, (int(hx + dx + sh) - HERO_ANCHOR[0], int(hy + 14) - HERO_ANCHOR[1]))
            if st_["guard"] or st_["ward"]:
                escudo_luz(S, hx + dx + 80, hy - 110, t, 70)
            if a == "cast" and self.cat_cor:
                add_glow(S, (hx + 80 + dx, hy - 150), 90, self.cat_cor, .6 + 1.2 * math.sin(min(1, k / 0.8) * math.pi))
        self.draw_fx(S)
        self.parts.draw(S)
        self.fl.draw(S)
        if self.flasht > 0 and self.flashc:
            ov = _flash(self.flashc)
            ov.set_alpha(int(110 * self.flasht / 0.3))
            S.blit(ov, (0, 0))
        if self.balao:
            self.draw_balao(S, self.balao)

    def draw_fx(self, S):
        for f in self.fx:
            p = f["t"] / f["dur"]
            k = f["kind"]
            sx, sy, tx, ty, cor = f["sx"], f["sy"], f["tx"], f["ty"], f["cor"]
            if k in ("ratio", "auctoritas", "distinguo", "apoio"):
                desenhar_fx_arg(S, f)
            elif k == "retorica":
                pr = min(1.0, p / 0.8)
                for i in range(5):
                    q = clamp(pr - i * 0.12, 0, 1)
                    if q > 0:
                        x, y = _lerp(sx, tx, q), _lerp(sy, ty, q) + math.sin(f["t"] * 14 + i) * 8
                        pygame.draw.circle(S, mix(cor, (255, 255, 255), .3), (int(x), int(y)), int(14 + 10 * q + i * 3), 4)
                add_glow(S, (_lerp(sx, tx, pr), _lerp(sy, ty, pr)), 50, cor)
                if p > 0.75:
                    q = (p - 0.75) / 0.25
                    pygame.draw.circle(S, (255, 255, 255), (int(tx), int(ty)), int(20 + 60 * q), 4)

    def draw_plate(self, S, e, bob):
        x = int(e["x"])
        y = int(e["y"] - e["h"] * (0.98 if e["boss"] else 0.86) + bob)
        y = max(64, y)
        w = 150 if e["boss"] else 124
        nm = trunc(e["nome"], 24, w + 90)
        im = draw_text(S, nm, 24, GOLD_L if e["boss"] else PARCH, (x, y - 16), bold=True)
        draw_bar(S, pygame.Rect(x - w // 2, y, w, 12), e["hp"] / max(1, e["hpmax"]), (240, 100, 100), (170, 40, 50))
        if e["obs"] and e.get("temp"):
            draw_text(S, TEMP_NOMES.get(e["temp"], ""), 20, (230, 215, 170), (x, y + 24), bold=True)
        if e["obs"] and e["fraqueza"]:
            ic = CAT_ICONE.get(e["fraqueza"], "ratio")
            c = (x + w // 2 + 20, y + 6)
            pygame.draw.circle(S, (24, 15, 8), c, 17)
            pygame.draw.circle(S, CAT_COR.get(e["fraqueza"], GOLD), c, 17, 3)
            desenhar_icone(S, ic, c, 24)

    def draw_balao(self, S, b):
        e = b["e"]
        k = min(1, b["t"] * 6)
        if k < 1:
            pass
        y = max(60, e["y"] - e["h"] - 92)
        balao_texto(S, b["text"], e["x"], y, 520, 28, (e["x"], e["y"] - e["h"] + 20))

    def draw_status(self, S):
        for i, j in enumerate(self.hs):
            x0 = 8 if i == 0 else 690
            r_ = pygame.Rect(x0, 8, 262, 92)
            panel(S, r_, 215)
            if self.coop and self.hi == i and self.ator == "h" and self.state in ("cmd", "skills", "items", "target"):
                pygame.draw.rect(S, GOLD_L, r_, 3, 12)
            barra_icone(S, x0 + 10, 14, 244, 28, "animo", j.hp / j.hp_max, BARRA_HP, "%d/%d" % (j.hp, j.hp_max))
            barra_icone(S, x0 + 10, 48, 244, 28, "tinta", j.tinta / j.tinta_max, BARRA_TINTA, "%d/%d" % (j.tinta, j.tinta_max))
            desenhar_icone(S, "estrela", (x0 + 22, 88), 20)
            draw_text(S, "%d" % j.nivel, 22, PARCH, (x0 + 38, 88), anchor="midleft", bold=True, sh=1)
            desenhar_icone(S, "florim", (x0 + 100, 88), 20)
            draw_text(S, "%d" % j.florins, 22, GOLD_L, (x0 + 116, 88), anchor="midleft", bold=True, sh=1)
            if self.coop:
                draw_text(S, "Jogador %d" % (i + 1), 20, (150, 220, 255) if i else GOLD_L, (x0 + 252, 88), anchor="midright", bold=True, sh=1)

    def draw_turnos(self, S):
        hn = ["h", "h2"][:len(self.hs)]
        itens = hn + [e for e in self.en if e["alive"]]
        n = len(itens)
        wbar = n * 54 + 24
        r = pygame.Rect(0, 6, wbar, 54)
        r.centerx = 500
        pygame.draw.rect(S, (20, 12, 6), r, 0, 27)
        pygame.draw.rect(S, GOLD, r, 2, 27)
        for i, it in enumerate(itens):
            c = (r.x + 39 + i * 54, r.centery)
            her = isinstance(it, str)
            ativo = (her and self.ator == "h" and self.hi == hn.index(it)) or (not her and self.ator is it)
            rad = 22 if ativo else 18
            pygame.draw.circle(S, (60, 44, 28) if her else mix(it["cor"], (0, 0, 0), .5), c, rad)
            if her:
                desenhar_icone(S, "pessoa", c, rad * 1.5)
            else:
                spr = miniatura_inimigo(it["id"], 2 * rad - 4)
                S.blit(spr, spr.get_rect(center=c))
            pygame.draw.circle(S, GOLD_L if ativo else (120, 90, 40), c, rad, 3)

    def draw_chip(self, S):
        c = self.chip
        k = c["t"]
        a = min(1, k * 6) * min(1, (1.5 - k) * 4)
        f = font(26, True)
        w = f.size(c["texto"])[0] + 76
        r = pygame.Rect(0, 0, w, 44)
        r.midtop = (500, 70 - int((1 - min(1, k * 6)) * 14))
        tmp = pygame.Surface((w, 44), pygame.SRCALPHA)
        pygame.draw.rect(tmp, (20, 12, 6, 225), tmp.get_rect(), 0, 22)
        pygame.draw.rect(tmp, c["cor"], tmp.get_rect(), 3, 22)
        desenhar_icone(tmp, c["icone"], (26, 22), 30)
        tmp.blit(txt(c["texto"], 26, PARCH, True), (50, 22 - f.get_height() // 2))
        tmp.set_alpha(int(255 * a))
        S.blit(tmp, r.topleft)

    def draw_cmd(self, S):
        ativo = self.state == "cmd"
        panel(S, pygame.Rect(176, 420, 628, 118), 215)
        if self.coop and self.state in ("cmd", "target"):
            draw_text(S, "Vez do Jogador %d" % (self.hi + 1), 22, (150, 220, 255) if self.hi else GOLD_L, (480, 410), bold=True)
        if self.state == "target":
            draw_text(S, "Toque no inimigo", 32, GOLD_L, (480, 452), bold=True)
            self.rbtn(S, (480, 495), 26, "x", None, self._cancel_target, "normal")
            self.foco_extra = [(pygame.Rect(int(e["x"]) - 70, int(e["y"] - e["h"]), 140, int(e["h"]) + 20),
                                (lambda e=e: self.tap_inimigo(e))) for e in self.vivos()]
            return
        for k, (lab, ic) in enumerate(CMD_ICONES):
            c = (480 + (k - 2) * 120, 468)
            st = "normal"
            if not ativo:
                st = "dim"
            elif lab == "Item" and not self.j.consumiveis:
                st = "dim"
            elif lab == "Autoridade" and self.j.tinta < 2:
                st = "dim"
            fn = [self.cmd_argumentar, self.cmd_autoridade, self.cmd_item, self.cmd_defender, self.cmd_fugir][k]
            if lab == "Fugir" and self.boss:
                st = "dim"
            r = 40
            rect = pygame.Rect(c[0] - r, c[1] - r, 2 * r, 2 * r + 30)
            draw_round(S, c, r, ic, lab, st, self.is_pressed(rect) and st != "dim", ativo and st != "dim" and k == 0 and self.turno == 1 and self.t % 1.6 < .8,
                       self.t, lsz=22)
            if ativo and st != "dim":
                self.reg(rect, fn)

    def _cancel_target(self):
        self.target_fn = None
        self.state = "cmd"

    def draw_lista(self, S, titulo, ic, extra):
        panel(S, pygame.Rect(16, 330, 928, 208), 240)
        draw_text(S, titulo, 32, GOLD_L, (40, 352), anchor="midleft", bold=True)
        desenhar_icone(S, ic, (300, 352), 30)
        draw_text(S, extra, 28, PARCH, (322, 352), anchor="midleft", bold=True)
        self.rbtn(S, (900, 352), 24, "x", None, self._back, "normal")
        if self.lst.n == 0:
            draw_text(S, "Nada aqui", 30, (176, 150, 104), (480, 450))
        self.lst.draw(S)

    def _back(self):
        self.lists = []
        self.target_fn = None
        self.set_state("cmd")

    def draw_obj(self, S):
        ob = self.obj
        if not ob:
            return
        e = ob["e"]
        # balao grande de objecao
        balao_texto(S, ob["curto"], 620, 68, 620, 32, (e["x"], e["y"] - e["h"] * 0.78), col=(252, 240, 214))
        if self.state == "objecao":
            desenhar_cartoes_resposta(self, S, [t for t, _ in ob["ops"]], ["normal"] * 3, 362, 160, self.responder, self.t)
        else:
            ok = ob["ok"]
            desenhar_feedback(self, S, ok, obj_expl(ob["o"]), ob.get("extras", []), self.fim_objecao, self.saber_mais, ob.get("t", 0), 332, 204)

    def draw_vit(self, S):
        v = self.vit
        panel(S, pygame.Rect(250, 90, 460, 440), 240)
        outlined(S, "MESTRE DERROTADO!" if v["boss"] else "VITÓRIA!", 60 if not v["boss"] else 44, GOLD, (480, 136), th=3, hi=GOLD_L)
        y = 190
        for ic, ln, col in v["linhas"]:
            desenhar_icone(S, ic, (300, y + 20), 36)
            draw_text(S, trunc(ln, 30, 360), 30, col, (332, y + 20), anchor="midleft", bold=True)
            y += 46
        self.btn(S, (340, 458, 280, 60), "Continuar", lambda: self.sair("venceu"), "gold", 34, icone="play")

    def draw_der(self, S):
        panel(S, pygame.Rect(250, 150, 460, 300), 240)
        outlined(S, "DERROTADO", 64, (230, 100, 90), (480, 214), th=3, hi=(255, 170, 160))
        desenhar_icone(S, "animo", (480, 300), 64, (120, 100, 100))
        self.btn(S, (340, 366, 280, 66), "Continuar", self.game.game_over, "gold", 36, icone="play")


_fl = {}


def _flash(col):
    if col not in _fl:
        s = pygame.Surface((W, H))
        s.fill(col)
        _fl[col] = s
    return _fl[col]
