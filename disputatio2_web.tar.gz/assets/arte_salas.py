﻿# -*- coding: utf-8 -*-
"""Cenarios das salas (960x540): fundo ESTATICO em cache por (tipo, andar, seed) + camada DINAMICA leve
(chamas, feixes de luz, poeira, brilhos) + portas gotico-ogivais. Pesquisa: simbolos.md (planta da igreja).

Geometria (igual ao motor): piso FL=(60,120,840,380); portas no centro das 4 bordas.
API principal:
  estilo_sala(tipo_jogo, andar_idx, pos) -> um dos 16 tipos de SALAS_ESTILO
  fundo_sala(tipo, andar_idx, tamanho=(960,540), seed=0) -> Surface (cache)
  desenhar_sala_dinamica(S, tipo, tempo, andar_idx=0, seed=0)
  fundo_combate(tipo, andar_idx, boss=False) -> Surface desfocada/escurecida
  draw_door(S, side, locked, special=None, estado=None)
"""
import math
import random

import pygame

import arte_base as B
from arte_base import mix, esc, surf, conv, luz_add, halo_a, sombra_elipse, PI

W, H = 960, 540
FL = pygame.Rect(60, 120, 840, 380)
DOOR_C = {"N": (480, 120), "S": (480, 500), "W": (60, 310), "E": (900, 310)}
DOOR_HW = 44


def door_rect(side):
    cx, cy = DOOR_C[side]
    if side == "N":
        return pygame.Rect(cx - DOOR_HW, 66, 2 * DOOR_HW, 56)
    if side == "S":
        return pygame.Rect(cx - DOOR_HW, 498, 2 * DOOR_HW, 42)
    if side == "W":
        return pygame.Rect(0, cy - DOOR_HW, 62, 2 * DOOR_HW)
    return pygame.Rect(898, cy - DOOR_HW, 62, 2 * DOOR_HW)


TIPOS = ("entrada", "combate_nave", "capela", "claustro", "scriptorium", "capitular", "sacristia", "cripta",
         "campanario", "biblioteca", "coro", "altar_mor", "loja", "tesouro", "enfermaria", "enigma")
ESPECIAIS = ("entrada", "enigma", "loja", "tesouro", "enfermaria", "altar_mor")

# pedra/piso/luz padrao por tipo (a luz vem de SALAS_ESTILO quando existe)
SPEC = {
    "entrada": dict(pedra=(186, 176, 158), piso="enc", cpiso=(150, 96, 70), luz=(235, 225, 195), amb=.62),
    "combate_nave": dict(pedra=(160, 150, 134), piso="xadrez", cpiso=(158, 144, 132), luz=(185, 165, 215), amb=.6),
    "capela": dict(pedra=(150, 132, 112), piso="enc", cpiso=(140, 90, 64), luz=(255, 196, 120), amb=.52),
    "claustro": dict(pedra=(200, 190, 170), piso="claustro", cpiso=(176, 166, 146), luz=(245, 240, 215), amb=.78),
    "scriptorium": dict(pedra=(176, 162, 134), piso="madeira", cpiso=(130, 88, 50), luz=(240, 228, 190), amb=.66),
    "capitular": dict(pedra=(170, 160, 146), piso="xadrez", cpiso=(120, 112, 112), luz=(210, 200, 180), amb=.58),
    "sacristia": dict(pedra=(150, 126, 98), piso="madeira", cpiso=(118, 78, 46), luz=(215, 185, 130), amb=.5),
    "cripta": dict(pedra=(112, 102, 92), piso="cripta", cpiso=(86, 78, 70), luz=(150, 120, 80), amb=.38),
    "campanario": dict(pedra=(150, 142, 130), piso="madeira", cpiso=(110, 84, 58), luz=(185, 200, 230), amb=.64),
    "biblioteca": dict(pedra=(150, 126, 98), piso="madeira", cpiso=(120, 80, 46), luz=(228, 212, 170), amb=.56),
    "coro": dict(pedra=(160, 150, 138), piso="enc", cpiso=(100, 82, 100), luz=(205, 175, 230), amb=.52),
    "altar_mor": dict(pedra=(214, 206, 188), piso="enc", cpiso=(176, 140, 90), luz=(255, 218, 140), amb=.7),
    "loja": dict(pedra=(166, 148, 120), piso="madeira", cpiso=(128, 84, 48), luz=(235, 205, 150), amb=.58),
    "tesouro": dict(pedra=(142, 120, 96), piso="lajes", cpiso=(112, 94, 70), luz=(255, 222, 125), amb=.5),
    "enfermaria": dict(pedra=(224, 216, 198), piso="lajes", cpiso=(190, 182, 164), luz=(225, 235, 210), amb=.74),
    "enigma": dict(pedra=(104, 100, 140), piso="lajes", cpiso=(84, 80, 120), luz=(180, 170, 235), amb=.54),
}
# grade de cor por andar (multiplicada no fim) e extras de ambiente
GRADE = [(255, 246, 232), (214, 230, 255), (250, 222, 250), (255, 212, 200)]
CF_PAD = [(46, 34, 24), (22, 30, 52), (40, 20, 30), (30, 14, 14)]
CP_PAD = [(150, 120, 70), (90, 110, 150), (130, 80, 90), (110, 60, 50)]


def _andar_cores(andar):
    cf, cp = CF_PAD[andar % 4], CP_PAD[andar % 4]
    try:
        import estado as E
        d = E.ANDARES[andar].get
        cf, cp = tuple(d("cor_fundo", cf)), tuple(d("cor_piso", cp))
    except Exception:
        pass
    return cf, cp


def _luz_estilo(tipo):
    try:
        import estado as E
        l = (E.SALAS_ESTILO.get(tipo) or {}).get("luz")
        if l:
            return tuple(l)
    except Exception:
        pass
    return SPEC[tipo]["luz"]


# ----------------------------------------------------------------------- mapeamento jogo -> estilo
def _salas_tipos(andar):
    try:
        import estado as E
        return list(E.ANDARES[andar].get("salas_tipos") or [])
    except Exception:
        return []


def estilo_sala(tipo, andar_idx=0, pos=(0, 0)):
    """Converte o tipo de sala do jogo (inicio/combate/tesouro/loja/cura/enigma/chefe) num dos 16 estilos."""
    if tipo in SPEC:
        return tipo
    lst = _salas_tipos(andar_idx) or ["combate_nave", "capela", "scriptorium"]
    if tipo == "inicio":
        return "entrada" if andar_idx == 0 else (lst[0] if lst[0] in SPEC else "claustro")
    if tipo == "cura":
        return "enfermaria"
    if tipo == "chefe":
        return "altar_mor"
    if tipo in ("tesouro", "loja", "enigma"):
        return tipo
    cand = [t for t in lst if t in SPEC and t not in ESPECIAIS] or ["combate_nave"]
    return cand[(pos[0] * 7 + pos[1] * 13 + andar_idx) % len(cand)]


# ----------------------------------------------------------------------- contexto de construcao
class Ctx:
    def __init__(self, tipo, andar, seed):
        self.tipo, self.andar, self.seed = tipo, andar, seed
        self.rnd = random.Random(hash((tipo, andar, seed)) & 0xFFFFFF)
        sp = SPEC[tipo]
        cf, cp = _andar_cores(andar)
        tone = esc(cf, 3.2)
        self.pedra = mix(mix(sp["pedra"], tone, .24), PEDRA_EST[andar % 4], .4)
        self.cpiso = mix(sp["cpiso"], cp, .28)
        self.luz = mix(_luz_estilo(tipo), LUZ_EST[andar % 4][0], LUZ_EST[andar % 4][1])
        self.amb = min(.92, sp["amb"] + (.16 if tipo == "cripta" else .1))
        self.S = pygame.Surface((W, H))
        self.luzes = []        # (x, y, r, cor, tipo, fase)
        self.janelas = []      # vidros colados depois da luz
        self.pools = []        # feixes dinamicos
        self.glints = []
        self.extra_post = []   # callables(S) depois da luz
        self.pontos = []       # poeira: (x0,y0,x1,y1)

    def chama(self, x, y, r=90, col=(255, 170, 80), tipo="chama", k=1.0):
        self.luzes.append((x, y, r, col, tipo, self.rnd.uniform(0, 6.28), k))

    def brilho(self, x, y, r=60, col=(255, 200, 100)):
        self.luzes.append((x, y, r, col, "fixa", 0, 1.0))

    def glint(self, x, y, col=(255, 240, 180), s=5):
        self.glints.append((x, y, col, s, self.rnd.uniform(0, 6.28)))


# ----------------------------------------------------------------------- estilo arquitetonico por andar
# 0 ROMANICO (Anselmo, Cluny, Bec): volta perfeita, paredes grossas, arcatura cega e friso lombardo, capiteis historiados, pedra quente.
# 1 GOTICO CLASSICO / RAYONNANT (Paris, Sainte-Chapelle): ogivas, vitrais, rosacea, nervuras, pinaculos e arcobotantes.
# 2 GOTICO TARDIO / FLAMEJANTE (Oxford, Colonia): arcos conopiais, rendilhado denso, abobada em leque, pinaculos, tons azul-violeta.
# 3 BARROCO (Salamanca, Coimbra): colunas salomonicas, retabulos dourados, marmore, estuque, putti, gloria, coracao e custodia.
NOMES_ESTILO = ("romanico", "gotico_rayonnant", "gotico_flamejante", "barroco")
PEDRA_EST = [(214, 178, 124), (190, 188, 180), (150, 150, 188), (178, 118, 100)]
LUZ_EST = [((255, 226, 170), .5), ((200, 218, 255), .3), ((206, 170, 255), .3), ((255, 200, 150), .35)]


def _vazio_porta(x):
    return abs(x - 480) < 118


def _decor_fundo(c):
    """Repinta a parede do fundo quando o estilo pede (barroco: marmore com almofadas douradas, cornija com dentes, estuque)."""
    if c.andar != 3:
        return
    S, rnd = c.S, c.rnd
    r = pygame.Rect(0, 0, W, 124)
    base = mix(c.pedra, (150, 64, 62), .4)
    pygame.draw.rect(S, esc(base, .55), r)
    for x in range(0, W, 120):
        pr = pygame.Rect(x + 8, 24, 104, 80)
        col = esc(base, .92 + .1 * ((x // 120) % 2))
        pygame.draw.rect(S, col, pr, 0, 3)
        for _ in range(9):
            x0, y0 = rnd.randint(pr.x, pr.right), rnd.randint(pr.y, pr.bottom - 10)
            pts = [(x0, y0)]
            for k in range(4):
                pts.append((pts[-1][0] + rnd.randint(-12, 12), pts[-1][1] + rnd.randint(4, 14)))
            pygame.draw.lines(S, esc(base, 1.4 if rnd.random() < .5 else .66), False, [(max(pr.x, min(pr.right, a)), min(pr.bottom, b)) for a, b in pts], 1)
        pygame.draw.rect(S, B.OURO_S, pr, 3, 3)
        pygame.draw.rect(S, B.OURO, pr.inflate(-6, -6), 1, 2)
        for (px, py) in ((pr.x, pr.y), (pr.right - 1, pr.y), (pr.x, pr.bottom - 1), (pr.right - 1, pr.bottom - 1)):
            pygame.draw.circle(S, B.OURO_C, (px, py), 3)
    B.granulado(S, r, .6, c.seed)
    S.blit(B.vgrad_a(W, 40, (0, 0, 0), 130, (0, 0, 0), 0), (0, 0))
    S.blit(B.vgrad_a(W, 22, (0, 0, 0), 0, (0, 0, 0), 100), (0, 102))
    # cornija: estuque creme com dentes dourados
    pygame.draw.rect(S, (206, 186, 150), (0, 0, W, 14))
    pygame.draw.rect(S, B.OURO_S, (0, 14, W, 3))
    pygame.draw.rect(S, B.OURO, (0, 12, W, 2))
    for x in range(4, W, 12):
        pygame.draw.rect(S, B.OURO_S, (x, 4, 6, 7))
        pygame.draw.rect(S, B.OURO_C, (x, 4, 6, 2))
    # volutas de estuque no alto
    for x in range(60, W, 160):
        for sg in (-1, 1):
            cx = x + sg * 14
            pygame.draw.arc(S, (228, 208, 170), (cx - 12, 18, 24, 24), 0 if sg > 0 else PI * .5, PI * 1.5 if sg > 0 else PI * 2, 3)
            pygame.draw.circle(S, (228, 208, 170), (cx, 30), 3)
    pygame.draw.rect(S, esc(base, .62), (0, 108, W, 16))
    pygame.draw.rect(S, B.OURO_S, (0, 108, W, 3))
    pygame.draw.line(S, (20, 14, 10), (0, 123), (W, 123), 2)


def _decor_frente(c):
    """Elementos estruturais do estilo sobre a parede do fundo e as laterais (antes dos moveis/janelas do tipo da sala)."""
    S, e, ped = c.S, c.andar, c.pedra
    clara, escura = esc(ped, 1.2), esc(ped, .42)
    if e == 0:
        # friso lombardo (arquinhos cegos) sob a cornija
        for x in range(0, W, 24):
            pygame.draw.polygon(S, esc(ped, .5), B.ogiva(x + 12, 34, 20, 10, 0))
            pygame.draw.polygon(S, esc(ped, 1.1), B.ogiva(x + 12, 34, 20, 10, 0), 1)
            pygame.draw.rect(S, esc(ped, .8), (x + 20, 28, 6, 8))
        pygame.draw.rect(S, esc(ped, 1.15), (0, 36, W, 3))
        # arcatura cega de volta perfeita, colunas curtas e grossas com capiteis historiados
        xs = list(range(62, 900, 112))
        for xc in xs[:-1]:
            cxm = xc + 56
            if _vazio_porta(cxm):
                continue
            pygame.draw.polygon(S, esc(ped, .5), B.ogiva(cxm, 108, 100, 52, 6))
            pygame.draw.polygon(S, clara, B.ogiva(cxm, 108, 100, 52, 6), 3)
            pygame.draw.polygon(S, escura, B.ogiva(cxm, 108, 86, 44, 6), 1)
        for x in xs:
            if _vazio_porta(x):
                continue
            pygame.draw.rect(S, esc(ped, 1.0), (x - 6, 62, 12, 46))
            pygame.draw.rect(S, esc(ped, 1.3), (x - 6, 62, 3, 46))
            pygame.draw.rect(S, esc(ped, .7), (x - 9, 104, 18, 6), 0, 2)
            B.capitel_historiado(S, x, 56, 14, ped)
        # pilares grossos nas laterais, com capitel
        for xx, sg in ((24, 1), (902, 1)):
            pygame.draw.rect(S, esc(ped, .95), (xx, 118, 34, 384))
            pygame.draw.rect(S, esc(ped, 1.28), (xx, 118, 5, 384))
            pygame.draw.rect(S, esc(ped, .6), (xx + 29, 118, 5, 384))
            B.capitel_historiado(S, xx + 17, 126, 28, ped)
            pygame.draw.rect(S, esc(ped, .72), (xx - 3, 486, 40, 16), 0, 2)
    elif e == 1:
        # arcatura de lancetas com colunetas, nervuras que nascem dos capiteis e arcobotantes nos cantos
        xs = list(range(62, 900, 112))
        for x in xs:
            if not _vazio_porta(x):
                pygame.draw.rect(S, esc(ped, 1.0), (x - 3, 50, 6, 58))
                pygame.draw.rect(S, esc(ped, 1.3), (x - 3, 50, 2, 58))
                pygame.draw.rect(S, esc(ped, .8), (x - 6, 46, 12, 5), 0, 2)
            for sg in (-1, 1):
                pygame.draw.lines(S, esc(ped, .55), False, [(x, 46), (x + sg * 14, 24), (x + sg * 40, 0)], 3)
                pygame.draw.lines(S, esc(ped, 1.25), False, [(x, 45), (x + sg * 14, 23), (x + sg * 40, -1)], 1)
        for xc in xs[:-1]:
            cxm = xc + 56
            if _vazio_porta(cxm):
                continue
            pygame.draw.polygon(S, esc(ped, .5), B.ogiva(cxm, 108, 86, 66, 4))
            pygame.draw.polygon(S, clara, B.ogiva(cxm, 108, 86, 66, 4), 2)
            pygame.draw.polygon(S, escura, B.ogiva(cxm, 108, 70, 56, 4), 1)
            B.trifolio(S, cxm, 74, 9, esc(ped, 1.1), 1)
        for xx, sg in ((0, 1), (960, -1)):                 # arcobotante: arco que pula do contraforte
            pts = [(xx + sg * 6, 4), (xx + sg * 34, 18), (xx + sg * 58, 48)]
            pygame.draw.lines(S, esc(ped, .5), False, pts, 8)
            pygame.draw.lines(S, esc(ped, 1.2), False, [(a, b - 3) for a, b in pts], 2)
            B.pinaculo(S, xx + sg * 14, 130, 70, 14, esc(ped, 1.0))
    elif e == 2:
        # abobada em leque no alto, arcos conopiais com rendilhado denso, pinaculos
        for cx in (130, 345, 560, 775, 960):
            for i in range(-6, 7):
                pygame.draw.line(S, esc(ped, .5), (cx, 40), (cx + i * 20, 0), 2)
                pygame.draw.line(S, esc(ped, 1.25), (cx - 1, 39), (cx + i * 20 - 1, 0), 1)
            pygame.draw.arc(S, esc(ped, .6), (cx - 90, -60, 180, 120), PI * 1.05, PI * 1.95, 3)
            pygame.draw.arc(S, esc(ped, .6), (cx - 60, -40, 120, 80), PI * 1.05, PI * 1.95, 2)
            pygame.draw.rect(S, esc(ped, .75), (cx - 8, 38, 16, 8), 0, 2)
        xs = list(range(62, 900, 106))
        for xc in xs[:-1]:
            cxm = xc + 53
            if _vazio_porta(cxm):
                continue
            pygame.draw.polygon(S, esc(ped, .42), B.conopial(cxm, 108, 80, 72, 4))
            pygame.draw.polygon(S, clara, B.conopial(cxm, 108, 80, 72, 4), 2)
            pygame.draw.polygon(S, escura, B.conopial(cxm, 108, 66, 60, 4), 1)
            for sg in (-1, 1):                                # mouchettes (chamas) e quadrifolio
                mx = cxm + sg * 11
                pygame.draw.polygon(S, esc(ped, 1.05), [(mx, 62), (mx + sg * 8, 76), (mx + sg * 2, 92), (mx - sg * 7, 78)], 1)
            B.quadrifolio(S, cxm, 64, 10, esc(ped, 1.1), 1)
            pygame.draw.line(S, esc(ped, 1.1), (cxm, 74), (cxm, 108), 1)
        for x in xs:
            pygame.draw.rect(S, esc(ped, 1.0), (x - 3, 60, 6, 48))
            B.pinaculo(S, x, 62, 44, 9, esc(ped, 1.05))
        for xx in (30, 930):
            for k in range(4):
                pygame.draw.rect(S, esc(ped, 1.05 - .12 * (k % 2)), (xx - 8 + k * 4, 126, 3, 360))
            B.pinaculo(S, xx, 130, 96, 16, esc(ped, 1.1))
    else:
        # barroco: colunas salomonicas, retabulos dourados com custodia e coracao, putti, gloria
        for x in (110, 350, 610, 850):
            B.coluna_torsa(S, x, 34, 108, 14)
        for x, ic in ((236, "custodia"), (724, "coracao_flamejante")):
            nich = pygame.Rect(x - 40, 26, 80, 84)
            pygame.draw.polygon(S, (36, 18, 16), B.ogiva(x, 110, 80, 50, 34))
            pygame.draw.polygon(S, B.OURO_S, B.ogiva(x, 110, 80, 50, 34), 4)
            pygame.draw.polygon(S, B.OURO, B.ogiva(x, 110, 70, 44, 34), 2)
            pygame.draw.polygon(S, (60, 30, 24), B.ogiva(x, 110, 70, 44, 34))
            for i in range(11):
                a = PI + PI * i / 10
                pygame.draw.line(S, (232, 188, 80), (x, 74), (x + math.cos(a) * 42, 74 + math.sin(a) * 42), 1)
            try:
                from icones import desenhar_icone
                desenhar_icone(S, ic, (x, 72), 44)
            except Exception:
                pass
            c.brilho(x, 70, 70, (150, 100, 40))
            B.putto(S, x - 46, 28, .9)
            B.putto(S, x + 46, 28, .9)
        # gloria sobre a porta e pediment quebrado dourado
        g = B.gloria_barroca(20)
        S.blit(g, (480 - g.get_width() // 2, 0))
        for sg in (-1, 1):
            pygame.draw.polygon(S, B.OURO_S, [(480 + sg * 30, 30), (480 + sg * 70, 44), (480 + sg * 70, 52), (480 + sg * 30, 40)])
            pygame.draw.polygon(S, B.OURO_C, [(480 + sg * 30, 30), (480 + sg * 70, 44), (480 + sg * 70, 46), (480 + sg * 30, 32)])
        for xx in (24, 902):
            pygame.draw.rect(S, esc(ped, .8), (xx, 118, 34, 384))
            pygame.draw.rect(S, esc(ped, 1.18), (xx, 118, 4, 384))
            B.coluna_torsa(S, xx + 17, 138, 484, 16)
            pygame.draw.rect(S, B.OURO_S, (xx - 2, 486, 38, 16), 0, 2)


# ----------------------------------------------------------------------- partes da sala
def _parede_fundo(c):
    S, rnd = c.S, c.rnd
    r = pygame.Rect(0, 0, W, 124)
    B.parede_pedra(S, r, c.pedra, rnd, bh=24, bw=60)
    B.granulado(S, r, .9, c.seed)
    # sombra do teto e do rodape
    S.blit(B.vgrad_a(W, 40, (0, 0, 0), 150, (0, 0, 0), 0), (0, 0))
    S.blit(B.vgrad_a(W, 22, (0, 0, 0), 0, (0, 0, 0), 110), (0, 102))
    # cornija com mísulas
    pygame.draw.rect(S, esc(c.pedra, .62), (0, 0, W, 13))
    pygame.draw.rect(S, esc(c.pedra, .85), (0, 13, W, 3))
    pygame.draw.line(S, esc(c.pedra, 1.2), (0, 16), (W, 16))
    for x in range(8, W, 26):
        pygame.draw.polygon(S, esc(c.pedra, .5), [(x, 0), (x + 16, 0), (x + 12, 13), (x + 4, 13)])
        pygame.draw.line(S, esc(c.pedra, .95), (x + 4, 13), (x + 12, 13))
    # rodape (plinto) com moldura
    pygame.draw.rect(S, esc(c.pedra, .72), (0, 108, W, 16))
    pygame.draw.rect(S, esc(c.pedra, 1.12), (0, 108, W, 3))
    pygame.draw.rect(S, esc(c.pedra, 1.0), (0, 111, W, 2))
    pygame.draw.line(S, (20, 14, 10), (0, 123), (W, 123), 2)


def _laterais(c):
    S, rnd = c.S, c.rnd
    for x0, sg in ((0, 1), (900, -1)):
        r = pygame.Rect(x0, 118, 60, 384)
        B.parede_pedra(S, r, esc(c.pedra, .9), rnd, bh=26, bw=34, var=7)
        B.granulado(S, r, .9, c.seed + x0)
        # sombra para o lado de fora (a parede some na sombra)
        for i in range(60):
            a = int(120 * (1 - i / 60.0) ** 1.4) if sg > 0 else int(120 * (i / 60.0) ** 1.4)
            pygame.draw.line(S, (0, 0, 0, a), (x0 + i, 118), (x0 + i, 502)) if False else None
        g = B.hgrad(60, 384, (10, 8, 8), (120, 100, 90)) if sg > 0 else B.hgrad(60, 384, (120, 100, 90), (10, 8, 8))
        g.set_alpha(120)
        S.blit(g, r.topleft)
        # colunetas do canto interno (feixe de 3 fustes) com capitel e base
        ix = 46 if sg > 0 else 902
        for k in range(3):
            xx = ix + k * 4
            for yy in range(124, 498):
                pass
            col = esc(c.pedra, 1.15 - .22 * abs(k - 1))
            pygame.draw.rect(S, col, (xx, 126, 4, 372))
            pygame.draw.line(S, esc(col, 1.3), (xx + 1, 126), (xx + 1, 498))
        pygame.draw.rect(S, esc(c.pedra, .8), (ix - 3, 118, 18, 12), 0, 2)
        pygame.draw.rect(S, esc(c.pedra, 1.2), (ix - 3, 118, 18, 3))
        pygame.draw.rect(S, esc(c.pedra, .8), (ix - 3, 490, 18, 12), 0, 2)
        pygame.draw.rect(S, esc(c.pedra, 1.2), (ix - 3, 490, 18, 3))
        # arco cego (arcatura) em cada baia lateral
        for (y0, y1) in ((150, 252), (368, 470)):
            cxm = x0 + 24
            pts = B.ogiva(cxm, y1, 30, 34, y1 - y0 - 34)
            pygame.draw.polygon(S, esc(c.pedra, .5), pts)
            pygame.draw.polygon(S, esc(c.pedra, 1.1), pts, 2)
            pygame.draw.polygon(S, esc(c.pedra, .3), B.ogiva(cxm, y1, 22, 26, y1 - y0 - 28), 1)
        # fiadas de rodape
        pygame.draw.rect(S, esc(c.pedra, .7), (x0, 492, 60, 10))


def _frente(c):
    S, rnd = c.S, c.rnd
    r = pygame.Rect(0, 500, W, 40)
    B.parede_pedra(S, r, esc(c.pedra, .78), rnd, bh=20, bw=58, var=6)
    S.blit(B.vgrad_a(W, 40, (0, 0, 0), 30, (0, 0, 0), 190), (0, 500))
    pygame.draw.rect(S, esc(c.pedra, 1.1), (0, 498, W, 4))
    pygame.draw.line(S, (20, 14, 10), (0, 502), (W, 502), 2)


def _molduras_portas(c):
    S = c.S
    ped = c.pedra
    # N: arco ogival sobre a porta, com colunetas
    cx = 480
    for (w, rise, col, lw) in ((118, 78, esc(ped, .55), 6), (112, 74, esc(ped, 1.18), 3), (100, 66, esc(ped, .4), 4)):
        pygame.draw.polygon(S, col, B.ogiva(cx, 124, w, rise, 14), lw)
    pygame.draw.polygon(S, esc(ped, .28), B.ogiva(cx, 124, 90, 60, 14))
    for sx in (-1, 1):
        for dx, cc in ((50, 1.2), (54, .9), (58, .7)):
            pygame.draw.rect(S, esc(ped, cc), (cx + sx * dx - 2, 70, 4, 54))
        pygame.draw.rect(S, esc(ped, .85), (cx + sx * 54 - 8, 64, 16, 8), 0, 2)
    # laterais W/E: arco ogival em pe
    for (x0, sg) in ((0, 1), (898, -1)):
        cxm = x0 + 31 + sg * -1 * 0
        pts = B.ogiva(cxm, 360, 76, 80, 24)
        pygame.draw.polygon(S, esc(ped, .3), pts)
        pygame.draw.polygon(S, esc(ped, 1.15), pts, 3)
        pygame.draw.polygon(S, esc(ped, .5), B.ogiva(cxm, 360, 64, 70, 24), 2)
    # S: soleira
    pygame.draw.rect(S, esc(ped, .3), (430, 498, 100, 42))
    pygame.draw.rect(S, esc(ped, 1.1), (430, 498, 100, 3))
    pygame.draw.rect(S, esc(ped, .5), (430, 498, 100, 42), 2)


# ----------------------------------------------------------------------- pisos
def _ladrilho_enc(S, x, y, s, base, alt, motivo, rnd):
    pygame.draw.rect(S, base, (x, y, s, s))
    if motivo == 0:
        pygame.draw.rect(S, alt, (x + 4, y + 4, s - 8, s - 8), 2)
        pygame.draw.circle(S, alt, (x + s // 2, y + s // 2), s // 4)
        pygame.draw.circle(S, base, (x + s // 2, y + s // 2), s // 6)
        B.cruz_latina(S, x + s // 2, y + s // 2, s // 3 + 4, alt, None, 3)
    elif motivo == 1:
        B.lis(S, x + s // 2, y + s // 2, s * .66, alt)
    elif motivo == 2:
        pygame.draw.circle(S, alt, (x + s // 2, y + s // 2), s // 2 - 5, 2)
        B.quadrifolio(S, x + s // 2, y + s // 2, s // 2 - 8, alt, 0)
    else:
        pygame.draw.polygon(S, alt, [(x + s // 2, y + 4), (x + s - 4, y + s // 2), (x + s // 2, y + s - 4), (x + 4, y + s // 2)], 2)
    pygame.draw.rect(S, esc(base, .55), (x, y, s, s), 1)
    pygame.draw.line(S, esc(base, 1.2), (x + 1, y + 1), (x + s - 2, y + 1))


def _piso(c):
    S, rnd = c.S, c.rnd
    kind = SPEC[c.tipo]["piso"]
    if c.andar == 0 and kind in ("xadrez", "enc"):
        kind = "lajes"                    # romanico: lajes de pedra lisas
    elif c.andar == 3 and kind in ("enc", "lajes"):
        kind = "xadrez"                   # barroco: marmore em xadrez
    cp = c.cpiso
    r = FL
    pygame.draw.rect(S, esc(cp, .6), r)
    S.set_clip(r)
    if kind == "enc":
        s = 40
        A = esc(cp, 1.0)
        Bc = esc(mix(cp, (60, 44, 34), .55), 1.0)
        C = mix(cp, (236, 216, 170), .5)
        for j in range(0, 10):
            for i in range(0, 21):
                x, y = r.x + i * s, r.y + j * s
                if y + s > r.bottom + 1:
                    h = r.bottom - y
                    if h <= 2:
                        continue
                par = (i + j) % 2
                base = A if par == 0 else Bc
                alt = C if par == 0 else mix(cp, (190, 160, 110), .4)
                borda = i in (0, 20) or j in (0, 9)
                _ladrilho_enc(S, x, y, s, esc(base, .8) if borda else base, alt, (i * 3 + j) % 4 if not borda else 3, rnd)
    elif kind == "xadrez":
        s = 42
        for j in range(0, 10):
            for i in range(0, 20):
                x, y = r.x + i * s, r.y + j * s
                col = esc(cp, 1.15) if (i + j) % 2 else esc(cp, .72)
                col = (col[0] + rnd.randint(-5, 5), col[1] + rnd.randint(-5, 5), col[2] + rnd.randint(-5, 5))
                pygame.draw.rect(S, col, (x, y, s, s))
                pygame.draw.rect(S, esc(col, .55), (x, y, s, s), 1)
                pygame.draw.line(S, esc(col, 1.2), (x + 1, y + 1), (x + s - 2, y + 1))
    elif kind in ("lajes", "cripta"):
        y = r.y
        row = 0
        hh = 52 if kind == "cripta" else 44
        while y < r.bottom:
            h = hh + rnd.randint(-6, 8)
            x = r.x - rnd.randint(0, 60)
            while x < r.right:
                w = rnd.randint(70, 150) if kind == "cripta" else rnd.randint(60, 120)
                t = rnd.randint(-12, 12)
                col = (max(0, min(255, cp[0] + t)), max(0, min(255, cp[1] + t)), max(0, min(255, cp[2] + t)))
                rr = pygame.Rect(x + 1, y + 1, w - 2, h - 2).clip(r)
                if rr.w > 2 and rr.h > 2:
                    pygame.draw.rect(S, col, rr, 0, 3)
                    pygame.draw.line(S, esc(col, 1.25), rr.topleft, (rr.right - 1, rr.y))
                    pygame.draw.line(S, esc(col, .6), (rr.x, rr.bottom - 1), (rr.right - 1, rr.bottom - 1))
                    if rnd.random() < .25:
                        px, py = rr.x + rnd.randint(4, max(5, rr.w - 8)), rr.y + rnd.randint(4, max(5, rr.h - 8))
                        pygame.draw.line(S, esc(col, .6), (px, py), (px + rnd.randint(-14, 14), py + rnd.randint(3, 14)))
                x += w
            y += h
            row += 1
    elif kind == "madeira":
        y = r.y
        tabuas = [(150, 100, 56), (140, 92, 50), (160, 108, 62), (132, 86, 48)]
        while y < r.bottom:
            h = 19
            x = r.x - rnd.randint(0, 120)
            while x < r.right:
                w = rnd.randint(120, 240)
                base = esc(mix(cp, rnd.choice(tabuas), .45), rnd.uniform(.88, 1.12))
                rr = pygame.Rect(x, y, w, h).clip(r)
                if rr.w > 1 and rr.h > 1:
                    pygame.draw.rect(S, base, rr)
                    for _ in range(3):
                        gy = rr.y + rnd.randint(2, h - 3)
                        pygame.draw.line(S, esc(base, .8), (rr.x, gy), (rr.right, gy))
                    pygame.draw.line(S, esc(base, 1.25), rr.topleft, (rr.right - 1, rr.y))
                    pygame.draw.line(S, esc(base, .5), (rr.x, rr.bottom - 1), (rr.right, rr.bottom - 1))
                    pygame.draw.line(S, esc(base, .45), (rr.x, rr.y), (rr.x, rr.bottom))
                    for nx in (rr.x + 5, rr.right - 6):
                        pygame.draw.circle(S, esc(base, .45), (nx, rr.y + h // 2), 1)
                x += w
            y += h
    elif kind == "claustro":
        # calcada de pedra em volta; jardim (relva) no meio com caminhos em cruz
        B.parede_pedra(S, r, esc(cp, 1.0), rnd, bh=36, bw=70, var=8)
        gr = pygame.Rect(150, 180, 660, 230)
        pygame.draw.rect(S, (60, 100, 46), gr, 0, 10)
        for _ in range(900):
            x, y = rnd.randint(gr.x + 4, gr.right - 5), rnd.randint(gr.y + 4, gr.bottom - 5)
            col = rnd.choice(((74, 128, 56), (50, 92, 40), (92, 148, 66), (66, 114, 50)))
            pygame.draw.line(S, col, (x, y), (x + rnd.randint(-2, 2), y - rnd.randint(2, 6)))
        pygame.draw.rect(S, esc(cp, .6), gr, 6, 10)
        pygame.draw.rect(S, esc(cp, 1.2), gr.inflate(-6, -6), 1, 8)
        # caminhos em cruz (terra batida)
        for rr in (pygame.Rect(150, 280, 660, 34), pygame.Rect(463, 180, 34, 230)):
            pygame.draw.rect(S, (176, 150, 108), rr)
            for _ in range(160):
                pygame.draw.circle(S, rnd.choice(((150, 124, 88), (200, 176, 130))), (rnd.randint(rr.x, rr.right), rnd.randint(rr.y, rr.bottom)), 1)
        # canteiros com flores
        for qx, qy in ((196, 206), (610, 206), (196, 330), (610, 330)):
            qr = pygame.Rect(qx, qy, 150, 60)
            pygame.draw.rect(S, (70, 56, 36), qr, 0, 8)
            for _ in range(26):
                fx, fy = rnd.randint(qr.x + 8, qr.right - 8), rnd.randint(qr.y + 8, qr.bottom - 8)
                pygame.draw.circle(S, (46, 110, 52), (fx, fy), 6)
                col = rnd.choice(((244, 241, 232), (240, 240, 230), (200, 40, 46), (236, 200, 80), (244, 241, 232)))
                pygame.draw.circle(S, col, (fx + rnd.randint(-2, 2), fy - rnd.randint(0, 3)), 3)
            pygame.draw.rect(S, esc(cp, 1.1), qr, 3, 8)
    S.set_clip(None)
    # oclusao ambiente: parede projeta sombra sobre o piso
    sh = surf(r.w, r.h)
    for i in range(46):
        a = int(150 * (1 - i / 46.0) ** 2)
        pygame.draw.line(sh, (0, 0, 0, a), (0, i), (r.w, i))
    for i in range(34):
        a = int(110 * (1 - i / 34.0) ** 2)
        pygame.draw.line(sh, (0, 0, 0, a), (i, 0), (i, r.h))
        pygame.draw.line(sh, (0, 0, 0, a), (r.w - 1 - i, 0), (r.w - 1 - i, r.h))
    for i in range(22):
        a = int(90 * (1 - i / 22.0) ** 2)
        pygame.draw.line(sh, (0, 0, 0, a), (0, r.h - 1 - i), (r.w, r.h - 1 - i))
    S.blit(sh, r.topleft)
    B.granulado(S, r, .8, c.seed + 5)


# ----------------------------------------------------------------------- luz
def _luz_mapa(c):
    S = c.S
    L = pygame.Surface((W, H))
    amb = esc(c.luz, c.amb)
    L.fill(amb)
    luz_add(L, (480, 330), 430, esc(c.luz, .5 * (1.0 - c.amb * .3)), pot=1.5)
    for (x, y, r, col, tipo, ph, k) in c.luzes:
        luz_add(L, (x, y), r, col if tipo != "fixa" else col, pot=1.7)
    for (pts, col, amax) in c.pools:
        pass
    S.blit(L, (0, 0), special_flags=pygame.BLEND_RGB_MULT)


def _vinheta(S, forca=1.0):
    S.blit(_vig(forca), (0, 0))


_VG = {}


def _vig(f):
    k = f
    if k not in _VG:
        s = surf(W, H)
        n = 90
        for i in range(n):
            a = int(185 * f * (1 - i / n) ** 2.3)
            pygame.draw.rect(s, (0, 0, 0, a), (i, i, W - 2 * i, H - 2 * i), 1)
        _VG[k] = conv(s)
    return _VG[k]


# ----------------------------------------------------------------------- pipeline
_CACHE = {}
_META = {}
_AND = [0]            # andar da sala desenhada por ultimo (as portas acompanham o estilo)


def fundo_sala(tipo, andar_idx=0, tamanho=(960, 540), seed=0):
    """Cenario estatico da sala (cache). 'tipo' pode ser um dos 16 estilos ou um tipo do jogo."""
    if tipo not in SPEC:
        tipo = estilo_sala(tipo, andar_idx)
    _AND[0] = andar_idx % 4
    k = (tipo, andar_idx % 4, tuple(tamanho), seed)
    s = _CACHE.get(k)
    if s is None:
        base = _CACHE.get((tipo, andar_idx % 4, (W, H), seed))
        if base is None:
            base = _construir(tipo, andar_idx % 4, seed)
            _CACHE[(tipo, andar_idx % 4, (W, H), seed)] = base
        s = base if tuple(tamanho) == (W, H) else conv(pygame.transform.smoothscale(base, tuple(tamanho)))
        _CACHE[k] = s
    return s


def _construir(tipo, andar, seed):
    old = B.set_estilo(andar)
    try:
        return _construir_est(tipo, andar, seed)
    finally:
        B.ESTILO[0] = old


def _construir_est(tipo, andar, seed):
    import arte_props as P
    c = Ctx(tipo, andar, seed)
    S = c.S
    S.fill((20, 14, 10))
    _parede_fundo(c)
    _decor_fundo(c)
    _laterais(c)
    _frente(c)
    _piso(c)
    _molduras_portas(c)
    _decor_frente(c)
    P.construir(c)                       # decoracao especifica do tipo (+ extras do andar)
    _luz_mapa(c)
    for fn in c.extra_post:
        fn(S)
    for (cx, by, w, h, tema, sd) in c.janelas:
        v = B.vitral(w, h, sd, tema)
        S.blit(v, (cx - v.get_width() // 2, by - h - 0))
        g = B.brilho(int(max(w, h) * .8), esc(mix((120, 120, 140), B.TEMAS[tema]["fundo"][0], .6), .45))
        S.blit(g, (cx - g.get_width() // 2, by - h // 2 - g.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
    gm = surf(W, H)
    gm.fill(GRADE[andar])
    S2 = pygame.Surface((W, H))
    S2.fill(GRADE[andar])
    S.blit(S2, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
    _vinheta(S, 1.0 if tipo != "cripta" else 1.25)
    _META[(tipo, andar, seed)] = dict(luzes=c.luzes, pools=_pools(c), glints=c.glints, pontos=c.pontos, luz=c.luz)
    return conv(S)


def _pools(c):
    out = []
    for (cx, by, w, h, tema, sd) in c.janelas:
        T = B.TEMAS[tema]["fundo"][0]
        col = mix(T, (255, 240, 200), .35)
        x0, x1 = cx - w // 2, cx + w // 2
        sh = 60 if cx < 480 else -60
        L = 190 + (h // 4)
        pts = [(x0, by), (x1, by), (x1 + sh + 40, by + L), (x0 + sh - 20, by + L)]
        s, o = B.feixe(pts, col, 54)
        out.append((s, o, c.rnd.uniform(0, 6.28)))
        # mancha no piso
    return out


# ----------------------------------------------------------------------- dinamica
def _chama(S, x, y, t, k, ph, big=False):
    f = 1 + math.sin(t * 15 + ph) * .13 + math.sin(t * 27 + ph * 2) * .08
    h = (13 if not big else 18) * f * k
    w = (4.5 if not big else 6.5) * k
    sway = math.sin(t * 6 + ph) * 1.4 * k
    pygame.draw.ellipse(S, (255, 150, 40), (x - w + sway * .5, y - h, 2 * w, h + 4))
    pygame.draw.ellipse(S, (255, 214, 110), (x - w * .62 + sway * .3, y - h * .78, w * 1.24, h * .8 + 2))
    pygame.draw.ellipse(S, (255, 252, 226), (x - w * .3, y - h * .42, w * .6, h * .45))


def desenhar_sala_dinamica(S, tipo, tempo, andar_idx=0, seed=0):
    """Camada leve por cima do cenario: chamas tremulas, feixes que oscilam, poeira, brilhos."""
    if tipo not in SPEC:
        tipo = estilo_sala(tipo, andar_idx)
    k = (tipo, andar_idx % 4, seed)
    if k not in _META:
        fundo_sala(tipo, andar_idx, seed=seed)
    m = _META[k]
    t = tempo
    for (s, o, ph) in m["pools"]:
        a = int(150 + 70 * math.sin(t * .7 + ph))
        s.set_alpha(a)
        S.blit(s, o)
    for (x, y, r, col, tp, ph, kk) in m["luzes"]:
        if tp == "fixa":
            continue
        fl = 1 + math.sin(t * 13 + ph) * .09 + math.sin(t * 7.3 + ph * 1.7) * .06
        luz_add(S, (x, y - 8), int(r * .8), esc(col, .55), fl)
        _chama(S, x, y, t, kk, ph, tp == "tocha")
    for (x, y, col, s, ph) in m["glints"]:
        a = max(0.0, math.sin(t * 2.2 + ph))
        if a > .25:
            q = int(s * a) + 1
            pygame.draw.line(S, esc(col, a), (x - q * 2, y), (x + q * 2, y))
            pygame.draw.line(S, esc(col, a), (x, y - q * 2), (x, y + q * 2))
            pygame.draw.circle(S, esc(col, a), (x, y), max(1, q // 2))
    # poeira em suspensao nos feixes (estateless)
    n = 22
    for i in range(n):
        rr = random.Random(i * 31 + 7)
        x0, y0 = rr.uniform(70, 890), rr.uniform(130, 490)
        sp = rr.uniform(4, 11)
        x = x0 + math.sin(t * .6 + i) * 18
        y = 490 - ((490 - y0 + t * sp) % 360)
        a = int(80 + 80 * math.sin(t * 1.6 + i * 2.1))
        c = m["luz"]
        pygame.draw.circle(S, (min(255, a + c[0] // 4), min(255, a + c[1] // 4), min(255, a)), (int(x), int(y)), 1)


def fundo_combate(tipo, andar_idx=0, boss=False, pos=(0, 0)):
    """Fundo do combate: o mesmo cenario da sala, desfocado e escurecido (cache)."""
    t = estilo_sala(tipo, andar_idx, pos)
    _AND[0] = andar_idx % 4
    k = ("cb", t, andar_idx % 4, boss)
    s = _CACHE.get(k)
    if s is None:
        base = fundo_sala(t, andar_idx)
        small = pygame.transform.smoothscale(base, (W // 4, H // 4))
        small = pygame.transform.smoothscale(small, (W // 8, H // 8))
        s = pygame.transform.smoothscale(small, (W, H))
        mixed = base.copy()
        s.set_alpha(185)
        mixed.blit(s, (0, 0))
        dk = pygame.Surface((W, H))
        dk.fill((130, 118, 124) if not boss else (150, 100, 100))
        mixed.blit(dk, (0, 0), special_flags=pygame.BLEND_RGB_MULT)
        mixed.blit(_vig(1.2), (0, 0))
        s = conv(mixed)
        _CACHE[k] = s
    return s


# ----------------------------------------------------------------------- portas
_PORTAS = {}


def _cadeado(S, cx, cy, s):
    pygame.draw.arc(S, (150, 150, 160), (cx - s * .3, cy - s * .62, s * .6, s * .8), 0, PI, max(3, int(s * .1)))
    pygame.draw.rect(S, (24, 20, 16), (cx - s * .4, cy - s * .08, s * .8, s * .62), 0, 3)
    pygame.draw.rect(S, (206, 170, 70), (cx - s * .36, cy - s * .04, s * .72, s * .54), 0, 3)
    pygame.draw.rect(S, (240, 210, 120), (cx - s * .36, cy - s * .04, s * .72, s * .16), 0, 3)
    pygame.draw.circle(S, (40, 28, 14), (cx, int(cy + s * .2)), max(2, int(s * .09)))
    pygame.draw.rect(S, (40, 28, 14), (cx - 1, cy + s * .2, 3, s * .15))


def _folhas(S, w, h, vertical, boss, locked, pts_clip=None):
    """Duas folhas de madeira com ferragens, dentro de (0,0,w,h)."""
    madeira = (96, 60, 34) if not boss else (110, 26, 30)
    ferro = (46, 44, 52)
    S.fill(madeira)
    for i in range(0, (w if vertical else h), 8):
        if vertical:
            pygame.draw.line(S, esc(madeira, .65), (i, 0), (i, h), 1)
            pygame.draw.line(S, esc(madeira, 1.2), (i + 1, 0), (i + 1, h), 1)
        else:
            pygame.draw.line(S, esc(madeira, .65), (0, i), (w, i), 1)
            pygame.draw.line(S, esc(madeira, 1.2), (0, i + 1), (w, i + 1), 1)
    if vertical:
        pygame.draw.line(S, (14, 8, 4), (w // 2, 0), (w // 2, h), 3)
        for y in (int(h * .3), int(h * .58), int(h * .84)):
            pygame.draw.rect(S, ferro, (0, y - 4, w, 8))
            pygame.draw.polygon(S, ferro, [(w // 2 - 4, y - 7), (w // 2 - 4, y + 7), (1, y + 3), (1, y - 3)])
            for x in range(8, w - 6, 14):
                pygame.draw.circle(S, (150, 150, 160) if not boss else (232, 196, 90), (x, y), 2)
        for sx in (-1, 1):
            pygame.draw.circle(S, ferro, (w // 2 + sx * 9, int(h * .56)), 6, 2)
    else:
        pygame.draw.line(S, (14, 8, 4), (0, h // 2), (w, h // 2), 3)
        for x in (int(w * .3), int(w * .58), int(w * .84)):
            pygame.draw.rect(S, ferro, (x - 4, 0, 8, h))
            for y in range(6, h - 4, 12):
                pygame.draw.circle(S, (150, 150, 160) if not boss else (232, 196, 90), (x, y), 2)


def _porta_surface(side, estado, special, andar=0):
    old = B.set_estilo(andar)
    try:
        return _porta_surface_est(side, estado, special, andar)
    finally:
        B.ESTILO[0] = old


def _porta_surface_est(side, estado, special, andar=0):
    boss = special == "chefe"
    r = door_rect(side)
    pad = 0
    w, h = r.size
    s = surf(w, h)
    vertical = side in ("N", "S")
    if side == "N":
        pts = B.ogiva(w / 2.0, h, 88, 62, 0)       # abertura (arco ogival), base no chao da parede
        pts = [(p[0], p[1]) for p in pts]
    elif side in ("W", "E"):
        pts = B.ogiva(w / 2.0, h, 56, 56, 32)
    else:
        pts = [(0, 0), (w, 0), (w - 6, h), (6, h)]
    msk = surf(w, h)
    pygame.draw.polygon(msk, (255, 255, 255, 255), pts)
    inner = surf(w, h)
    if estado == "aberta":
        # passagem: escuridao com degrade e luz fria/quente ao fundo
        g = B.vgrad(w, h, (6, 4, 10), (22, 16, 28)) if side != "S" else B.vgrad(w, h, (26, 20, 24), (4, 3, 6))
        inner.blit(g, (0, 0))
        gc = DOOR_GLOW.get(special)
        if gc:
            hh = B.halo_a(int(max(w, h) * .62), gc, 190, 1.4)
            inner.blit(hh, (w // 2 - hh.get_width() // 2, h // 2 - hh.get_height() // 2))
        # degraus de soleira
        for i in range(3):
            yy = h - 3 - i * 4 if side != "S" else 2 + i * 5
            pygame.draw.line(inner, (70, 62, 56) if i == 0 else (44, 40, 38), (0, yy), (w, yy), 2)
    else:
        _folhas(inner, w, h, vertical, boss, estado == "trancada")
    inner.blit(msk, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    s.blit(inner, (0, 0))
    # aro de pedra/ferro
    cor_aro = (150, 116, 56) if not boss else (232, 196, 90)
    if andar == 3:
        cor_aro = (232, 190, 80)
        pygame.draw.polygon(s, (20, 12, 6), pts, 7)
        pygame.draw.polygon(s, (170, 124, 36), pts, 5)
    elif andar == 0:
        cor_aro = (120, 100, 70)
        pygame.draw.polygon(s, (20, 12, 6), pts, 7)
    elif andar == 2:
        cor_aro = (170, 150, 220)
    pygame.draw.polygon(s, (20, 12, 6), pts, 5)
    pygame.draw.polygon(s, cor_aro, pts, 2)
    if boss and estado == "aberta":
        pass
    if estado == "trancada":
        _cadeado(s, w // 2, h // 2 + 2, min(w, h) * .62)
    if estado == "aberta" and special in DOOR_ICONE:
        try:
            from icones import desenhar_icone
            gc = DOOR_GLOW[special]
            desenhar_icone(s, DOOR_ICONE[special], (w // 2, h // 2), min(w, h) - 22, mix(gc, (255, 255, 255), .55))
        except Exception:
            pass
    if boss and estado != "aberta":
        # cranio/mitra: placa dourada
        try:
            from icones import desenhar_icone
            pygame.draw.circle(s, (20, 10, 4), (w // 2, h // 2 - 4), 13)
            pygame.draw.circle(s, (232, 196, 90), (w // 2, h // 2 - 4), 11, 2)
            desenhar_icone(s, "mitra", (w // 2, h // 2 - 4), 18, (255, 230, 150))
        except Exception:
            pass
    return conv(s)


DOOR_GLOW = {"chefe": (150, 30, 30), "tesouro": (170, 140, 40), "loja": (60, 130, 180), "cura": (60, 170, 100), "enigma": (120, 80, 170)}
DOOR_ICONE = {"chefe": "mitra", "tesouro": "bau", "loja": "livro", "cura": "cruz_latina", "enigma": "interrogacao"}


def draw_door(S, side, locked, special=None, estado=None, andar=None):
    """estado: 'aberta' | 'fechada' | 'trancada' (padrao: trancada se locked, senao aberta). A porta segue o estilo do andar
    (volta perfeita no 1, ogiva no 2, lanceta alta no 3, moldura barroca no 4)."""
    if estado is None:
        estado = "trancada" if locked else "aberta"
    an = _AND[0] if andar is None else andar % 4
    k = (side, estado, special if (estado == "aberta" or special == "chefe") else None, an)
    s = _PORTAS.get(k)
    if s is None:
        s = _PORTAS[k] = _porta_surface(side, estado, k[2], an)
    S.blit(s, door_rect(side).topleft)
    if special == "chefe":
        r = door_rect(side)
        # tochas grandes ladeando a porta do chefe (estaticas + brilho)
        luz_add(S, r.center, 60, (150, 30, 30), 1.0)

