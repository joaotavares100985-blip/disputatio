# -*- coding: utf-8 -*-
"""Sincronizacao do online (mesmo metodo do Firewall): o anfitriao manda o ESTADO do jogo (poucos KB) e o convidado
DESENHA na propria tela. Aqui ficam: fotografar o estado (host), remontar as cenas (convidado) e a lista de eventos
(sons, particulas e numeros que saltam)."""
import json
import time
import zlib

import pygame

import audio
import conteudo as C
import estado as E
from desenho import W, H, Particulas, Flutuantes

_NAO = object()
# atributos que nao viajam: funcoes, superficies e coisas que cada aparelho recria
PULAR = {"game", "run", "hits", "lists", "lst", "dl", "parts", "fl", "bg", "stage", "q", "cb", "pid", "pressed", "dpos",
         "target_fn", "foco_extra", "dust", "dados_codex", "cards", "sw", "joy", "joy_o", "joyvec", "wait", "pend"}


# ------------------------------------------------------------------ conteudo fixo (vai so o numero)
def _indexar():
    lista, ids = [], {}

    def anda(v):
        if isinstance(v, dict):
            if id(v) in ids:
                return
            ids[id(v)] = len(lista)
            lista.append(v)
            for x in v.values():
                anda(x)
        elif isinstance(v, (list, tuple)):
            for x in v:
                anda(x)

    for nome in sorted(n for n in vars(C) if n.isupper()):
        anda(getattr(C, nome))
    return lista, ids


_CONTEUDO, _CONTEUDO_ID = _indexar()


# ------------------------------------------------------------------ codificar (anfitriao)
class Codificador:
    def __init__(self, run):
        self.memo = {}                    # id(lista/dict) -> numero (preserva "e o mesmo objeto" do outro lado)
        self.herois = {id(h): i for i, h in enumerate(run.herois)} if run else {}

    def enc(self, v, prof=0):
        if v is None or isinstance(v, (bool, int, str)):
            return v
        if isinstance(v, float):
            return round(v, 2)
        if isinstance(v, E.Jogador):
            i = self.herois.get(id(v))
            return {"~J": i} if i is not None else _NAO
        if isinstance(v, pygame.Rect):
            return {"~r": [v.x, v.y, v.w, v.h]}
        if prof > 7:
            return _NAO
        if isinstance(v, tuple):
            return {"~t": [self._item(x, prof) for x in v]}
        if isinstance(v, (set, frozenset)):
            return {"~s": [self._item(x, prof) for x in v]}
        if isinstance(v, (list, dict)):
            if isinstance(v, dict):
                c = _CONTEUDO_ID.get(id(v))
                if c is not None:
                    return {"~C": c}
            n = self.memo.get(id(v))
            if n is not None:
                return {"~@": n}
            self.memo[id(v)] = len(self.memo)
            if isinstance(v, list):
                return [self._item(x, prof) for x in v]
            return {"~d": [[self._item(k, prof), self._item(x, prof)] for k, x in v.items()]}
        return _NAO                       # funcoes, superficies etc.

    def _item(self, x, prof):
        r = self.enc(x, prof + 1)
        return None if r is _NAO else r

    def attrs(self, obj):
        out = []
        for k, v in vars(obj).items():
            if k in PULAR or (k.startswith("_") and k != "_st_t"):
                continue
            if k == "dados" and type(obj).__name__ == "Codex":
                continue                  # o Codex remonta do conteudo
            r = self.enc(v)
            if r is not _NAO:
                out.append([k, r])
        return out


class Decodificador:
    def __init__(self, herois):
        self.memo = []
        self.herois = herois

    def dec(self, v):
        if isinstance(v, list):
            out = []
            self.memo.append(out)
            for x in v:
                out.append(self.dec(x))
            return out
        if not isinstance(v, dict):
            return v
        if "~d" in v:
            out = {}
            self.memo.append(out)
            for k, x in v["~d"]:
                kk = self.dec(k)
                out[kk] = self.dec(x)
            return out
        if "~t" in v:
            return tuple(self.dec(x) for x in v["~t"])
        if "~s" in v:
            return set(self.dec(x) for x in v["~s"])
        if "~C" in v:
            return _CONTEUDO[v["~C"]]
        if "~@" in v:
            return self.memo[v["~@"]]
        if "~J" in v:
            return self.herois[v["~J"]]
        if "~r" in v:
            return pygame.Rect(v["~r"])
        return v


# ------------------------------------------------------------------ eventos (sons, particulas, numeros)
class Eventos:
    """O anfitriao grava; cada foto leva os eventos dos ultimos instantes (se uma foto se perder, a proxima repete)."""

    def __init__(self):
        self.l = []                       # (seq, quando, alvo, tipo, args)
        self.seq = 0
        self.ativo = False

    def grava(self, alvo, tipo, args):
        if self.ativo:
            self.seq += 1
            self.l.append((self.seq, time.time(), alvo, tipo, args))
            if len(self.l) > 120:
                del self.l[:-120]


EVENTOS = Eventos()


def _instalar_ganchos():
    burst, add, sfx = Particulas.burst, Flutuantes.add, audio.sfx

    def burst_(self, *a, **k):
        EVENTOS.grava(self, "p", (a, k))
        return burst(self, *a, **k)

    def add_(self, *a, **k):
        EVENTOS.grava(self, "f", (a, k))
        return add(self, *a, **k)

    def sfx_(nome):
        EVENTOS.grava(None, "s", (nome,))
        return sfx(nome)

    Particulas.burst, Flutuantes.add, audio.sfx = burst_, add_, sfx_


_instalar_ganchos()


# ------------------------------------------------------------------ foto (anfitriao)
_uid = [0]


def _uid_de(cena):
    u = getattr(cena, "_uid", None)
    if u is None:
        _uid[0] += 1
        u = cena._uid = _uid[0]
    return u


def visiveis(game):
    if not game.stack:
        return []
    i = len(game.stack) - 1
    while i > 0 and not game.stack[i].opaque:
        i -= 1
    return game.stack[i:]


def _enc_run(cod, run):
    if run is None:
        return None
    a = run.andar
    return dict(herois=[cod.attrs(h) for h in run.herois], foco=run.foco, andar_i=run.andar_i,
                stats=cod.enc(run.stats), pos=cod.enc(run.pos), n=len(run.herois),
                andar=dict(idx=a.idx, boss=cod.enc(a.boss), inicio=cod.enc(a.inicio), dados=cod.enc(a.dados),
                           salas=[cod.attrs(s) for s in a.salas.values()]))


def foto(game, n):
    cod = Codificador(game.run)
    pk = dict(n=n, run=_enc_run(cod, game.run))
    cenas = []
    donos = {}
    for sc in visiveis(game):
        u = _uid_de(sc)
        d = dict(c=type(sc).__name__, u=u, a=cod.attrs(sc))
        if getattr(sc, "parts", None) is not None:
            donos[id(sc.parts)] = (u, "parts")
        if getattr(sc, "fl", None) is not None:
            donos[id(sc.fl)] = (u, "fl")
        off = [round(l.off, 1) for l in sc.lists if hasattr(l, "off")]
        if off:
            d["off"] = off
        cenas.append(d)
    pk["cenas"] = cenas
    agora = time.time()
    evs = []
    for seq, quando, alvo, tipo, args in EVENTOS.l:
        if agora - quando > 0.7:
            continue
        if alvo is None:
            evs.append([seq, tipo, None, Codificador(None).enc(args)])       # cada evento se le sozinho
        elif id(alvo) in donos:
            evs.append([seq, tipo, donos[id(alvo)][0], Codificador(None).enc(args)])
    pk["ev"] = evs
    tr = game.tr
    pk["tr"] = [round(tr["t"], 3), tr["kind"]] if tr else None
    pk["toasts"] = [[round(t["t"], 2), t["texto"], t["icone"]] for t in game.toasts[:1]]
    pk["mus"] = [audio._pedido, audio._pedido_loop]
    pk["st"] = game.estado_terminal()
    return zlib.compress(json.dumps(pk, separators=(",", ":")).encode(), 6)


# ------------------------------------------------------------------ espelho (convidado)
class JogoEspelho:
    """O `game` que as cenas do convidado enxergam: a partida e a copia recebida; o resto e o jogo local."""

    def __init__(self, game):
        self._real = game
        self.run = None

    def __getattr__(self, nome):
        return getattr(self._real, nome)


def _classes():
    import ui
    from mundo import Mundo
    from combate import Combate
    d = {n: getattr(ui, n) for n in ("Titulo", "Tutorial", "Codex", "Cartao", "Dialogo", "Pausa", "Inventario",
                                     "Pergunta", "CartaoAndar", "GameOver", "Vitoria")}
    d.update(Mundo=Mundo, Combate=Combate)
    return d


class Espelho:
    def __init__(self, game):
        self.jogo = JogoEspelho(game)
        self.cls = _classes()
        self.cenas = []                   # cenas visiveis, de baixo pra cima
        self.por_uid = {}
        self.ult_ev = -1
        self.ult_n = -1
        self.st = {"ex": False, "a": None}
        self.tr = None

    @property
    def topo(self):
        return self.cenas[-1] if self.cenas else None

    def _run(self, dec_memo, d):
        """remonta a partida (os objetos Run/Jogador/Andar/Sala locais sao reaproveitados)"""
        if d is None:
            return None
        run = self.jogo.run
        if run is None:
            run = E.Run.__new__(E.Run)
            run.herois, run.andar, run.usadas, run.rng = [], None, set(), None
            self.jogo.run = run
        while len(run.herois) < d["n"]:
            run.herois.append(E.Jogador.__new__(E.Jogador))
        del run.herois[d["n"]:]
        dec_memo.herois = run.herois
        for h, attrs in zip(run.herois, d["herois"]):
            for k, v in attrs:
                setattr(h, k, dec_memo.dec(v))
        run.foco, run.andar_i = d["foco"], d["andar_i"]
        run.stats = dec_memo.dec(d["stats"])
        run.pos = dec_memo.dec(d["pos"])
        da = d["andar"]
        a = E.Andar.__new__(E.Andar)
        a.idx = da["idx"]
        a.boss, a.inicio = dec_memo.dec(da["boss"]), dec_memo.dec(da["inicio"])
        a.dados = dec_memo.dec(da["dados"])
        a.salas = {}
        for attrs in da["salas"]:
            s = E.Sala.__new__(E.Sala)
            for k, v in attrs:
                setattr(s, k, dec_memo.dec(v))
            a.salas[s.pos] = s
        run.andar = a
        return run

    def _nova(self, nome):
        from ui import Cena
        cls = self.cls[nome]
        sc = cls.__new__(cls)
        Cena.__init__(sc, self.jogo)
        sc.convidado = True
        return sc

    def aplica(self, bruto):
        """aplica uma foto; devolve False se for velha"""
        pk = json.loads(zlib.decompress(bruto))
        if pk["n"] <= self.ult_n:
            return False
        self.ult_n = pk["n"]
        dec = Decodificador([])
        run = self._run(dec, pk["run"])
        cenas, usados = [], {}
        for d in pk["cenas"]:
            nome, u = d["c"], d["u"]
            if nome not in self.cls:
                for _k, v in d["a"]:
                    dec.dec(v)            # le mesmo assim: a numeracao das listas segue a ordem
                continue
            sc = self.por_uid.get(u)
            nova = sc is None
            if nova:
                sc = self._nova(nome)
            antes = {} if nova else dict(vars(sc))
            for k, v in d["a"]:
                setattr(sc, k, dec.dec(v))
            sc.run = run
            sc.game = self.jogo
            if nome == "Mundo":
                sc.reconciliar(antes, nova)
            elif nome == "Combate":
                sc.reconciliar(antes, nova)
            else:
                if not nova and abs(antes.get("t", 0) - sc.t) < 0.25:
                    sc.t = antes["t"]
                self._preparar(sc, nome, nova, antes)
            if "off" in d:
                for lista, off in zip(sc.lists, d["off"]):
                    lista.off = off
            cenas.append(sc)
            usados[u] = sc
        self.cenas, self.por_uid = cenas, usados
        primeira = self.ult_ev < 0
        for seq, tipo, u, args in pk["ev"]:
            if seq <= self.ult_ev:
                continue
            self.ult_ev = seq
            if primeira:
                continue
            ad = Decodificador(run.herois if run else [])
            args = ad.dec(args)
            if tipo == "s":
                audio.sfx(args[0])
                continue
            sc = usados.get(u)
            alvo = getattr(sc, "parts" if tipo == "p" else "fl", None) if sc else None
            if alvo is not None:
                a, k = args
                (alvo.burst if tipo == "p" else alvo.add)(*a, **k)
        self.ult_ev = max(self.ult_ev, 0)
        self.tr = pk["tr"]
        real = self.jogo._real
        novos = [dict(t=t, texto=x, icone=i) for t, x, i in pk["toasts"]]
        if not (novos and real.toasts and real.toasts[0]["texto"] == novos[0]["texto"]):
            real.toasts = novos
        mus, loop = pk["mus"]
        if audio._pedido != mus:
            audio.musica(mus, loop)
        self.st = pk["st"]
        return True

    def _preparar(self, sc, nome, nova, antes):
        """recria o que nao viaja (listas rolaveis, particulas)"""
        if nome in ("GameOver", "Vitoria"):
            if nova:
                sc.parts = Particulas(40 if nome == "GameOver" else 150)
        elif nome == "Codex":
            if nova or antes.get("aba") != sc.aba or bool(antes.get("det")) != bool(sc.det):
                det = sc.det
                sc.dados = [sc._simbolos(), sc._glossario(), sc._bios()]
                sc.mk_lists()
                if det:
                    from ui import GradeRolavel
                    sc.det = det
                    sc.dl = GradeRolavel((100, 214, 780, 244), len(det[1]), 1, 32, 0, sc.item_det)
                    sc.lists = [sc.dl]
        elif nome == "Inventario":
            sc.mk()
        elif nome == "Tutorial":
            if nova:
                from ui import cartoes_tutorial
                sc.cards = cartoes_tutorial()
                sc.sw = None

    def avancar(self, dt, direc):
        """entre duas fotos o convidado continua animando sozinho (e o proprio heroi anda na hora)"""
        for sc in self.cenas:
            nome = type(sc).__name__
            if nome == "Mundo":
                sc.animar_convidado(dt, direc, self.st.get("ex") and sc is self.topo)
            elif nome == "Combate":
                sc.animar(dt)
            elif nome == "Dialogo":
                sc.t += dt
                sc.typed = min(sc.total, sc.typed + dt * 80)
            else:
                sc.t += dt
                if getattr(sc, "parts", None) is not None:
                    sc.parts.update(dt)
        if self.tr:
            self.tr[0] += dt / 0.6
            if self.tr[0] >= 1:
                self.tr = None

    def desenhar(self, S):
        for sc in self.cenas:
            sc.draw(S)

    def desenhar_transicao(self, S):
        if not self.tr:
            return
        k, tipo = self.tr
        a = 1 - abs(2 * min(1.0, k) - 1)
        ov = pygame.Surface((W, H))
        ov.fill((250, 244, 220) if tipo == "flash" else (8, 4, 2))
        ov.set_alpha(int(255 * min(1, a * (1.8 if tipo == "flash" else 1.7))))
        S.blit(ov, (0, 0))
