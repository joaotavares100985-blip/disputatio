# -*- coding: utf-8 -*-
"""Exploracao (960x540): sala em tela cheia, HUD compacto, joystick virtual, botao INTERAGIR (A), minimapa."""
import math
import random

import pygame

import audio
import estado as E
import arte_salas
from desenho import *
from textos import curto_txt
from ui import (Cena, Cartao, Dialogo, Pergunta, Pausa, Inventario, Codex, clamp, barra_icone, desenhar_item, desenhar_dica, mais_item,
                BARRA_HP, BARRA_TINTA)
import ui_extra as X

NOMES_SALA = {"inicio": "Salão de Entrada", "combate": "Sala de Disputa", "tesouro": "Sala do Tesouro",
              "loja": "Livraria", "cura": "Enfermaria", "enigma": "Sed Contra", "chefe": "Sala do Mestre"}
MINI_COR = {"inicio": (200, 200, 200), "combate": (168, 120, 70), "tesouro": (240, 200, 60), "loja": (80, 160, 220),
            "cura": (90, 200, 120), "enigma": (180, 110, 230), "chefe": (220, 60, 60)}
DICAS = {
    "sala": "Joystick para andar, botão A para interagir.",
    "tesouro": "Um tesouro! Leve só um.",
    "loja": "Livraria: gaste seus florins.",
    "cura": "O altar cura Ânimo e Tinta, uma vez.",
    "enigma": "Responda ao enigma para ganhar florins.",
    "chefe": "Cuidado: um grande mestre!",
}
BTN_A = (872, 442)
R_A = 56
BTN_FICHA = (768, 486)
BTN_PAUSA = (790, 38)
JOY_R = 66


class Mundo(Cena):
    coop_livre = True      # coop: os dois herois andam ao mesmo tempo (entradas separadas)

    def __init__(self, game):
        super().__init__(game)
        self.run = game.run
        self.p2 = [520.0, 440.0]     # heroi 2 (coop)
        self.face2 = "S"
        self.moving2 = False
        self.alvo2 = None
        self.parts = Particulas()
        self.fl = Flutuantes()
        self.p = [480.0, 440.0]
        self.face = "S"
        self.moving = False
        self.joy = None
        self.joy_o = (150, 430)
        self.joyvec = (0.0, 0.0)
        self.ents = []
        self.objs = []
        self.locked = False
        self.busy = False
        self.grace = 0.0
        self.titulo_t = 0.0
        self.dica = None
        self.pend = None
        self.alvo = None
        self.lock_t = 0.0
        self.a_t = 0.0
        self.moveu = False
        self.dust = [[random.uniform(70, 890), random.uniform(130, 490), random.uniform(4, 10), random.uniform(.5, 2)] for _ in range(18)]
        self.enter_room(self.run.pos, None, first=True)

    # ---------------------------------------------------------- salas
    @property
    def sala(self):
        return self.run.sala()

    @property
    def coop(self):
        return len(self.run.herois) > 1

    def _ps(self):
        return [self.p, self.p2] if self.coop else [self.p]

    def icone_a2(self):
        a = self.alvo2
        if not a:
            return None
        if a["k"] == "ent":
            return "mitra" if a["e"]["boss"] else "duelo"
        return a["icone"]

    def acao_p2(self, a):
        """botoes do convidado (heroi 2)"""
        if a == "ok":
            self.a_t = 0.18
            self.apertar_a(1)
        elif a == "ficha":
            self.run.foco = 1
            self.game.push(Inventario(self.game))
        elif a == "codex":
            self.run.foco = 1
            self.game.push(Codex(self.game))

    def enter_room(self, pos, moved, first=False):
        run = self.run
        run.pos = pos
        s = self.sala
        if not s.visitada:
            s.visitada = True
            run.stats["salas"] += 1
        for nb in s.portas.values():
            run.andar.salas[nb].vista = True
        if moved:
            cx, cy = DOOR_C[E.OPOSTO[moved]]
            dx, dy = E.DIRS[moved]
            self.p = [cx + dx * 50, cy + dy * 50]
            self.face = moved
        else:
            self.p = [480.0, 440.0]
        self.p2 = [self.p[0] + (34 if moved in (None, "N", "S") else 0), self.p[1] + (34 if moved in ("W", "E") else 0)]
        self.face2 = self.face
        self.alvo2 = None
        self.entry = tuple(self.p)
        self.ents, self.objs = [], []
        self.grace = 1.3
        self.titulo_t = 2.4
        self.joy = None
        self.joyvec = (0.0, 0.0)
        self.busy = False
        self.alvo = None
        self.estilo = arte_salas.estilo_sala(s.tipo, run.andar_i, run.pos)
        t = s.tipo
        if t in ("combate", "chefe") and not s.limpa:
            self.spawn_inimigos(s)
        if t == "chefe" and s.limpa and s.stairs:
            self.objs.append(dict(kind="stairs", x=480, y=250, r=34))
        if t in ("tesouro", "loja") and not (t == "tesouro" and s.usada):
            for it, (x, y) in zip(s.itens, self.ped_pos(len(s.itens), t)):
                if not it["pego"]:
                    self.objs.append(dict(kind="ped", x=x, y=y, r=26, it=it))
        if t == "loja":
            self.objs.append(dict(kind="npc", x=480, y=232, r=34, npc="livreiro"))
        if t == "cura":
            self.objs.append(dict(kind="altar", x=480, y=300, r=44))
            self.objs.append(dict(kind="npc", x=650, y=270, r=30, npc="monge_enfermeiro"))
        if t == "enigma" and not s.usada and s.pergunta is not None:
            self.objs.append(dict(kind="enigma", x=480, y=300, r=40))
        self.locked = bool(self.ents)
        if t == "chefe" and not s.limpa:
            self.grace = 0.8
        self.dica_sala(t, first)

    def ped_pos(self, n, tipo):
        y = 370 if tipo == "loja" else 330
        return [(480 + (i - (n - 1) / 2.0) * 150, y + (30 if (tipo == "tesouro" and n == 3 and i == 1) else 0)) for i in range(n)]

    def spawn_inimigos(self, s):
        for iid in s.inimigos:
            d = E.CHEFES.get(iid) or E.INIM.get(iid)
            if not d:
                continue
            boss = iid in E.CHEFES
            x, y = 480, 300
            for _ in range(40):
                x, y = random.uniform(140, 820), random.uniform(220, 440)
                if math.hypot(x - self.p[0], y - self.p[1]) > 230:
                    break
            if boss:
                x, y = 480, 300
            a = random.uniform(0, math.tau)
            sp = 0 if boss else random.uniform(22, 40)
            self.ents.append(dict(id=iid, d=d, boss=boss, x=x, y=y, vx=math.cos(a) * sp, vy=math.sin(a) * sp, tmr=random.uniform(1, 3),
                                  ph=random.uniform(0, 6), h=215 if boss else 130))

    def dica_sala(self, t, first):
        g = self.game
        chaves = []
        if first:
            chaves.append("sala")
        if t in DICAS and t != "sala":
            chaves.append(t)
        for k in chaves:
            if k not in g.seen:
                g.seen.add(k)
                self.dica = [g.inp.dica_interagir() if k == "sala" else DICAS[k], 0.0]
                break

    def musica(self):
        audio.musica("andar%d" % min(self.run.andar_i, 3))

    def enter(self):
        self.musica()

    def resume(self):
        super().resume()
        self.joy = None
        self.joyvec = (0.0, 0.0)
        self.musica()

    def desenhar_foco(self, S, t):
        pass

    def acao(self, a):
        """Controle/teclado na exploracao: andar e continuo (teclas_dir); aqui so botoes."""
        if a == "ok":
            self.key(pygame.K_RETURN)
        elif a == "back" or a == "menu":
            self.key(pygame.K_ESCAPE)
        elif a == "ficha":
            self.game.push(Inventario(self.game))
        elif a == "codex":
            self.game.push(Codex(self.game))

    # ----------------------------------------------------------- entrada
    def down(self, i, pos):
        if self.busy:
            return
        if math.hypot(pos[0] - BTN_A[0], pos[1] - BTN_A[1]) < R_A + 10:
            self.a_t = 0.18
            self.apertar_a()
            return
        near_btn = any(math.hypot(pos[0] - c[0], pos[1] - c[1]) < 44 for c in (BTN_FICHA, BTN_PAUSA))
        if (not near_btn) and pos[0] < 560 and pos[1] > 90 and self.joy is None:
            self.joy = i
            self.joy_o = (clamp(pos[0], 80, 480), clamp(pos[1], 190, 480))
            self.set_joy(pos)
            return
        super().down(i, pos)

    def move(self, i, pos):
        if i == self.joy:
            self.set_joy(pos)
            return
        super().move(i, pos)

    def up(self, i, pos):
        if i == self.joy:
            self.joy = None
            self.joyvec = (0.0, 0.0)
            return
        super().up(i, pos)

    def set_joy(self, pos):
        dx, dy = (pos[0] - self.joy_o[0]) / 60.0, (pos[1] - self.joy_o[1]) / 60.0
        n = math.hypot(dx, dy)
        if n > 1:
            dx, dy = dx / n, dy / n
        self.joyvec = (dx, dy) if n > 0.16 else (0.0, 0.0)

    def key(self, k):
        if k in (pygame.K_ESCAPE, pygame.K_p):
            self.game.push(Pausa(self.game))
        elif k in (pygame.K_i, pygame.K_TAB):
            self.game.push(Inventario(self.game))
        elif k == pygame.K_c:
            self.game.push(Codex(self.game))
        elif k in (pygame.K_e, pygame.K_SPACE, pygame.K_RETURN):
            self.a_t = 0.18
            self.apertar_a()

    # ----------------------------------------------------------- fisica
    def walkable(self, x, y):
        R = 14
        if FL.left + R <= x <= FL.right - R and FL.top + R <= y <= FL.bottom - R:
            return True
        if self.locked:
            return False
        por = self.sala.portas
        for side, (cx, cy) in DOOR_C.items():
            if side not in por:
                continue
            if side == "N" and abs(x - cx) <= DOOR_HW - 10 and FL.top - 50 <= y <= FL.top + R:
                return True
            if side == "S" and abs(x - cx) <= DOOR_HW - 10 and FL.bottom - R <= y <= FL.bottom + 50:
                return True
            if side == "W" and abs(y - cy) <= DOOR_HW - 10 and FL.left - 50 <= x <= FL.left + R:
                return True
            if side == "E" and abs(y - cy) <= DOOR_HW - 10 and FL.right - R <= x <= FL.right + 50:
                return True
        return False

    def achar_alvo(self, pp=None):
        px, py = pp or self.p
        best, bd = None, 1e9
        for o in self.objs:
            d = math.hypot(o["x"] - px, o["y"] - py) - o["r"]
            if d < 46 and d < bd:
                best, bd = dict(k="obj", o=o, x=o["x"], y=o["y"] - 70, icone=self.icone_obj(o)), d
        if self.grace <= 0:
            for e in self.ents:
                rr = 60 if e["boss"] else 30
                d = math.hypot(e["x"] - px, e["y"] - py) - rr
                if d < 50 and d < bd:
                    best, bd = dict(k="ent", e=e, x=e["x"], y=e["y"] - e["h"] - 8, icone="mitra" if e["boss"] else "duelo"), d
        for side, (cx, cy) in DOOR_C.items():
            if side in self.sala.portas:
                d = math.hypot(px - cx, py - cy) - 20
                if d < 56 and d < bd:
                    ix, iy = cx - E.DIRS[side][0] * 62, cy - E.DIRS[side][1] * 62
                    best, bd = dict(k="door", side=side, locked=self.locked, x=ix, y=iy - 30,
                                    icone="cadeado" if self.locked else "porta"), d
        return best

    def icone_obj(self, o):
        k = o["kind"]
        if k == "ped":
            return "bau" if self.sala.tipo == "tesouro" else "florim"
        if k == "npc":
            return "livro" if o["npc"] == "livreiro" else "pessoa"
        return {"altar": "coracao_flamejante", "enigma": "pergaminho", "stairs": "escada"}.get(k, "mao")

    def apertar_a(self, quem=0):
        if self.busy:
            return
        a = self.alvo if quem == 0 else self.alvo2
        pq = self.p if quem == 0 else self.p2
        if not a:
            self.fl.add("?", pq[0], pq[1] - 110, (230, 220, 180))
            return
        if a["k"] == "obj":
            self.interagir(a["o"], quem)
        elif a["k"] == "ent":
            self.iniciar_combate()
        elif a["k"] == "door":
            if a["locked"]:
                self.lock_t = 0.5
                audio.sfx("erro")
                self.fl.add("Trancada!", pq[0], pq[1] - 110, (255, 140, 120))
            else:
                self.passar(a["side"])

    def update(self, dt):
        self.t += dt
        if self.dica:
            self.dica[1] += dt
            if self.dica[1] > 4.5:
                self.dica = None
        self.a_t = max(0, self.a_t - dt)
        self.lock_t = max(0, self.lock_t - dt)
        self.run.foco = 0
        if self.busy:
            self.parts.update(dt)
            return
        self.titulo_t = max(0, self.titulo_t - dt)
        self.grace = max(0, self.grace - dt)
        kx, ky = self.game.inp.teclas_dir()
        vx, vy = self.joyvec[0] + kx, self.joyvec[1] + ky
        n = math.hypot(vx, vy)
        if n > 1:
            vx, vy = vx / n, vy / n
        self.moving = n > 0.1
        if self.moving:
            self.moveu = True
            self.passo_t = getattr(self, "passo_t", 0.0) - dt
            if self.passo_t <= 0:
                self.passo_t = 0.36
                audio.sfx("passo")
            sp = 190
            nx, ny = self.p[0] + vx * sp * dt, self.p[1] + vy * sp * dt
            if self.walkable(nx, ny):
                self.p = [nx, ny]
            elif self.walkable(nx, self.p[1]):
                self.p[0] = nx
            elif self.walkable(self.p[0], ny):
                self.p[1] = ny
            if abs(vx) > abs(vy):
                self.face = "E" if vx > 0 else "W"
            else:
                self.face = "S" if vy > 0 else "N"
        for o in self.objs:
            dx, dy = self.p[0] - o["x"], self.p[1] - o["y"]
            d = math.hypot(dx, dy)
            lim = o["r"] + 14
            if 0 < d < lim and o["kind"] != "stairs":
                self.p[0] = o["x"] + dx / d * lim
                self.p[1] = o["y"] + dy / d * lim
                if not self.walkable(*self.p):
                    self.p = [clamp(self.p[0], FL.left + 14, FL.right - 14), clamp(self.p[1], FL.top + 14, FL.bottom - 14)]
        if self.coop:
            self.mover2(dt)
        for e in self.ents:
            e["tmr"] -= dt
            if e["tmr"] <= 0 and not e["boss"]:
                a = random.uniform(0, math.tau)
                sp = random.uniform(20, 42)
                e["vx"], e["vy"] = math.cos(a) * sp, math.sin(a) * sp
                e["tmr"] = random.uniform(1.2, 3)
            e["x"] += e["vx"] * dt
            e["y"] += e["vy"] * dt
            if e["x"] < FL.left + 60 or e["x"] > FL.right - 60:
                e["vx"] *= -1
                e["x"] = clamp(e["x"], FL.left + 60, FL.right - 60)
            if e["y"] < FL.top + 110 or e["y"] > FL.bottom - 24:
                e["vy"] *= -1
                e["y"] = clamp(e["y"], FL.top + 110, FL.bottom - 24)
            rr = 62 if e["boss"] else 30
            if self.grace <= 0 and any(math.hypot(e["x"] - q[0], e["y"] - q[1]) < rr + 10 for q in self._ps()):
                self.iniciar_combate()
                return
        for side, (cx, cy) in DOOR_C.items():
            if side in self.sala.portas and not self.locked:
                for px, py in self._ps():
                    if (side == "N" and py < FL.top - 8) or (side == "S" and py > FL.bottom + 8) or \
                            (side == "W" and px < FL.left - 8) or (side == "E" and px > FL.right + 8):
                        self.passar(side)
                        return
        self.alvo = self.achar_alvo()
        self.alvo2 = self.achar_alvo(self.p2) if self.coop else None
        self.parts.update(dt)
        self.fl.update(dt)
        for d in self.dust:
            d[1] -= d[2] * dt
            d[0] += math.sin(self.t + d[3]) * 5 * dt
            if d[1] < FL.top:
                d[1] = FL.bottom
                d[0] = random.uniform(FL.left, FL.right)

    # ----------------------------------------------------------- online (convidado)
    convidado = False
    g_joy = None              # joystick do convidado na tela dele: (origem, vetor)
    g_a_t = 0.0

    def reconciliar(self, antes, nova):
        """chegou uma foto do anfitriao: o resto segue suave ate a posicao dele; o heroi do convidado ja andou na hora e
        so e corrigido se passar da folga do atraso."""
        alvo_p, alvo_p2 = list(self.p), list(self.p2)
        alvo_ents = [(e["x"], e["y"]) for e in self.ents]
        mesma_sala = not nova and antes.get("_sala_vista") == (self.run.andar_i, self.run.pos)
        self._sala_vista = (self.run.andar_i, self.run.pos)
        if nova:
            self.parts = Particulas()
            self.fl = Flutuantes()
            self.joy = None
            self.joyvec = (0.0, 0.0)
            self.dust = [[random.uniform(70, 890), random.uniform(130, 490), random.uniform(4, 10), random.uniform(.5, 2)]
                         for _ in range(18)]
            self._parado = 9.0
        elif abs(antes.get("t", 0) - self.t) < 0.25:
            self.t = antes["t"]
        if self.alvo and "o" in self.alvo:        # religa o balao ao objeto certo da lista nova
            self.alvo["o"] = next((o for o in self.objs if o is self.alvo["o"] or
                                   (o["kind"], o["x"], o["y"]) == (self.alvo["o"]["kind"], self.alvo["o"]["x"], self.alvo["o"]["y"])),
                                  self.alvo["o"])
        self._alvo_p, self._alvo_ents = alvo_p, alvo_ents
        if not mesma_sala:
            return
        self.p = list(antes["p"])
        if len(antes.get("ents", ())) == len(self.ents):
            for e, v in zip(self.ents, antes["ents"]):
                if math.hypot(e["x"] - v["x"], e["y"] - v["y"]) < 90:
                    e["x"], e["y"] = v["x"], v["y"]
        meu = list(antes["p2"])
        ex, ey = alvo_p2[0] - meu[0], alvo_p2[1] - meu[1]
        d = math.hypot(ex, ey)
        if self.busy or d > 150:
            meu = alvo_p2                         # divergencia grande: usa a do anfitriao
        else:
            ses = self.game.sessao
            ms = (ses.rtt_atual()[1] if ses is not None else None) or 150
            if self._parado > ms / 1000.0 + 0.15:
                meu = [meu[0] + ex * 0.2, meu[1] + ey * 0.2]       # parado: junta devagar com o anfitriao
            else:
                folga = 190 * (ms / 1000.0) + 30  # andando: e normal estar na frente por causa do atraso
                if d > folga:
                    k = (d - folga) / d * 0.25
                    meu = [meu[0] + ex * k, meu[1] + ey * k]
        self.p2 = meu

    def animar_convidado(self, dt, direc, posso):
        self.t += dt
        if self.dica:
            self.dica[1] += dt
        self.lock_t = max(0, self.lock_t - dt)
        self.titulo_t = max(0, self.titulo_t - dt)
        self.g_a_t = max(0, self.g_a_t - dt)
        vx, vy = direc if (posso and not self.busy and self.coop) else (0.0, 0.0)
        n = math.hypot(vx, vy)
        if n > 0.1:
            self._parado = 0.0
            self.moving2 = True
            if n > 1:
                vx, vy = vx / n, vy / n
            self.p2 = self._passo(self.p2, vx, vy, dt)
            if abs(vx) > abs(vy):
                self.face2 = "E" if vx > 0 else "W"
            else:
                self.face2 = "S" if vy > 0 else "N"
        else:
            self._parado += dt
            self.moving2 = False
        k = min(1.0, 14 * dt)
        self.p = [self.p[0] + (self._alvo_p[0] - self.p[0]) * k, self.p[1] + (self._alvo_p[1] - self.p[1]) * k]
        for i, e in enumerate(self.ents):
            if i < len(self._alvo_ents):
                ax, ay = self._alvo_ents[i]
                e["x"] += (ax - e["x"]) * k
                e["y"] += (ay - e["y"]) * k
        self.parts.update(dt)
        self.fl.update(dt)
        for d in self.dust:
            d[1] -= d[2] * dt
            d[0] += math.sin(self.t + d[3]) * 5 * dt
            if d[1] < FL.top:
                d[1] = FL.bottom
                d[0] = random.uniform(FL.left, FL.right)

    def _passo(self, p, vx, vy, dt):
        """um passo do heroi 2 com colisao (paredes e objetos); usado pelo anfitriao e pela previsao do convidado"""
        p = list(p)
        if vx or vy:
            nx, ny = p[0] + vx * 190 * dt, p[1] + vy * 190 * dt
            if self.walkable(nx, ny):
                p = [nx, ny]
            elif self.walkable(nx, p[1]):
                p[0] = nx
            elif self.walkable(p[0], ny):
                p[1] = ny
        for o in self.objs:
            dx, dy = p[0] - o["x"], p[1] - o["y"]
            d = math.hypot(dx, dy)
            lim = o["r"] + 14
            if 0 < d < lim and o["kind"] != "stairs":
                p[0] = o["x"] + dx / d * lim
                p[1] = o["y"] + dy / d * lim
                if not self.walkable(*p):
                    p[0], p[1] = clamp(p[0], FL.left + 14, FL.right - 14), clamp(p[1], FL.top + 14, FL.bottom - 14)
        return p

    def mover2(self, dt):
        """heroi 2 (convidado): direcional vindo da EntradaVirtual"""
        ses = self.game.sessao
        vx, vy = ses.vinp.teclas_dir() if (ses is not None and ses.vinp is not None) else (0.0, 0.0)
        n = math.hypot(vx, vy)
        self.moving2 = n > 0.1
        if self.moving2:
            if abs(vx) > abs(vy):
                self.face2 = "E" if vx > 0 else "W"
            else:
                self.face2 = "S" if vy > 0 else "N"
        else:
            vx = vy = 0.0
        self.p2 = self._passo(self.p2, vx, vy, dt)

    def passar(self, side):
        self.busy = True
        audio.sfx("porta")
        dest = self.sala.portas[side]
        self.game.fade(lambda: self.enter_room(dest, side))

    # --------------------------------------------------------- combate
    def iniciar_combate(self):
        if self.busy:
            return
        self.busy = True
        s = self.sala
        boss = s.tipo == "chefe"
        ids = [e["id"] for e in self.ents]
        self.game.fade(lambda: self.game.iniciar_combate(ids, boss, self.fim_combate), kind="flash")

    def fim_combate(self, res):
        s = self.sala
        self.busy = False
        self.joy = None
        self.joyvec = (0.0, 0.0)
        if res == "venceu":
            s.limpa = True
            self.ents = []
            self.locked = False
            self.run.stats["inimigos"] += len(s.inimigos)
            if s.tipo == "chefe":
                self.run.stats["chefes"] += 1
                self.pos_chefe()
            else:
                self.parts.burst(480, 330, 24, [GOLD_L, GOLD], up=120)
        elif res == "fugiu":
            self.p = list(self.entry)
            self.p2 = [self.p[0] + 34, self.p[1]]
            self.grace = 2.5
            for e in self.ents:
                e["x"], e["y"] = random.uniform(200, 760), random.uniform(240, 400)

    def pos_chefe(self):
        g = self.game
        s = self.sala
        cid = s.inimigos[0]
        ch = E.CHEFES.get(cid, {})
        iid = ch.get("recompensa_item")
        ultimo = self.run.andar_i >= self.run.n_andares - 1

        def depois():
            if ultimo:
                g.vitoria()
            else:
                s.stairs = True
                self.p = [480.0, 420.0]
                self.objs.append(dict(kind="stairs", x=480, y=250, r=34))
                g.toast("A escada se abriu!", "escada")
        if iid in E.ITENS:
            for h in self.run.herois:
                h.add_item(iid)
            it = E.ITENS[iid]
            g.push(Cartao(g, it.get("nome", iid), "Recompensa do chefe", it.get("desc", ""), item=it, mais=mais_item(it),
                          extra=[("estrela", E.efeito_texto(it.get("efeito")), GOLD_L)], botoes=[("Pegar", "gold", depois)]))
        else:
            depois()

    # -------------------------------------------------------- interacao
    def interagir(self, o, quem=0):
        g = self.game
        j = self.run.herois[quem]
        if o["kind"] != "stairs":
            self.run.foco = quem          # a cena aberta (loja, enigma...) e do heroi que interagiu
        s = self.sala
        k = o["kind"]
        if k == "stairs":
            self.busy = True
            g.descer()
        elif k == "ped":
            it_ = o["it"]
            it = E.ITENS[it_["id"]]
            ef = E.efeito_texto(it.get("efeito"))
            tipo = "Consumível" if it.get("tipo") == "consumivel" else "Passivo"
            if s.tipo == "tesouro":
                g.push(Cartao(g, it.get("nome", ""), tipo + " - " + ef, it.get("desc", ""), item=it, mais=mais_item(it),
                              botoes=[("Levar este", "gold", lambda: self.pegar_tesouro(it_, quem)), ("Deixar", "normal", None)]))
            else:
                pr = it_["preco"]
                pode = j.florins >= pr
                g.push(Cartao(g, it.get("nome", ""), tipo + " - " + ef, it.get("desc", ""), item=it, mais=mais_item(it),
                              extra=[("florim", "%d florins (você tem %d)" % (pr, j.florins), GOLD_L if pode else RED)],
                              botoes=[("Comprar" if pode else "Sem florins", "gold" if pode else "dim", (lambda: self.comprar(it_, quem)) if pode else None),
                                      ("Voltar", "normal", None)]))
        elif k == "npc":
            nid = o["npc"]
            g.push(Dialogo(g, nid, E.npc_fala(nid, random.randrange(8), "...")))
        elif k == "altar":
            if s.usada:
                g.push(Dialogo(g, "monge_enfermeiro", "O altar já foi usado. Siga em frente, filho."))
            else:
                s.usada = True
                audio.sfx("cura")
                for h in self.run.herois:           # o altar cura o grupo todo
                    h.hp, h.tinta = h.hp_max, h.tinta_max
                self.parts.burst(480, 300, 30, [(120, 240, 150), (255, 255, 255)], up=140)
                self.fl.add("+Ânimo", 440, 250, (120, 240, 150))
                self.fl.add("+Tinta", 530, 250, (130, 170, 255))
                g.toast("Ânimo e Tinta restaurados", "coracao_flamejante")
        elif k == "enigma":
            q = E.PERGUNTAS[s.pergunta]
            g.push(Pergunta(g, q.get("tema", ""), q.get("enunciado", ""), q.get("opcoes", ["", "", ""]), q.get("correta", 0),
                            q.get("explicacao", ""), lambda ok: self.fim_enigma(ok, quem), dados=q))

    def pegar_tesouro(self, it_, quem=0):
        s = self.sala
        pq = self.p if quem == 0 else self.p2
        it_["pego"] = True
        s.usada = True
        audio.sfx("item")
        self.run.herois[quem].add_item(it_["id"])
        self.objs = [o for o in self.objs if o["kind"] != "ped"]
        self.parts.burst(pq[0], pq[1] - 20, 26, [GOLD_L, GOLD, (255, 255, 255)], up=150)
        self.fl.add("Item!", pq[0], pq[1] - 80, GOLD_L, False)

    def comprar(self, it_, quem=0):
        j = self.run.herois[quem]
        pq = self.p if quem == 0 else self.p2
        if j.florins < it_["preco"]:
            return
        j.florins -= it_["preco"]
        audio.sfx("moeda")
        it_["pego"] = True
        j.add_item(it_["id"])
        self.objs = [o for o in self.objs if not (o["kind"] == "ped" and o["it"] is it_)]
        self.parts.burst(pq[0], pq[1] - 20, 16, [GOLD_L, GOLD], up=120)
        self.fl.add("-%d" % it_["preco"], pq[0], pq[1] - 80, GOLD_L)

    def fim_enigma(self, ok, quem=0):
        g = self.game
        s = self.sala
        j = self.run.herois[quem]
        pq = self.p if quem == 0 else self.p2
        s.usada = True
        self.objs = [o for o in self.objs if o["kind"] != "enigma"]
        a = self.run.andar_i + 1
        st = self.run.stats
        if ok:
            fl = int((10 + 5 * a) * (1 + j.bonus("bonus_florins_pct") / 100.0))
            xp = 10 + 6 * a
            j.florins += fl
            st["florins"] += fl
            st["acertos"] += 1
            sub = j.ganhar_xp(xp)
            for h in self.run.herois:               # XP compartilhado
                if h is not j:
                    h.ganhar_xp(xp)
            audio.sfx("levelup" if sub else "moeda")
            self.fl.add("+%d" % fl, pq[0], pq[1] - 90, GOLD_L)
            self.parts.burst(480, 300, 20, [GOLD_L, GOLD], up=120)
            for s_ in sub:
                g.toast("Nível %d: %s" % (s_["nivel"], s_["titulo"]), "estrela")
                for h in s_["novas"]:
                    g.toast("Nova habilidade: " + E.HAB[h].get("nome", h), E.icone_hab(E.HAB[h]))
        else:
            dano = max(0, min(j.hp - 1, 3 + 2 * a))
            j.hp -= dano
            st["erros"] += 1
            self.fl.add("-%d" % dano, pq[0], pq[1] - 90, RED)

    # ---------------------------------------------------------- desenho
    def draw(self, S):
        self.hits = []
        run = self.run
        s = self.sala
        dados = run.andar.dados
        t = self.t
        S.blit(arte_salas.fundo_sala(self.estilo, run.andar_i), (0, 0))
        for side in "NSWE":
            if side in s.portas:
                nb = run.andar.salas[s.portas[side]]
                esp = nb.tipo if (nb.tipo in ("chefe", "tesouro", "loja", "cura", "enigma") and (nb.visitada or nb.vista)) else None
                draw_door(S, side, self.locked, esp)
                if self.lock_t > 0 and self.locked:
                    add_glow(S, door_rect(side).center, 70, (200, 40, 30), self.lock_t * 2)
        lst = []
        for o in self.objs:
            lst.append((o["y"] + (o["r"] if o["kind"] in ("ped", "altar") else 20), 0, o))
        for e in self.ents:
            lst.append((e["y"], 1, e))
        lst.append((self.p[1] + 14, 2, None))
        if self.coop:
            lst.append((self.p2[1] + 14, 3, None))
        lst.sort(key=lambda a: a[0])
        for _, k, o in lst:
            if k == 0:
                self.draw_obj(S, o, t)
            elif k == 1:
                self.draw_ent(S, o, t)
            elif k == 3:
                hero_sala(S, int(self.p2[0]), int(self.p2[1] + 14), t, self.face2, self.moving2, self.run.herois[1].nivel)
                draw_text(S, "2", 22, (150, 220, 255), (int(self.p2[0]), int(self.p2[1] - 112)), bold=True)
            else:
                hero_sala(S, int(self.p[0]), int(self.p[1] + 14), t, self.face, self.moving, self.run.herois[0].nivel, "dano" if self.run.herois[0].hp < 0 else "normal")
                if self.coop:
                    draw_text(S, "1", 22, GOLD_L, (int(self.p[0]), int(self.p[1] - 112)), bold=True)
        arte_salas.desenhar_sala_dinamica(S, self.estilo, t, run.andar_i)
        for d in self.dust:
            a = int(110 + 90 * math.sin(t * 2 + d[3] * 5))
            pygame.draw.circle(S, (a, int(a * .9), int(a * .6)), (int(d[0]), int(d[1])), 1)
        self.parts.draw(S)
        self.fl.draw(S)
        if self.alvo:
            self.draw_balao_alvo(S, self.alvo)
        if self.alvo2:
            self.draw_balao_alvo(S, self.alvo2)
        if self.titulo_t > 0:
            a = min(1.0, self.titulo_t * 1.5)
            nome = E.nome_sala(self.estilo, NOMES_SALA.get(s.tipo, ""))
            im = outlined_surf(nome, 52, GOLD_L, 3)
            im = im.copy()
            im.set_alpha(int(255 * a))
            S.blit(im, im.get_rect(center=(480, 176)))
        self.draw_hud(S)
        self.draw_mini(S)
        self.draw_controles(S)
        if self.dica:
            desenhar_dica(S, self.dica[0], self.dica[1], 82)

    def draw_balao_alvo(self, S, a):
        bob = math.sin(self.t * 6) * 4
        x, y = int(a["x"]), int(a["y"] + bob)
        if a["k"] == "ent":
            ic = "ponto_de_exclamacao"
        else:
            ic = a["icone"]
        pygame.draw.polygon(S, (250, 242, 220), [(x - 9, y + 20), (x + 9, y + 20), (x, y + 34)])
        pygame.draw.circle(S, (14, 8, 4), (x, y + 2), 30)
        pygame.draw.circle(S, (250, 242, 220), (x, y), 27)
        pygame.draw.circle(S, (90, 60, 20), (x, y), 27, 3)
        desenhar_icone(S, ic, (x, y), 36, None, self.t)

    def draw_ent(self, S, e, t):
        h = e["h"]
        d = e["d"]
        bob = math.sin(t * 3 + e["ph"]) * 3
        spr = sprite_inimigo(e["id"], t + e["ph"], "idle", int(h * escala_inimigo(d)))
        S.blit(spr, spr.get_rect(midbottom=(int(e["x"]), int(e["y"] + h * 0.075 + bob))))
        if e["boss"]:
            draw_text(S, trunc(d.get("nome", ""), 26, 400), 26, GOLD_L, (int(e["x"]), int(e["y"] - h - 6)), bold=True)

    def draw_obj(self, S, o, t):
        k = o["kind"]
        x, y = int(o["x"]), int(o["y"])
        s = self.sala
        if k == "ped":
            it_ = o["it"]
            it = E.ITENS[it_["id"]]
            pygame.draw.ellipse(S, (20, 14, 10), (x - 32, y + 8, 64, 26))
            pygame.draw.rect(S, (150, 140, 120), (x - 22, y - 6, 44, 32), 0, 3)
            pygame.draw.rect(S, (90, 82, 70), (x - 22, y - 6, 44, 32), 2, 3)
            pygame.draw.rect(S, (190, 180, 160), (x - 30, y - 14, 60, 12), 0, 3)
            pygame.draw.rect(S, (90, 82, 70), (x - 30, y - 14, 60, 12), 2, 3)
            desenhar_item(S, x, y - 48, it, 56, t + x)
            if s.tipo == "loja":
                desenhar_icone(S, "florim", (x - 18, y + 44), 22)
                draw_text(S, "%d" % it_["preco"], 26, GOLD_L if self.run.j.florins >= it_["preco"] else RED, (x - 4, y + 44), anchor="midleft", bold=True)
            if self.alvo and self.alvo.get("o") is o:
                balao_texto(S, it.get("nome", ""), x, y - 142, 260, 24, (x, y - 86))
        elif k == "npc":
            nid = o["npc"]
            kk = ("npc", nid)
            sc = npc_frame(nid, t, 150)
            S.blit(sc, sc.get_rect(midbottom=(x, y + 12)))
            if self.alvo and self.alvo.get("o") is o:
                balao_texto(S, E.npc(nid)["nome"], x, y - 190, 300, 26, (x, y - 140))
        elif k == "altar":
            base = pygame.Rect(0, 0, 124, 56)
            base.center = (x, y + 20)
            pygame.draw.rect(S, (170, 164, 150), base, 0, 6)
            pygame.draw.rect(S, (90, 84, 74), base, 3, 6)
            pygame.draw.rect(S, (200, 194, 180), (x - 62, y - 8, 124, 16), 0, 4)
            if not s.usada:
                add_glow(S, (x, y - 20), 80, (60, 160, 90), 1 + .1 * math.sin(t * 3))
            desenhar_icone(S, "cruz_latina", (x, y - 34), 52, (240, 230, 190) if not s.usada else (120, 110, 90))
            draw_candle(S, x - 46, y - 4, t, not s.usada, 22)
            draw_candle(S, x + 46, y - 4, t + 1, not s.usada, 22)
        elif k == "enigma":
            draw_lectern(S, x, y - 14)
            add_glow(S, (x, y - 50), 80, (110, 70, 160), 1 + .1 * math.sin(t * 3))
            desenhar_icone(S, "interrogacao", (x, int(y - 70 + math.sin(t * 2.5) * 5)), 52, None, t)
        elif k == "stairs":
            for i in range(5):
                c = 30 + i * 10
                pygame.draw.rect(S, (c, c - 4, c + 8), (x - 56 + i * 6, y - 24 + i * 10, 112 - i * 12, 12))
                pygame.draw.rect(S, (90, 80, 100), (x - 56 + i * 6, y - 24 + i * 10, 112 - i * 12, 12), 1)
            add_glow(S, (x, y + 10), 90, (200, 160, 60), 1 + .15 * math.sin(t * 3))
            desenhar_icone(S, "escada", (x, int(y - 48 + math.sin(t * 3) * 4)), 48)

    def draw_hud(self, S):
        run = self.run
        j = run.herois[0]
        if self.coop:
            h2 = run.herois[1]
            panel(S, pygame.Rect(8, 124, 232, 84), 205)
            barra_icone(S, 18, 130, 214, 24, "animo", h2.hp / h2.hp_max, BARRA_HP, "%d/%d" % (h2.hp, h2.hp_max))
            barra_icone(S, 18, 158, 214, 24, "tinta", h2.tinta / h2.tinta_max, BARRA_TINTA, "%d/%d" % (h2.tinta, h2.tinta_max))
            desenhar_icone(S, "florim", (34, 194), 20)
            draw_text(S, "%d   Jogador 2" % h2.florins, 22, (150, 220, 255), (52, 194), anchor="midleft", bold=True)
        panel(S, pygame.Rect(8, 8, 232, 112), 205)
        barra_icone(S, 18, 16, 214, 28, "animo", j.hp / j.hp_max, BARRA_HP, "%d/%d" % (j.hp, j.hp_max))
        barra_icone(S, 18, 50, 214, 28, "tinta", j.tinta / j.tinta_max, BARRA_TINTA, "%d/%d" % (j.tinta, j.tinta_max))
        desenhar_icone(S, "florim", (34, 100), 26)
        draw_text(S, "%d" % j.florins, 28, GOLD_L, (52, 100), anchor="midleft", bold=True)
        desenhar_icone(S, "estrela", (142, 100), 28)
        draw_text(S, "%d" % j.nivel, 28, PARCH, (160, 100), anchor="midleft", bold=True)

    def draw_mini(self, S):
        run = self.run
        a = run.andar
        ox, oy = 838, 40
        panel(S, pygame.Rect(826, 8, 126, 148), 240, "pergaminho")
        draw_text(S, "Andar " + ["I", "II", "III", "IV", "V", "VI"][min(run.andar_i, 5)], 22, (96, 54, 14), (889, 24), bold=True, shadow=None)
        cs, gp = 18, 4
        for pos, s in a.salas.items():
            if not (s.visitada or s.vista):
                continue
            x = ox + pos[0] * (cs + gp)
            y = oy + pos[1] * (cs + gp)
            r = pygame.Rect(x, y, cs, cs)
            esp = s.tipo in ("chefe", "tesouro", "loja", "cura", "enigma", "inicio")
            if s.visitada:
                col = MINI_COR.get(s.tipo, (168, 120, 70))
                if s.tipo == "combate" and s.limpa:
                    col = (120, 112, 100)
                pygame.draw.rect(S, col, r, 0, 3)
            else:
                col = MINI_COR[s.tipo] if esp else (70, 58, 44)
                pygame.draw.rect(S, mix(col, (0, 0, 0), .55), r, 0, 3)
                pygame.draw.rect(S, mix(col, (0, 0, 0), .2), r, 1, 3)
            for d, nb in s.portas.items():
                s2 = a.salas[nb]
                if s2.visitada or s2.vista:
                    dx, dy = E.DIRS[d]
                    if dx > 0:
                        pygame.draw.rect(S, (110, 90, 60), (x + cs, y + 6, gp, 6))
                    if dy > 0:
                        pygame.draw.rect(S, (110, 90, 60), (x + 6, y + cs, 6, gp))
            if pos == run.pos:
                c = (255, 255, 255) if int(self.t * 3) % 2 == 0 else GOLD_L
                pygame.draw.rect(S, c, r.inflate(4, 4), 2, 4)

    def draw_controles(self, S):
        g = self.game
        t = self.t
        # joystick virtual: so aparece onde o dedo toca (dica discreta nos primeiros momentos)
        eu = self.convidado
        joy = self.g_joy if eu else ((self.joy_o, self.joyvec) if self.joy is not None else None)
        if joy is not None:
            (ox, oy), vec = joy
            S.blit(_joy_base(), (ox - JOY_R - 4, oy - JOY_R - 4))
            kx, ky = ox + vec[0] * 46, oy + vec[1] * 46
            S.blit(_joy_knob(), (int(kx) - 30, int(ky) - 30))
        elif not self.moveu and not eu:
            im = _joy_base()
            im.set_alpha(int(60 + 50 * math.sin(t * 3)))
            S.blit(im, (150 - JOY_R - 4, 430 - JOY_R - 4))
            im.set_alpha(255)
            desenhar_icone(S, "mao", (150, 430), 46)
        # botao INTERAGIR
        a = self.alvo2 if eu else self.alvo
        a_t = self.g_a_t if eu else self.a_t
        ic = a["icone"] if a else "mao"
        if a and a["k"] == "ent":
            ic = "mitra" if a["e"]["boss"] else "duelo"
        pulse = a is not None
        st = "gold" if a else "dim"
        if a and a["k"] == "door" and a["locked"]:
            st = "dim"
        r = R_A + (4 if a_t > 0 else 0)
        draw_round(S, BTN_A, r, ic, "Interagir", st, a_t > 0, pulse, t, lsz=22, isz=int(R_A * 1.3))
        mo = g.inp.modo
        if mo == "controle":
            X.glifo(S, "cruz", (BTN_A[0] + 40, BTN_A[1] - 44), 30)
        elif mo == "teclado":
            X.g_tecla(S, (BTN_A[0] + 40, BTN_A[1] - 44), "E", 30)
        else:
            draw_text(S, "A", 22, INK, (BTN_A[0] + 38, BTN_A[1] - 40), bold=True, shadow=None)
        self.rbtn(S, BTN_FICHA, 30, "pessoa", None, lambda: g.push(Inventario(g)), "normal")
        if not eu:                  # no online, so o anfitriao pausa
            self.rbtn(S, BTN_PAUSA, 28, "pausa", None, lambda: g.push(Pausa(g)), "normal")


_npc_sc = {}
_jb = {}


def _joy_base():
    import arte_ui
    return arte_ui.joy_base(JOY_R)
    if "b" not in _jb:
        s = pygame.Surface((2 * JOY_R + 8, 2 * JOY_R + 8), pygame.SRCALPHA)
        c = (JOY_R + 4, JOY_R + 4)
        pygame.draw.circle(s, (14, 9, 5, 150), c, JOY_R)
        pygame.draw.circle(s, (214, 170, 60, 200), c, JOY_R, 4)
        pygame.draw.circle(s, (214, 170, 60, 110), c, int(JOY_R * .62), 2)
        for d, (dx, dy) in {"u": (0, -1), "d": (0, 1), "l": (-1, 0), "r": (1, 0)}.items():
            draw_arrow(s, int(c[0] + dx * (JOY_R - 14)), int(c[1] + dy * (JOY_R - 14)), d, (214, 170, 60, 200), 7)
        _jb["b"] = cvt(s)
    return _jb["b"]


def _joy_knob():
    import arte_ui
    return arte_ui.joy_knob()
    if "k" not in _jb:
        s = pygame.Surface((60, 60), pygame.SRCALPHA)
        pygame.draw.circle(s, (255, 228, 140, 230), (30, 30), 28)
        pygame.draw.circle(s, (255, 246, 210, 255), (22, 21), 9)
        pygame.draw.circle(s, (150, 104, 30, 255), (30, 30), 28, 4)
        _jb["k"] = cvt(s)
    return _jb["k"]
