# -*- coding: utf-8 -*-
"""Efeitos de combate dos ARGUMENTOS (sem laminas): silogismo (ratio), codice com cruz de luz (auctoritas), pena que divide a tabula (distinguo),
bencao com agua benta e pombas (apoio).  desenhar_fx(S, f) com f = dict(kind, t, dur, sx, sy, tx, ty, cor)."""
import math

import pygame

from desenho import add_glow, mix
from icones import desenhar_icone


def clamp(v, a, b):
    return a if v < a else (b if v > b else v)

_surf_cache = {}


def _e(x):
    x = clamp(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def _lerp(a, b, t):
    return a + (b - a) * t


def _alfa(w, h):
    k = (w, h)
    s = _surf_cache.get(k)
    if s is None:
        s = _surf_cache[k] = pygame.Surface((w, h), pygame.SRCALPHA)
    s.fill((0, 0, 0, 0))
    return s


# ------------------------------------------------------------------ RATIO: silogismo
def _ratio(S, f, p):
    sx, sy, tx, ty, cor = f["sx"], f["sy"], f["tx"], f["ty"], f["cor"]
    dx, dy = tx - sx, ty - sy
    L = math.hypot(dx, dy) or 1.0
    ux, uy = dx / L, dy / L
    nx, ny = -uy, ux
    p1 = _e(p / .34)                 # as tres linhas surgem diante da mao
    p2 = _e((p - .34) / .44)         # encaixam e disparam
    cols = ((110, 165, 255), (160, 208, 255), (255, 255, 255))
    comp = (84, 66, 48)              # premissa maior, premissa menor, conclusao
    if p < .8:
        for i in range(3):
            off = (i - 1) * 22 * (1 - p2)
            head = 34 + p1 * 28 + p2 * (L - 40 - 28)
            ln = comp[i] * p1 * (1 + .6 * p2)
            a = (sx + ux * (head - ln) + nx * off, sy + uy * (head - ln) + ny * off)
            b = (sx + ux * head + nx * off, sy + uy * head + ny * off)
            pygame.draw.line(S, mix(cols[i], (0, 0, 0), .4), a, b, 13)
            pygame.draw.line(S, cols[i], a, b, 9)
            pygame.draw.line(S, (255, 255, 255), (a[0] - ny * 2, a[1] + nx * 2), (b[0] - ny * 2, b[1] + nx * 2), 2)
            pygame.draw.circle(S, (255, 255, 255), (int(b[0]), int(b[1])), 6)
            add_glow(S, b, 30, cols[i], .9)
    if p2 > .15 and p < .8:                         # o feixe unico da conclusao
        h = (sx + ux * (34 + p1 * 28 + p2 * (L - 68)), sy + uy * (34 + p1 * 28 + p2 * (L - 68)))
        pygame.draw.line(S, (255, 255, 255), (sx + ux * 36, sy + uy * 36), h, 3)
        add_glow(S, h, 54, cor)
    if p > .74:
        q = (p - .74) / .26
        pygame.draw.circle(S, (255, 255, 255), (int(tx), int(ty)), int(18 + 70 * q), 4)
        pygame.draw.circle(S, cor, (int(tx), int(ty)), int(10 + 50 * q), 3)
        add_glow(S, (tx, ty), 80, cor, 1.0 - q * .5)


# ------------------------------------------------------------------ AUCTORITAS: codice + cruz de luz
def _codice(S, x, y, ang, s=1.0):
    ca, sa = math.cos(ang), math.sin(ang)

    def T(px, py):
        px, py = px * s, py * s
        return (x + px * ca - py * sa, y + px * sa + py * ca)
    pygame.draw.polygon(S, (110, 28, 40), [T(-34, -24), T(34, -24), T(34, 26), T(-34, 26)])
    pygame.draw.polygon(S, (250, 242, 214), [T(-31, -21), T(-1, -17), T(-1, 24), T(-31, 22)])
    pygame.draw.polygon(S, (240, 230, 196), [T(31, -21), T(1, -17), T(1, 24), T(31, 22)])
    for j in range(5):
        yy = -12 + j * 7
        pygame.draw.line(S, (120, 96, 70), T(-25, yy), T(-6, yy + .5), 1)
        pygame.draw.line(S, (120, 96, 70), T(6, yy + .5), T(25, yy), 1)
    pygame.draw.line(S, (150, 120, 80), T(0, -17), T(0, 24), 2)
    c = T(0, 2)
    pygame.draw.circle(S, (190, 40, 48), (int(c[0]), int(c[1])), int(8 * s))
    pygame.draw.circle(S, (255, 226, 140), (int(c[0]), int(c[1])), int(8 * s), 2)
    pygame.draw.polygon(S, (20, 10, 6), [T(-34, -24), T(34, -24), T(34, 26), T(-34, 26)], 2)


def _auctoritas(S, f, p):
    sx, sy, tx, ty, cor = f["sx"], f["sy"], f["tx"], f["ty"], f["cor"]
    pr = min(1.0, p / .62)
    if p < .68:
        x = _lerp(sx, tx, pr)
        y = _lerp(sy, ty, pr) - math.sin(pr * math.pi) * 110
        add_glow(S, (x, y), 52, cor)
        # o codice sobe aberto e vai de frente para o alvo (leve giro)
        _codice(S, x, y, -.5 + pr * .9 + math.sin(f["t"] * 14) * .05, 1.0 + .35 * math.sin(pr * math.pi))
        for i in range(5):                                     # rastro de letras de luz
            q = clamp(pr - i * .06, 0, 1)
            if q > 0:
                px, py = _lerp(sx, tx, q), _lerp(sy, ty, q) - math.sin(q * math.pi) * 110
                pygame.draw.circle(S, (255, 244, 190), (int(px), int(py) + 6), max(1, 5 - i))
    if p >= .6:
        q = clamp((p - .6) / .4, 0, 1)
        add_glow(S, (tx, ty), int(100 * (.4 + q)), cor)
        hh, ww = int(120 * q) + 10, int(84 * q) + 8
        pygame.draw.rect(S, (255, 244, 190), (tx - 8, ty - hh, 16, hh * 2 - 30), 0, 5)
        pygame.draw.rect(S, (255, 244, 190), (tx - ww, ty - hh * .45, ww * 2, 16), 0, 5)
        pygame.draw.rect(S, (255, 255, 255), (tx - 3, ty - hh + 6, 6, hh * 2 - 42), 0, 3)
        desenhar_icone(S, "cruz_latina", (int(tx), int(ty - 6)), int(120 * (.5 + q * .5)), (255, 230, 140))


# ------------------------------------------------------------------ DISTINGUO: pena que divide a tabula
def _pena(S, x, y, ang=-2.3, s=1.0):
    ca, sa = math.cos(ang), math.sin(ang)

    def T(px, py):
        return (x + (px * ca - py * sa) * s, y + (px * sa + py * ca) * s)
    pygame.draw.polygon(S, (250, 250, 255), [T(0, 0), T(22, -6), T(52, -9), T(74, -2), T(54, 6), T(24, 5)])
    pygame.draw.polygon(S, (130, 130, 160), [T(0, 0), T(22, -6), T(52, -9), T(74, -2), T(54, 6), T(24, 5)], 1)
    pygame.draw.line(S, (150, 150, 180), T(0, 0), T(72, -2), 2)
    pygame.draw.polygon(S, (214, 170, 60), [T(0, 0), T(14, -3), T(14, 3)])
    pygame.draw.polygon(S, (60, 40, 10), [T(0, 0), T(14, -3), T(14, 3)], 1)


def _distinguo(S, f, p):
    tx, ty, cor = f["tx"], f["ty"], f["cor"]
    q = _e(min(1.0, p / .6))
    sep = 30 * _e((p - .56) / .4)
    y0, y1 = ty - 126, ty + 122
    hy = _lerp(y0, y1, q)
    w, h = 150, y1 - y0 + 8
    fade = clamp(1.4 - p, 0, 1)
    for sg in (-1, 1):
        im = _alfa(w // 2 + 4, h + 4)
        pygame.draw.rect(im, (246, 236, 204, int(205 * fade)), (2, 2, w // 2, h), 0, 4)
        pygame.draw.rect(im, (120, 90, 54, int(230 * fade)), (2, 2, w // 2, h), 2, 4)
        for j in range(9):
            yy = 18 + j * (h - 30) // 9
            x0, x1 = (10, w // 2 - 8) if sg < 0 else (8, w // 2 - 12)
            pygame.draw.line(im, (96, 74, 56, int(190 * fade)), (x0, yy), (x1, yy), 2)
        S.blit(im, (tx + (-w // 2 - 2 if sg < 0 else 0) + sg * sep, y0 - 4))
    pygame.draw.line(S, mix(cor, (255, 255, 255), .3), (tx, y0), (tx, hy), 9)
    pygame.draw.line(S, (255, 255, 255), (tx, y0), (tx, hy), 4)
    add_glow(S, (tx, hy), 56, cor)
    if p < .62:
        _pena(S, tx + 4, hy - 2, -2.4)
    elif p > .56:
        a = _e((p - .56) / .3) * clamp(1.2 - p, 0, 1)
        add_glow(S, (tx, ty), int(110 * a) + 8, cor, 1.0)
        pygame.draw.line(S, (255, 255, 255), (tx, y0), (tx, y1), max(1, int(5 * (1 - p) + 1)))


# ------------------------------------------------------------------ APOIO: bencao, agua benta e pombas
def _pomba(S, x, y, s, flap, d=1):
    def T(px, py):
        return (x + px * s * d, y + py * s)
    asa = -14 * flap
    pygame.draw.polygon(S, (214, 226, 248), [T(-4, -2), T(-16, -16 + asa), T(-30, -26 + asa * 1.2), T(-12, -6), T(2, 2)])
    pygame.draw.polygon(S, (255, 255, 255), [T(-26, 6), T(-14, 2), T(10, -2), T(22, -10), T(30, -8), T(26, 2), T(12, 10), T(-8, 14)])
    pygame.draw.polygon(S, (255, 255, 255), [T(-4, -4), T(4, -20 + asa), T(18, -30 + asa * 1.3), T(14, -8), T(8, 2)])
    pygame.draw.polygon(S, (150, 160, 190), [T(-4, -4), T(4, -20 + asa), T(18, -30 + asa * 1.3), T(14, -8), T(8, 2)], 1)
    pygame.draw.polygon(S, (230, 236, 250), [T(-26, 6), T(-44, 2), T(-40, 12), T(-48, 18), T(-26, 14)])
    pygame.draw.circle(S, (255, 255, 255), (int(T(26, -10)[0]), int(T(26, -10)[1])), max(2, int(5 * s)))
    pygame.draw.polygon(S, (230, 170, 60), [T(30, -10), T(40, -8), T(30, -6)])
    pygame.draw.circle(S, (30, 24, 40), (int(T(27, -11)[0]), int(T(27, -11)[1])), 1)


def _apoio(S, f, p):
    cx, cy, cor = f["tx"], f["ty"], f["cor"]
    ouro = (255, 226, 140)
    # coluna de luz dourada
    k = math.sin(p * math.pi)
    add_glow(S, (cx, cy - 30), 130, (214, 170, 60), .5 + .9 * k)
    for rr in (0.0, .25):
        qq = clamp(p - rr, 0, 1)
        if 0 < qq < 1:
            pygame.draw.circle(S, mix(cor, ouro, .5), (int(cx), int(cy)), int(30 + qq * 130), 3)
    # gotas de agua benta caindo
    for i in range(12):
        a = i * .83
        y = cy - 120 + ((p * 260 + i * 23) % 240)
        x = cx + math.cos(a) * 54 + math.sin(p * 6 + i) * 6
        pygame.draw.polygon(S, (170, 214, 255), [(x, y - 7), (x + 3.5, y + 1), (x, y + 5), (x - 3.5, y + 1)])
        pygame.draw.circle(S, (255, 255, 255), (int(x - 1), int(y)), 1)
    # duas pombas que circulam e sobem
    for j, ph in enumerate((0.0, math.pi)):
        a = p * 5.2 + ph
        x = cx + math.cos(a) * 92
        y = cy - 60 - p * 70 + math.sin(a) * 26
        _pomba(S, x, y, 1.0, .5 + .5 * math.sin(f["t"] * 22 + j), 1 if math.sin(a) < 0 else -1)
    for i in range(8):
        a = i * .8 + p * 2
        y = cy + 80 - ((p * 200 + i * 19) % 200)
        desenhar_icone(S, "estrela", (int(cx + math.cos(a) * 78), int(y)), 16, ouro)


def desenhar_fx(S, f):
    p = f["t"] / f["dur"]
    k = f["kind"]
    if k == "ratio":
        _ratio(S, f, p)
    elif k == "auctoritas":
        _auctoritas(S, f, p)
    elif k == "distinguo":
        _distinguo(S, f, p)
    elif k == "apoio":
        _apoio(S, f, p)
    else:
        return False
    return True
