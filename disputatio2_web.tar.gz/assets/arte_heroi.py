# -*- coding: utf-8 -*-
"""O Bacharel (jogador): vista 3/4 voltada para os inimigos, rosto expressivo, cappa azul com debrum dourado, livro, pena e bolsa.

Evolui com o nivel (tier 1..5): Estudante, Bacharel (debrum duplo), Licenciado (pileus preto), Mestre (forro escarlate), Doutor (pileus escarlate + arminho).
Armas = INSTRUMENTOS DE ARGUMENTO (nada de laminas): dedo/silogismo (ratio), codice com cruz de luz (auctoritas), pena que divide a tabula (distinguo),
maos abertas com bencao (apoio).

API (mesma de arte_personagens):
    hero_combate(nivel, pose, s, flash=0) -> Surface 260x310, pes em HERO_ANCHOR
    hero_sala(S, x, y, t, face, moving, nivel=1, estado="normal")   exploracao (4 direcoes)
    hero_sprite(which=0, nivel=1)   frontal 150x200 (ficha)
    hero_retrato(size=96, nivel=1)  retrato redondo (HUD / dialogos / ficha)
    escudo_luz(S, cx, cy, t, r)
"""
import math

import pygame

from arte_kit import Tela, mix, lit, dk, catmull, ik2, INK, OURO, OURO_L, OURO_D, BRANCO, clamp
from arte_vista import Vista
from arte_figuras import sino_manto, hem_pts, mao, pileus, livro_obj, pergaminho_obj, sombra_chao, cilindro, figura_frontal, rot  # noqa: F401

HERO_CW, HERO_CH = 260, 310
HERO_ANCHOR = (120, 290)

AZUL = (30, 52, 128)
AZUL_T = (84, 116, 192)
CREME = (238, 228, 200)
PELE = (243, 205, 172)
CABELO = (110, 68, 38)
ESCARLATE = (156, 28, 36)
COURO = (126, 82, 46)
IRIS = (62, 130, 168)


def tier(nivel):
    return max(1, min(5, int(nivel)))


def ease(x):
    x = clamp(x, 0.0, 1.0)
    return x * x * (3 - 2 * x)


def _arminho(V, pts_line, w=6):
    V.pline(pts_line, (238, 236, 230), w)
    V.pline(pts_line, (190, 188, 184), .7)
    for (x, y) in pts_line[::2]:
        V.poly([(x - 1, y - 1), (x + 1, y - 1), (x, y + 3.2)], (30, 28, 32), None)


# ===================================================================== poses
def _bump(s, t0=.28, t1=.46, t2=.62, t3=.95):
    if s < t0:
        return -ease(s / t0)
    if s < t1:
        return -1 + 2 * ease((s - t0) / (t1 - t0))
    if s < t2:
        return 1.0
    if s < t3:
        return 1 - ease((s - t2) / (t3 - t2))
    return 0.0


def _lerp(a, b, k):
    return (a[0] + (b[0] - a[0]) * k, a[1] + (b[1] - a[1]) * k)


def _mix3(idle, wind, strike, u):
    return _lerp(idle, strike, u) if u > 0 else _lerp(idle, wind, -u)


IDLE_A, IDLE_B = (50, -88), (-26, -82)


def pose(nome, s):
    P = dict(lean=0.0, crouch=0.0, hop=0.0, hx=0.0, hy=0.0, A=IDLE_A, B=IDLE_B, itA="pena", itB="livro", olho="aberto", boca="sorriso", sobr="n", angA=0.0, sway=0.0,
             glow=0.0, walk=None)
    if nome in ("idle", "", None):
        c = math.sin(s * math.tau)
        P.update(crouch=-c * 1.4, lean=c * .8, A=(50, -88 + c * 1.6), B=(-26, -82 + c), sway=math.sin(s * math.tau + 1) * 1.4,
                 olho="pisca" if (int(s * 16) % 16 == 11) else "aberto", angA=-.9)
        return P
    if nome == "dedo":                       # RATIO: indicador erguido e silogismo
        u = _bump(s)
        P.update(lean=9 * u, A=_mix3(IDLE_A, (36, -158), (92, -134), u), itA="dedo", angA=-.1 * u, hx=2 * u, boca="o" if u > .5 else "sorriso", sway=-3 * u,
                 B=_mix3(IDLE_B, (-30, -96), (-18, -106), u), glow=max(0, u), sobr="bravo" if u > .1 else "n")
    elif nome == "livro":                    # AUCTORITAS: codice erguido com cruz de luz
        u = _bump(s)
        P.update(lean=7 * u, A=_mix3(IDLE_A, (28, -186), (74, -176), u), itA="codice", angA=-.35 + .45 * max(0, u), hy=-5 * max(0, u) - 3 * max(0, -u), sway=-3 * u,
                 B=_mix3(IDLE_B, (-14, -100), (-10, -104), u), itB="livro", glow=max(0, u), sobr="alto", boca="o" if u > .4 else "sorriso")
    elif nome == "pergaminho":               # DISTINGUO: pena que traca a linha e divide a tabula
        u = _bump(s, .26, .42, .56, .95)
        P.update(lean=10 * u, A=_mix3(IDLE_A, (24, -156), (96, -100), u), itA="estilete", angA=.9 * u, hx=2 * u, sway=-4 * u,
                 B=_mix3(IDLE_B, (-26, -94), (-6, -100), u), itB="tabula", glow=max(0, u), sobr="bravo" if u > .1 else "n")
    elif nome in ("bencao", "cast"):         # APOIO: maos abertas, luz dourada
        up = ease(s / .35) * (1 - ease((s - .72) / .25))
        P.update(A=_lerp(IDLE_A, (70, -164), up), B=_lerp(IDLE_B, (-32, -158), up), itA="palma", itB="palma", hy=-4 * up, lean=-2 * up, olho="fechado" if up > .3 else "aberto",
                 crouch=-3 * up, boca="sorriso", glow=up, sway=math.sin(s * 5) * 1.5, sobr="alto")
    elif nome == "dano":
        u = 1 - ease(s / .5)
        P.update(lean=-14 * u, A=_lerp(IDLE_A, (58, -104), u), B=_lerp(IDLE_B, (-40, -100), u), itA=None, itB="livro", hy=4 * u, olho="fechado" if u > .15 else "aberto",
                 boca="o" if u > .15 else "sorriso", sway=5 * u, crouch=4 * u, sobr="triste" if u > .15 else "n")
    elif nome in ("guarda", "guard"):
        k = ease(s / .22)
        P.update(A=_lerp(IDLE_A, (56, -116), k), B=_lerp(IDLE_B, (34, -98), k), itA="codice_f", itB=None, angA=.1 * k, crouch=6 * k, lean=5 * k, glow=k, olho="aberto",
                 sobr="bravo", boca="n")
    elif nome == "vitoria":
        P.update(hop=abs(math.sin(s * 5.2)) * 9, A=(40, -222 + math.sin(s * 5) * 3), B=(-34, -176), itA="codice", itB="punho", angA=-.3, olho="feliz", boca="sorriso", hy=-3, lean=2,
                 sobr="alto")
    elif nome == "derrota":
        k = ease(s / .8)
        P.update(crouch=44 * k, lean=-5 * k, hy=14 * k, hx=-2 * k, A=_lerp(IDLE_A, (24, -44), k), B=_lerp(IDLE_B, (-26, -40), k), itA=None, itB=None, olho="fechado", boca="o",
                 sobr="triste")
    return P


# ===================================================================== objetos
def _estilete(V, x, y, ang, k=1.0, brilho=False):
    """Pena de escrever: ponta metalica na frente (direcao ang), plumagem para tras."""
    dx, dy = math.cos(ang), math.sin(ang)
    nx, ny = -dy, dx
    tip = (x + dx * 20 * k, y + dy * 20 * k)
    back = (x - dx * 36 * k, y - dy * 36 * k - 4 * k)
    pts = [tip, (x + dx * 6 * k + nx * 2.4 * k, y + dy * 6 * k + ny * 2.4 * k),
           (x - dx * 10 * k + nx * 7 * k, y - dy * 10 * k + ny * 7 * k),
           (back[0] + nx * 4 * k, back[1] + ny * 4 * k), back,
           (back[0] - nx * 4 * k, back[1] - ny * 4 * k),
           (x - dx * 12 * k - nx * 6 * k, y - dy * 12 * k - ny * 6 * k),
           (x + dx * 6 * k - nx * 2.4 * k, y + dy * 6 * k - ny * 2.4 * k)]
    V.poly(pts, (250, 250, 252), (120, 120, 140), .9)
    V.pline([tip, back], (150, 150, 170), .9)
    V.poly([tip, (x + dx * 11 * k + nx * 1.6 * k, y + dy * 11 * k + ny * 1.6 * k), (x + dx * 11 * k - nx * 1.6 * k, y + dy * 11 * k - ny * 1.6 * k)], OURO, OURO_D, .6)
    if brilho:
        V.luz(tip[0], tip[1], 22 * k, (255, 236, 160), 230)
        V.circ(tip[0], tip[1], 2.2 * k, (255, 255, 255))


def _codice(V, x, y, ang=0.0, k=1.0, aberto=False, cruz=False, cor=(124, 34, 46)):
    """Codice (livro) com cantoneiras de ouro; aberto: paginas com texto e selo."""
    if aberto:
        w, h = 36 * k, 44 * k
        V.poly(rot([(-w * .66, -h * .54), (w * .66, -h * .54), (w * .66, h * .56), (-w * .66, h * .56)], ang, x, y), dk(cor, .3), INK, 1.0)
        V.gpoly(rot([(-w * .6, -h * .5), (-.03 * w, -h * .44), (-.03 * w, h * .52), (-w * .6, h * .48)], ang, x, y), [(252, 246, 222), (228, 212, 168)], INK, .8)
        V.gpoly(rot([(w * .6, -h * .5), (.03 * w, -h * .44), (.03 * w, h * .52), (w * .6, h * .48)], ang, x, y), [(252, 246, 222), (222, 204, 160)], INK, .8)
        for j in range(6):
            yy = -h * .3 + j * h * .15
            V.pline(rot([(-w * .5, yy), (-w * .1, yy + 1)], ang, x, y), (110, 90, 70), .7)
            V.pline(rot([(w * .1, yy + 1), (w * .5, yy)], ang, x, y), (110, 90, 70), .7)
        V.pline(rot([(0, -h * .44), (0, h * .52)], ang, x, y), (150, 120, 80), .9)
        if cruz:
            cx, cy = rot([(0, -h * .05)], ang, x, y)[0]
            V.circ(cx, cy, 8.5 * k, (170, 36, 44), OURO_D, .9)
            V.poly(rot([(-1.6, -6), (1.6, -6), (1.6, -1.6), (6, -1.6), (6, 1.6), (1.6, 1.6), (1.6, 7), (-1.6, 7), (-1.6, 1.6), (-6, 1.6), (-6, -1.6), (-1.6, -1.6)], 0, cx, cy), OURO_L, None)
        return
    livro_obj(V, x, y, ang, 30 * k, 38 * k, cor)
    cx, cy = x, y
    V.circ(cx, cy - 2 * k, 5 * k, OURO, OURO_D, .7)


def _tabula(V, x, y, ang=-.1, k=1.0, cortada=0.0):
    """Tabula de pergaminho com duas colunas (o corte do distinguo a divide)."""
    w, h = 34 * k, 40 * k
    off = cortada * 5 * k
    for s_ in (-1, 1):
        pts = [(s_ * off, -h / 2), (s_ * off + s_ * w / 2, -h / 2), (s_ * off + s_ * w / 2, h / 2), (s_ * off, h / 2)]
        V.gpoly(rot(pts, ang, x, y), [(252, 244, 214), (226, 208, 164)], INK, .9)
        for j in range(5):
            yy = -h * .34 + j * h * .17
            V.pline(rot([(s_ * (off + 3), yy), (s_ * (off + w / 2 - 3), yy)], ang, x, y), (110, 90, 70), .7)
    V.pline(rot([(0, -h / 2 - 2), (0, h / 2 + 2)], ang, x, y), (150, 90, 200) if cortada > .05 else (160, 140, 110), 1.1)


def _silogismo(V, x, y, u):
    """Tres linhas luminosas (premissa maior, menor, conclusao) que se encaixam diante da mao."""
    a = int(60 + 190 * u)
    for i, (w, col) in enumerate(((34, (130, 190, 255)), (26, (170, 215, 255)), (18, (255, 255, 255)))):
        yy = y - 8 + i * 9
        xx = x + 6 + (1 - u) * (14 - i * 6)
        V.luz(xx + w / 2, yy, 14, col, a)
        V.line((xx, yy), (xx + w, yy), col, 3.0)
        V.line((xx, yy - .6), (xx + w, yy - .6), (255, 255, 255), 1.0)


# ===================================================================== rosto
def _olho(V, x, y, rx, ry, estado, look=1.0):
    if estado in ("fechado", "pisca"):
        V.pline([(x - rx, y - .5), (x, y + ry * .5), (x + rx, y - .5)], INK, 1.5)
        V.pline([(x + rx, y - .5), (x + rx + 2.4, y - 2.4)], INK, 1.1)
        return
    if estado == "feliz":
        V.arc(x, y + ry * .6, rx, ry * 1.1, math.pi * 1.08, math.pi * 1.92, INK, 1.8)
        return
    V.ell(x, y, rx * 2, ry * 2, (253, 251, 246), INK, .9)
    ix = x + look * rx * .34
    V.ell(ix, y + ry * .05, rx * 1.3, ry * 1.62, IRIS, dk(IRIS, .6), .7)
    V.ell(ix, y + ry * .32, rx * 1.1, ry * .8, lit(IRIS, .28), None)
    V.circ(ix + .2, y + ry * .05, rx * .36, (16, 14, 22))
    V.circ(ix - rx * .36, y - ry * .42, rx * .3, (255, 255, 255))
    V.circ(ix + rx * .3, y + ry * .46, rx * .15, (255, 255, 255))
    V.arc(x, y, rx, ry, math.pi * 1.02, math.pi * 1.98, INK, 1.9)
    V.pline([(x + rx, y - ry * .5), (x + rx + 2.6, y - ry * 1.0)], INK, 1.1)


def _cabeca(V, hx, hy, tr, P):
    """Cabeca 3/4 voltada para a direita. (hx, hy) = centro; raio ~25."""
    cab = CABELO
    # volume do cabelo atras e nuca
    V.gell(hx - 6, hy - 2, 54, 54, [lit(cab, .14), cab, dk(cab, .45)], dk(cab, .75), 1.1)
    for k in range(5):
        V.pline([(hx - 24 + k * 3.4, hy - 16 + k * 2), (hx - 28 + k * 3.2, hy + 10 + k * 3)], lit(cab, .22), .8)
    # orelha
    V.ell(hx - 11, hy + 5, 8, 12, dk(PELE, .04), dk(PELE, .6), .8)
    V.pline([(hx - 12, hy + 1), (hx - 9.4, hy + 5), (hx - 12, hy + 9)], dk(PELE, .42), .7)
    # rosto
    face = [(hx - 14, hy - 17), (hx + 4, hy - 24), (hx + 19, hy - 19), (hx + 26, hy - 6), (hx + 27, hy + 5), (hx + 26, hy + 13), (hx + 21, hy + 21), (hx + 11, hy + 27),
            (hx - 1, hy + 24), (hx - 9, hy + 15), (hx - 15, hy + 2), (hx - 16, hy - 9)]
    V.gpoly(catmull(face, 4, True), [lit(PELE, .16), PELE, dk(PELE, .2)], dk(PELE, .6), 1.1)
    V.ell(hx + 5, hy + 13, 12, 6, (232, 124, 112, 60))                      # bochecha proxima
    # nariz (ponta fora do contorno)
    V.poly([(hx + 24, hy - 2), (hx + 29.5, hy + 6.5), (hx + 26, hy + 9.2), (hx + 22, hy + 8.4)], lit(PELE, .04), dk(PELE, .55), .9)
    V.pline([(hx + 22, hy + 9.5), (hx + 25.5, hy + 11)], dk(PELE, .55), .8)
    # olhos
    est = P["olho"]
    _olho(V, hx + 8.5, hy - 1.5, 6.2, 6.8, est, 1.0)
    _olho(V, hx + 22.5, hy - 1.2, 4.0, 6.2, est, 1.0)
    # sobrancelhas
    so = P["sobr"]
    bcol = dk(CABELO, .15)
    if so == "bravo":
        V.pline([(hx + 1, hy - 12.5), (hx + 14, hy - 10.4)], bcol, 2.2)
        V.pline([(hx + 18.5, hy - 10.2), (hx + 27, hy - 12.6)], bcol, 1.9)
    elif so == "triste":
        V.pline([(hx + 1, hy - 9.5), (hx + 14, hy - 13)], bcol, 2.2)
        V.pline([(hx + 18.5, hy - 13), (hx + 27, hy - 10)], bcol, 1.9)
    elif so == "alto":
        V.arc(hx + 8, hy - 9, 8, 4, math.pi * 1.1, math.pi * 1.9, bcol, 2.0)
        V.arc(hx + 22.5, hy - 9, 5, 3.4, math.pi * 1.1, math.pi * 1.9, bcol, 1.7)
    else:
        V.pline([(hx + 1.5, hy - 11.5), (hx + 8, hy - 13.2), (hx + 14.5, hy - 11.4)], bcol, 2.1)
        V.pline([(hx + 18.5, hy - 11.4), (hx + 23, hy - 12.8), (hx + 27, hy - 11)], bcol, 1.8)
    # boca
    mx, my = hx + 16, hy + 17
    b = P["boca"]
    if b == "o":
        V.ell(mx + 1, my, 6, 7.5, (92, 24, 28), INK, .8)
        V.ell(mx + 1, my + 2.4, 3.6, 2.6, (200, 84, 90))
    elif b == "sorriso":
        V.arc(mx, my - 3.2, 8, 6, math.pi * .12, math.pi * .88, INK, 1.5)
        V.pline([(mx - 7.4, my + .6), (mx - 8.4, my - .6)], INK, 1.1)
    else:
        V.pline([(mx - 5, my), (mx + 5, my - 1)], dk(PELE, .6), 1.4)
    # cabelo da frente (franja), cobrindo a testa em mecha para a direita
    V.gpoly(catmull([(hx - 25, hy + 3), (hx - 25, hy - 14), (hx - 16, hy - 27), (hx + 1, hy - 33), (hx + 17, hy - 30), (hx + 28, hy - 20), (hx + 29, hy - 11),
                     (hx + 21, hy - 17), (hx + 12, hy - 14), (hx + 4, hy - 19), (hx - 6, hy - 16), (hx - 11, hy - 6), (hx - 14, hy + 4), (hx - 18, hy + 10)], 3, True),
            [lit(cab, .2), cab, dk(cab, .35)], dk(cab, .75), 1.0)
    for k in range(4):
        V.pline([(hx - 14 + k * 8, hy - 28 + k * 1.4), (hx - 8 + k * 8.5, hy - 17 + k * .3)], lit(cab, .3), .8)
    if tr <= 2:                               # tonsura discreta (clerigo menor)
        V.ell(hx - 8, hy - 31, 14, 4.4, dk(PELE, .02), dk(PELE, .5), .7)


def _chapeu(V, hx, hy, tr):
    if tr == 3:
        pileus(V, hx - 2, hy - 20, 52, (28, 28, 40), botao=False)
    elif tr == 4:
        pileus(V, hx - 2, hy - 20, 52, (28, 28, 40), botao=True)
        V.circ(hx - 2, hy - 20 - 26, 3.8, OURO_L, OURO_D, .7)
    elif tr == 5:
        pileus(V, hx - 2, hy - 20, 54, ESCARLATE, botao=True)
        _arminho(V, [(hx - 26, hy - 20), (hx - 13, hy - 17), (hx, hy - 16), (hx + 13, hy - 17), (hx + 24, hy - 20)], 5)


# ===================================================================== corpo (combate)
def _objeto_mao(V, it, x, y, ang, P):
    g = P["glow"]
    if it == "pena":
        _estilete(V, x + 2, y - 6, -1.0, 1.0)
    elif it == "livro":
        _codice(V, x - 2, y + 2, -.15, .8)
    elif it == "dedo":
        if g > .05:
            _silogismo(V, x + 8, y - 28, g)
    elif it == "codice":
        if g > .05:
            V.luz(x + 10, y - 14, 70, (255, 220, 120), 150 * g + 20)
        _codice(V, x + 8, y - 20, ang, 1.0, aberto=True, cruz=True)
    elif it == "codice_f":
        V.luz(x + 6, y - 6, 66, (255, 226, 140), 120)
        _codice(V, x + 12, y - 4, ang, 1.5, aberto=False)
        V.circ(x + 12, y - 6, 8, OURO_L, OURO_D, .8)
        V.poly([(x + 10.5, y - 13), (x + 13.5, y - 13), (x + 13.5, y - 8), (x + 18, y - 8), (x + 18, y - 5), (x + 13.5, y - 5), (x + 13.5, y + 1), (x + 10.5, y + 1), (x + 10.5, y - 5),
                (x + 6, y - 5), (x + 6, y - 8), (x + 10.5, y - 8)], (255, 250, 220), None)
    elif it == "estilete":
        _estilete(V, x + 2, y - 4, -.55 + ang * .9, 1.15, brilho=g > .3)
    elif it == "tabula":
        _tabula(V, x + 12, y - 8, -.12, 1.0, cortada=max(0.0, g - .2) * 1.2)


def _shoes(V, P, walk):
    for (sx, lift, far) in ((-8, 0, 0), (24, 0, 1)):
        x = sx
        y = -4
        if walk is not None:
            st = math.sin(walk * math.tau)
            ph = st if not far else -st
            x += ph * 8
            y -= max(0.0, ph) * 6
        col = (60, 40, 28) if not far else (46, 32, 22)
        V.poly([(x - 12, y - 7), (x + 5, y - 9), (x + 20, y - 3), (x + 24, y), (x + 20, y + 4), (x - 12, y + 4)], col, INK, 1.0)
        V.pline([(x - 8, y - 5), (x + 14, y - 5)], lit(col, .25), 1.0)


def _desenha(T, tr, P, ox=HERO_ANCHOR[0], oy=HERO_ANCHOR[1], k=1.0, sombra=True):
    V0 = Vista(T, ox, oy, k)
    if sombra:
        sombra_chao(V0, 140, 22, 3)
    V = Vista(T, ox, oy - P["hop"] * k, k)
    lean, cr, sw = P["lean"], P["crouch"], P["sway"]
    ytop = -118 + cr
    _shoes(V, P, P["walk"])
    # --- cappa
    Vb = V.sub(4, 0)
    sino_manto(Vb, ytop, -6, 30, 56, AZUL, sway=sw, folds=5, lean=lean, hem_wave=2.0, flare=1.25)
    Vb.pline(hem_pts(56, -6, sw, 2.0, -3.4), OURO, 2.4)
    if tr >= 2:
        Vb.pline(hem_pts(56, -6, sw, 2.0, -8.2), OURO_D, 1.1)
    if tr >= 4:
        Vb.pline(hem_pts(56, -6, sw, 2.0, -1.4), ESCARLATE, 2.2)
    if tr == 5:
        _arminho(Vb, hem_pts(56, -6, sw, 2.0, -13)[::2], 5)
    # abertura frontal: tunica clara em V
    fx = lean * .9
    op = [(10 + fx, ytop + 4), (26 + fx, ytop + 6), (50 + sw, -6), (16 + sw, -6)]
    V.gpoly(op, [lit(AZUL_T, .35), AZUL_T, dk(AZUL_T, .35)], None, 1.0, True)
    forro = ESCARLATE if tr >= 4 else CREME
    V.pline([(10 + fx, ytop + 4), (16 + sw, -6)], forro, 3.2)
    V.pline([(26 + fx, ytop + 6), (50 + sw, -6)], forro, 3.2)
    V.pline([(10 + fx, ytop + 4), (16 + sw, -6)], OURO, 1.0)
    V.pline([(26 + fx, ytop + 6), (50 + sw, -6)], OURO, 1.0)
    for j in range(4):                         # botoes da tunica
        V.circ(18 + fx * (1 - j * .2) + j * 1.5, ytop + 20 + j * 17, 1.9, OURO_L, OURO_D, .5)
    # cordao na cintura + borla
    V.pline([(-18, -62), (4, -58), (30, -61), (44, -64)], CREME, 3.0)
    V.pline([(30, -61), (33, -40), (31, -30)], CREME, 2.6)
    V.circ(31, -28, 3.6, OURO, OURO_D, .6)
    # faixa e bolsa
    V.pline([(24 + fx, ytop + 6), (2, ytop + 44), (-30, -64)], dk(COURO, .4), 4.0)
    V.pline([(24 + fx, ytop + 6), (2, ytop + 44), (-30, -64)], COURO, 2.0)
    V.gpoly([(-46, -72), (-18, -72), (-18, -44), (-46, -44)], [lit(COURO, .28), COURO, dk(COURO, .4)], INK, 1.0)
    V.poly([(-46, -72), (-18, -72), (-20, -60), (-32, -54), (-44, -60)], lit(COURO, .1), INK, .9)
    V.circ(-32, -57, 2.6, OURO, OURO_D, .6)
    # capuz arriado + liripipe
    V.tube([(-18, ytop + 2), (-26 + sw * .6, ytop + 28), (-26 + sw * 1.6, ytop + 62)], 14, 8, dk(AZUL, .05), dk(AZUL, .7), 1.0)
    V.gell(-2 + lean * .8, ytop - 2, 74, 28, [lit(AZUL, .14), AZUL, dk(AZUL, .45)], dk(AZUL, .7), 1.2)
    if tr == 5:
        _arminho(V, [(-34 + lean, ytop + 2), (-16 + lean, ytop + 9), (2 + lean, ytop + 11), (20 + lean, ytop + 9), (36 + lean, ytop + 2)], 6)
    else:
        V.arc(-2 + lean * .8, ytop + 1, 35, 12, math.pi * .06, math.pi * .94, OURO, 2.0)
    # pescoco
    hx, hy = 6 + lean * .8 + P["hx"], ytop - 30 + P["hy"]
    V.rect(hx - 7, hy + 16, 16, 18, dk(PELE, .12), dk(PELE, .6), .8, 4)
    # bracos
    shB = (lean - 22, ytop + 12)
    shA = (lean + 28, ytop + 12)
    for lado, sh, hand, it, ang in ((-1, shB, P["B"], P["itB"], 0.0), (1, shA, P["A"], P["itA"], P["angA"])):
        hand = (hand[0] + lean * .5, hand[1] + cr * .4)
        dist = math.hypot(hand[0] - sh[0], hand[1] - sh[1])
        ll = max(dist * .6, 26)
        el = ik2(sh, hand, ll, ll, 1 if lado > 0 else -1)
        for col, add in ((INK, 2.6), (AZUL_T if lado < 0 else lit(AZUL, .1), 0)):
            V.line(sh, el, col, 17 + add)
            V.line(el, hand, col, 14 + add)
            V.circ(el[0], el[1], 7 + add / 2, col)
        V.line((sh[0] - 3, sh[1] + 2), (el[0] - 2, el[1]), lit(AZUL_T, .22), 2.2)
        V.circ(hand[0], hand[1], 8.6, dk(AZUL, .1), dk(AZUL, .7), .8)
        V.circ(hand[0], hand[1], 8.8, None, OURO, 1.4)
        if it in ("livro", "pena", "codice", "codice_f", "estilete", "tabula", "dedo"):
            _objeto_mao(V, it, hand[0], hand[1], ang, P)
        if it == "dedo":
            mao(V, hand[0] + 3, hand[1] - 1, PELE, 6.6, -.12 + ang, dedo=True)
        elif it == "palma":
            if P["glow"] > .1:
                V.luz(hand[0], hand[1] - 8, 40, (255, 226, 140), 190 * P["glow"])
            mao(V, hand[0], hand[1] - 4, PELE, 7.0, punho=True)
            for f in range(4):
                a = -math.pi / 2 + (f - 1.5) * .34
                V.line((hand[0] + math.cos(a) * 4, hand[1] - 4 + math.sin(a) * 4), (hand[0] + math.cos(a) * 12, hand[1] - 4 + math.sin(a) * 12), PELE, 3.3)
        elif it == "mao_alta":
            mao(V, hand[0], hand[1] - 2, PELE, 6.8)
        elif it == "punho":
            mao(V, hand[0], hand[1] - 3, PELE, 7.0, punho=True)
        else:
            mao(V, hand[0] + 2, hand[1] - 1, PELE, 6.4, punho=True)
    # cabeca e chapeu
    _cabeca(V, hx, hy, tr, P)
    _chapeu(V, hx, hy, tr)
    if tr >= 2:
        V.circ(lean * .9 + 14, ytop + 6, 3.6, OURO_L, OURO_D, .8)       # fecho
    if tr >= 4:
        V.pline([(lean * .9 - 22, ytop + 5), (lean * .9 + 4, ytop + 20), (lean * .9 + 30, ytop + 7)], OURO, 1.5)
        V.circ(lean * .9 + 4, ytop + 20, 3.2, OURO_L, OURO_D, .7)


# ===================================================================== combate (cache)
_hc = {}


def hero_combate(nivel, nome, s, flash=0):
    """Quadro do heroi em combate (HERO_CW x HERO_CH, pes em HERO_ANCHOR). flash: 0 normal, 1 branco, 2 vermelho."""
    tr = tier(nivel)
    nm = nome or "idle"
    if nm in ("idle", ""):
        key_s = int(s * 6) % 16
        ss = key_s / 16.0
    elif nm == "vitoria":
        key_s = int(s * 12) % 40
        ss = key_s / 12.0
    elif nm in ("guarda", "guard"):
        key_s = min(int(s * 12), 6)
        ss = key_s / 12.0
    elif nm == "derrota":
        key_s = min(int(s * 14), 12)
        ss = key_s / 14.0
    else:
        key_s = min(int(s * 14), 14)
        ss = key_s / 14.0
    k = (tr, nm, key_s)
    sp = _hc.get(k)
    if sp is None:
        if len(_hc) > 520:
            _hc.clear()
        T = Tela(HERO_CW, HERO_CH, 2)
        _desenha(T, tr, pose(nm if nm != "" else "idle", ss))
        sp = _hc[k] = T.final()
    if flash:
        k2 = k + (flash,)
        f = _hc.get(k2)
        if f is None:
            f = sp.copy()
            f.fill((150, 150, 150, 0) if flash == 1 else (140, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
            _hc[k2] = f
        return f
    return sp


# ===================================================================== retrato
_hr = {}


def hero_retrato(size=96, nivel=1, mood="sorriso"):
    """Retrato redondo do Bacharel (moldura dourada, fundo azul de vitral)."""
    tr = tier(nivel)
    k = (size, tr, mood)
    s = _hr.get(k)
    if s is None:
        ss = 2
        T = Tela(size, size, ss)
        S = T.S
        R = size * ss / 2.0
        for i in range(int(R), 0, -2):
            f = i / R
            c = mix((70, 96, 190), (22, 30, 80), f)
            pygame.draw.circle(S, c, (int(R), int(R)), i)
        T.luz(size * .5, size * .42, size * .5, (255, 226, 150), 120)
        P = pose("idle", 0.0)
        P.update(boca=mood, olho="aberto")
        kk = size / 80.0
        # cabeca em (hx,hy)=(6,-148) local -> centro do retrato
        _desenha(T, tr, P, ox=size * .5 - 6 * kk, oy=size * .47 + 148 * kk, k=kk, sombra=False)
        mask = pygame.Surface(S.get_size(), pygame.SRCALPHA)
        pygame.draw.circle(mask, (255, 255, 255, 255), (int(R), int(R)), int(R - ss))
        S.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        w = max(2, int(size * .06 * ss))
        pygame.draw.circle(S, (30, 20, 6), (int(R), int(R)), int(R - 1), w + ss)
        pygame.draw.circle(S, OURO, (int(R), int(R)), int(R - ss), w)
        pygame.draw.circle(S, OURO_L, (int(R), int(R)), int(R - ss - w * .45), max(1, ss))
        s = _hr[k] = T.final()
    return s


# ===================================================================== escudo de luz
_esc = {}


def escudo_luz(S, cx, cy, t, r=80):
    """Escudo de luz com cruz (Defender): disco translucido dourado-azulado com cruz luminosa."""
    base = _esc.get(r)
    if base is None:
        T = Tela(2 * r + 20, 2 * r + 20, 2)
        V = Vista(T, r + 10, r + 10)
        V.luz(0, 0, r + 8, (120, 160, 255), 150)
        V.circ(0, 0, r * .86, (60, 100, 200, 90), (200, 225, 255, 230), 2.2)
        V.circ(0, 0, r * .72, None, (255, 240, 180, 200), 1.4)
        for a in range(0, 360, 30):
            ar = math.radians(a)
            V.line((math.cos(ar) * r * .72, math.sin(ar) * r * .72), (math.cos(ar) * r * .86, math.sin(ar) * r * .86), (255, 240, 180), 1.4)
        kk = r * .45
        V.poly([(-kk * .13, -kk), (kk * .13, -kk), (kk * .13, -kk * .3), (kk * .6, -kk * .3), (kk * .6, kk * .0), (kk * .13, kk * .0), (kk * .13, kk * .9), (-kk * .13, kk * .9),
                (-kk * .13, kk * .0), (-kk * .6, kk * .0), (-kk * .6, -kk * .3), (-kk * .13, -kk * .3)], (255, 244, 190), OURO_D, 1.2)
        base = _esc[r] = T.final()
    a = 190 + int(50 * math.sin(t * 6))
    im = base.copy()
    im.set_alpha(max(0, min(255, a)))
    sc = 1.0 + .04 * math.sin(t * 6)
    if abs(sc - 1) > .005:
        im = pygame.transform.rotozoom(im, math.sin(t * 2) * 4, sc)
    S.blit(im, im.get_rect(center=(int(cx), int(cy))))


# ===================================================================== exploracao
def _pequeno(T, direc, ph, tr, estado):
    """Heroi pequeno: direc 'S','N','E' (W = E espelhado). Pes em (40,104)."""
    dano = estado == "dano"
    if direc == "E":
        P = pose("idle", 0.0)
        P.update(A=(46, -92), B=(-22, -88), olho="aberto", boca="n" if not dano else "o", sobr="n", itA="pena" if False else None, itB="livro",
                 walk=ph, sway=(math.sin((ph or 0) * math.tau) * 3 if ph is not None else 0), hop=(abs(math.sin((ph or 0) * math.tau)) * 5 if ph is not None else 0))
        if dano:
            P.update(A=(58, -140), B=(-40, -130), olho="fechado", sobr="triste", lean=-6)
        _desenha(T, tr, P, ox=40, oy=104, k=.5, sombra=True)
        return
    V = Vista(T, 40, 104)
    mov = ph is not None
    phi = (ph or 0.0) * math.tau
    st = math.sin(phi)
    bob = abs(math.sin(phi)) * 2.0 if mov else 0
    sway = st * 2.4 if mov else 0
    cor = AZUL
    sombra_chao(V, 50, 11, 1)
    for s_ in (-1, 1):
        lift = max(0, st * s_) * 5 if mov else 0
        V.ell(s_ * 8, -3 - lift, 13, 7, (60, 40, 28), INK, .9)
    ytop = -60 - bob * .6
    wt, wh = 16, 26
    sino_manto(V, ytop, -5, wt, wh, cor, sway=sway * .6, folds=3, hem_wave=1.4, base_ol=1.1, lean=0)
    V.pline(hem_pts(wh, -5, sway * .6, 1.4, -2.4), OURO, 1.7)
    if tr >= 4:
        V.pline(hem_pts(wh, -5, sway * .6, 1.4, -.8), ESCARLATE, 1.6)
    cb = COURO
    if direc == "S":
        V.gpoly([(-4, ytop + 6), (4, ytop + 6), (8, -7), (-8, -7)], [AZUL_T, dk(AZUL_T, .3)], None, 1.0, True)
        for s_ in (-1, 1):
            V.pline([(s_ * 4, ytop + 6), (s_ * 8, -7)], OURO, 1.5)
        V.pline([(-12, ytop + 6), (12, -26)], dk(cb, .3), 3.0)
        V.pline([(-12, ytop + 6), (12, -26)], cb, 1.4)
        V.gpoly([(-24, -34), (-10, -34), (-10, -20), (-24, -20)], [lit(cb, .2), dk(cb, .35)], INK, .9)
        V.circ(-17, -27, 1.6, OURO)
    else:
        V.pline([(0, ytop + 8), (1 + sway * .3, -8)], dk(cor, .5), 1.0)
        V.pline([(-12, ytop + 6), (12, -24)], dk(cb, .3), 3.0)
        V.gpoly([(8, -32), (21, -32), (21, -18), (8, -18)], [lit(cb, .2), dk(cb, .35)], INK, .9)
    V.gell(0, ytop - 1, 36, 13, [lit(cor, .12), cor, dk(cor, .45)], dk(cor, .7), 1.0)
    if tr == 5:
        _arminho(V, [(-14, ytop + 1), (-7, ytop + 4), (0, ytop + 5), (7, ytop + 4), (14, ytop + 1)], 4)
    else:
        V.arc(0, ytop + 1, 17, 5, math.pi * .08, math.pi * .92, OURO, 1.3)
    if direc == "N":
        V.tube([(-3, ytop + 2), (-5, ytop + 16), (-4 + sway * .4, ytop + 30)], 7, 4, dk(cor, .05), dk(cor, .7), .8)
    arm_c = AZUL_T
    for s_ in (-1, 1):
        sh = (s_ * 15, ytop + 5)
        if direc == "S":
            h_ = (s_ * 19, -39 + (st * s_ * 2 if mov else 0))
            if s_ > 0:
                h_ = (19, -39 + (st * 2 if mov else 0))
        else:
            h_ = (s_ * 19, -38 + (st * s_ * 2 if mov else 0))
        if dano:
            h_ = (s_ * 26, -62)
        for col, add in ((INK, 1.8), (arm_c, 0)):
            V.line(sh, h_, col, 9 + add)
        V.circ(h_[0], h_[1], 4.3, PELE, dk(PELE, .6), .8)
        if direc == "S" and s_ > 0:
            livro_obj(V, h_[0] + 1, h_[1] - 5, -.1, 12, 15, (146, 34, 44))
            V.circ(h_[0], h_[1] + 1, 3.6, PELE, dk(PELE, .6), .7)
    hy = ytop - 15
    r = 13.4
    cab = CABELO
    V.gell(0, hy, r * 2.2, r * 2.25, [lit(cab, .14), cab, dk(cab, .4)], dk(cab, .7), 1.0)
    if direc == "S":
        V.gell(0, hy + 2, r * 1.8, r * 1.92, [lit(PELE, .16), PELE, dk(PELE, .2)], dk(PELE, .62), 1.0)
        V.poly([(-r * .92, hy - 2), (-r * .84, hy - 9), (-r * .3, hy - 12), (r * .1, hy - 8), (r * .5, hy - 12), (r * .88, hy - 8), (r * .92, hy - 2), (r * .6, hy - 5), (0, hy - 6), (-r * .6, hy - 5)], cab, None)
        for s_ in (-1, 1):
            if dano:
                V.pline([(s_ * 5 - 2, hy + 1), (s_ * 5 + 2, hy + 3)], INK, 1.1)
            else:
                V.ell(s_ * 5, hy + 1.8, 5.2, 5.6, (253, 251, 246), INK, .6)
                V.ell(s_ * 5, hy + 2.2, 3.4, 4.2, IRIS, None)
                V.circ(s_ * 5, hy + 2.2, 1.3, (16, 14, 22))
                V.circ(s_ * 5 - .9, hy + 1.2, .9, (255, 255, 255))
        V.pline([(-8, hy - 4), (-3, hy - 4.6)], dk(cab, .2), 1.1)
        V.pline([(8, hy - 4), (3, hy - 4.6)], dk(cab, .2), 1.1)
        if dano:
            V.ell(0, hy + 8.4, 4, 5, (90, 22, 24), INK, .6)
        else:
            V.arc(0, hy + 6, 3.6, 2.4, math.pi * .1, math.pi * .9, INK, 1.0)
        for s_ in (-1, 1):
            V.ell(s_ * 8.4, hy + 6.4, 4, 2.4, (232, 124, 112, 100))
        if tr <= 2:
            V.ell(0, hy - 13, 9, 3, PELE, dk(PELE, .5), .6)
    elif direc == "N":
        for k in range(6):
            V.pline([(-8 + k * 3.2, hy - 8), (-9 + k * 3.6, hy + 9)], lit(cab, .2), .7)
        if tr <= 2:
            V.ell(0, hy - 10, 8, 3.2, PELE, dk(PELE, .5), .6)
        V.ell(-r * .98, hy + 3, 3, 6, PELE, dk(PELE, .6), .6)
        V.ell(r * .98, hy + 3, 3, 6, PELE, dk(PELE, .6), .6)
    ox = 0
    if tr == 3:
        pileus(V, ox, hy - 8, 26, (28, 28, 40), botao=False)
    elif tr == 4:
        pileus(V, ox, hy - 8, 26, (28, 28, 40), botao=True)
    elif tr == 5:
        pileus(V, ox, hy - 8, 27, ESCARLATE, botao=True)
        _arminho(V, [(ox - 13, hy - 8), (ox, hy - 6), (ox + 13, hy - 8)], 3.4)


_hs = {}


def hero_sala(S, x, y, t, face, moving, nivel=1, estado="normal"):
    """Heroi da exploracao. (x, y) = pes. face: N/S/E/W. estado: normal|dano."""
    tr = tier(nivel)
    d = "E" if face in ("E", "W") else face
    q = (int(t * 10) % 8) if moving else None
    k = (tr, d, q, estado)
    sp = _hs.get(k)
    if sp is None:
        if len(_hs) > 300:
            _hs.clear()
        T = Tela(80, 112, 3)
        _pequeno(T, d, None if q is None else q / 8.0, tr, estado)
        sp = _hs[k] = T.final()
    if face == "W":
        kw = k + ("w",)
        sw_ = _hs.get(kw)
        if sw_ is None:
            sw_ = _hs[kw] = pygame.transform.flip(sp, True, False)
        sp = sw_
    if estado == "dano" and int(t * 20) % 2 == 0:
        kf = k + ("f", face == "W")
        f = _hs.get(kf)
        if f is None:
            f = sp.copy()
            f.fill((120, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
            _hs[kf] = f
        sp = f
    S.blit(sp, (int(x) - 40, int(y) - 104))


# ===================================================================== ficha (frontal)
def _frontal(tr):
    return dict(tunica=AZUL_T, capa=AZUL, forro=ESCARLATE if tr >= 4 else (214, 200, 170), capuz="forrado" if tr != 5 else "baixo", capuz_cor=AZUL, cabelo=CABELO, tonsura=(tr <= 2),
                pele=PELE, mao_e="livro", mao_d="pena", humor="feliz", cinto="couro", livro_cor=(146, 34, 44), jovem=True, bolsa=True, pos_e=(-40, -74), pos_d=(42, -92),
                chapeu="pileus" if tr >= 3 else None, chapeu_cor=ESCARLATE if tr == 5 else (28, 28, 38), medalha=OURO if tr >= 4 else None, olhos=IRIS)


_hspr = {}


def hero_sprite(which=0, nivel=1):
    """Heroi frontal (150x200) para a ficha/inventario. which: 0 normal, 2 flash vermelho."""
    tr = tier(nivel)
    k = (tr, which)
    if k not in _hspr:
        T = Tela(150, 200, 2)
        figura_frontal(T, 75, 190, _frontal(tr), 0.0, .78)
        s = T.final()
        if which:
            s = s.copy()
            s.fill((130, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
        _hspr[k] = s
    return _hspr[k]
