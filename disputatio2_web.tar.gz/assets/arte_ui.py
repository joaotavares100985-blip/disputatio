# -*- coding: utf-8 -*-
"""Skin gotica da interface: paineis de couro/pergaminho com filetes de ouro duplos e cantoneiras trifoliadas,
botoes com cantos chanfrados, medalhoes redondos, barras com engaste, baloes, cartoes, joystick.
Tudo em cache por tamanho/estado; nada de arquivos externos."""
import math
import random

import pygame

import arte_base as B
from arte_base import mix, esc, surf, conv

OURO = (214, 170, 60)
OURO_C = (255, 228, 140)
OURO_S = (120, 86, 24)
_C = {}


def _noise(s, k=.7, seed=1):
    B.granulado(s, s.get_rect(), k, seed)


def _trifolio_canto(S, x, y, r, col, dx, dy):
    """Cantoneira: pequeno trifolio de ouro apontando para fora do canto (dx,dy = sinais)."""
    for (ox, oy) in ((0, 0), (r * 1.5, 0), (0, r * 1.5)):
        pygame.draw.circle(S, (30, 20, 8), (int(x + dx * ox), int(y + dy * oy)), r + 1)
        pygame.draw.circle(S, col, (int(x + dx * ox), int(y + dy * oy)), r)
    pygame.draw.circle(S, OURO_C, (int(x - dx * 1), int(y - dy * 1)), max(1, r // 2))


def _gradiente(w, h, c1, c2, rad, a=255):
    g = B.vgrad(w, h, c1, c2).convert_alpha() if pygame.display.get_surface() else B.vgrad(w, h, c1, c2)
    g = g.convert_alpha() if g.get_flags() & pygame.SRCALPHA == 0 else g
    m = surf(w, h)
    pygame.draw.rect(m, (255, 255, 255, a), (0, 0, w, h), 0, rad)
    g.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    return g


def painel(w, h, alpha=236, estilo="couro"):
    k = ("p", w, h, alpha, estilo)
    s = _C.get(k)
    if s is None:
        if len(_C) > 220:
            _C.clear()
        rad = 14
        if estilo == "pergaminho":
            c1, c2 = (240, 226, 188), (212, 190, 144)
            borda = (110, 76, 30)
        else:
            c1, c2 = (52, 34, 20), (28, 17, 9)
            borda = OURO
        s = _gradiente(w, h, c1, c2, rad, alpha)
        _noise(s, .6 if estilo == "couro" else .5, w + h)
        # realce superior
        hl = surf(w - 12, 14)
        pygame.draw.rect(hl, (255, 255, 255, 26 if estilo == "couro" else 60), hl.get_rect(), 0, 10)
        s.blit(hl, (6, 4))
        # filete duplo: grosso de ouro + fino interno
        pygame.draw.rect(s, (24, 14, 6), (0, 0, w, h), 4, rad)
        pygame.draw.rect(s, borda, (1, 1, w - 2, h - 2), 3, rad)
        pygame.draw.rect(s, esc(borda, 1.25), (1, 1, w - 2, 1), 0)
        pygame.draw.rect(s, esc(borda, .62), (7, 7, w - 14, h - 14), 1, rad - 4)
        pygame.draw.rect(s, esc(borda, 1.0), (9, 9, w - 18, h - 18), 1, rad - 6)
        # cantoneiras trifoliadas
        if w >= 90 and h >= 60:
            for (x, y, dx, dy) in ((11, 11, 1, 1), (w - 12, 11, -1, 1), (11, h - 12, 1, -1), (w - 12, h - 12, -1, -1)):
                _trifolio_canto(s, x, y, 3, esc(borda, 1.1), dx, dy)
        if w >= 200:
            for x in (w // 2,):
                for y in (4, h - 5):
                    pygame.draw.polygon(s, esc(borda, 1.1), [(x - 6, y), (x, y - 3), (x + 6, y), (x, y + 3)])
        s = conv(s)
        _C[k] = s
    return s


def botao(w, h, c1, c2, dim=False, foco=False):
    """Base do botao (SRCALPHA w+10 x h+12): chanfros nos cantos, pergaminho, filetes de ouro, cantoneiras."""
    k = ("b", w, h, c1, c2, dim)
    s = _C.get(k)
    if s is None:
        if len(_C) > 220:
            _C.clear()
        ch = max(8, min(14, h // 4))
        out = surf(w + 10, h + 12)
        shp = [(ch, 0), (w - ch, 0), (w, ch), (w, h - ch), (w - ch, h), (ch, h), (0, h - ch), (0, ch)]
        pygame.draw.polygon(out, (0, 0, 0, 120), [(x + 3, y + 7) for x, y in shp])
        g = B.vgrad(w, h, c1, c2).convert_alpha() if pygame.display.get_surface() else B.vgrad(w, h, c1, c2)
        m = surf(w, h)
        pygame.draw.polygon(m, (255, 255, 255, 255), shp)
        gs = surf(w, h)
        gs.blit(g, (0, 0))
        gs.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        _noise(gs, .35, w * 3 + h)
        gs.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        out.blit(gs, (0, 0))
        borda = (96, 66, 22) if not dim else (70, 62, 46)
        ouro = OURO if not dim else (110, 96, 68)
        pygame.draw.polygon(out, (28, 16, 6), shp, 5)
        pygame.draw.polygon(out, ouro, shp, 3)
        pygame.draw.polygon(out, esc(ouro, 1.3), [(ch + 1, 1), (w - ch - 1, 1)] + [(w - ch - 1, 1)], 1) if False else None
        ins = [(ch + 3, 6), (w - ch - 3, 6), (w - 6, ch + 3), (w - 6, h - ch - 3), (w - ch - 3, h - 6), (ch + 3, h - 6), (6, h - ch - 3), (6, ch + 3)]
        pygame.draw.polygon(out, borda, ins, 1)
        hl = surf(w - 2 * ch, max(4, h // 4))
        pygame.draw.rect(hl, (255, 255, 255, 60), hl.get_rect(), 0, 6)
        out.blit(hl, (ch, 4))
        for (x, y, dx, dy) in ((ch - 3, ch - 3, 1, 1), (w - ch + 3, ch - 3, -1, 1), (ch - 3, h - ch + 3, 1, -1), (w - ch + 3, h - ch + 3, -1, -1)):
            for (ox, oy) in ((0, 0), (4, -4 * 0), (0, 4)):
                pygame.draw.circle(out, (28, 16, 6), (int(x + dx * ox * 1.4), int(y + dy * oy * 1.4)), 3)
                pygame.draw.circle(out, ouro, (int(x + dx * ox * 1.4), int(y + dy * oy * 1.4)), 2)
        s = conv(out)
        _C[k] = s
    return s


def medalhao(r, c1, c2, dim=False):
    k = ("m", r, c1, c2, dim)
    s = _C.get(k)
    if s is None:
        if len(_C) > 220:
            _C.clear()
        out = surf(2 * r + 10, 2 * r + 12)
        cx, cy = r + 4, r + 4
        pygame.draw.circle(out, (0, 0, 0, 120), (cx + 2, cy + 6), r)
        pygame.draw.circle(out, (26, 14, 6), (cx, cy), r)
        ouro = OURO if not dim else (110, 96, 68)
        pygame.draw.circle(out, ouro, (cx, cy), r - 1)
        pygame.draw.circle(out, esc(ouro, .55), (cx, cy), r - 5)
        n = 10
        for i in range(n):
            pygame.draw.circle(out, mix(c2, c1, i / (n - 1)), (cx, int(cy - i * r * .035)), int((r - 7) * (1 - i * .06)))
        pygame.draw.circle(out, esc(ouro, 1.2), (cx, cy), r - 3, 1)
        for i in range(12):
            a = i * math.pi / 6
            pygame.draw.circle(out, esc(ouro, 1.3), (int(cx + math.cos(a) * (r - 3)), int(cy + math.sin(a) * (r - 3))), 1)
        pygame.draw.circle(out, (255, 255, 255, 40) if False else mix(c1, (255, 255, 255), .5), (cx - r // 3, cy - r // 3), max(2, r // 6))
        s = conv(out)
        _C[k] = s
    return s


def barra(S, rect, frac, c1, c2, label=None, lsz=20):
    rect = pygame.Rect(rect)
    frac = max(0.0, min(1.0, frac))
    k = ("br", rect.w, rect.h, c1, c2, int(frac * rect.w))
    s = _C.get(k)
    if s is None:
        if len(_C) > 220:
            _C.clear()
        w, h = rect.size
        s = surf(w, h)
        r = h // 2
        pygame.draw.rect(s, (12, 7, 3), (0, 0, w, h), 0, r)
        inner = pygame.Rect(3, 3, w - 6, h - 6)
        pygame.draw.rect(s, (34, 22, 12), inner, 0, r - 2)
        fw = int(inner.w * frac)
        if fw > 1:
            f = pygame.Rect(inner.x, inner.y, fw, inner.h)
            pygame.draw.rect(s, c2, f, 0, r - 2)
            pygame.draw.rect(s, c1, (f.x, f.y, f.w, max(2, f.h // 2)), 0, r - 3)
            pygame.draw.line(s, (255, 255, 255), (f.x + 4, f.y + 1), (f.right - 5, f.y + 1))
            for x in range(f.x + 18, f.right - 4, 18):
                pygame.draw.line(s, esc(c2, .7), (x, f.y + 2), (x, f.bottom - 3))
        pygame.draw.rect(s, OURO_S, (0, 0, w, h), 3, r)
        pygame.draw.rect(s, OURO, (1, 1, w - 2, h - 2), 1, r)
        for x in (r - 1, w - r):
            pygame.draw.circle(s, OURO, (x, h // 2), 3)
            pygame.draw.circle(s, (30, 20, 8), (x, h // 2), 3, 1)
        s = conv(s)
        _C[k] = s
    S.blit(s, rect.topleft)
    return rect


def caixa_balao(S, rect, tail=None, col=(250, 242, 220), borda=(90, 60, 20)):
    """Caixa de fala de pergaminho com filetes e cantoneiras (desenhada direto, e barata)."""
    r = pygame.Rect(rect)
    pygame.draw.rect(S, (14, 8, 4), r.move(3, 5), 0, 14)
    if tail:
        tx = max(r.x + 26, min(r.right - 26, tail[0]))
        if tail[1] > r.bottom:
            pts = [(tx - 12, r.bottom - 3), (tx + 12, r.bottom - 3), (tail[0], tail[1])]
        else:
            pts = [(tx - 12, r.y + 3), (tx + 12, r.y + 3), (tail[0], tail[1])]
        pygame.draw.polygon(S, col, pts)
        pygame.draw.polygon(S, borda, pts, 3)
    pygame.draw.rect(S, col, r, 0, 14)
    pygame.draw.rect(S, mix(col, (255, 255, 255), .5), (r.x + 8, r.y + 5, r.w - 16, 5), 0, 3)
    pygame.draw.rect(S, borda, r, 3, 14)
    pygame.draw.rect(S, OURO, r.inflate(-8, -8), 1, 10)
    for (x, y) in ((r.x + 9, r.y + 9), (r.right - 10, r.y + 9), (r.x + 9, r.bottom - 10), (r.right - 10, r.bottom - 10)):
        pygame.draw.circle(S, borda, (x, y), 3)
        pygame.draw.circle(S, OURO, (x, y), 2)


def cartao(S, rr, col, dim=False):
    """Cartao de resposta (parchment com moldura gotica)."""
    w, h = rr.size
    k = ("c", w, h, col, dim)
    s = _C.get(k)
    if s is None:
        if len(_C) > 220:
            _C.clear()
        s = surf(w + 6, h + 8)
        pygame.draw.rect(s, (0, 0, 0, 130), (3, 5, w, h), 0, 16)
        g = _gradiente(w, h, mix(col, (255, 255, 255), .35), esc(col, .9), 16)
        _noise(g, .4, w + h)
        s.blit(g, (0, 0))
        borda = (120, 84, 24) if not dim else (90, 80, 60)
        pygame.draw.rect(s, (28, 16, 6), (0, 0, w, h), 5, 16)
        pygame.draw.rect(s, borda, (1, 1, w - 2, h - 2), 3, 16)
        pygame.draw.rect(s, OURO if not dim else (130, 116, 84), (7, 7, w - 14, h - 14), 1, 11)
        for (x, y, dx, dy) in ((13, 13, 1, 1), (w - 14, 13, -1, 1), (13, h - 14, 1, -1), (w - 14, h - 14, -1, -1)):
            _trifolio_canto(s, x, y, 3, OURO if not dim else (130, 116, 84), dx, dy)
        s = conv(s)
        _C[k] = s
    S.blit(s, rr.topleft)


def joy_base(R):
    k = ("jb", R)
    s = _C.get(k)
    if s is None:
        s = surf(2 * R + 8, 2 * R + 8)
        c = (R + 4, R + 4)
        pygame.draw.circle(s, (14, 9, 5, 150), c, R)
        pygame.draw.circle(s, (214, 170, 60, 210), c, R, 4)
        pygame.draw.circle(s, (120, 86, 24, 220), c, R - 6, 1)
        pygame.draw.circle(s, (214, 170, 60, 120), c, int(R * .62), 2)
        # rosa dos ventos em quadrifolio
        for a in range(4):
            ang = a * math.pi / 2
            pygame.draw.circle(s, (214, 170, 60, 90), (int(c[0] + math.cos(ang) * R * .45), int(c[1] + math.sin(ang) * R * .45)), int(R * .22), 2)
        for d, (dx, dy) in {"u": (0, -1), "d": (0, 1), "l": (-1, 0), "r": (1, 0)}.items():
            x, y = int(c[0] + dx * (R - 14)), int(c[1] + dy * (R - 14))
            pts = {"l": [(x + 7, y - 7), (x - 7, y), (x + 7, y + 7)], "r": [(x - 7, y - 7), (x + 7, y), (x - 7, y + 7)],
                   "u": [(x - 7, y + 7), (x, y - 7), (x + 7, y + 7)], "d": [(x - 7, y - 7), (x, y + 7), (x + 7, y - 7)]}[d]
            pygame.draw.polygon(s, (214, 170, 60, 220), pts)
        s = conv(s)
        _C[k] = s
    return s


def joy_knob():
    s = _C.get("jk")
    if s is None:
        s = surf(60, 60)
        pygame.draw.circle(s, (0, 0, 0, 90), (31, 34), 28)
        pygame.draw.circle(s, (120, 86, 24), (30, 30), 28)
        pygame.draw.circle(s, (255, 228, 140), (30, 30), 25)
        pygame.draw.circle(s, (214, 160, 50), (30, 33), 20)
        B.cruz_latina(s, 30, 30, 26, (120, 70, 16), None, 5)
        pygame.draw.circle(s, (255, 250, 220), (21, 20), 7)
        pygame.draw.circle(s, (150, 104, 30), (30, 30), 28, 3)
        s = conv(s)
        _C["jk"] = s
    return s
