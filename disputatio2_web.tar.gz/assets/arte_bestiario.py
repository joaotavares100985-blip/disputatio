# -*- coding: utf-8 -*-
"""Bestiario das FALACIAS: cada inimigo e um personagem/objeto simbolico coerente com o proprio nome (nada de "bestas" genericas).

Caixa de pecas reutilizaveis: figura humana (estudante / mestre / monge, de arte_figuras), cabeca com mascara, hábito/cappa, maos, livro, rolo, pena,
placa com texto, portas, balanca, espelho, galo e sol, peixe, ampulheta, astrolabio, roda, chamas, nuvem, fantasma...
Receita por id (RECEITAS) ou, para ids novos, por palavra-chave do nome / pela 'forma' do conteudo.

desenhar(V, iid, d, ph) -> True se desenhou.  V = Vista com origem nos pes (x=0 centro, y para cima negativo); sprite cabe em ~210 px de altura.
"""
import math

import pygame

import arte_figuras as AF
from arte_kit import mix, lit, dk, catmull, olho, boca, INK, PELE, OURO, OURO_L, OURO_D, BRANCO
from arte_vista import Vista

TAU = math.tau
_FT = {}


# ===================================================================== pecas basicas
def _txt(V, s, x, y, size, col=(250, 240, 210), ol=(30, 20, 14), bold=True):
    ss = V.T.ss
    X, Y = V.pt(x, y)
    sz = max(8, int(size * V.k * ss))
    f = _FT.get(sz)
    if f is None:
        f = _FT[sz] = pygame.font.Font(None, sz)
        f.set_bold(bold)
    im, om = f.render(s, True, col), f.render(s, True, ol)
    r = im.get_rect(center=(int(X * ss), int(Y * ss)))
    o = max(1, ss)
    for dx, dy in ((-o, 0), (o, 0), (0, -o), (0, o), (o, o), (-o, -o)):
        V.T.S.blit(om, r.move(dx, dy))
    V.T.S.blit(im, r)


def _hum(V, e, ph, mood=None, esc=1.0, abre=0.0, dx=0.0, dy=0.0):
    AF.figura_frontal(V.T, V.ox + dx * V.k, V.oy + dy * V.k, e, ph, V.k * esc, mood, abre=abre, sombra=False)


def _punho(V, x, y, r=6.4):
    AF.mao(V, x, y, PELE, r, punho=True)


def _olhos(V, x, y, sep, r, mood="neutro", iris=(70, 46, 30), look=(0, 0)):
    for s in (-1, 1):
        olho(V, x + s * sep, y, r, mood, look, iris, s)


def _bola_texto(V, x, y, r, s, cor=(252, 246, 226), tam=26):
    V.circ(x, y, r, cor, INK, 1.2)
    V.poly([(x - r * .3, y + r * .8), (x - r * .9, y + r * 1.5), (x + r * .1, y + r * .95)], cor, None)
    _txt(V, s, x, y + 1, tam, (60, 30, 90), (255, 255, 255))


def _fogo(V, x, y, k=1.0, ph=0.0):
    f = 1 + math.sin(ph * TAU * 2) * .12
    V.poly([(x - 9 * k, y), (x - 11 * k, y - 14 * k), (x - 4 * k, y - 26 * k * f), (x - 1 * k, y - 18 * k), (x + 5 * k, y - 36 * k * f), (x + 9 * k, y - 18 * k), (x + 12 * k, y - 8 * k), (x + 8 * k, y)],
           (240, 90, 30), (150, 40, 16), .9)
    V.poly([(x - 5 * k, y), (x - 5 * k, y - 10 * k), (x, y - 20 * k * f), (x + 3 * k, y - 10 * k), (x + 6 * k, y)], (255, 200, 70), None)
    V.poly([(x - 2 * k, y), (x - 2 * k, y - 6 * k), (x + 1 * k, y - 11 * k), (x + 3 * k, y)], (255, 244, 190), None)
    V.luz(x, y - 14 * k, 34 * k, (255, 150, 60), 120)


def _nuvem(V, x, y, k=1.0, cor=(150, 160, 190)):
    for (dx, dy, r) in ((-24, 4, 17), (-6, -6, 22), (16, -2, 20), (30, 6, 14), (4, 8, 18)):
        V.circ(x + dx * k, y + dy * k, r * k, lit(cor, .16), None)
    for (dx, dy, r) in ((-24, 4, 17), (-6, -6, 22), (16, -2, 20), (30, 6, 14)):
        V.circ(x + dx * k, y + dy * k, r * k, None, dk(cor, .45), 1.1)
    for (dx, dy, r) in ((-24, 4, 17), (-6, -6, 22), (16, -2, 20), (30, 6, 14), (4, 8, 18)):
        V.circ(x + dx * k, y + dy * k, r * k - 1, lit(cor, .16), None)


def _livro_pe(V, x, y, w, h, cor, aberto=False):
    AF.livro_obj(V, x, y, 0, w, h, cor, aberto=aberto)


def _placa(V, x, y, w, h, s, cor=(228, 206, 150), tam=24, haste=True):
    if haste:
        V.rect(x - 3, y + h / 2 - 4, 6, 70, (110, 74, 40), INK, 1.0)
    V.gpoly([(x - w / 2, y - h / 2), (x + w / 2, y - h / 2), (x + w / 2, y + h / 2), (x - w / 2, y + h / 2)], [lit(cor, .22), cor, dk(cor, .3)], INK, 1.3)
    V.pline([(x - w / 2 + 3, y - h / 2 + 3), (x + w / 2 - 3, y - h / 2 + 3)], lit(cor, .5), 1.0)
    _txt(V, s, x, y, tam, (92, 30, 36), (255, 244, 214))


def _portinha(V, x, y, w, h, cor=(130, 84, 46), aberta=False):
    pts = [(x - w / 2, y)] + [(x + (w / 2) * math.cos(math.pi + math.pi * i / 10), y - h + w / 2 + (w / 2) * math.sin(math.pi + math.pi * i / 10)) for i in range(11)] + [(x + w / 2, y)]
    V.gpoly(pts, [lit(cor, .22), cor, dk(cor, .4)], INK, 1.3, True)
    for j in range(1, 4):
        V.pline([(x - w / 2 + j * w / 4, y), (x - w / 2 + j * w / 4, y - h * .8)], dk(cor, .5), .9)
    V.circ(x + w * .26, y - h * .42, 2.2, OURO, OURO_D, .6)


# ===================================================================== estilos humanos
def _est(tunica, **kw):
    e = dict(tunica=tunica, tonsura=True, jovem=True, cabelo=(120, 86, 56), cinto="couro", humor="sereno")
    e.update(kw)
    return e


def _mes(cor, **kw):
    e = dict(tunica=dk(cor, .3), capa=cor, forro=lit(cor, .55), capuz="forrado", capuz_cor=cor, chapeu="pileus", chapeu_cor=dk(cor, .5), barba="curta", barba_cor=(214, 214, 218),
             cabelo=(214, 214, 218), cinto="couro", humor="sereno")
    e.update(kw)
    return e


def _monge(V, cor, ph=0.0, mood="neutro", k=1.0, olhos=(255, 236, 160), rosto_visivel=True):
    """Monge/herege de capuz: manto em sino, capuz e rosto na sombra (olhos acesos)."""
    S = V.sub(0, 0, k)
    AF.sino_manto(S, -118, -6, 30, 58, cor, folds=4, sway=math.sin(ph * TAU) * 1.5)
    S.pline(AF.hem_pts(58, -6, 0, 2.0, -3.4), lit(cor, .5), 1.6)
    S.gell(0, -134, 78, 72, [lit(cor, .14), cor, dk(cor, .5)], dk(cor, .7), 1.3)
    S.poly([(-16, -170), (4, -192), (24, -160)], cor, dk(cor, .7), 1.2)
    S.gell(0, -130, 46, 52, (22, 14, 28), None)
    S.gell(0, -127, 38, 44, [lit(PELE, .1), dk(PELE, .35), dk(PELE, .6)], None) if rosto_visivel else None
    for sx in (-1, 1):
        olho(S, sx * 9, -132, 5.4, mood if mood != "neutro" else "bravo", (0, 0), olhos, sx)
    S.pline([(-6, -112), (6, -112.8)], dk(PELE, .7), 1.4)
    for sx in (-1, 1):
        S.tube([(sx * 34, -108), (sx * 44, -82), (sx * 38, -60)], 17, 13, dk(cor, .2), dk(cor, .7), 1.0)
        S.circ(sx * 38, -58, 6.8, PELE, dk(PELE, .6), .8)


# ===================================================================== bestiario
def r_equivoco(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, pos_d=(52, -118), mao_e=None, mao_d=None, humor="feliz", chapeu="chaperon", chapeu_cor=lit(cor, .3), tonsura=False)
    _hum(V, e, ph, "feliz")
    _placa(V, 64, -126 + s, 54, 30, "CÃO", tam=26, haste=True)
    _punho(V, 52, -108)
    for (x, ic) in ((-50, "cao_tocha"), (-14, "estrela")):
        _bola_texto(V, x, -208 + (2 if ic == "estrela" else 0) + s * 2, 15, "", (240, 236, 250))
        V.icone(ic, x, -208, 22)


def r_anfibolia(V, cor, ph):
    s = math.sin(ph * TAU)
    AF.sino_manto(V, -118, -6, 30, 58, dk(cor, .25), folds=4, sway=s)
    V.pline(AF.hem_pts(58, -6, 0, 2.0, -3.4), OURO, 1.8)
    # duas faces de perfil, costas com costas (Jano)
    for sg, cc in ((-1, (252, 248, 238)), (1, (238, 232, 252))):
        x = sg * 12
        V.gell(x, -152, 40, 50, [lit(PELE, .12), PELE, dk(PELE, .2)], dk(PELE, .6), 1.1)
        V.poly([(x + sg * 20, -156), (x + sg * 30, -146), (x + sg * 21, -142)], PELE, dk(PELE, .6), .9)
        V.gell(x - sg * 3, -166, 36, 20, [lit(cor, .2), dk(cor, .3)], dk(cor, .7), 1.0)
        olho(V, x + sg * 9, -154, 4.6, "surpreso" if sg < 0 else "bravo", (sg, 0), (60, 90, 150), sg)
        V.pline([(x + sg * 8, -138), (x + sg * 18, -139)], dk(PELE, .6), 1.2)
    V.gell(0, -180, 54, 14, [lit(cor, .3), dk(cor, .3)], dk(cor, .7), 1.0)
    # placa de sinalizacao com duas setas opostas
    V.line((58, -4), (58, -170), (110, 74, 40), 5)
    V.line((57, -4), (57, -170), (160, 112, 64), 2)
    V.poly([(30, -176), (54, -176), (54, -160), (30, -160), (20, -168)], (230, 206, 150), INK, 1.2)
    V.poly([(62, -156), (86, -156), (96, -148), (86, -140), (62, -140)], (230, 206, 150), INK, 1.2)
    for sx in (-1, 1):
        V.tube([(sx * 30, -108), (sx * 44, -92 + s * sx * 2), (sx * 44, -70)], 17, 13, dk(cor, .2), dk(cor, .7), 1.0)
        V.circ(sx * 44, -68, 6.6, PELE, dk(PELE, .6), .8)
    V.circ(58, -150, 6.6, PELE, dk(PELE, .6), .8)


def _bloco(V, x, y, w, h, cor, ol=INK):
    V.gpoly([(x - w / 2, y - h), (x + w / 2, y - h), (x + w / 2, y), (x - w / 2, y)], [lit(cor, .25), cor, dk(cor, .45)], ol, 1.4)
    V.poly([(x - w / 2, y - h), (x + w / 2, y - h), (x + w / 2 - 5, y - h + 6), (x - w / 2 + 5, y - h + 6)], lit(cor, .38), None)
    V.pline([(x - w / 2 + 2, y - h * .55), (x + w / 2 - 2, y - h * .55)], dk(cor, .5), .9)


def r_composicao(V, cor, ph):
    """Golem de blocos: cada parte e leve; o todo pesa (falacia da composicao/divisao)."""
    s = math.sin(ph * TAU)
    for x in (-24, 24):
        _bloco(V, x, -2, 38, 52, dk(cor, .15))
    _bloco(V, 0, -50, 84, 66, cor)
    _bloco(V, -62, -62 + s * 3, 32, 40, lit(cor, .05))
    _bloco(V, 62, -60 - s * 3, 32, 40, lit(cor, .05))
    _bloco(V, 0, -118, 56, 46, lit(cor, .1))
    _olhos(V, 0, -140, 11, 5.4, "bravo", (255, 214, 90))
    V.pline([(-10, -128), (10, -128)], INK, 2.0)
    _txt(V, "Σ", 0, -80, 34, (255, 236, 160), (60, 30, 10))
    for i in range(3):                                  # pedacos soltos
        _bloco(V, -88 + i * 7, -150 - i * 12 + s * 2, 12 - i * 2, 12 - i * 2, lit(cor, .2))


def r_pergunta_multipla(V, cor, ph):
    s = math.sin(ph * TAU)
    _monge(V, cor, ph, "bravo")
    for i, (x, y, k) in enumerate(((-62, -196, 1.0), (4, -216, 1.15), (66, -190, .9))):
        _bola_texto(V, x, y + math.sin(ph * TAU + i * 2) * 4, 16 * k, "?", (252, 246, 226), int(30 * k))
    V.icone("labirinto", 0, -80, 40)


def r_falso_dilema(V, cor, ph):
    s = math.sin(ph * TAU)
    # a terceira porta, escondida atras da capa
    _portinha(V, 0, -6, 78, 160, (170, 120, 60))
    V.luz(0, -70, 60, (255, 220, 140), 80)
    for sx in (-1, 1):
        _portinha(V, sx * 86, -2, 54, 110, (110, 76, 46))
    e = _est(cor, capa=dk(cor, .3), forro=lit(cor, .5), capuz="baixo", capuz_cor=dk(cor, .3), pos_e=(-46, -96), pos_d=(46, -96), humor="bravo", tonsura=False, cabelo=(90, 80, 70), chapeu="chaperon",
             chapeu_cor=dk(cor, .2))
    _hum(V, e, ph, "bravo")
    for sx in (-1, 1):                                   # chaves nas maos
        V.line((sx * 46, -96), (sx * 46, -122), OURO_D, 2.4)
        V.circ(sx * 46, -126, 5, None, OURO, 2.0)
        V.rect(sx * 46 - 1, -118, 6, 2.4, OURO)


def _boneco(V, x, y, k=1.0, ang=0.0):
    V.tube([(x, y + 6 * k), (x, y + 28 * k)], 13 * k, 11 * k, (214, 190, 150), INK, 1.0, False)
    V.circ(x, y - 4 * k, 9 * k, (232, 206, 164), INK, 1.0)
    for sx in (-1, 1):
        V.line((x + sx * 3.4 * k, y - 6 * k), (x + sx * 1 * k, y - 3 * k), INK, 1.0)
        V.line((x + sx * 3.4 * k, y - 3 * k), (x + sx * 1 * k, y - 6 * k), INK, 1.0)
        V.line((x + sx * 6 * k, y + 8 * k), (x + sx * 16 * k, y + 20 * k), (214, 190, 150), 4 * k)
    V.pline([(x - 3 * k, y + 1 * k), (x + 3 * k, y + 1 * k)], INK, 1.0)
    V.line((x - 4 * k, y + 12 * k), (x + 6 * k, y + 14 * k), (180, 40, 40), 1.4)           # alfinete


def r_ad_hominem(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, mao_d="dedo", mao_e=None, pos_e=(-44, -84), humor="bravo", cabelo=(140, 60, 40))
    _hum(V, e, ph, "bravo", abre=.4)
    _boneco(V, -50, -110 + s * 2, 1.15)
    _punho(V, -44, -90)
    for (x, y) in ((70, -176), (84, -158)):
        V.line((x, y), (x + 8, y - 8), (240, 90, 60), 3)
    _txt(V, "!", 82, -190, 30, (255, 120, 90))


def r_peticao_principio(V, cor, ph):
    """Ourobouros verde (circulo vicioso): a conclusao ja esta nas premissas."""
    cx, cy, R = 0, -108, 62
    n = 40
    a0 = ph * .5
    pts = [(cx + math.cos(a0 + TAU * i / n * .93 + .35) * R, cy + math.sin(a0 + TAU * i / n * .93 + .35) * R) for i in range(n)]
    V.tube(pts, 30, 30, [lit(cor, .2), cor, dk(cor, .4)][1], INK, 1.5, False)
    for i in range(1, n - 1, 2):
        x, y = pts[i]
        V.poly([(x - 5, y), (x, y - 7), (x + 5, y), (x, y + 7)], dk(cor, .45), None)
        V.circ(x, y - 3, 1.6, lit(cor, .4))
    hx, hy = pts[-1]
    V.gell(hx, hy, 40, 34, [lit(cor, .2), cor, dk(cor, .35)], INK, 1.3)
    olho(V, hx - 4, hy - 4, 5, "bravo", (0, 0), (255, 220, 60), 1)
    V.pline([(hx + 8, hy + 6), (hx + 22, hy + 14), (hx + 28, hy + 8)], (210, 40, 50), 2)
    AF.pergaminho_obj(V, 0, -108, 0, 56, 40)
    _txt(V, "A = A", 0, -108, 22, (80, 40, 30), (250, 238, 200))


def r_goliardo(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, chapeu="chaperon", chapeu_cor=(210, 70, 50), tonsura=False, pos_d=(58, -140 + s * 3), pos_e=(-40, -90), humor="feliz", cabelo=(150, 90, 40), bigode=True, barba_cor=(150, 90, 40))
    _hum(V, e, ph, "feliz", abre=.7)
    V.gell(-46, -86, 34, 40, [(200, 160, 100), (120, 80, 40)], INK, 1.2, rot=.5)
    V.pline([(-58, -102), (-62, -112)], (110, 76, 44), 5)
    _punho(V, -40, -90)
    for k in range(3):                                       # fala sem parar
        V.pline([(40 + k * 8, -190 + k * 6), (54 + k * 9, -196 + k * 8)], (255, 220, 120), 2.4)
        V.pline([(-40 - k * 8, -190 + k * 6), (-54 - k * 9, -196 + k * 8)], (255, 220, 120), 2.4)
    V.icone("roda_fortuna", 74, -92, 30)


def r_gramatico(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _mes(cor, mao_e="livro_a", mao_d="vara", vara_cor=(190, 140, 70), humor="bravo", sobr=(60, 50, 60), livro_cor=(80, 50, 30), pos_d=(60, -90 + s * 2))
    _hum(V, e, ph, "bravo", abre=.2)
    _txt(V, "AMO AMAS", 8, -180, 14, (40, 20, 10), (240, 230, 200))


def r_acidente(V, cor, ph):
    s = math.sin(ph * TAU)
    V.rect(-46, -204, 92, 10, OURO_D, INK, 1.0, 4)
    V.gell(0, -112, 112, 184, [OURO_L, OURO, OURO_D], INK, 1.6)
    V.gell(0, -112, 90, 162, [(236, 242, 252), (160, 176, 210)], INK, 1.0)
    _monge(V.sub(-14, -4, .52), cor, ph, "neutro")
    V.sub(26, -4, .42)
    _monge(V.sub(30, -4, .42), (200, 70, 74), ph + .3, "bravo")
    V.pline([(-8, -190), (-2, -160), (-16, -140), (6, -110), (-4, -88), (12, -66)], (50, 40, 60), 1.8)       # a rachadura: o acidente
    for sx in (-1, 1):
        V.line((sx * 30, -24), (sx * 40, -4), OURO_D, 5)
    V.line((-40, -2), (40, -2), OURO_D, 4)


def _balanca(V, x, y, k, tilt, cor, ph):
    V.rect(x - 7 * k, y - 120 * k, 14 * k, 118 * k, lit(cor, .1), INK, 1.2, 3)
    V.poly([(x - 30 * k, y), (x + 30 * k, y), (x + 18 * k, y - 14 * k), (x - 18 * k, y - 14 * k)], dk(cor, .3), INK, 1.2)
    bx, by = x, y - 120 * k
    L = 70 * k
    ca, sa = math.cos(tilt), math.sin(tilt)
    a = (bx - L * ca, by - L * sa)
    b = (bx + L * ca, by + L * sa)
    V.line(a, b, OURO_D, 7 * k)
    V.line((a[0], a[1] - 1), (b[0], b[1] - 1), OURO_L, 2.5 * k)
    V.circ(bx, by, 9 * k, OURO, INK, 1.2)
    for (p, pesado) in ((a, True), (b, False)):
        V.line(p, (p[0] - 26 * k, p[1] + 50 * k), OURO_D, 1.6)
        V.line(p, (p[0] + 26 * k, p[1] + 50 * k), OURO_D, 1.6)
        V.gpoly([(p[0] - 32 * k, p[1] + 50 * k), (p[0] + 32 * k, p[1] + 50 * k), (p[0] + 22 * k, p[1] + 64 * k), (p[0] - 22 * k, p[1] + 64 * k)], [OURO_L, OURO, OURO_D], INK, 1.2)
        if pesado:
            V.circ(p[0], p[1] + 38 * k, 17 * k, (60, 56, 72), INK, 1.2)
            V.circ(p[0] - 5 * k, p[1] + 33 * k, 5 * k, (140, 136, 160))
        else:
            V.icone("pena", p[0], p[1] + 34 * k, 22 * k)


def r_secundum_quid(V, cor, ph):
    s = math.sin(ph * TAU)
    _balanca(V, 0, -2, 1.18, .30 + s * .03, (150, 190, 180), ph)
    _olhos(V, 0, -104, 6, 5.6, "louco", (255, 240, 120))
    boca(V, 0, -88, 12, "grito", .5)
    for sx in (-1, 1):
        V.ell(sx * 22, 2, 30, 11, dk(cor, .5), INK, 1.0)


def r_consequente(V, cor, ph):
    s = math.sin(ph * TAU)
    V.ell(0, -2, 120, 26, (90, 140, 200, 200), (60, 100, 160), 1.2)
    V.ell(-18, -3, 44, 10, (170, 210, 250, 200))
    e = _est(cor, mao_d="dedo", pos_d=(54, -116), mao_e=None, pos_e=(-40, -84), humor="feliz")
    _hum(V, e, ph, "feliz", abre=.35)
    _nuvem(V, 0, -214, 1.0)
    for i in range(7):
        x = -34 + i * 11
        y = -196 + ((ph * 40 + i * 9) % 40)
        V.line((x, y), (x - 2, y + 9), (130, 180, 240), 2)
    _txt(V, "logo...", 70, -196, 20, (250, 240, 200))
    V.pline([(48, -120), (60, -150)], (255, 255, 255, 0), 1) if False else None


def r_nao_causa(V, cor, ph):
    s = math.sin(ph * TAU)
    # o sol que 'obedece' ao galo
    for i in range(12):
        a = TAU * i / 12 + ph * .3
        V.poly([(math.cos(a - .1) * 66, -128 + math.sin(a - .1) * 66), (math.cos(a) * 92, -128 + math.sin(a) * 92), (math.cos(a + .1) * 66, -128 + math.sin(a + .1) * 66)], (255, 214, 90), None)
    V.circ(0, -128, 64, (255, 214, 96), dk(OURO, .3), 1.6)
    V.circ(0, -128, 50, lit((255, 214, 96), .35), None)
    V.ell(0, -4, 150, 40, (110, 150, 80), (60, 90, 44), 1.2)
    # galo
    c = (200, 110, 50)
    for i, (dx, dy, cc) in enumerate(((-34, -70, (40, 130, 110)), (-42, -56, (60, 90, 170)), (-30, -48, (200, 80, 60)), (-40, -84, (40, 130, 110)))):
        V.tube([(-18, -56), (dx, dy - 4), (dx - 8, dy - 24 + i * 2)], 14, 6, cc, INK, 1.0)
    V.gell(0, -52, 70, 56, [lit(c, .3), c, dk(c, .45)], INK, 1.4)
    V.gell(-6, -50, 40, 28, [lit(c, .1), dk(c, .3)], dk(c, .7), 1.0, rot=-.3)
    V.tube([(14, -64), (24, -84), (22, -102 + s * 1)], 20, 18, c, INK, 1.2)
    V.gell(26, -106, 34, 30, [lit(c, .3), c, dk(c, .3)], INK, 1.3)
    for i, x in enumerate((18, 26, 34)):
        V.poly([(x - 4, -118), (x, -130 - i % 2 * 6), (x + 4, -118)], (210, 30, 40), INK, .9)
    V.poly([(40, -108), (60, -116 - s), (52, -104), (62, -92 + s), (40, -98)], OURO, INK, 1.0)          # bico aberto
    V.poly([(32, -96), (36, -84), (40, -94)], (210, 30, 40), INK, .8)
    olho(V, 32, -110, 4.4, "bravo", (1, 0), (40, 30, 20), 1)
    for x in (-8, 10):
        V.pline([(x, -28), (x + 2, -8), (x + 8, -4)], (210, 150, 60), 3)
    for k in range(3):
        V.pline([(60 + k * 6, -126 - k * 6), (70 + k * 8, -134 - k * 8)], (255, 255, 255), 2)


def r_regresso(V, cor, ph):
    s = math.sin(ph * TAU)
    for (x, k) in ((-66, 1.0), (28, .62), (68, .38), (86, .23)):
        _monge(V.sub(x, 0, k), cor, ph, "neutro")
    for i, x in enumerate((100, 110, 120)):
        V.circ(x, -22, 2.4 - i * .3, lit(cor, .6))


def r_astrologo(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _mes(cor, mao_e=None, mao_d="dedo", humor="sereno", pos_e=(-38, -100), pos_d=(60, -150 - s * 3), barba="longa", cabelo=(220, 220, 230))
    _hum(V, e, ph, "sereno")
    # astrolabio
    cx, cy = -48, -102
    V.circ(cx, cy, 24, OURO, INK, 1.5)
    V.circ(cx, cy, 20, (30, 36, 80), OURO_D, 1.0)
    for i in range(12):
        a = TAU * i / 12
        V.line((cx + math.cos(a) * 17, cy + math.sin(a) * 17), (cx + math.cos(a) * 20, cy + math.sin(a) * 20), OURO_L, 1.2)
    V.line((cx - 17, cy + 4), (cx + 15, cy - 8), OURO_L, 1.6)
    V.circ(cx, cy, 3, OURO_L)
    V.circ(cx, cy - 27, 4, None, OURO, 2.0)
    _punho(V, -40, -100)
    for i in range(7):
        x = (-70, -34, 28, 54, 70, -18, 14)[i]
        y = (-120, -76, -58, -100, -66, -22, -40)[i] if False else (-132, -84, -64, -110, -72, -40, -96)[i]
        V.poly([(x, y - 4), (x + 1.4, y - 1.4), (x + 4, y), (x + 1.4, y + 1.4), (x, y + 4), (x - 1.4, y + 1.4), (x - 4, y), (x - 1.4, y - 1.4)], OURO_L, None)
    for i in range(4):
        V.icone("estrela", -60 + i * 34, -214 + (i % 2) * 12, 14)


def r_copista(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(dk(cor, .3), capa=dk(cor, .5), forro=(90, 80, 70), capuz="baixo", capuz_cor=dk(cor, .5), mao_d="pena", mao_e=None, pos_e=(-30, -70), humor="neutro", cinto="corda")
    _hum(V, e, ph, "louco")
    V.pline([(-12, -186), (-26, -204)], (255, 255, 255), 5)           # pena atras da orelha
    V.ell(-9, -160, 12, 8, (40, 36, 60, 190))                              # mancha de tinta no rosto
    # estante inclinada na frente
    V.poly([(-62, -4), (62, -4), (56, -60), (-56, -60)], [(160, 112, 62)][0], INK, 1.5)
    V.poly([(-62, -4), (62, -4), (62, 2), (-62, 2)], (100, 66, 36), INK, 1.0)
    V.poly([(-52, -58), (52, -58), (46, -76), (-46, -76)], (214, 180, 120), INK, 1.2)
    for y in (-70, -64):
        V.pline([(-34, y), (30, y - 1)], (90, 60, 40), 1.0)
    V.ell(-46, -80, 12, 8, (30, 30, 60), INK, 1.0)                                    # tinteiro
    for i in range(3):
        V.circ(-46 + i * 3, -60 + i * 8 + (ph * 8) % 8, 2.2, (30, 30, 60))
    for i, (x, y, a) in enumerate(((62, -150, .5), (84, -120, -.4), (-72, -130, .3))):          # folhas voando
        AF.pergaminho_obj(V, x, y + math.sin(ph * TAU + i) * 4, a, 26, 16)


def r_panteista(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, capa=dk(cor, .35), forro=lit(cor, .4), capuz="baixo", capuz_cor=dk(cor, .35), mao_e="livro", mao_d=None, pos_d=(44, -92), pos_e=(-14, -106), humor="bravo", cinto="corda")
    _hum(V, e, ph, "bravo")
    _fogo(V, -12, -128, 1.3, ph)
    for i in range(9):                         # tudo e Deus: folhas e raizes ao redor
        a = TAU * i / 9 + ph * .5
        x, y = math.cos(a) * 72, -108 + math.sin(a) * 76
        V.ell(x, y, 16, 9, (70, 150, 70), (30, 80, 40), 1.0, a)
        V.pline([(x, y), (x * .8, -108 + (y + 108) * .8)], (50, 110, 50), 1.2)
    V.pline([(-30, -4), (-50, 4), (-70, -2)], (92, 64, 36), 3)
    V.pline([(30, -4), (50, 4), (70, -2)], (92, 64, 36), 3)


def r_ignoratio(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _mes(cor, mao_e=None, mao_d=None, pos_e=(-62, -118), pos_d=(56, -176 + s * 3), humor="feliz", barba="curta")
    _hum(V, e, ph, "feliz")
    # arenque vermelho (red herring) erguido
    V.gell(56, -196 + s * 3, 62, 24, [(250, 110, 90), (200, 40, 40), (150, 24, 30)], INK, 1.3, rot=-.5)
    V.poly([(80, -208 + s * 3), (96, -226 + s * 3), (96, -190 + s * 3)], (200, 50, 50), INK, 1.0)
    V.circ(40, -202 + s * 3, 3.6, BRANCO, INK, .7)
    for k in range(4):
        V.pline([(50 + k * 7, -200 + s * 3), (52 + k * 7, -188 + s * 3)], (250, 150, 130), 1.0)
    V.circ(56, -176 + s * 3, 6.4, PELE, dk(PELE, .6), .8)
    # outra mao aponta para outro assunto
    V.poly([(-96, -140), (-70, -140), (-70, -150), (-52, -134), (-70, -118), (-70, -128), (-96, -128)], (230, 206, 150), INK, 1.2)
    _punho(V, -62, -118)


def r_fideista(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, capa=dk(cor, .3), forro=lit(cor, .4), capuz="baixo", capuz_cor=dk(cor, .3), mao_e="livro", mao_d=None, pos_e=(-6, -96), pos_d=(30, -80), humor="sereno", cinto="corda", livro_cor=(60, 40, 90))
    _hum(V, e, ph, "sereno")
    V.poly([(-26, -170), (26, -170), (27, -158), (-27, -158)], (240, 236, 224), dk((240, 236, 224), .5), 1.1)           # venda
    V.poly([(26, -166), (40, -156 + s * 2), (34, -150), (24, -158)], (240, 236, 224), dk((240, 236, 224), .5), 1.0)
    V.icone("cruz_latina", -6, -100, 20)
    V.luz(-6, -100, 36, (255, 230, 150), 90)
    V.pline([(-62, -26), (-30, -4)], (110, 90, 64), 3)                                  # bengala tateando
    V.line((56, -4), (74, -150), (130, 96, 60), 4)


def _compasso(V, x, y, h, ab, cor=(210, 214, 226)):
    V.circ(x, y, 5, OURO, INK, 1.0)
    for sx in (-1, 1):
        V.line((x, y), (x + sx * ab, y + h), dk(cor, .45), 6)
        V.line((x, y), (x + sx * ab, y + h), cor, 3.4)
        V.poly([(x + sx * ab - 2, y + h), (x + sx * ab + 2, y + h), (x + sx * ab, y + h + 8)], INK, None)


def r_racionalista(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _mes(cor, mao_e=None, mao_d=None, pos_e=(-52, -112), pos_d=(56, -92), humor="sereno", largura=1.1, capa=dk(cor, .3), forro=OURO, chapeu_cor=(30, 30, 50))
    _hum(V, e, ph, "bravo", abre=0)
    V.pline([(-14, -168), (-4, -169)], INK, 1.4)
    V.circ(-52, -122, 18, (190, 230, 255, 190), (150, 190, 230), 1.5)                   # esfera de cristal
    V.circ(-57, -128, 5, (255, 255, 255))
    V.luz(-52, -122, 34, (180, 230, 255), 110)
    _punho(V, -52, -108)
    _compasso(V, 62, -150 + s * 2, 56, 22)
    _punho(V, 56, -96)
    V.pline([(46, -86), (60, -150)], dk(cor, .5), 3)


def r_maniqueia(V, cor, ph):
    s = math.sin(ph * TAU)
    pts = [(-52, -8)] + [(52 * math.cos(math.pi + math.pi * i / 14), -126 + 76 * math.sin(math.pi + math.pi * i / 14)) for i in range(15)] + [(52, -8)]
    pts += [(52 - i * 13, -4 + (10 if i % 2 else 0) + s * (4 if i % 2 else -4)) for i in range(9)]
    V.luz(0, -100, 100, (150, 40, 50), 70)
    V.gpoly(pts, [(40, 34, 58), (14, 10, 24)], (10, 6, 14), 1.8)
    half = [(0, -210), (-60, -210), (-60, 10), (0, 10)]
    V.clip_poly(half, lambda W: W.gpoly(pts, [(255, 248, 226), (222, 204, 160), (190, 170, 120)], None))
    V.pline([(0, -204), (0, -6)], (140, 120, 90), 1.4)
    V.gell(0, -134, 44, 48, (30, 24, 40), None)
    olho(V, -10, -136, 6, "neutro", (0, 0), (255, 214, 90), 1)
    olho(V, 10, -136, 6, "bravo", (0, 0), (255, 50, 50), -1)
    for sx, cc in ((-1, (255, 244, 200)), (1, (40, 30, 50))):
        V.tube([(sx * 48, -100), (sx * 74, -80), (sx * 68, -54)], 18, 10, cc, INK, 1.0)
    V.icone("cruz_latina", -66, -48, 22)
    V.circ(66, -48, 10, (200, 40, 40), INK, 1.0)


def r_pelagiano(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, capa=None, capuz="baixo", capuz_cor=dk(cor, .2), mao_e=None, mao_d=None, pos_e=(-36, -204), pos_d=(36, -204), humor="bravo", largura=1.12, cinto="corda", cabelo=(140, 90, 50))
    Vf = V.sub(0, 0, .84)
    _hum(Vf, e, ph, "bravo", abre=.35)
    # a pedra erguida "so com as proprias forcas" (sem a graca)
    Vf.gpoly(catmull([(-48, -226), (-36, -262), (4, -276), (42, -262), (54, -230), (38, -212), (-32, -210)], 4, True), [(190, 186, 176), (138, 132, 124), (92, 88, 82)], INK, 1.6)
    Vf.pline([(-20, -254), (6, -244), (-8, -224)], (80, 76, 70), 1.2)
    Vf.pline([(14, -266), (28, -248)], (200, 196, 186), 1.2)
    Vf.circ(-36, -204, 7.5, PELE, dk(PELE, .6), .9)
    Vf.circ(36, -204, 7.5, PELE, dk(PELE, .6), .9)
    for i in range(3):
        V.pline([(-70 + i * 6, -190 + i * 10), (-80 + i * 6, -196 + i * 10)], (255, 255, 255), 2.0)
        V.pline([(70 - i * 6, -190 + i * 10), (80 - i * 6, -196 + i * 10)], (255, 255, 255), 2.0)


def r_triteista(V, cor, ph):
    s = math.sin(ph * TAU)
    AF.sino_manto(V, -108, -6, 40, 70, cor, folds=5, sway=s)
    V.pline(AF.hem_pts(70, -6, 0, 2.0, -3.4), OURO, 2.0)
    V.icone("scutum_fidei", 0, -60, 44)
    for i, x in enumerate((-46, 0, 46)):
        y = -156 - (10 if i == 1 else 0)
        e = _est(cor, capuz=None, tonsura=False, cabelo=((90, 60, 40), (190, 190, 200), (50, 40, 36))[i], pele=PELE, chapeu=None, humor="neutro")
        AF.rosto(V, x, y, 21, AF._est(e), ("bravo", "neutro", "triste")[i])
        V.gell(x, y - 18, 52, 16, [lit(cor, .3), dk(cor, .3)], dk(cor, .7), 1.0)
        V.poly([(x - 14, y - 22), (x - 14, y - 36), (x - 7, y - 28), (x, y - 40), (x + 7, y - 28), (x + 14, y - 36), (x + 14, y - 22)], OURO, OURO_D, 1.0)
    V.luz(0, -176, 60, (255, 220, 120), 60)


def r_antropomorfita(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, mao_d=None, mao_e=None, pos_e=(-40, -84), pos_d=(48, -130), humor="feliz")
    _hum(V, e, ph, "feliz")
    # mao enorme erguida com 'Deus' de barba sobre a palma
    x, y = 62, -146 + s * 2
    V.tube([(46, -118), (56, -132), (x, y + 12)], 22, 30, dk(cor, .15), dk(cor, .7), 1.0)
    V.gell(x, y, 46, 40, [lit(PELE, .15), PELE, dk(PELE, .2)], dk(PELE, .6), 1.3)
    for k in range(4):
        V.tube([(x - 18 + k * 12, y - 10), (x - 20 + k * 13, y - 30 + (k % 2) * 4)], 11, 9, PELE, dk(PELE, .6), 1.0, False)
    V.tube([(x - 24, y + 2), (x - 38, y - 8)], 11, 9, PELE, dk(PELE, .6), 1.0, False)
    V.gell(x, y - 22, 20, 22, [lit(PELE, .2), PELE], dk(PELE, .6), 1.0)
    V.poly([(x - 10, y - 14), (x, y + 6), (x + 10, y - 14), (x + 8, y - 4), (x, y + 1), (x - 8, y - 4)], (240, 240, 244), dk((240, 240, 244), .5), .9)
    V.circ(x, y - 32, 10, None, OURO_L, 2.0)


def r_fatalista(V, cor, ph):
    cx, cy = 0, -112
    V.circ(cx, cy, 80, (118, 76, 40), INK, 1.8)
    V.circ(cx, cy, 64, (38, 30, 52), dk(INK, .1), 1.2)
    for i in range(8):
        a = TAU * i / 8 + ph * .7
        V.line((cx, cy), (cx + math.cos(a) * 76, cy + math.sin(a) * 76), (214, 164, 92), 4)
        V.circ(cx + math.cos(a) * 72, cy + math.sin(a) * 72, 3.6, OURO, INK, .8)
    V.circ(cx, cy, 12, OURO, INK, 1.2)
    # o homem preso a roda; fios de cima conduzem seus membros
    V.sub(0, -22, .56)
    e = _mes(dk(cor, .0), capuz="baixo", chapeu=None, mao_e=None, mao_d=None, humor="triste", barba="curta", pos_e=(-52, -100), pos_d=(52, -100))
    _hum(V, e, ph, "triste", esc=.56, dy=-22)
    for x in (-40, 0, 40):
        V.line((x, -214), (x * .6, -150), (230, 224, 200), 1.2)
    V.line((-60, -214), (60, -214), (130, 90, 56), 4)


def r_sentenciario(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, mao_e=None, mao_d=None, pos_e=(-30, -84), pos_d=(30, -84), humor="triste", cabelo=(150, 100, 60))
    _hum(V, e, ph, "triste", abre=.4, dx=-6)
    V.rect(-44, -128, 74, 82, (120, 36, 40), INK, 1.4, 5)
    V.rect(-44, -128, 12, 82, dk((120, 36, 40), .4), INK, 1.0)
    V.rect(-30, -122, 56, 70, (246, 238, 208), None)
    _txt(V, "SENTENÇAS", -4, -100, 13, (60, 20, 20), (246, 238, 208))
    _punho(V, -30, -90)
    _punho(V, 30, -90)
    for i, (x, y, a) in enumerate(((60, -170, .5), (78, -130, -.4), (-62, -168, .3), (52, -96, .8))):
        AF.pergaminho_obj(V, x, y + math.sin(ph * TAU + i) * 3, a, 24, 14)
    # ampulheta e gotas de suor
    V.poly([(-92, -200), (-72, -200), (-82, -188), (-72, -176), (-92, -176), (-82, -188)], (240, 220, 160), INK, 1.2)
    V.rect(-95, -204, 26, 4, (110, 70, 40), INK, .8)
    V.rect(-95, -176, 26, 4, (110, 70, 40), INK, .8)
    V.circ(-82, -182, 3, (230, 190, 100))
    for k in range(3):
        V.pline([(-60 - k * 7, -150 + k * 10), (-76 - k * 8, -150 + k * 10)], (255, 255, 255), 2.0)
    V.poly([(26, -176), (30, -168), (26, -162), (22, -168)], (130, 190, 250), None)


def r_glosador(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(dk(cor, .3), capa=dk(cor, .5), forro=(100, 90, 70), capuz="baixo", capuz_cor=dk(cor, .5), mao_d="pena", mao_e=None, pos_e=(-40, -84), pos_d=(56, -120), humor="neutro", cinto="corda")
    _hum(V, e, ph, "neutro")
    # livro enorme aberto: SIC / NON
    V.poly([(-74, -120), (0, -112), (74, -120), (74, -34), (0, -26), (-74, -34)], (120, 36, 44), INK, 1.6)
    V.gpoly([(-68, -116), (-2, -108), (-2, -32), (-68, -40)], [(252, 246, 224), (232, 218, 176)], INK, 1.0)
    V.gpoly([(68, -116), (2, -108), (2, -32), (68, -40)], [(246, 238, 210), (224, 208, 164)], INK, 1.0)
    for k in range(7):
        V.pline([(-60, -102 + k * 9), (-30, -100 + k * 9)] if k > 2 else [(-60, -92 + k * 9), (-8, -90 + k * 9)], (150, 130, 110), 1.0)
        V.pline([(12, -90 + k * 9), (60, -92 + k * 9)] if k > 2 else [(12, -100 + k * 9), (40, -102 + k * 9)], (150, 130, 110), 1.0)
    _txt(V, "SIC", -34, -100, 26, (190, 30, 40), (252, 246, 224))
    _txt(V, "NON", 34, -100, 26, (40, 60, 150), (252, 246, 224))
    V.pline([(0, -110), (0, -30)], (110, 80, 60), 1.4)
    _punho(V, -60, -88)


def r_dupla_verdade(V, cor, ph):
    s = math.sin(ph * TAU)
    pts = [(-52, -34)] + [(52 * math.cos(math.pi + math.pi * i / 14), -126 + 74 * math.sin(math.pi + math.pi * i / 14)) for i in range(15)] + [(52, -34)]
    pts += [(52 - i * 13, -14 + (14 if i % 2 else 0) + s * (4 if i % 2 else -4)) for i in range(9)]
    V.luz(0, -100, 96, cor, 90)
    V.gpoly(pts, [lit(cor, .6), lit(cor, .3), cor], lit(cor, .75), 1.6)
    V.gell(-13, -134, 34, 42, (252, 250, 244), INK, 1.2)
    V.gell(13, -134, 34, 42, (36, 34, 56), lit(cor, .6), 1.2)
    olho(V, -18, -138, 5, "feliz")
    olho(V, -6, -138, 5, "feliz")
    olho(V, 8, -138, 5, "triste", (0, 0), (255, 255, 255), 1)
    olho(V, 20, -138, 5, "triste", (0, 0), (255, 255, 255), -1)
    V.pline([(-18, -122), (-6, -120)], INK, 1.8)
    V.pline([(8, -118), (20, -120)], (255, 255, 255), 1.8)
    for sx, ic in ((-1, "cruz_latina"), (1, "compasso")):
        V.tube([(sx * 48, -96), (sx * 74, -80), (sx * 70, -60)], 18, 11, lit(cor, .4), lit(cor, .75), 1.0)
        AF.livro_obj(V, sx * 74, -62, sx * .15, 32, 40, (130, 40, 50) if sx < 0 else (40, 60, 130))
        V.icone(ic, sx * 74, -64, 20)


def r_monopsiquismo(V, cor, ph):
    s = math.sin(ph * TAU)
    # um unico intelecto (nuvem azul com um grande olho) sobre varios individuos
    for (dx, dy, r) in ((-44, 0, 24), (-14, -12, 32), (22, -8, 30), (50, 4, 22), (4, 8, 28)):
        V.circ(dx, -190 + dy + s * 2, r, lit(cor, .25), None)
    for (dx, dy, r) in ((-44, 0, 24), (-14, -12, 32), (22, -8, 30), (50, 4, 22)):
        V.circ(dx, -190 + dy + s * 2, r, None, dk(cor, .5), 1.3)
    V.luz(0, -190, 90, cor, 90)
    V.ell(0, -188, 40, 24, (252, 250, 244), INK, 1.2)
    V.circ(0, -188, 9, cor, INK, 1.0)
    V.circ(0, -188, 4, INK)
    for x, k in ((-62, .56), (0, .64), (62, .56)):
        V.line((x * .5, -168), (x, -108 * k - 4), lit(cor, .55), 1.6)
        _monge(V.sub(x, 0, k), dk(cor, .15), ph, "neutro", rosto_visivel=True)


def r_eternalista(V, cor, ph):
    s = math.sin(ph * TAU)
    cx, cy = 0, -122
    V.circ(cx, cy, 86, (40, 40, 56), INK, 1.8)
    V.circ(cx, cy, 78, (220, 206, 170), OURO_D, 1.4)
    V.circ(cx, cy, 66, (60, 54, 82), None)
    for i in range(24):
        a = TAU * i / 24 + ph * .2
        V.line((cx + math.cos(a) * 62, cy + math.sin(a) * 62), (cx + math.cos(a) * (72 if i % 2 == 0 else 68), cy + math.sin(a) * (72 if i % 2 == 0 else 68)), OURO_D, 1.6)
    e = _mes(cor, mao_e=None, mao_d=None, pos_e=(-46, -96), pos_d=(46, -96), humor="sereno", barba="longa", chapeu_cor=dk(cor, .5), capa=cor, forro=OURO)
    _hum(V, e, ph, "sereno")
    V.pline([(-22, -44), (-10, -56), (0, -44), (10, -32), (22, -44), (10, -56), (0, -44), (-10, -32), (-22, -44)], OURO_L, 3.0)
    _txt(V, "α", -66, -122, 30, OURO_L, (40, 24, 6))
    _txt(V, "ω", 66, -122, 30, OURO_L, (40, 24, 6))


def r_necessitarista(V, cor, ph):
    s = math.sin(ph * TAU)
    for (y, w) in ((-4, 120), (-62, 84), (-112, 52)):
        V.gpoly([(-w / 2, y), (w / 2, y), (w / 2 - 6, y - 24), (-w / 2 + 6, y - 24)], [lit(cor, .35), cor, dk(cor, .4)], INK, 1.4)
        V.ell(0, y - 24, w - 12, 14, (140, 200, 240), dk(cor, .5), 1.2)
    V.rect(-8, -140, 16, 28, lit(cor, .1), INK, 1.2)
    V.rect(-9, -86, 18, 26, lit(cor, .1), INK, 1.2)
    # jorros de agua que descem em cascata, ligados por elos (cadeia causal)
    for sx in (-1, 1):
        for k in range(3):
            y0 = (-120, -76, -30)[k]
            w = (40, 58, 78)[k]
            V.pline([(sx * 6, y0 - 12), (sx * (w * .5), y0 - 6), (sx * (w * .5 + 6), y0 + 32)], (170, 220, 255), 3)
            V.circ(sx * (w * .5 + 3), y0 + 12 + math.sin(ph * TAU * 2 + k) * 2, 3, (200, 236, 255))
    V.gell(0, -170, 50, 54, [lit(cor, .35), dk(cor, .15)], dk(cor, .7), 1.3)
    _olhos(V, 0, -172, 9, 5, "neutro", (80, 140, 220))
    V.pline([(-6, -156), (6, -156)], INK, 1.4)
    V.poly([(-14, -196), (0, -216), (14, -196)], lit(cor, .5), dk(cor, .6), 1.0)
    for i in range(4):
        V.circ(-42 + i * 28, -134 + (i % 2) * 6, 5, None, OURO, 1.8)


def r_astro_fatalista(V, cor, ph):
    cx, cy = 0, -120
    V.circ(cx, cy, 92, (20, 20, 56), INK, 1.8)
    V.circ(cx, cy, 86, None, OURO, 2.0)
    V.circ(cx, cy, 64, None, OURO_D, 1.4)
    for i in range(12):
        a = TAU * i / 12 + ph * .15
        V.line((cx + math.cos(a) * 64, cy + math.sin(a) * 64), (cx + math.cos(a) * 86, cy + math.sin(a) * 86), OURO_D, 1.4)
        x, y = cx + math.cos(a + .26) * 75, cy + math.sin(a + .26) * 75
        V.poly([(x, y - 4), (x + 1.4, y - 1.4), (x + 4, y), (x + 1.4, y + 1.4), (x, y + 4), (x - 1.4, y + 1.4), (x - 4, y), (x - 1.4, y - 1.4)], OURO_L, None)
    e = _mes(cor, mao_e=None, mao_d=None, pos_e=(-54, -112), pos_d=(54, -112), humor="sereno", barba="longa", capa=cor, forro=(120, 100, 210), chapeu_cor=dk(cor, .4))
    _hum(V, e, ph, "sereno")
    for sx in (-1, 1):
        V.luz(sx * 54, -112, 22, (150, 130, 255), 120)


def r_multiplicador(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, capa=dk(cor, .3), capuz="baixo", capuz_cor=dk(cor, .3), mao_e=None, mao_d=None, pos_e=(-52, -118), pos_d=(52, -118), humor="feliz", chapeu="chaperon", chapeu_cor=lit(cor, .3), tonsura=False)
    _hum(V, e, ph, "louco")
    # bracos extras (multiplicados sem necessidade)
    for sx in (-1, 1):
        V.tube([(sx * 30, -112), (sx * 56, -86), (sx * 66, -66)], 15, 11, dk(cor, .3), dk(cor, .7), 1.0)
        V.circ(sx * 66, -64, 6.4, PELE, dk(PELE, .6), .8)
    for i, ic in enumerate(("livro", "estrela", "rosa", "pergaminho", "pena", "tinteiro", "chaves")):
        a = TAU * i / 7 + ph * TAU * .25
        x, y = math.cos(a) * 92, -128 + math.sin(a) * 74
        V.circ(x, y, 15, (250, 244, 228), INK, 1.1)
        V.icone(ic, x, y, 22)
    _txt(V, "+ + +", 0, -206, 20, (255, 230, 120))


def r_mentiroso(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _est(cor, capa=lit(cor, .1), forro=lit(cor, .6), capuz="forrado", capuz_cor=lit(cor, .1), chapeu="chaperon", chapeu_cor=dk(cor, .3), tonsura=False, mao_e=None, mao_d=None,
             pos_d=(0, -124), pos_e=(-30, -90), humor="neutro", cabelo=(90, 80, 70))
    _hum(V, e, ph, "sorriso_mau" if False else "neutro")
    V.poly([(-46, -196), (46, -196), (50, -122), (-50, -122)], (240, 228, 190), INK, 1.4)
    _txt(V, "ESTA FRASE", 0, -182, 14, (60, 20, 30), (250, 240, 210))
    _txt(V, "É FALSA", 0, -164, 18, (190, 30, 40), (250, 240, 210))
    V.pline([(-34, -150), (34, -150)], (120, 90, 60), 1.0)
    # fita de Moebius (volta sem fim)
    pts = [(math.sin(a) * 60, -222 + math.sin(2 * a) * 10) for a in [TAU * i / 24 for i in range(25)]]
    V.pline(pts, (240, 220, 140), 4)
    V.pline(pts, (150, 110, 40), 1.0)
    _punho(V, -30, -90)


def r_cetico(V, cor, ph):
    s = math.sin(ph * TAU)
    e = _mes(cor, mao_e=None, mao_d=None, pos_e=(-62, -98), pos_d=(62, -98), humor="triste", barba="curta", capa=dk(cor, .2), forro=lit(cor, .4), chapeu_cor=(40, 40, 46))
    _hum(V, e, ph, "triste")
    for sx in (-1, 1):                              # palmas abertas: nao sabe
        V.circ(sx * 62, -98, 8, PELE, dk(PELE, .6), .9)
        for f in range(4):
            a = -math.pi / 2 + (f - 1.5) * .3
            V.line((sx * 62 + math.cos(a) * 4, -98 + math.sin(a) * 4), (sx * 62 + math.cos(a) * 12, -98 + math.sin(a) * 12 - 2), PELE, 3.2)
    for i in range(3):
        _txt(V, "?", -40 + i * 40, -214 - (i % 2) * 10 + math.sin(ph * TAU + i) * 3, 34, (230, 230, 240), (30, 30, 40))
    for (x, a) in ((-76, .3), (-58, -.2)):          # livros queimados aos pes
        AF.livro_obj(V, x, -12, a, 24, 14, (110, 60, 50))
    _fogo(V, -66, -16, 1.0, ph)


def r_censor(V, cor, ph):
    s = math.sin(ph * TAU)
    _monge(V, cor, ph, "bravo", olhos=(255, 120, 60))
    # tocha e carimbo
    V.line((70, -34), (66, -128), (110, 74, 40), 6)
    _fogo(V, 66, -128, 1.5, ph)
    V.rect(-84, -88, 30, 20, (190, 30, 40), INK, 1.4, 3)
    V.rect(-74, -108, 10, 22, (110, 74, 40), INK, 1.2, 3)
    _txt(V, "NON", -69, -78, 14, (255, 236, 220), (80, 10, 14))
    for (x, a) in ((-30, .1), (0, -.1), (30, .15)):
        AF.livro_obj(V, x, -10, a, 26, 16, (110, 70, 50))
    _fogo(V, -10, -22, .9, ph + .3)
    _fogo(V, 28, -22, .8, ph + .6)


RECEITAS = dict(equivoco=r_equivoco, anfibolia=r_anfibolia, composicao=r_composicao, pergunta_multipla=r_pergunta_multipla, falso_dilema=r_falso_dilema,
                ad_hominem=r_ad_hominem, peticao_principio=r_peticao_principio, goliardo=r_goliardo, gramatico_pedante=r_gramatico, falacia_acidente=r_acidente,
                secundum_quid=r_secundum_quid, falacia_consequente=r_consequente, nao_causa=r_nao_causa, regresso_infinito=r_regresso, astrologo=r_astrologo,
                copista_distraido=r_copista, panteista_dinant=r_panteista, ignoratio_elenchi=r_ignoratio, fideista=r_fideista, racionalista=r_racionalista,
                sombra_maniqueia=r_maniqueia, pelagiano=r_pelagiano, triteista=r_triteista, antropomorfita=r_antropomorfita, fatalista=r_fatalista,
                sentenciario_atrasado=r_sentenciario, glosador_sic_et_non=r_glosador, dupla_verdade=r_dupla_verdade, monopsiquismo=r_monopsiquismo,
                eternalista=r_eternalista, necessitarista=r_necessitarista, astro_fatalista=r_astro_fatalista, multiplicador_entes=r_multiplicador,
                mentiroso_insoluvel=r_mentiroso, cetico_autrecourt=r_cetico, censor_zeloso=r_censor)

# palavras-chave do nome (ids novos): (trecho, receita)
PALAVRAS = (("astr", r_astrologo), ("roda", r_fatalista), ("espelho", r_acidente), ("balan", r_secundum_quid), ("galo", r_nao_causa), ("peixe", r_ignoratio), ("arenque", r_ignoratio),
            ("livro", r_glosador), ("copista", r_copista), ("censor", r_censor), ("herege", r_panteista), ("sofista", r_equivoco), ("fantasma", r_dupla_verdade),
            ("espectro", r_dupla_verdade), ("sombra", r_maniqueia), ("mestre", r_gramatico), ("estudante", r_ad_hominem))


def _generico(V, d, cor, ph):
    forma = d.get("forma", "capuz")
    if forma == "mestre":
        _hum(V, _mes(cor, mao_e="livro", mao_d="dedo", humor="bravo"), ph, "bravo")
    elif forma == "estudante":
        _hum(V, _est(cor, mao_e="livro", mao_d="dedo", humor="bravo"), ph, "bravo")
    elif forma == "livro":
        r_glosador(V, cor, ph)
    elif forma == "espirito":
        r_dupla_verdade(V, cor, ph)
    elif forma == "besta":
        r_composicao(V, cor, ph)
    else:
        _monge(V, cor, ph, "bravo")


def desenhar(V, iid, d, ph):
    cor = tuple(d.get("cor", (120, 80, 150)))
    fn = RECEITAS.get(iid)
    if fn is None:
        nm = (str(iid) + " " + str(d.get("nome", ""))).lower()
        for k, f in PALAVRAS:
            if k in nm:
                fn = f
                break
    if fn is not None:
        fn(V, cor, ph)
    else:
        _generico(V, d, cor, ph)
    return True
