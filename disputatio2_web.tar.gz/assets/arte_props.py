# -*- coding: utf-8 -*-
"""Decoracao especifica de cada um dos 16 tipos de sala (props estaticos + registro de luzes/janelas)."""
import math

import pygame

import arte_base as B
from arte_base import mix, esc, surf

PI = math.pi
MAD = (112, 72, 38)
OURO = B.OURO
PERG = B.PERG


# ------------------------------------------------------------------ pecas comuns
def vela(c, x, y, h=22, acesa=True):
    S = c.S
    pygame.draw.ellipse(S, (0, 0, 0), (x - 9, y - 2, 18, 6))
    pygame.draw.ellipse(S, (170, 138, 50), (x - 9, y - 4, 18, 6))
    pygame.draw.rect(S, (242, 230, 196), (x - 4, y - h, 8, h - 2))
    pygame.draw.rect(S, (200, 186, 150), (x + 1, y - h, 3, h - 2))
    pygame.draw.line(S, (40, 30, 20), (x, y - h), (x, y - h - 3), 1)
    if acesa:
        c.chama(x, y - h - 2, 70, (255, 190, 100), "chama", .8)


def candelabro(c, x, y, h=90, n=5):
    S = c.S
    sombra = B.sombra_elipse
    sombra(S, x, y + 2, 46, 14, 110)
    for dx in (-18, 0, 18):
        pygame.draw.line(S, (30, 28, 30), (x, y - h * .25), (x + dx, y), 3)
    pygame.draw.rect(S, (36, 34, 38), (x - 2, y - h, 5, h - 10))
    for yy in (y - h * .3, y - h * .6):
        pygame.draw.circle(S, (150, 120, 50), (x, int(yy)), 5)
    top = y - h
    for i in range(n):
        dx = (i - (n - 1) / 2) * 15
        yy = top + abs(dx) * .45
        pygame.draw.line(S, (36, 34, 38), (x, top + 8), (x + dx, yy + 2), 2)
        vela(c, int(x + dx), int(yy + 2), 14)
    c.brilho(x, top, 120, (120, 80, 36))


def arandela(c, x, y, tocha=True):
    S = c.S
    pygame.draw.rect(S, (30, 28, 30), (x - 3, y - 4, 6, 30))
    pygame.draw.polygon(S, (40, 38, 42), [(x - 10, y + 16), (x + 10, y + 16), (x + 6, y + 26), (x - 6, y + 26)])
    pygame.draw.rect(S, (92, 62, 36), (x - 4, y - 14, 8, 22))
    pygame.draw.rect(S, (150, 110, 60), (x - 4, y - 14, 3, 22))
    c.chama(x, y - 14, 110, (255, 160, 70), "tocha")


def lamparina(c, x, y0, y, cor=(255, 190, 100)):
    S = c.S
    pygame.draw.line(S, (90, 80, 60), (x, y0), (x, y), 2)
    for yy in range(int(y0), int(y), 6):
        pygame.draw.circle(S, (120, 104, 70), (x, yy), 2, 1)
    pygame.draw.polygon(S, (150, 120, 50), [(x - 10, y), (x + 10, y), (x + 6, y + 9), (x - 6, y + 9)])
    pygame.draw.rect(S, (60, 44, 30), (x - 10, y - 1, 20, 3))
    c.chama(x, y, 90, cor, "chama", .9)


def estandarte(c, x, y, w, h, cor, emblema="lis"):
    S = c.S
    pygame.draw.rect(S, (70, 52, 30), (x - w // 2 - 4, y - 4, w + 8, 5))
    pygame.draw.circle(S, OURO, (x - w // 2 - 4, y - 2), 3)
    pygame.draw.circle(S, OURO, (x + w // 2 + 4, y - 2), 3)
    pts = [(x - w // 2, y), (x + w // 2, y), (x + w // 2, y + h - 12), (x + w // 4, y + h), (x, y + h - 10), (x - w // 4, y + h), (x - w // 2, y + h - 12)]
    pygame.draw.polygon(S, cor, pts)
    pygame.draw.polygon(S, esc(cor, 1.25), [(x - w // 2, y), (x - w // 2 + 4, y), (x - w // 2 + 4, y + h - 12), (x - w // 2, y + h - 12)])
    pygame.draw.polygon(S, OURO, pts, 2)
    if emblema == "lis":
        for (dx, dy) in ((0, h * .3), (-w * .22, h * .62), (w * .22, h * .62)):
            B.lis(S, x + dx, y + dy, w * .34, OURO)
    elif emblema == "cruz":
        B.cruz_latina(S, x, y + h * .42, h * .5, OURO, None, 4)
    elif emblema == "estrela":
        B.estrela8(S, x, y + h * .4, w * .3, OURO)
    elif emblema == "scutum":
        for (dx, dy) in ((0, -.18), (-.2, .12), (.2, .12)):
            pygame.draw.circle(S, (240, 232, 205), (int(x + dx * w * 1.2), int(y + h * .45 + dy * w * 1.2)), 6)
            pygame.draw.circle(S, OURO, (int(x + dx * w * 1.2), int(y + h * .45 + dy * w * 1.2)), 6, 1)


def estante(c, x, y, w, h, linhas=3, acorrentado=False, pergs=False):
    S, rnd = c.S, c.rnd
    pygame.draw.rect(S, esc(MAD, .55), (x - 5, y - 6, w + 10, h + 12))
    pygame.draw.rect(S, esc(MAD, .35), (x, y, w, h))
    lh = h // linhas
    for r in range(linhas):
        yy = y + r * lh
        xx = x + 3
        while xx < x + w - 8:
            bw = rnd.randint(6, 13)
            bh = rnd.randint(lh - 14, lh - 5)
            col = esc(rnd.choice([(150, 40, 44), (36, 60, 120), (90, 60, 34), (46, 90, 60), (110, 70, 120), (170, 130, 60)]), rnd.uniform(.7, 1.0))
            if pergs and rnd.random() < .3:
                pygame.draw.rect(S, PERG, (xx, yy + lh - 8 - bh // 2, bw + 2, bh // 2 + 2), 0, 4)
                pygame.draw.ellipse(S, esc(PERG, .8), (xx, yy + lh - 8 - bh // 2, bw + 2, 5))
            else:
                lean = rnd.random() < .08
                pygame.draw.rect(S, col, (xx, yy + lh - 7 - bh, bw, bh), 0, 1)
                pygame.draw.line(S, esc(col, 1.4), (xx + 1, yy + lh - 7 - bh), (xx + 1, yy + lh - 8))
                pygame.draw.line(S, OURO, (xx, yy + lh - 7 - bh + 4), (xx + bw - 1, yy + lh - 7 - bh + 4))
                pygame.draw.line(S, OURO, (xx, yy + lh - 7 - bh + bh // 2), (xx + bw - 1, yy + lh - 7 - bh + bh // 2))
                if acorrentado:
                    pygame.draw.line(S, (150, 150, 160), (xx + bw // 2, yy + lh - 7 - bh), (xx + bw // 2, yy + lh - 7 - bh - 5))
            xx += bw + 1
        pygame.draw.rect(S, MAD, (x - 3, yy + lh - 7, w + 6, 7))
        pygame.draw.line(S, esc(MAD, 1.3), (x - 3, yy + lh - 7), (x + w + 2, yy + lh - 7))
        if acorrentado:
            for cx2 in range(x + 2, x + w - 2, 7):
                pygame.draw.ellipse(S, (170, 170, 180), (cx2, yy + 4, 6, 3), 1)
    S.blit(B.vgrad_a(w, h, (0, 0, 0), 80, (0, 0, 0), 0), (x, y))
    pygame.draw.rect(S, (20, 14, 10), (x - 5, y - 6, w + 10, h + 12), 1)
    B.cruz_latina(S, x + w // 2, y - 14, 14, OURO, None, 3)


def arca(c, x, y, w=96, h=46, aberta=False):
    S = c.S
    B.sombra_elipse(S, x + w // 2, y + h + 4, w + 20, 18, 130)
    B.caixa(S, (x, y, w, h), (120, 80, 44), (92, 58, 30), 14)
    for fx in (x + 10, x + w - 18):
        pygame.draw.rect(S, (46, 44, 52), (fx, y - 14, 8, h + 14))
        pygame.draw.circle(S, (170, 170, 178), (fx + 4, y + 8), 2)
    pygame.draw.rect(S, (206, 170, 70), (x + w // 2 - 6, y + 4, 12, 14), 0, 2)
    pygame.draw.rect(S, (40, 28, 14), (x + w // 2 - 1, y + 9, 3, 6))
    if aberta:
        for i in range(14):
            cx = x + 8 + (i * 37) % (w - 16)
            pygame.draw.circle(S, OURO if i % 2 else B.OURO_C, (cx, y - 12 + (i % 3)), 4)


def atril(c, x, y, aberto=True):
    S = c.S
    B.sombra_elipse(S, x, y + 4, 56, 14, 110)
    pygame.draw.polygon(S, esc(MAD, .8), [(x - 6, y - 36), (x + 6, y - 36), (x + 10, y), (x - 10, y)])
    pygame.draw.polygon(S, MAD, [(x - 28, y - 34), (x + 28, y - 34), (x + 24, y - 52), (x - 24, y - 52)])
    pygame.draw.line(S, esc(MAD, 1.3), (x - 28, y - 34), (x + 28, y - 34), 2)
    pygame.draw.polygon(S, PERG, [(x - 22, y - 38), (x - 1, y - 40), (x - 1, y - 54), (x - 20, y - 52)])
    pygame.draw.polygon(S, esc(PERG, .93), [(x + 1, y - 40), (x + 22, y - 38), (x + 20, y - 52), (x + 1, y - 54)])
    for i in range(4):
        pygame.draw.line(S, B.TINTA, (x - 18, y - 44 - i * 2), (x - 5, y - 45 - i * 2))
        pygame.draw.line(S, B.TINTA, (x + 4, y - 45 - i * 2), (x + 18, y - 44 - i * 2))
    pygame.draw.rect(S, (180, 30, 36), (x - 19, y - 52, 5, 4))


def altar(c, cx, y, w=200, cruz=True):
    S = c.S
    B.sombra_elipse(S, cx, y + 6, w + 40, 26, 150)
    B.caixa(S, (cx - w // 2, y - 40, w, 44), (232, 226, 210), (240, 236, 224), 14)
    # pano: faixa bordada vermelha/ouro e franjas
    pygame.draw.rect(S, (170, 30, 36), (cx - w // 2, y - 40, w, 10))
    pygame.draw.rect(S, OURO, (cx - w // 2, y - 41, w, 2))
    pygame.draw.rect(S, OURO, (cx - w // 2, y - 30, w, 2))
    for xx in range(cx - w // 2 + 8, cx + w // 2 - 4, 22):
        B.cruz_latina(S, xx, y - 35, 9, OURO, None, 2)
    for xx in range(cx - w // 2, cx + w // 2, 4):
        pygame.draw.line(S, OURO, (xx, y + 4), (xx, y + 9))
    for dx in (-w // 4, w // 4):
        pygame.draw.line(S, (200, 196, 180), (cx + dx, y - 26), (cx + dx, y + 4))
    for dx in (-w // 2 + 2, w // 2 - 3):
        pygame.draw.line(S, (200, 196, 180), (cx + dx, y - 26), (cx + dx, y + 4))
    if cruz:
        B.crucifixo(S, cx, y - 92, 64)
        pygame.draw.rect(S, (150, 138, 120), (cx - 16, y - 64, 32, 8), 0, 2)
    vela(c, cx - w // 2 + 22, y - 54, 28)
    vela(c, cx + w // 2 - 22, y - 54, 28)


def retabulo(c, cx, y, w=180, h=44):
    S = c.S
    pygame.draw.rect(S, (60, 40, 22), (cx - w // 2, y - h, w, h), 0, 3)
    for i in range(3):
        px = cx - w // 2 + 4 + i * (w - 8) // 3
        pw = (w - 8) // 3 - 3
        pygame.draw.rect(S, (216, 176, 70), (px, y - h + 4, pw, h - 8))
        pygame.draw.polygon(S, (30, 63, 140), B.ogiva(px + pw / 2, y - 6, pw - 6, pw, h - 8 - pw - 2))
        pygame.draw.circle(S, (240, 228, 200), (int(px + pw / 2), int(y - h * .6)), 5)
        pygame.draw.circle(S, OURO, (int(px + pw / 2), int(y - h * .6)), 8, 1)
        pygame.draw.polygon(S, (200, 40, 46), [(px + pw / 2 - 7, y - 8), (px + pw / 2 + 7, y - 8), (px + pw / 2, y - h * .5)])
    pygame.draw.rect(S, OURO, (cx - w // 2, y - h, w, h), 2, 3)


def sarcofago(c, x, y, w=120, h=52, efigie=True):
    S = c.S
    B.sombra_elipse(S, x + w // 2, y + h + 6, w + 30, 20, 150)
    B.caixa(S, (x, y, w, h), (122, 112, 100), (96, 88, 78), 16)
    pygame.draw.rect(S, (130, 120, 106), (x - 4, y - 20, w + 8, 8), 0, 2)
    for i in range(4):
        pygame.draw.rect(S, esc((96, 88, 78), .7), (x + 8 + i * (w - 16) // 4, y + 8, (w - 16) // 4 - 6, h - 16), 1)
    if efigie:
        B.cruz_latina(S, x + w // 2, y - 8, 22, (60, 54, 48), (160, 150, 136), 5)
        pygame.draw.ellipse(S, (140, 130, 116), (x + 10, y - 17, 12, 8))


def cama(c, x, y, w=130, h=60):
    S = c.S
    B.sombra_elipse(S, x + w // 2, y + h + 6, w + 20, 18, 120)
    pygame.draw.rect(S, esc(MAD, .8), (x - 4, y - 18, 10, h + 18))
    pygame.draw.rect(S, esc(MAD, .8), (x + w - 6, y - 8, 10, h + 8))
    B.caixa(S, (x, y, w, h), (240, 238, 228), (226, 224, 212), 16)
    pygame.draw.ellipse(S, (250, 250, 244), (x + 6, y - 14, 38, 20))
    pygame.draw.rect(S, (150, 170, 190), (x + 50, y - 12, w - 54, h + 8), 0, 3)
    pygame.draw.rect(S, (110, 130, 160), (x + 50, y - 12, w - 54, h + 8), 2, 3)
    B.cruz_latina(S, x + 50 + (w - 54) // 2, y + 14, 22, (240, 238, 228), None, 4)


def lirio_vaso(c, x, y, n=3):
    S = c.S
    B.sombra_elipse(S, x, y + 3, 30, 10, 110)
    pygame.draw.polygon(S, (170, 140, 90), [(x - 9, y - 16), (x + 9, y - 16), (x + 6, y), (x - 6, y)])
    for i in range(n):
        dx = (i - (n - 1) / 2) * 9
        pygame.draw.line(S, (60, 130, 66), (x + dx * .3, y - 16), (x + dx, y - 44 - i % 2 * 6), 2)
        px, py = x + dx, y - 44 - i % 2 * 6
        for a in (-40, 0, 40):
            pygame.draw.ellipse(S, (250, 250, 244), (px - 3 + a * .12, py - 8, 6, 12))
        pygame.draw.circle(S, (240, 200, 70), (int(px), int(py - 2)), 1)


def sino_grande(c, x, y):
    S = c.S
    pygame.draw.rect(S, esc(MAD, .75), (x - 70, y - 8, 140, 12))
    pygame.draw.rect(S, esc(MAD, 1.25), (x - 70, y - 8, 140, 3))
    for sx in (-1, 1):
        pygame.draw.rect(S, esc(MAD, .65), (x + sx * 66 - 5, y - 6, 10, 150))
    B.sombra_elipse(S, x, y + 146, 130, 22, 130)
    br = (176, 141, 87)
    pts = [(x - 12, y + 4), (x + 12, y + 4), (x + 22, y + 40), (x + 40, y + 96), (x + 50, y + 120), (x - 50, y + 120), (x - 40, y + 96), (x - 22, y + 40)]
    pygame.draw.polygon(S, br, pts)
    pygame.draw.polygon(S, esc(br, 1.3), [(x - 12, y + 4), (x - 2, y + 4), (x - 8, y + 40), (x - 24, y + 96), (x - 38, y + 118), (x - 50, y + 120), (x - 40, y + 96), (x - 22, y + 40)])
    pygame.draw.polygon(S, esc(br, .6), [(x + 12, y + 4), (x + 22, y + 40), (x + 40, y + 96), (x + 50, y + 120), (x + 34, y + 120), (x + 24, y + 96), (x + 12, y + 40)])
    for yy in (60, 100):
        pygame.draw.line(S, esc(br, .55), (x - 40 + (yy - 60) * 0.25, y + yy), (x + 40 - (yy - 60) * 0.25, y + yy), 3)
    pygame.draw.rect(S, esc(br, .5), (x - 50, y + 116, 100, 5), 0, 2)
    pygame.draw.circle(S, (60, 44, 26), (x, y + 124), 7)
    B.cruz_latina(S, x, y + 80, 16, esc(br, .55), None, 3)
    for i in range(10):
        pygame.draw.circle(S, (200, 180, 130), (x + 4, y + 130 + i * 8), 2)
        pygame.draw.circle(S, (150, 130, 90), (x + 4, y + 130 + i * 8), 2, 1)
    c.glint(x - 24, y + 60, (255, 240, 190), 4)


def janela_sala(c, cx, by, w, h, tema, seed):
    """Recesso de pedra + vidro colado depois da luz. Romanico: fresta estreita e funda; barroco: vidro claro dourado."""
    S = c.S
    if c.andar == 0:
        w, h = max(18, int(w * .6)), int(h * .92)
        pygame.draw.polygon(S, esc(c.pedra, .35), B.ogiva(cx, by + 4, w + 34, (w + 34) * .5, h - (w + 34) * .5))
    elif c.andar == 3 and tema in ("azul", "rubi", "violeta"):
        tema = "ouro" if tema != "azul" else "grisalha"
    elif c.andar == 2:
        h = int(h * 1.08)
    pts = B.ogiva(cx, by, w + 14, min((w + 14) * 1.15, h * .55), h - min((w + 14) * 1.15, h * .55))
    pygame.draw.polygon(S, esc(c.pedra, .25), pts)
    pygame.draw.polygon(S, esc(c.pedra, 1.2), pts, 3)
    pygame.draw.rect(S, esc(c.pedra, 1.1), (cx - w // 2 - 12, by, w + 24, 5))
    c.janelas.append((cx, by, w, h, tema, seed))


def arcatura_cega(c, cx, by, w, h):
    S = c.S
    rise = w * 1.1
    pygame.draw.polygon(S, esc(c.pedra, .5), B.ogiva(cx, by, w, rise, h - rise))
    pygame.draw.polygon(S, esc(c.pedra, 1.15), B.ogiva(cx, by, w, rise, h - rise), 2)
    pygame.draw.polygon(S, esc(c.pedra, .3), B.ogiva(cx, by, w - 12, rise - 6, h - rise - 4), 1)
    for sx in (-1, 1):
        pygame.draw.rect(S, esc(c.pedra, 1.0), (cx + sx * (w // 2) - 3, by - h + int(rise), 6, h - int(rise)))
        pygame.draw.rect(S, esc(c.pedra, 1.25), (cx + sx * (w // 2) - 3, by - h + int(rise), 2, h - int(rise)))


def hera(c, x, y, sentido=1, n=14):
    S, rnd = c.S, c.rnd
    px, py = x, y
    for i in range(n):
        nx, ny = px + sentido * rnd.randint(-4, 6), py + rnd.randint(6, 12)
        pygame.draw.line(S, (40, 70, 36), (px, py), (nx, ny), 2)
        for sg in (-1, 1):
            pygame.draw.ellipse(S, rnd.choice(((50, 110, 50), (70, 130, 60), (38, 90, 44))), (nx + sg * 4 - 3, ny - 2, 7, 5))
        px, py = nx, ny


def espelho(c, x, y, w=46, h=64):
    S = c.S
    pygame.draw.ellipse(S, (150, 120, 50), (x - w // 2 - 5, y - h // 2 - 5, w + 10, h + 10))
    pygame.draw.ellipse(S, (210, 216, 226), (x - w // 2, y - h // 2, w, h))
    pygame.draw.ellipse(S, (150, 160, 190), (x - w // 2 + 4, y - h // 2 + 4, w - 8, h - 8))
    pygame.draw.line(S, (255, 255, 255), (x - w // 4, y - h // 4), (x + w // 8, y - h // 2 + 10), 3)
    pygame.draw.ellipse(S, (80, 60, 30), (x - w // 2 - 5, y - h // 2 - 5, w + 10, h + 10), 2)
    c.glint(x + 6, y - 14, (255, 255, 255), 4)


def labirinto(c, cx, cy, R):
    S = c.S
    pygame.draw.circle(S, (40, 36, 78), (cx, cy), R)
    pygame.draw.circle(S, (150, 140, 190), (cx, cy), R, 4)
    n = 11
    for i in range(n):
        r = R - 10 - i * (R - 30) / n
        a0 = (i * 37) % 360
        gap = 36 if i % 2 == 0 else 28
        rect = pygame.Rect(cx - r, cy - r, 2 * r, 2 * r)
        pygame.draw.arc(S, (190, 178, 230) if i % 2 == 0 else (120, 110, 170), rect, math.radians(a0 + gap), math.radians(a0 + 360 - 8), 3)
    for a in range(0, 360, 60):
        x = cx + math.cos(math.radians(a)) * (R - 4)
        y = cy + math.sin(math.radians(a)) * (R - 4)
        pygame.draw.circle(S, B.OURO, (int(x), int(y)), 3)
    pygame.draw.circle(S, (230, 200, 90), (cx, cy), 14, 2)
    B.estrela8(S, cx, cy, 11, B.OURO_C)


def scutum(c, x, y, r=34):
    S = c.S
    pygame.draw.rect(S, (30, 24, 50), (x - r - 8, y - r - 8, 2 * r + 16, 2 * r + 24), 0, 6)
    pygame.draw.rect(S, B.OURO, (x - r - 8, y - r - 8, 2 * r + 16, 2 * r + 24), 2, 6)
    pts = [(x, y - r + 10), (x - r * .86, y + r * .5), (x + r * .86, y + r * .5)]
    pygame.draw.polygon(S, B.OURO, pts, 2)
    for (px, py) in pts + [(x, y + 2)]:
        pygame.draw.circle(S, (240, 232, 205), (int(px), int(py)), 8)
        pygame.draw.circle(S, B.OURO, (int(px), int(py)), 8, 2)
    for (px, py) in pts:
        pygame.draw.line(S, B.OURO, (px, py), (x, y + 2), 1)


def arvore_porfirio(c, x, y):
    S = c.S
    pygame.draw.rect(S, PERG, (x - 34, y - 56, 68, 112), 0, 3)
    pygame.draw.rect(S, (110, 70, 36), (x - 34, y - 56, 68, 112), 3, 3)
    for i, nome in enumerate(("S", "C", "V", "A", "H")):
        yy = y - 48 + i * 21
        pygame.draw.rect(S, (200, 180, 130), (x - 12, yy, 24, 15), 0, 2)
        pygame.draw.rect(S, (150, 40, 44), (x - 12, yy, 24, 15), 1, 2)
        if i < 4:
            pygame.draw.line(S, (42, 33, 27), (x, yy + 15), (x, yy + 21), 2)
        pygame.draw.line(S, (150, 40, 44), (x + 12, yy + 7), (x + 28, yy + 7), 1)
        pygame.draw.line(S, (150, 40, 44), (x - 12, yy + 7), (x - 28, yy + 7), 1)


def pia_agua_benta(c, x, y):
    S = c.S
    B.sombra_elipse(S, x, y + 4, 54, 16, 130)
    pygame.draw.polygon(S, (128, 118, 104), [(x - 8, y - 32), (x + 8, y - 32), (x + 12, y), (x - 12, y)])
    pygame.draw.ellipse(S, (96, 88, 78), (x - 26, y - 46, 52, 22))
    pygame.draw.ellipse(S, (150, 140, 124), (x - 24, y - 48, 48, 20))
    pygame.draw.ellipse(S, (88, 130, 200), (x - 18, y - 44, 36, 13))
    pygame.draw.ellipse(S, (170, 200, 240), (x - 12, y - 43, 14, 5))
    c.glint(x + 6, y - 40, (220, 240, 255), 3)


# ------------------------------------------------------------------ construcao por tipo
def construir(c):
    f = TIPOS[c.tipo]
    f(c)
    _extras_andar(c)
    # tochas laterais padrao (se o tipo nao for iluminado so por luz do dia)
    if c.tipo not in ("claustro", "campanario"):
        pass


def _tochas_laterais(c, y1=200, y2=440):
    for (x, y) in ((30, y1), (930, y1), (30, y2), (930, y2)):
        arandela(c, x, y)


def _extras_andar(c):
    a = c.andar
    if a == 1:
        hera(c, 66, 128, 1, 22)
        hera(c, 894, 128, -1, 22)
        hera(c, 26, 380, 1, 12)
    elif a == 2 and c.tipo not in ("cripta",):
        for x in (200, 760):
            lamparina(c, x, 0, 46)
    elif a == 3:
        for x in (150, 810):
            for i, yy in enumerate(range(0, 52, 6)):
                pygame.draw.ellipse(c.S, (110, 108, 116), (x - 2 + (i % 2), yy, 5, 7), 1)
        for i in range(8):
            x, y = c.rnd.randint(110, 850), c.rnd.randint(150, 470)
            pygame.draw.polygon(c.S, (196, 170, 120), [(x, y), (x + 14, y + 3), (x + 12, y + 12), (x + 1, y + 9)])
            pygame.draw.line(c.S, (60, 30, 20), (x + 2, y + 3), (x + 10, y + 5))
        c.brilho(480, 480, 220, (90, 30, 20))


def t_entrada(c):
    S = c.S
    # Galeria dos Reis: nichos com reis coroados
    for i, x in enumerate((250, 330, 630, 710)):
        arcatura_cega(c, x, 100, 50, 76)
        pygame.draw.rect(S, (200, 190, 170), (x - 10, 62, 20, 36), 0, 3)
        pygame.draw.circle(S, (222, 200, 170), (x, 58), 6)
        pygame.draw.polygon(S, OURO, [(x - 7, 54), (x - 7, 46), (x - 3, 50), (x, 44), (x + 3, 50), (x + 7, 46), (x + 7, 54)])
        pygame.draw.rect(S, (150, 140, 124), (x - 14, 96, 28, 6))
    # rosacea pequena sobre a porta
    r = B.rosacea(34, 5, 12, "azul")
    c.extra_post.append(lambda S2, r=r: S2.blit(r, (480 - r.get_width() // 2, 6)))
    pygame.draw.circle(S, esc(c.pedra, .3), (480, 40), 36)
    for (x, y, sg) in ((90, 40, 1), (870, 40, -1)):  # gargulas nas quinas
        pygame.draw.polygon(S, (110, 102, 90), [(x - sg * 22, y - 10), (x + sg * 12, y - 12), (x + sg * 26, y + 2), (x + sg * 8, y + 14), (x - sg * 22, y + 12)])
        pygame.draw.circle(S, (30, 24, 20), (x + sg * 14, y - 2), 2)
        pygame.draw.line(S, (88, 130, 200), (x + sg * 26, y + 4), (x + sg * 28, y + 30), 2)
    estandarte(c, 180, 18, 44, 80, (30, 63, 140), "lis")
    estandarte(c, 780, 18, 44, 80, (30, 63, 140), "lis")
    pia_agua_benta(c, 120, 238)
    # tapete vermelho com bordas douradas
    pygame.draw.rect(S, (150, 24, 30), (430, 126, 100, 374))
    pygame.draw.rect(S, OURO, (430, 126, 100, 374), 3)
    pygame.draw.rect(S, (110, 16, 22), (440, 126, 80, 374), 2)
    for y in range(150, 490, 56):
        B.cruz_latina(S, 480, y, 22, OURO, None, 4)
    # luz de fora vinda do sul
    c.brilho(480, 520, 300, (150, 130, 80))
    for (x, y) in ((250, 470), (710, 470)):
        candelabro(c, x, y, 80, 3)
    janela_sala(c, 120, 106, 34, 80, "azul", 1)
    janela_sala(c, 840, 106, 34, 80, "rubi", 2)
    c.glint(250, 60, OURO), c.glint(710, 60, OURO)


def t_nave(c):
    S = c.S
    # grande arco formeiro com janelas, triforio
    if c.andar in (1, 2):
        pygame.draw.polygon(S, esc(c.pedra, 1.12), B.ogiva(480, 124, 640, 420, 0))
        pygame.draw.polygon(S, esc(c.pedra, 1.35), B.ogiva(480, 124, 640, 420, 0), 5)
        pygame.draw.polygon(S, esc(c.pedra, .5), B.ogiva(480, 124, 610, 400, 0), 3)
    # nervuras descendo
    for k, (x0, ex) in enumerate(((0, 1), (960, -1))):
        for j in range(3):
            pts = [(x0, 0), (x0 + ex * (80 + j * 90), 6 + j * 4), (x0 + ex * (210 + j * 120), 46 + j * 6)]
            pygame.draw.lines(S, esc(c.pedra, .45), False, pts, 5)
            pygame.draw.lines(S, esc(c.pedra, 1.2), False, [(p[0], p[1] - 2) for p in pts], 1)
    # triforio sobre o plinto
    for x in range(250, 720, 34):
        if 430 < x < 530:
            continue
        pygame.draw.polygon(S, esc(c.pedra, .25), B.ogiva(x + 14, 100, 26, 30, 10))
        pygame.draw.polygon(S, esc(c.pedra, 1.1), B.ogiva(x + 14, 100, 26, 30, 10), 1)
    janela_sala(c, 340, 94, 52, 80, "azul", 3)
    janela_sala(c, 620, 94, 52, 80, "rubi", 4)
    janela_sala(c, 250, 94, 36, 58, "violeta", 5)
    janela_sala(c, 710, 94, 36, 58, "azul", 6)
    # cruz de pedra inlay no piso e jube ao fundo
    pygame.draw.rect(S, (150, 138, 120), (470, 150, 20, 310))
    pygame.draw.rect(S, (150, 138, 120), (330, 270, 300, 20))
    B.cruz_latina(S, 480, 280, 4, (0, 0, 0))
    estandarte(c, 120, 20, 40, 70, (160, 30, 36), "cruz")
    estandarte(c, 840, 20, 40, 70, (30, 63, 140), "lis")
    _tochas_laterais(c)
    # pilar de feixe (fustes) nas laterais ja existe; capitel foliado extra
    for x in (50, 910):
        for yy in (150, 470):
            for i in range(5):
                pygame.draw.circle(S, (96, 120, 70), (x - 6 + i * 3, yy + (i % 2) * 3), 3)


def t_capela(c):
    S = c.S
    altar(c, 640, 232, 170)
    retabulo(c, 640, 150, 160, 54)
    # estatua de Maria com lirios (console a esquerda)
    pygame.draw.polygon(S, (200, 196, 214), [(300, 108), (330, 108), (336, 60), (294, 60)])
    pygame.draw.circle(S, (230, 214, 190), (315, 52), 8)
    pygame.draw.polygon(S, (30, 63, 140), [(300, 62), (330, 62), (340, 108), (290, 108)])
    pygame.draw.ellipse(S, OURO, (306, 38, 18, 6))
    pygame.draw.polygon(S, OURO, [(305, 44), (325, 44), (320, 36), (315, 41), (310, 36)])
    lirio_vaso(c, 270, 230, 3)
    lirio_vaso(c, 360, 232, 3)
    # relicario sobre a mesa
    B.caixa(S, (230, 150, 70, 30), (150, 120, 70), (110, 86, 50), 10)
    pygame.draw.polygon(S, (30, 63, 140), [(246, 138), (284, 138), (284, 122), (265, 110), (246, 122)])
    pygame.draw.polygon(S, OURO, [(246, 138), (284, 138), (284, 122), (265, 110), (246, 122)], 2)
    c.glint(265, 124, B.OURO_C, 4)
    janela_sala(c, 170, 100, 50, 82, "azul", 11)
    janela_sala(c, 790, 100, 50, 82, "rubi", 12)
    # tapete
    pygame.draw.rect(S, (130, 24, 32), (560, 280, 160, 190), 0, 4)
    pygame.draw.rect(S, OURO, (560, 280, 160, 190), 2, 4)
    B.lis(S, 640, 375, 54, OURO)
    lamparina(c, 520, 0, 70, (255, 120, 90))
    _tochas_laterais(c, 220, 430)


def t_claustro(c):
    S, rnd = c.S, c.rnd
    # arcada romanica sobre colunas geminadas; ao fundo o jardim sob o ceu
    sky = B.vgrad(960, 110, (150, 190, 232), (214, 226, 236))
    S.blit(sky, (0, 12))
    for i in range(7):
        x = rnd.randint(40, 920)
        pygame.draw.circle(S, (248, 248, 250), (x, 40 + rnd.randint(0, 20)), 14)
        pygame.draw.circle(S, (248, 248, 250), (x + 14, 44), 10)
    for x in range(30, 940, 30):
        h = rnd.randint(22, 50)
        pygame.draw.circle(S, rnd.choice(((60, 110, 56), (80, 130, 66), (44, 90, 50))), (x, 118 - h // 2), h // 2 + 6)
    pygame.draw.polygon(S, (170, 120, 90), [(700, 96), (860, 96), (830, 60), (730, 60)])
    # arcos
    n = 6
    for i in range(n):
        cx = 120 + i * 144
        if 436 - 40 < cx < 524 + 40:
            pass
        pygame.draw.rect(S, esc(c.pedra, 1.0), (cx - 72, 14, 144, 110))
    S.blit(sky, (0, 12), (0, 0, 0, 0))
    # redesenha a aberta
    for i in range(n):
        cx = 120 + i * 144
        arc = pygame.Rect(cx - 60, 30, 120, 190)
        pts = [(cx - 54, 124), (cx - 54, 70)]
        for j in range(0, 17):
            a = PI - PI * j / 16
            pts.append((cx + math.cos(a) * 54, 70 - math.sin(a) * 52))
        pts.append((cx + 54, 124))
        pygame.draw.polygon(S, (130, 176, 214), pts)
        pygame.draw.polygon(S, (230, 236, 242), [(cx - 54, 80), (cx + 54, 70), (cx + 54, 124), (cx - 54, 124)]) if False else None
        # jardim visto atraves do arco
        pygame.draw.rect(S, (74, 126, 58), (cx - 54, 96, 108, 28))
        for k in range(10):
            pygame.draw.circle(S, rnd.choice(((60, 110, 50), (90, 150, 70))), (cx - 48 + k * 11, 98 + rnd.randint(-3, 3)), 8)
        pygame.draw.polygon(S, esc(c.pedra, 1.2), pts, 6)
        pygame.draw.polygon(S, esc(c.pedra, .55), pts, 2)
        # colunas geminadas
        for dx in (-67, -61, 61, 67):
            pass
        for dx in (-70, 70):
            for k in (-4, 4):
                pygame.draw.rect(S, esc(c.pedra, 1.1), (cx + dx + k - 3, 62, 6, 58))
                pygame.draw.rect(S, esc(c.pedra, 1.4), (cx + dx + k - 3, 62, 2, 58))
            pygame.draw.rect(S, esc(c.pedra, .8), (cx + dx - 11, 56, 22, 8), 0, 2)
            pygame.draw.rect(S, esc(c.pedra, .8), (cx + dx - 11, 116, 22, 8), 0, 2)
    # porta N: reconstroi moldura por cima do arco do centro
    S.blit(B.parede_pedra.__call__ and S.subsurface((0, 0, 1, 1)), (0, 0)) if False else None
    pygame.draw.rect(S, esc(c.pedra, .9), (410, 40, 140, 84))
    pygame.draw.polygon(S, esc(c.pedra, .25), B.ogiva(480, 124, 90, 60, 14))
    for x in (60, 900):
        pass
    # banco de pedra
    for x in (100, 740):
        B.caixa(S, (x, 232, 120, 16), (176, 166, 148), (140, 130, 114), 8)
    # poco: medalhao plano no centro
    S2 = S
    pygame.draw.circle(S2, (112, 102, 90), (480, 340), 40)
    pygame.draw.circle(S2, (170, 160, 142), (480, 340), 40, 5)
    pygame.draw.circle(S2, (40, 76, 120), (480, 340), 30)
    pygame.draw.circle(S2, (120, 170, 220), (480, 340), 30, 2)
    for a in range(0, 360, 90):
        x = 480 + math.cos(math.radians(a)) * 36
        y = 340 + math.sin(math.radians(a)) * 36
        pygame.draw.circle(S2, (120, 90, 56), (int(x), int(y)), 4)
    pygame.draw.circle(S2, (170, 210, 240), (474, 334), 8)
    c.glint(470, 332, (255, 255, 255), 4)
    # sombras das arcadas sobre o piso (faixas diagonais de luz)
    for i in range(n):
        cx = 120 + i * 144
        pts = [(cx - 54, 124), (cx + 54, 124), (cx + 94, 250), (cx - 14, 250)]
        s, o = B.feixe(pts, (255, 250, 200), 46)
        c.pools.append((s, o, 0))
    c.brilho(480, 300, 420, (110, 110, 90))
    # lirios e roseiras ja no piso; estandarte nao
    c.glint(330, 262, (255, 255, 255)), c.glint(660, 390, (255, 255, 255))


def t_scriptorium(c):
    S, rnd = c.S, c.rnd
    janela_sala(c, 280, 106, 64, 90, "grisalha", 21)
    janela_sala(c, 680, 106, 64, 90, "grisalha", 22)
    # armario de rolos
    for x0 in (80, 800):
        pygame.draw.rect(S, esc(MAD, .45), (x0, 20, 80, 90))
        for r in range(3):
            for k in range(4):
                px, py = x0 + 6 + k * 19, 26 + r * 28
                pygame.draw.rect(S, (30, 20, 12), (px, py, 16, 24))
                pygame.draw.ellipse(S, PERG, (px + 1, py + 8, 14, 14))
                pygame.draw.ellipse(S, esc(PERG, .75), (px + 3, py + 10, 10, 10), 1)
        pygame.draw.rect(S, (20, 14, 10), (x0, 20, 80, 90), 2)
    # escrivaninhas inclinadas com pergaminho, tinteiro e pena
    for (x, y) in ((100, 200), (100, 380), (740, 200), (740, 380)):
        B.sombra_elipse(S, x + 60, y + 52, 150, 20, 130)
        pygame.draw.rect(S, esc(MAD, .7), (x + 6, y + 14, 8, 38))
        pygame.draw.rect(S, esc(MAD, .7), (x + 106, y + 14, 8, 38))
        pygame.draw.polygon(S, MAD, [(x, y + 20), (x + 120, y + 20), (x + 108, y - 6), (x + 12, y - 6)])
        pygame.draw.polygon(S, PERG, [(x + 14, y + 14), (x + 106, y + 14), (x + 98, y - 2), (x + 22, y - 2)])
        for i in range(5):
            pygame.draw.line(S, B.TINTA, (x + 28 + i * 3, y + 10 - i * 3), (x + 92 - i * 3, y + 10 - i * 3))
        pygame.draw.rect(S, (170, 30, 36), (x + 26, y - 2, 12, 10))
        pygame.draw.circle(S, (14, 10, 8), (x + 112, y + 4), 5)
        pygame.draw.line(S, (250, 250, 244), (x + 112, y + 2), (x + 122, y - 14), 2)
        pygame.draw.line(S, (200, 200, 196), (x + 118, y - 8), (x + 122, y - 14), 1)
        pygame.draw.rect(S, esc(MAD, 1.0), (x, y + 20, 120, 4))
    for (x, y) in ((260, 232), (840, 232)):
        vela(c, x, y, 20)
    pygame.draw.rect(S, (170, 30, 36), (320, 450, 40, 30), 0, 3)  # livro no chao
    estante(c, 370, 30, 70, 78, 3, False, True)
    estante(c, 520, 30, 70, 78, 3, False, True)
    c.brilho(480, 300, 380, (90, 76, 46))
    _tochas_laterais(c, 220, 430)


def t_capitular(c):
    S = c.S
    # arcatura geminada com oculos
    for x in (250, 330, 630, 710):
        pygame.draw.polygon(S, esc(c.pedra, .35), B.ogiva(x - 14, 100, 24, 40, 26))
        pygame.draw.polygon(S, esc(c.pedra, .35), B.ogiva(x + 14, 100, 24, 40, 26))
        pygame.draw.circle(S, esc(c.pedra, .3), (x, 52), 8)
        pygame.draw.circle(S, esc(c.pedra, 1.2), (x, 52), 8, 2)
        pygame.draw.polygon(S, esc(c.pedra, 1.2), B.ogiva(x, 104, 70, 96, 4), 3)
    # banco de pedra ao longo da parede (3D) com cantos em U
    for (x, w) in ((200, 200), (560, 200)):
        B.caixa(S, (x, 104, w, 16), (176, 166, 148), (138, 128, 112), 8)
    for y in (160, 380):
        for x in (66, 842):
            B.caixa(S, (x, y + 40, 52, 70), (176, 166, 148), (138, 128, 112), 10) if False else None
    for x in (64, 846):
        for y0 in (140, 380):
            B.caixa(S, (x, y0 + 80, 50, 70), (176, 166, 148), (138, 128, 112), 12)
    # catedra do superior com dossel
    x, y = 290, 230
    B.sombra_elipse(S, x, y + 4, 90, 18, 140)
    pygame.draw.rect(S, esc(MAD, .8), (x - 30, y - 56, 60, 56))
    pygame.draw.rect(S, MAD, (x - 24, y - 50, 48, 36))
    pygame.draw.polygon(S, esc(MAD, 1.1), [(x - 36, y - 56), (x + 36, y - 56), (x, y - 96)])
    pygame.draw.polygon(S, OURO, [(x - 36, y - 56), (x + 36, y - 56), (x, y - 96)], 2)
    pygame.draw.rect(S, (140, 40, 70), (x - 26, y - 34, 52, 10))
    atril(c, 640, 238)
    # cruz e selo na parede + estandartes violeta
    B.crucifixo(S, 480, 36, 50) if False else None
    estandarte(c, 180, 20, 44, 76, (91, 44, 111), "cruz")
    estandarte(c, 780, 20, 44, 76, (91, 44, 111), "cruz")
    pygame.draw.circle(S, (150, 30, 36), (560, 62), 16)
    pygame.draw.circle(S, (190, 50, 50), (558, 60), 11)
    pygame.draw.circle(S, (110, 16, 22), (560, 62), 16, 2)
    # medalhao central (coluna central da abobada)
    pygame.draw.circle(S, (130, 120, 130), (480, 330), 52)
    pygame.draw.circle(S, (170, 160, 170), (480, 330), 52, 4)
    pygame.draw.circle(S, (92, 80, 100), (480, 330), 40, 2)
    B.cruz_latina(S, 480, 330, 46, OURO, (90, 70, 20), 8)
    janela_sala(c, 400, 96, 34, 62, "violeta", 31)
    janela_sala(c, 560, 96, 34, 62, "violeta", 32) if False else None
    c.brilho(480, 250, 400, (80, 70, 70))
    _tochas_laterais(c)


def t_sacristia(c):
    S = c.S
    # lambril de madeira
    pygame.draw.rect(S, esc(MAD, .75), (0, 56, 960, 56))
    for x in range(0, 960, 40):
        pygame.draw.rect(S, esc(MAD, .55), (x + 4, 62, 32, 44), 2, 3)
    # armario de paramentos aberto (esq.) com casulas conicas
    x0 = 220
    pygame.draw.rect(S, esc(MAD, .55), (x0, 14, 200, 108))
    pygame.draw.rect(S, (30, 20, 12), (x0 + 8, 22, 184, 92))
    for i, col in enumerate(((244, 241, 232), (46, 107, 58), (91, 44, 111), (163, 22, 26), (244, 241, 232))):
        px = x0 + 22 + i * 38
        pygame.draw.line(S, (150, 120, 60), (px, 26), (px, 34), 2)
        pygame.draw.polygon(S, col, [(px - 3, 34), (px + 3, 34), (px + 16, 110), (px - 16, 110)])
        pygame.draw.polygon(S, esc(col, .75), [(px, 34), (px + 3, 34), (px + 16, 110), (px + 2, 110)])
        pygame.draw.line(S, OURO, (px, 38), (px, 108), 2)
    pygame.draw.polygon(S, MAD, [(x0 - 24, 18), (x0, 14), (x0, 122), (x0 - 24, 122)])
    pygame.draw.polygon(S, MAD, [(x0 + 224, 18), (x0 + 200, 14), (x0 + 200, 122), (x0 + 224, 122)])
    pygame.draw.rect(S, (20, 14, 10), (x0, 14, 200, 108), 2)
    # comoda com calice, turibulo e pixide pendente
    B.caixa(S, (560, 80, 170, 44), (138, 96, 56), (104, 70, 38), 14)
    for i in range(3):
        pygame.draw.rect(S, esc(MAD, .65), (568 + i * 54, 86, 46, 32), 2, 2)
        pygame.draw.circle(S, OURO, (591 + i * 54, 102), 3)
    # calice
    pygame.draw.polygon(S, OURO, [(590, 56), (610, 56), (604, 70), (596, 70)])
    pygame.draw.rect(S, OURO, (598, 70, 4, 8))
    pygame.draw.ellipse(S, B.OURO_S, (590, 77, 20, 6))
    pygame.draw.circle(S, (244, 241, 232), (600, 52), 6)
    # turibulo
    pygame.draw.circle(S, OURO, (660, 70), 9)
    pygame.draw.polygon(S, B.OURO_S, [(651, 66), (669, 66), (660, 54)])
    for dx in (-8, 0, 8):
        pygame.draw.line(S, (170, 150, 90), (660 + dx, 54), (660, 40), 1)
    pygame.draw.circle(S, (190, 190, 190), (664, 36), 4)
    # pixide (pomba pendente) sobre a comoda
    pygame.draw.line(S, (150, 150, 160), (700, 0), (700, 38), 1)
    pygame.draw.ellipse(S, (230, 226, 210), (690, 38, 20, 11))
    pygame.draw.polygon(S, (230, 226, 210), [(696, 40), (688, 34), (700, 40)])
    # lavabo/agua benta
    pia_agua_benta(c, 130, 240)
    # arca com casula dobrada
    arca(c, 760, 360, 96, 46)
    arca(c, 90, 400, 80, 42)
    B.crucifixo(S, 470, 150 if False else 0, 0) if False else None
    lamparina(c, 480, 0, 60)
    candelabro(c, 860, 250, 90, 3)
    c.glint(600, 52, B.OURO_C, 4)
    # tapete verde
    pygame.draw.rect(S, (46, 90, 60), (380, 300, 200, 150), 0, 4)
    pygame.draw.rect(S, OURO, (380, 300, 200, 150), 2, 4)
    janela_sala(c, 160, 100, 34, 70, "verde", 41) if False else None


def t_cripta(c):
    S = c.S
    # abobada baixa e pesada: arcos de volta perfeita
    for x in range(-40, 1000, 160):
        pts = [(x, 124)]
        for j in range(0, 17):
            a = PI - PI * j / 16
            pts.append((x + 80 + math.cos(a) * 80, 122 - math.sin(a) * 70))
        pts.append((x + 160, 124))
        pygame.draw.polygon(S, esc(c.pedra, .38), pts)
        pygame.draw.lines(S, esc(c.pedra, 1.1), False, pts[1:-1], 6)
        pygame.draw.lines(S, esc(c.pedra, .5), False, pts[1:-1], 2)
    for x in range(40, 960, 160):
        pygame.draw.rect(S, esc(c.pedra, .95), (x - 14, 52, 28, 72))
        pygame.draw.rect(S, esc(c.pedra, .75), (x - 18, 44, 36, 12), 0, 2)
        pygame.draw.rect(S, esc(c.pedra, 1.3), (x - 14, 52, 5, 72))
    # sarcofagos
    sarcofago(c, 84, 180, 130, 54)
    sarcofago(c, 84, 380, 130, 54)
    sarcofago(c, 746, 180, 130, 54)
    sarcofago(c, 746, 380, 130, 54)
    # relicario em nicho + ichthys gravado + caveira de Adao sob cruz
    pygame.draw.polygon(S, esc(c.pedra, .25), B.ogiva(330, 112, 50, 60, 14))
    pygame.draw.polygon(S, (30, 63, 140), [(316, 100), (344, 100), (344, 84), (330, 74), (316, 84)])
    pygame.draw.polygon(S, OURO, [(316, 100), (344, 100), (344, 84), (330, 74), (316, 84)], 2)
    c.glint(330, 88, B.OURO_C, 3)
    pygame.draw.arc(S, (60, 54, 48), (606, 76, 40, 24), 0.4, 2.7, 2)
    pygame.draw.arc(S, (60, 54, 48), (606, 70, 40, 24), 3.5, 5.9, 2)
    pygame.draw.polygon(S, (60, 54, 48), [(646, 88), (656, 78), (656, 98)], 1)
    B.cruz_latina(S, 720, 60, 40, (140, 126, 100), (40, 36, 30), 7)
    pygame.draw.circle(S, (214, 206, 184), (720, 94), 6)
    # epitafios no piso
    for (x, y) in ((420, 400), (540, 250), (300, 300)):
        pygame.draw.rect(S, (60, 54, 48), (x - 30, y - 18, 60, 36), 0, 3)
        pygame.draw.rect(S, (110, 100, 86), (x - 30, y - 18, 60, 36), 1, 3)
        B.cruz_latina(S, x, y, 20, (110, 100, 86), None, 3)
    for x in (200, 760):
        lamparina(c, x, 0, 70, (255, 160, 80))
    for (x, y) in ((50, 160), (910, 160), (50, 460), (910, 460)):
        vela(c, x, y + 10, 18)
    # teias
    for (x, sg) in ((6, 1), (954, -1)):
        for k in range(1, 4):
            pygame.draw.line(S, (150, 150, 150), (x, 124), (x + sg * 14 * k, 124 + 4 * k))
        pygame.draw.line(S, (150, 150, 150), (x, 124), (x + sg * 44, 160))


def t_campanario(c):
    S = c.S
    # vãos com abat-sons
    for x in (250, 380, 580, 710):
        pts = B.ogiva(x, 108, 60, 70, 26)
        pygame.draw.polygon(S, (170, 196, 230), pts)
        for yy in range(30, 108, 7):
            pygame.draw.line(S, esc(MAD, .75), (x - 32, yy), (x + 32, yy + 4), 3)
            pygame.draw.line(S, esc(MAD, 1.2), (x - 32, yy - 1), (x + 32, yy + 3), 1)
        pygame.draw.polygon(S, esc(c.pedra, 1.2), pts, 4)
        c.janelas.append((x, 108, 0, 0, "grisalha", 0)) if False else None
    # galo (cata-vento) em silhueta num vao
    pygame.draw.polygon(S, (30, 24, 20), [(380, 54), (392, 48), (396, 38), (402, 42), (398, 52), (390, 58)])
    pygame.draw.line(S, (30, 24, 20), (380, 54), (372, 44), 2)
    pygame.draw.line(S, (30, 24, 20), (388, 58), (388, 76), 2)
    # gargula
    for (x, sg) in ((86, 1), (874, -1)):
        pygame.draw.polygon(S, (110, 102, 90), [(x - sg * 24, 36), (x + sg * 10, 32), (x + sg * 30, 46), (x + sg * 10, 62), (x - sg * 24, 58)])
        pygame.draw.circle(S, (30, 24, 20), (x + sg * 18, 44), 2)
    # vigas
    pygame.draw.rect(S, esc(MAD, .8), (0, 20, 960, 10))
    for x in (0, 300, 660):
        pygame.draw.polygon(S, esc(MAD, .7), [(x, 30), (x + 150, 30), (x, 110)])
    sino_grande(c, 150, 130)
    sino_grande(c, 810, 150) if False else None
    # escada em caracol (poste + degraus)
    x, y = 808, 276
    B.sombra_elipse(S, x, y + 120, 120, 26, 140)
    pygame.draw.rect(S, esc(MAD, .8), (x - 6, y - 40, 12, 162))
    for i in range(9):
        yy = y + 112 - i * 18
        w = 56 + (i % 2) * 8
        pygame.draw.polygon(S, esc(c.pedra, 1.1 - i * .03), [(x - w if i % 2 else x - 8, yy), (x + 8 if i % 2 else x + w, yy), (x + 8 if i % 2 else x + w, yy + 8), (x - w if i % 2 else x - 8, yy + 8)])
        pygame.draw.line(S, esc(c.pedra, 1.4), (x - w if i % 2 else x - 8, yy), (x + 8 if i % 2 else x + w, yy))
    lamparina(c, 480, 0, 50, (200, 220, 255))
    c.brilho(480, 60, 300, (110, 120, 150))
    # penas e cordas
    for i in range(6):
        x, y = c.rnd.randint(260, 700), c.rnd.randint(160, 470)
        pygame.draw.ellipse(S, (230, 230, 226), (x, y, 10, 3))


def t_biblioteca(c):
    S = c.S
    estante(c, 240, 20, 96, 92, 3, True)
    estante(c, 360, 20, 60, 92, 3, True)
    estante(c, 540, 20, 60, 92, 3, True)
    estante(c, 624, 20, 96, 92, 3, True)
    estante(c, 80, 30, 110, 82, 3, True)
    # estantes baixas laterais
    for (x, y) in ((70, 160), (70, 380), (840, 160), (840, 380)):
        pass
    for (x, y) in ((90, 150), (810, 150), (90, 380), (810, 380)):
        B.sombra_elipse(S, x + 30, y + 60, 90, 18, 120)
        pygame.draw.polygon(S, MAD, [(x, y + 16), (x + 60, y + 16), (x + 54, y), (x + 6, y)])
        pygame.draw.polygon(S, PERG, [(x + 8, y + 12), (x + 52, y + 12), (x + 48, y + 2), (x + 12, y + 2)])
        pygame.draw.rect(S, esc(MAD, .7), (x + 4, y + 16, 6, 36))
        pygame.draw.rect(S, esc(MAD, .7), (x + 50, y + 16, 6, 36))
        for k in range(3):
            pygame.draw.ellipse(S, (170, 170, 180), (x + 26 + k * 3, y + 14 + k * 4, 6, 4), 1)
    arvore_porfirio(c, 880, 66) if False else None
    arvore_porfirio(c, 180, 66) if False else None
    # escada de biblioteca
    x, y = 440, 130
    pygame.draw.line(S, esc(MAD, .8), (x, y), (x - 24, y + 90), 5)
    pygame.draw.line(S, esc(MAD, .8), (x + 16, y), (x + 32, y + 90), 5) if False else None
    estandarte(c, 480, 16, 0, 0, (0, 0, 0)) if False else None
    janela_sala(c, 160, 100, 36, 64, "ouro", 51) if False else None
    lamparina(c, 300, 0, 40)
    lamparina(c, 660, 0, 40)
    arca(c, 760, 430, 90, 40)
    c.brilho(480, 220, 380, (100, 80, 40))
    _tochas_laterais(c, 220, 430)


def t_coro(c):
    S = c.S
    # jube: galeria de arcos com cruz triunfal
    for i, x in enumerate(range(230, 740, 40)):
        if 430 < x < 530:
            continue
        pygame.draw.polygon(S, esc(c.pedra, .3), B.ogiva(x + 14, 112, 30, 40, 40))
        pygame.draw.polygon(S, esc(c.pedra, 1.2), B.ogiva(x + 14, 112, 30, 40, 40), 2)
    pygame.draw.rect(S, esc(c.pedra, 1.0), (200, 18, 560, 12))
    janela_sala(c, 330, 108, 40, 80, "violeta", 61)
    janela_sala(c, 630, 108, 40, 80, "azul", 62)
    # estalas de madeira
    for x0, sg in ((64, 1), (846, -1)):
        for (ya, yb) in ((140, 260), (368, 488)):
            n = 3
            h = (yb - ya) // n
            for i in range(n):
                y = ya + i * h
                B.sombra_elipse(S, x0 + 24, y + h - 2, 56, 14, 100)
                pygame.draw.rect(S, esc(MAD, .6), (x0, y + 4, 50, h - 6))
                pygame.draw.rect(S, MAD, (x0 + 4, y + 8, 42, h - 14), 0, 3)
                pygame.draw.polygon(S, esc(MAD, 1.15), [(x0, y + 4), (x0 + 50, y + 4), (x0 + 25, y - 8)])
                pygame.draw.line(S, esc(MAD, 1.4), (x0 + 4, y + 10), (x0 + 46, y + 10), 2)
                pygame.draw.circle(S, OURO, (x0 + 25, y - 8), 3)
                pygame.draw.rect(S, esc(MAD, 1.25), (x0 - 2 if sg > 0 else x0, y + h - 22, 52, 8), 0, 2)
    # atril-aguia com saltério
    x, y = 300, 250
    B.sombra_elipse(S, x, y + 4, 70, 16, 130)
    pygame.draw.rect(S, (176, 141, 87), (x - 4, y - 70, 8, 70))
    pygame.draw.ellipse(S, (176, 141, 87), (x - 18, y - 6, 36, 10))
    pygame.draw.polygon(S, (176, 141, 87), [(x - 28, y - 84), (x + 28, y - 84), (x + 20, y - 70), (x - 20, y - 70)])
    pygame.draw.polygon(S, esc((176, 141, 87), 1.3), [(x - 28, y - 84), (x, y - 100), (x + 28, y - 84)])
    pygame.draw.polygon(S, (150, 30, 36), [(x - 22, y - 85), (x + 22, y - 85), (x + 18, y - 98), (x - 18, y - 98)])
    pygame.draw.rect(S, (250, 236, 200), (x - 8, y - 96, 16, 10))
    atril(c, 660, 250)
    for (x, y) in ((250, 450), (710, 450)):
        candelabro(c, x, y, 84, 3)
    estandarte(c, 120, 20, 40, 70, (91, 44, 111), "estrela")
    estandarte(c, 840, 20, 40, 70, (91, 44, 111), "estrela")
    _tochas_laterais(c, 180, 450) if False else None


def t_altar_mor(c):
    S = c.S
    # abside: tres lancetas; mandorla com Cristo sobre a porta; tetramorfo nos cantos
    janela_sala(c, 250, 108, 48, 92, "azul", 71)
    janela_sala(c, 350, 108, 40, 80, "rubi", 72)
    janela_sala(c, 610, 108, 40, 80, "rubi", 73)
    janela_sala(c, 710, 108, 48, 92, "azul", 74)
    # mandorla
    mand = surf(80, 60)
    pygame.draw.ellipse(mand, (255, 224, 140, 230), (0, 0, 80, 60))
    pygame.draw.ellipse(mand, (30, 63, 140, 255), (0, 0, 80, 60), 3)
    S.blit(mand, (440, 2))
    pygame.draw.polygon(S, (240, 232, 214), [(472, 22), (488, 22), (494, 52), (466, 52)])
    pygame.draw.circle(S, (230, 200, 170), (480, 18), 6)
    pygame.draw.circle(S, OURO, (480, 18), 9, 2)
    pygame.draw.line(S, (200, 40, 46), (480, 12), (480, 24), 2)
    for (x, y, k) in ((420, 12, "a"), (546, 12, "b")):
        pygame.draw.circle(S, (230, 220, 190), (x, y + 8), 7)
        pygame.draw.polygon(S, OURO, [(x - 12, y + 10), (x - 2, y + 16), (x - 2, y + 4)])
        pygame.draw.polygon(S, OURO, [(x + 12, y + 10), (x + 2, y + 16), (x + 2, y + 4)])
    # altar-mor com crucifixo, velas; sem tabernaculo
    # degraus (presbiterio)
    for i in range(3):
        pygame.draw.rect(S, esc((200, 190, 170), 1 - i * .08), (360 - i * 18, 200 + i * 12, 240 + i * 36, 12))
        pygame.draw.line(S, (255, 244, 220), (360 - i * 18, 200 + i * 12), (600 + i * 18, 200 + i * 12))
    altar(c, 480, 196, 210)
    retabulo(c, 480, 152, 170, 36) if False else None
    # pixide pendente (pomba eucaristica)
    pygame.draw.line(S, (190, 190, 190), (560, 0), (560, 58), 1)
    pygame.draw.ellipse(S, (240, 236, 220), (548, 58, 24, 13))
    pygame.draw.polygon(S, (240, 236, 220), [(554, 60), (544, 52), (558, 60)])
    candelabro(c, 250, 380, 100, 5)
    candelabro(c, 710, 380, 100, 5)
    for x in (140, 820):
        B.sombra_elipse(S, x, 470, 56, 16, 130)
        pygame.draw.rect(S, (190, 180, 160), (x - 14, 400, 28, 70))
        pygame.draw.polygon(S, (210, 200, 180), [(x - 22, 400), (x + 22, 400), (x + 14, 388), (x - 14, 388)])
        B.cruz_latina(S, x, 436, 24, OURO, None, 4)
    # tapete vermelho central
    pygame.draw.rect(S, (150, 24, 30), (430, 250, 100, 250))
    pygame.draw.rect(S, OURO, (430, 250, 100, 250), 3)
    c.brilho(480, 180, 300, (160, 120, 50))
    c.glint(480, 120, B.OURO_C, 6), c.glint(420, 160, B.OURO_C, 4), c.glint(540, 160, B.OURO_C, 4)


def t_loja(c):
    S = c.S
    for (x0, sg) in ((250, 1), (540, 1)):
        B.caixa(S, (x0, 86, 170, 38), (176, 128, 70), (120, 80, 44), 12)
        for i, col in enumerate(((150, 40, 44), (36, 70, 130), (46, 107, 58), (176, 130, 50), (110, 60, 110))):
            pygame.draw.rect(S, col, (x0 + 10 + i * 30, 60 + (i % 2) * 4, 22, 22 - (i % 2) * 4))
            pygame.draw.line(S, OURO, (x0 + 10 + i * 30, 66), (x0 + 31 + i * 30, 66))
        pygame.draw.rect(S, (20, 14, 10), (x0, 74, 170, 50), 1)
    # peciae penduradas
    for x in range(260, 700, 52):
        if 430 < x < 530:
            continue
        pygame.draw.line(S, (110, 90, 60), (x, 20), (x, 30), 1)
        pygame.draw.rect(S, PERG, (x - 8, 30, 16, 24))
        for k in range(3):
            pygame.draw.line(S, B.TINTA, (x - 5, 36 + k * 5), (x + 5, 36 + k * 5))
    estante(c, 66, 24, 110, 88, 3, False, True)
    estante(c, 784, 24, 110, 88, 3, False, True)
    # selo do livreiro + pena e tinteiro
    pygame.draw.circle(S, (160, 30, 36), (480, 30), 12) if False else None
    for (x, y) in ((130, 220), (830, 220)):
        arca(c, x - 40, y + 20, 80, 40)
    # tapete verde-ocre
    pygame.draw.rect(S, (60, 100, 60), (180, 300, 600, 170), 0, 6)
    pygame.draw.rect(S, OURO, (180, 300, 600, 170), 3, 6)
    pygame.draw.rect(S, (46, 80, 46), (192, 312, 576, 146), 2, 4)
    for x in range(230, 760, 80):
        B.quadrifolio(S, x, 385, 40, (80, 130, 76), 2)
    lamparina(c, 240, 0, 40, (255, 200, 120))
    lamparina(c, 720, 0, 40, (255, 200, 120))
    for (x, y) in ((70, 300), (890, 300)):
        vela(c, x, y + 120, 22) if False else None
    c.brilho(480, 260, 380, (110, 86, 44))
    _tochas_laterais(c, 220, 430)


def t_tesouro(c):
    S = c.S
    pygame.draw.rect(S, (24, 18, 14), (250, 28, 460, 62))
    for i, x in enumerate((290, 380, 580, 670)):
        pygame.draw.rect(S, esc(c.pedra, .35), (x - 30, 34, 60, 78))
        pygame.draw.polygon(S, (30, 63, 140), [(x - 16, 82), (x + 16, 82), (x + 16, 60), (x, 44), (x - 16, 60)])
        pygame.draw.polygon(S, OURO, [(x - 16, 82), (x + 16, 82), (x + 16, 60), (x, 44), (x - 16, 60)], 2)
        pygame.draw.polygon(S, OURO, [(x - 16, 60), (x, 44), (x + 16, 60)], 0) if False else None
        B.lis(S, x, 66, 18, OURO)
        c.glint(x + 8, 56, B.OURO_C, 4)
    # grade
    for x in range(30, 130, 10):
        pygame.draw.line(S, (30, 28, 32), (x, 20), (x, 112), 2)
    arca(c, 84, 170, 110, 52, True)
    arca(c, 770, 170, 110, 52, True)
    arca(c, 100, 400, 90, 44)
    arca(c, 780, 400, 90, 44, True)
    for (x, y) in ((190, 410), (770, 270), (180, 260)):
        for i in range(14):
            px, py = x + c.rnd.randint(-30, 30), y + c.rnd.randint(-10, 10)
            pygame.draw.circle(S, B.OURO if i % 2 else B.OURO_C, (px, py), 5)
            pygame.draw.circle(S, (120, 80, 14), (px, py), 5, 1)
        c.glint(x, y - 6, B.OURO_C, 5)
    # calice sobre mesa e agnus dei
    B.caixa(S, (150, 100, 40, 14), (140, 100, 70), (100, 70, 44), 8) if False else None
    pygame.draw.rect(S, (130, 24, 36), (240, 280, 480, 190), 0, 6)
    pygame.draw.rect(S, OURO, (240, 280, 480, 190), 3, 6)
    pygame.draw.rect(S, (30, 63, 140), (254, 294, 452, 162), 2, 4)
    for x in range(290, 700, 70):
        B.lis(S, x, 375, 40, OURO)
    for (x, y) in ((200, 130), (760, 130)):
        candelabro(c, x, y + 100, 80, 3)
    c.brilho(480, 250, 400, (150, 120, 40))


def t_enfermaria(c):
    S = c.S
    # crucifixo na parede e pelicano em relevo
    B.crucifixo(S, 360, 58, 76)
    pygame.draw.circle(S, (200, 190, 170), (610, 56), 26)
    pygame.draw.circle(S, (150, 140, 120), (610, 56), 26, 3)
    pygame.draw.ellipse(S, (250, 246, 236), (600, 52, 20, 14))
    pygame.draw.polygon(S, (250, 246, 236), [(603, 54), (592, 44), (606, 50)])
    pygame.draw.polygon(S, (230, 190, 70), [(594, 52), (586, 60), (598, 56)])
    for dx in (-8, 0, 8):
        pygame.draw.circle(S, (170, 30, 36), (610 + dx, 72), 2)
    janela_sala(c, 200, 106, 44, 86, "grisalha", 81)
    janela_sala(c, 760, 106, 44, 86, "grisalha", 82)
    cama(c, 76, 190, 140, 66)
    cama(c, 76, 380, 140, 66)
    cama(c, 744, 190, 140, 66)
    cama(c, 744, 380, 140, 66)
    # ervas penduradas e horto
    for x in range(270, 700, 56):
        if 430 < x < 530:
            continue
        pygame.draw.line(S, (110, 90, 60), (x, 18), (x, 30), 1)
        for k in range(5):
            pygame.draw.ellipse(S, c.rnd.choice(((70, 130, 70), (110, 150, 80), (150, 120, 60))), (x - 8 + k * 3, 30 + k * 4, 6, 14))
    # mesinha com pao bento e jarros
    B.caixa(S, (280, 160, 70, 32), (160, 120, 80), (120, 90, 56), 10) if False else None
    for (x, y) in ((300, 200), (660, 200)):
        lirio_vaso(c, x, y, 3)
    pygame.draw.circle(S, (200, 155, 90), (640, 440), 12)
    pygame.draw.line(S, (150, 110, 60), (634, 440), (646, 440), 2)
    pygame.draw.line(S, (150, 110, 60), (640, 434), (640, 446), 2)
    pia_agua_benta(c, 480, 470) if False else None
    # tapete verde com cruz
    pygame.draw.rect(S, (60, 130, 96), (330, 270, 300, 190), 0, 8)
    pygame.draw.rect(S, (230, 240, 225), (330, 270, 300, 190), 3, 8)
    B.cruz_latina(S, 480, 365, 96, (236, 244, 230), None, 14)
    c.brilho(480, 260, 400, (110, 120, 100))
    for x in (480,):
        pass


def t_enigma(c):
    S = c.S
    labirinto(c, 480, 330, 150)
    espelho(c, 330, 64)
    espelho(c, 630, 64)
    scutum(c, 240, 64, 26) if False else None
    scutum(c, 150, 66, 26)
    arvore_porfirio(c, 810, 64)
    r = B.rosacea(34, 9, 12, "violeta")
    pygame.draw.circle(S, esc(c.pedra, .3), (480, 36), 38)
    c.extra_post.append(lambda S2, r=r: S2.blit(r, (480 - r.get_width() // 2, 4)))
    # tres circulos entrelacados
    for (dx, dy, col) in ((-12, 0, (46, 120, 70)), (12, 0, (47, 91, 183)), (0, -18, (200, 40, 46))):
        pygame.draw.circle(S, col, (240 + dx * 1.4, 70 + dy * 1.4 + 18), 22, 3)
    for (x, y) in ((140, 170), (820, 170), (140, 460), (820, 460)):
        pygame.draw.polygon(S, (60, 50, 100), [(x, y - 60), (x + 12, y), (x - 12, y)])
        pygame.draw.circle(S, (160, 190, 255), (x, y - 62), 4)
        c.chama(x, y - 60, 90, (110, 150, 255), "chama", .9)
    c.brilho(480, 330, 280, (70, 60, 140))
    c.glint(330, 64, (255, 255, 255), 5), c.glint(630, 64, (255, 255, 255), 5)
    for i in range(10):
        a = i * 2 * PI / 10
        c.glint(int(480 + math.cos(a) * 130), int(330 + math.sin(a) * 130), (180, 170, 255), 3)


TIPOS = {"entrada": t_entrada, "combate_nave": t_nave, "capela": t_capela, "claustro": t_claustro,
         "scriptorium": t_scriptorium, "capitular": t_capitular, "sacristia": t_sacristia, "cripta": t_cripta,
         "campanario": t_campanario, "biblioteca": t_biblioteca, "coro": t_coro, "altar_mor": t_altar_mor,
         "loja": t_loja, "tesouro": t_tesouro, "enfermaria": t_enfermaria, "enigma": t_enigma}
