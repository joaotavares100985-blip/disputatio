# -*- coding: utf-8 -*-
"""Sprites dos 36 inimigos (arte_bestiario: personagens/objetos simbolicos) e 4 chefes (procedurais, pre-renderizados e cacheados).

sprite_inimigo(id_ou_inimigo, tempo, estado="idle", tamanho=200, fase=0) -> Surface
    estado: idle (tempo = relogio global) | ataque | dano | morte (tempo = segundos desde o inicio do estado; morte dura 0.72s)
escala_inimigo(inim) -> fator de tamanho (menores nos primeiros andares); miniatura_inimigo(id, px)
"""
import math
import random

import pygame

import arte_figuras as AF
from arte_kit import Tela, mix, lit, dk, catmull, olho, boca, INK, OURO, OURO_L, OURO_D, BRANCO
from arte_vista import Vista

CW, CH, GY = 240, 260, 240


def _dados(x):
    import conteudo as C
    if isinstance(x, dict):
        for k, v in list(C.INIMIGOS.items()) + list(C.CHEFES.items()):
            if v is x or v.get("nome") == x.get("nome"):
                return k, v
        return x.get("nome", "?"), x
    d = C.CHEFES.get(x) or C.INIMIGOS.get(x) or {}
    return x, d


def escala_inimigo(d):
    if d.get("titulo") is not None:
        return 1.0
    return max(.7, min(1.12, .62 + d.get("hp", 20) / 130.0))     # pequenos nos primeiros andares


# ------------------------------------------------------------------ inimigos comuns (caixa de pecas em arte_bestiario)
def _desenha_inimigo(T, iid, d, ph):
    import arte_bestiario as BE
    V = Vista(T, CW // 2, GY, 1.0)
    AF.sombra_chao(V, 150, 24, 2)
    BE.desenhar(V, iid, d, ph)


# ------------------------------------------------------------------ chefes
def _desenha_chefe(T, cid, d, ph, fase):
    cor = tuple(d.get("cor", (120, 40, 60)))
    V = Vista(T, CW // 2, GY, 1.0)
    rage = min(3, fase)
    AF.sombra_chao(V, 170, 26, 2)
    V.luz(0, -120, 120 + rage * 14, mix(cor, (255, 60, 30), .3 + rage * .2), 80 + rage * 30)
    if cid == "gaunilo":
        e = dict(tunica=(21, 19, 26), capa=(21, 19, 26), forro=(70, 64, 76), capuz="baixo", capuz_cor=(21, 19, 26), tonsura=True, cabelo=(90, 70, 50), pele=(224, 188, 156), mao_e="livro",
                 mao_d="dedo", cinto="corda", humor="bravo" if rage else "sereno", livro_cor=(90, 60, 40), largura=1.05)
        AF.figura_frontal(T, CW // 2, GY, e, ph, 1.12, None, sombra=False)
        V2 = Vista(T, CW // 2 + 78, GY - 190, 1.0)
        V2.circ(0, 0, 34, (140, 200, 240, 120), (220, 240, 255), 1.5)
        V2.ell(0, 14, 50, 14, (220, 200, 140), INK, 1.0)
        for x in (-8, 8):
            V2.pline([(x, 12), (x + 3, -8)], (110, 70, 36), 3)
            V2.ell(x + 3, -12, 18, 10, (60, 150, 70), INK, .8)
    elif cid == "siger":
        e = dict(tunica=(60, 30, 36), capa=(150, 28, 36), forro=(222, 208, 176), capuz="forrado", capuz_cor=(150, 28, 36), chapeu="pileus", chapeu_cor=(150, 24, 30), cabelo=(60, 40, 30),
                 pele=(232, 192, 156), mao_e="livro_a", mao_d="dedo", cinto="couro", humor="bravo" if rage else "sereno", jovem=True, medalha=OURO, largura=1.05)
        AF.figura_frontal(T, CW // 2, GY, e, ph, 1.12, None, sombra=False)
        for i, (x, y, c) in enumerate(((-84, -170, (60, 90, 150)), (92, -150, (130, 90, 40)), (-92, -110, (40, 110, 100)))):
            yy = y + math.sin(ph * 6.28 + i * 2) * 5
            AF.livro_obj(V, x, yy, .3 * (i - 1), 30, 38, c, aberto=i == 0)
            if rage:
                V.icone("chama", x, yy - 26, 26, None, ph * 3)
    elif cid == "saint_amour":
        e = dict(tunica=(40, 40, 64), capa=(58, 60, 92), forro=(206, 196, 170), capuz="forrado", capuz_cor=(58, 60, 92), chapeu="pileus", chapeu_cor=(30, 30, 44), barba="curta",
                 barba_cor=(210, 210, 214), cabelo=(210, 210, 214), pele=(226, 184, 148), mao_e="pergaminho", mao_d="dedo", cinto="couro", humor="bravo", medalha=(176, 30, 36), largura=1.05)
        AF.figura_frontal(T, CW // 2, GY, e, ph, 1.12, None, sombra=False)
        V.icone("selo", 84, -96, 44)
    else:
        e = dict(tunica=(236, 232, 220), capa=cor, forro=OURO, capuz=None, chapeu="mitra", barba="curta", barba_cor=(190, 190, 196), cabelo=(190, 190, 196), pele=(226, 184, 148),
                 mao_e="pergaminho", mao_d=None, cinto="couro", humor="bravo" if rage else "sereno", peitoral=True, largura=1.1, pos_e=(-40, -92))
        AF.figura_frontal(T, CW // 2, GY, e, ph, 1.0, None, sombra=False)
        # baculo
        V.line((78, -4), (78, -190), OURO_D, 5)
        V.line((77, -4), (77, -190), OURO_L, 2)
        V.pline([(78, -190)] + [(78 + 14 * math.sin(a), -208 + 14 * math.cos(a)) for a in [i * .4 for i in range(1, 12)]], OURO, 4)
        for i in range(rage + 1):
            V.icone("pergaminho", -90 - i * 8, -150 + i * 24, 26)
    if rage:
        V.luz(0, -110, 80, (255, 60, 40), 40 + rage * 20)


# ------------------------------------------------------------------ cache e estados
_base = {}
_frames = {}
_hole = {}


def _base_img(iid, d, f4, fase):
    k = (iid, f4, fase)
    s = _base.get(k)
    if s is None:
        T = Tela(CW, CH, 2)
        ph = f4 / 4.0
        if d.get("titulo") is not None:
            _desenha_chefe(T, iid, d, ph, fase)
        else:
            _desenha_inimigo(T, iid, d, ph)
        s = _base[k] = T.final()
    return s


def _holes(k):
    m = _hole.get(k)
    if m is None:
        rnd = random.Random(k)
        m = pygame.Surface((CW, CH), pygame.SRCALPHA)
        m.fill((255, 255, 255, 255))
        n = int(k * 70) + 4
        for _ in range(n * 6):
            x, y = rnd.randrange(0, CW, 8), rnd.randrange(0, CH, 8)
            if rnd.random() < k:
                pygame.draw.rect(m, (0, 0, 0, 0), (x, y, 8 + rnd.randrange(0, 8), 8 + rnd.randrange(0, 8)))
        _hole[k] = m
    return _hole[k]


def sprite_inimigo(inim, tempo=0.0, estado="idle", tamanho=200, fase=0):
    iid, d = _dados(inim)
    boss = d.get("titulo") is not None
    fase = min(3, fase) if boss else 0
    f4 = int(tempo * 4) % 4 if estado == "idle" else 0
    b = int(math.sin(tempo * 2.2) * 3) if estado == "idle" else 0
    st = estado
    if st == "idle":
        key = (iid, fase, "i", f4, b, tamanho)
    elif st == "ataque":
        q = min(5, int(tempo / .6 * 6))
        key = (iid, fase, "a", q, tamanho)
    elif st == "dano":
        q = int(tempo * 28) % 2
        key = (iid, fase, "d", q, tamanho)
    else:
        q = min(5, int(tempo / .72 * 6))
        key = (iid, fase, "m", q, tamanho)
    s = _frames.get(key)
    if s is not None:
        return s
    if len(_frames) > 700:
        _frames.clear()
    base = _base_img(iid, d, f4, fase)
    w = int(CW * tamanho / CH)
    if st == "idle":
        sc = 1 + b * .008
        s = pygame.transform.smoothscale(base, (int(w * (1 - b * .004)), int(tamanho * sc)))
        out = pygame.Surface((w, tamanho), pygame.SRCALPHA)
        out.blit(s, s.get_rect(midbottom=(w // 2, tamanho - int(tamanho * .075) + int(tamanho * .075))))
        s = out
    elif st == "ataque":
        k = math.sin(min(1, tempo / .6) * math.pi)
        s0 = pygame.transform.smoothscale(base, (int(w * (1 + .12 * k)), int(tamanho * (1 - .06 * k))))
        out = pygame.Surface((w, tamanho), pygame.SRCALPHA)
        out.blit(s0, s0.get_rect(midbottom=(w // 2, tamanho)))
        s = out
    elif st == "dano":
        s0 = pygame.transform.smoothscale(base, (w, tamanho))
        s = s0.copy()
        s.fill((170, 170, 170, 0) if q else (150, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
    else:
        kk = q / 5.0
        s0 = pygame.transform.smoothscale(base, (w, tamanho)).copy()
        m = pygame.transform.smoothscale(_holes(round(kk, 2)), (w, tamanho))
        s0.blit(m, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        s0.fill((int(255 * kk * .4), int(200 * kk * .3), 0, 0), special_flags=pygame.BLEND_RGB_ADD)
        out = pygame.Surface((w, tamanho), pygame.SRCALPHA)
        out.blit(s0, (0, -int(kk * tamanho * .08)))
        out.set_alpha(int(255 * (1 - kk * .6)))
        s = out
    _frames[key] = s
    return s


def miniatura_inimigo(inim, px=40):
    iid, d = _dados(inim)
    k = ("mini", iid, px)
    s = _frames.get(k)
    if s is None:
        b = _base_img(iid, d, 0, 0)
        r = b.get_bounding_rect()
        side = int(max(r.w, r.h) * (.62 if d.get("titulo") is None else .5))
        cx, top = r.centerx, r.y
        rect = pygame.Rect(cx - side // 2, top - 2, side, side).clip(b.get_rect())
        s = _frames[k] = pygame.transform.smoothscale(b.subsurface(rect).copy(), (px, px))
    return s


TODOS = None
