# -*- coding: utf-8 -*-
"""
Icones desenhados por codigo (apenas pygame + stdlib).

API estavel:
    desenhar_icone(superficie, id, centro, tamanho, cor_principal=None, tempo=0.0)
    desenhar_item_icone(superficie, id_item, centro, tamanho, tempo=0.0)   # arte propria por item (61)
    existe(id) -> bool       ICONES: id -> funcao       NOMES_PADRAO: id -> (nome, curto)
    ids_usados_sem_desenho() -> lista de simbolos de conteudo sem desenho proprio (o teste exige lista vazia)

Os desenhos vivem em icones_sacros.py (liturgia/fe), icones_saber.py (saber/arquitetura/categorias) e aqui (UI).
Cada icone e renderizado em alta resolucao (supersampling), recebe contorno escuro + sombra e e CACHEADO.
Id desconhecido cai no icone generico (gema).
"""
import math

import pygame

from icones_base import *  # noqa: F401,F403
from icones_base import Pen, flame, star_pts  # noqa: F401
import icones_sacros
import icones_saber

_star_pts = star_pts
_flame = flame


# ================================================================== UI e utilidades
def i_florim(p, c, t):
    p.circ(0, 0, .92, G(lt(c, .55), c, dkc(c, .45)), INK)
    p.circ(0, 0, .72, G(dkc(c, .1), lt(c, .35)), dkc(c, .6))
    p.ring(0, 0, .8, lt(c, .6), .025)
    p.poly([(0, -.5), (.16, -.2), (.12, .1), (0, .18), (-.12, .1), (-.16, -.2)], G(lt(c, .7), c), dkc(c, .5))
    p.poly([(-.1, .0), (-.48, -.2), (-.4, .12), (-.12, .16)], G(lt(c, .7), c), dkc(c, .5))
    p.poly([(.1, .0), (.48, -.2), (.4, .12), (.12, .16)], G(lt(c, .7), c), dkc(c, .5))
    p.rect(-.34, .2, .68, .1, G(lt(c, .7), c), dkc(c, .5), .02)
    p.arc(0, 0, 1.5, 1.5, 2.3, 3.5, (255, 255, 255), .07)


def i_animo(p, c, t):
    pts = []
    for k in range(40):
        a = math.tau * k / 40
        pts.append((.058 * 16 * math.sin(a) ** 3, -.058 * (13 * math.cos(a) - 5 * math.cos(2 * a) - 2 * math.cos(3 * a) - math.cos(4 * a)) + .08))
    p.poly(pts, G(lt(c, .5), c, dkc(c, .5)), dkc(c, .65))
    p.hl([(-.5, -.1), (-.4, -.34), (-.2, -.36), (-.34, -.1)], 130)


def i_tinta(p, c, t):
    pts = [(0, -.98), (.3, -.5), (.58, -.05), (.66, .3), (.5, .7), (0, .94), (-.5, .7), (-.66, .3), (-.58, -.05), (-.3, -.5)]
    from arte_kit import catmull
    p.poly(catmull(pts, 5, True), G(lt(c, .45), c, dkc(c, .5)), dkc(c, .7))
    p.hl([(-.38, .05), (-.3, -.1), (-.22, .1), (-.3, .5), (-.4, .4)], 130)


def i_balao(p, c, t):
    p.poly([(-.9, -.6), (.9, -.6), (.9, .35), (.1, .35), (-.4, .85), (-.35, .35), (-.9, .35)], G(WHITE, c, dkc(c, .2)), INK)
    for k in range(3):
        p.circ(-.4 + k * .4, -.12, .09, INK, None)


def i_mochila(p, c, t):
    p.ln(-.5, -.45, -.3, -.8, dkc(c, .5), .09)
    p.ln(.5, -.45, .3, -.8, dkc(c, .5), .09)
    p.curva([(-.74, -.3), (-.6, -.5), (.6, -.5), (.74, -.3), (.8, .55), (.5, .9), (-.5, .9), (-.8, .55)], G(lt(c, .4), c, dkc(c, .5)), INK)
    p.poly([(-.76, -.3), (.76, -.3), (.62, .15), (0, .3), (-.62, .15)], G(lt(c, .3), dkc(c, .3)), INK)
    p.rect(-.1, .08, .2, .26, G(lt(GOLD, .5), GOLD), INK, .03)
    p.ln(-.6, .5, .6, .5, dkc(c, .4), .035)


def i_pessoa(p, c, t):
    """Retrato do Bacharel (rosto 3/4 com capuz azul e debrum dourado), em vez de um boneco generico."""
    from arte_heroi import hero_retrato
    d = max(8, int(p.u * 2.04))
    im = hero_retrato(d, 2)
    p.S.blit(im, (p.cx - im.get_width() / 2.0, p.cy - im.get_height() / 2.0))

def i_interrogacao(p, c, t):
    p.circ(0, 0, .92, G(lt(c, .5), c, dkc(c, .45)), INK)
    p.ring(0, 0, .78, lt(c, .6), .03)
    p.text("?", 0, .04, 1.5, INK)


def i_mao(p, c, t):
    cor = G(lt(c, .3), c, dkc(c, .3))
    for k in range(4):
        p.rect(-.55 + k * .28, -.75 + (k % 3 == 1) * -.12 + (k == 3) * .1, .22, .75, cor, INK, .1)
    p.rect(-.55, -.05, 1.1, .85, cor, INK, .2)
    p.poly([(-.55, .1), (-.9, -.05), (-.78, -.25), (-.5, -.05)], cor, INK)
    p.ln(-.4, .5, .4, .5, dkc(c, .35), .05)


def i_duelo(p, c, t):
    for sx in (1, -1):
        p.poly([(.85 * sx, -.92), (.7 * sx, -.92), (-.55 * sx, .55), (-.4 * sx, .7)], G((250, 252, 255), (170, 180, 205)), INK)
        p.ln(-.7 * sx, .45, -.3 * sx, .85, G(lt(GOLD, .4), GOLD)[1], .14)
        p.ln(-.5 * sx, .65, -.85 * sx, .95, BROWN, .14)
        p.hln(.78 * sx, -.86, -.4 * sx, .5, .03, 160)


def i_joystick(p, c, t):
    p.ring(0, 0, .9, dkc(c, .3), .12)
    p.circ(0, 0, .45, G(lt(c, .5), c, dkc(c, .3)), INK)
    p.circ(-.12, -.14, .14, lt(c, .6), None)
    for d, (dx, dy) in {"u": (0, -1), "d": (0, 1), "l": (-1, 0), "r": (1, 0)}.items():
        p.poly([(dx * .72 - dy * .12, dy * .72 + dx * .12), (dx * .98, dy * .98), (dx * .72 + dy * .12, dy * .72 - dx * .12)], WHITE, None)


def i_play(p, c, t):
    p.poly([(-.5, -.8), (.8, 0), (-.5, .8)], G(lt(c, .4), c, dkc(c, .3)))


def i_seta_esq(p, c, t):
    p.poly([(.5, -.8), (-.5, 0), (.5, .8), (.5, .45), (-.0, 0), (.5, -.45)], c, None)


def i_seta_dir(p, c, t):
    p.poly([(-.5, -.8), (.5, 0), (-.5, .8), (-.5, .45), (.0, 0), (-.5, -.45)], c, None)


def i_olho(p, c, t):
    p.poly([(-.95, 0), (-.4, -.5), (.4, -.5), (.95, 0), (.4, .5), (-.4, .5)], WHITE)
    p.circ(0, 0, .34, G(lt(c, .4), c, dkc(c, .4)))
    p.circ(0, 0, .15, INK, None)
    p.circ(-.1, -.1, .06, WHITE, None)


def i_pausa(p, c, t):
    p.rect(-.55, -.7, .4, 1.4, G(lt(c, .3), c), INK, .06)
    p.rect(.15, -.7, .4, 1.4, G(lt(c, .3), c), INK, .06)


def i_menu(p, c, t):
    for k in range(3):
        p.rect(-.7, -.6 + k * .5, 1.4, .26, G(lt(c, .3), c), INK, .06)


def i_gema(p, c, t):
    p.poly([(0, -.9), (.7, -.3), (.45, .75), (-.45, .75), (-.7, -.3)], G(lt(c, .5), c, dkc(c, .45)))
    p.ln(-.7, -.3, .7, -.3, lt(c, .6), .05)
    p.ln(0, -.9, -.2, -.3, lt(c, .6), .05)
    p.ln(0, -.9, .2, -.3, lt(c, .6), .05)
    p.circ(0, .1, .1, WHITE, None)


def i_porta(p, c, t):
    pts = [(-.62, .95), (-.62, -.25)]
    for k in range(1, 12):
        a = math.pi - math.pi * k / 12
        pts.append((.62 * math.cos(a), -.25 - .62 * math.sin(a)))
    pts += [(.62, -.25), (.62, .95)]
    p.poly(pts, PEDRA)
    pts2 = [(-.46, .95), (-.46, -.2)]
    for k in range(1, 12):
        a = math.pi - math.pi * k / 12
        pts2.append((.46 * math.cos(a), -.2 - .46 * math.sin(a)))
    pts2 += [(.46, -.2), (.46, .95)]
    p.poly(pts2, GH(dkc(c, .3), lt(c, .3), dkc(c, .2)))
    p.ln(0, -.66, 0, .95, dkc(c, .6), .04)
    p.ln(-.46, .2, .46, .2, dkc(c, .6), .04)
    p.circ(.28, .4, .07, OURO, INK)


def i_porta_aberta(p, c, t):
    i_porta(p, c, t)


def i_bau(p, c, t):
    p.rect(-.84, -.05, 1.68, .92, MADEIRA, INK, .06)
    pts = [(-.84, -.05)]
    for k in range(1, 12):
        a = math.pi - math.pi * k / 12
        pts.append((.84 * math.cos(a), -.05 - .58 * math.sin(a)))
    pts.append((.84, -.05))
    p.poly(pts, G((196, 140, 84), (130, 84, 44), (84, 52, 26)), INK)
    for x in (-.55, .43):
        p.rect(x, -.62, .12, 1.48, OURO, GOLD_D, .02)
    p.rect(-.16, -.14, .32, .38, G(lt(GOLD, .5), GOLD, GOLD_D), INK, .04)
    p.circ(0, .06, .05, INK, None)
    p.hl([(-.7, -.4), (-.2, -.56), (.0, -.54), (-.5, -.3)], 80)


def i_escada(p, c, t):
    for k in range(4):
        x = -.85 + k * .42
        y = .95 - (k + 1) * .42
        p.rect(x, y, 1.7 - k * .42, .42, G(lt(c, .2 + k * .08), dkc(c, .1)), INK, .02)
    p.poly([(.55, -.85), (.85, -.45), (.35, -.45)], G(GOLD_L, GOLD), INK)


def i_check(p, c, t):
    p.poly([(-.8, .05), (-.5, -.25), (-.2, .15), (.55, -.7), (.85, -.4), (-.2, .78)], c, None)


def i_x(p, c, t):
    p.poly([(-.7, -.4), (-.4, -.7), (0, -.3), (.4, -.7), (.7, -.4), (.3, 0), (.7, .4), (.4, .7), (0, .3), (-.4, .7), (-.7, .4), (-.3, 0)], c, None)


def i_ponto_de_exclamacao(p, c, t):
    p.circ(0, 0, .92, G(lt(c, .4), c, dkc(c, .4)), INK)
    p.poly([(-.14, -.62), (.14, -.62), (.09, .15), (-.09, .15)], INK, None)
    p.circ(0, .42, .12, INK, None)


def i_frasco(p, c, t):
    p.rect(-.14, -.92, .28, .24, G((190, 140, 90), BROWN, (90, 56, 28)), INK, .03)
    p.rect(-.17, -.7, .34, .45, G((250, 252, 255), (206, 220, 236)), INK, .03)
    p.circ(0, .34, .62, G((250, 252, 255), (206, 220, 236)), INK)
    p.circ(0, .42, .5, G(lt(c, .4), c, dkc(c, .4)), None)
    p.ln(-.4, .0, .4, .0, lt(c, .5), .04)
    p.hl([(-.44, .16), (-.34, -.04), (-.22, -.02), (-.3, .3)], 160)
    p.circ(-.2, .22, .06, WHITE, None)


def i_escudo(p, c, t):
    p.poly([(-.8, -.82), (.8, -.82), (.82, .05), (0, .98), (-.82, .05)], G(lt(c, .45), c, dkc(c, .5)), INK)
    p.poly([(-.66, -.7), (.66, -.7), (.68, .0), (0, .84), (-.68, .0)], None, GOLD_L)
    p.poly([(-.1, -.6), (.1, -.6), (.1, -.2), (.4, -.2), (.4, .0), (.1, .0), (.1, .5), (-.1, .5), (-.1, .0), (-.4, .0), (-.4, -.2), (-.1, -.2)], G(lt(GOLD, .5), GOLD), GOLD_D)
    p.hl([(-.7, -.76), (-.1, -.76), (-.7, -.2)], 60)


def i_seta_fuga(p, c, t):
    p.poly([(-.25, -.34), (.3, -.34), (.3, -.7), (.95, 0), (.3, .7), (.3, .34), (-.25, .34)], G(lt(c, .4), c, dkc(c, .3)), INK)
    for k, yy in enumerate((-.3, 0, .3)):
        p.ln(-.95 + k * .1, yy, -.45, yy, lt(c, .5), .08)


def i_cadeado(p, c, t):
    p.arc(0, -.2, .8, .95, 0, math.pi, (150, 154, 170), .16)
    p.ln(-.4, -.18, -.4, .05, (150, 154, 170), .16)
    p.ln(.4, -.18, .4, .05, (150, 154, 170), .16)
    p.rect(-.6, -.05, 1.2, .95, G(lt(c, .5), c, dkc(c, .45)), INK, .1)
    p.circ(0, .36, .12, INK, None)
    p.rect(-.04, .38, .08, .26, INK, None, 0)
    p.hl([(-.5, .02), (.5, .02), (.5, .14), (-.5, .14)], 90)


def i_coroa_ui(p, c, t):
    icones_sacros.i_coroa(p, c, t)


# ----------------------------------------------------------- novos para itens
def i_pao(p, c, t):
    p.ell(0, .62, 1.7, .3, (0, 0, 0), None)
    p.curva([(-.9, .4), (-.85, -.1), (-.5, -.5), (0, -.6), (.5, -.5), (.85, -.1), (.9, .4), (.5, .6), (-.5, .6)], G((200, 150, 90), (150, 96, 50), (96, 56, 26)), (70, 40, 18))
    for x in (-.4, 0, .4):
        p.pl([(x - .16, -.28), (x + .1, -.1)], (230, 190, 130), .07)
    p.hl([(-.7, -.1), (-.3, -.4), (.1, -.5), (-.3, -.2)], 80, (255, 230, 180))


def i_queijo(p, c, t):
    p.poly([(-.95, .3), (.95, .0), (.95, .6), (-.95, .6)], G((246, 214, 100), (214, 170, 50)), (130, 96, 20))
    p.poly([(-.95, .3), (.0, -.7), (.95, .0)], G((255, 238, 150), (240, 200, 80)), (130, 96, 20))
    for x, y, r in ((-.2, -.05, .1), (.4, .08, .07), (-.55, .36, .07), (.15, .38, .09), (.7, .38, .06)):
        p.circ(x, y, r, (214, 170, 50), (150, 110, 20))


def i_tigela(p, c, t):
    for i in range(3):
        ph = (t * .7 + i * .33) % 1
        p.circ(-.2 + i * .25 + math.sin((t + i) * 2) * .05, -.35 - ph * .5, .08 + ph * .06, (240, 240, 246), None)
    p.ell(0, -.05, 1.6, .44, (176, 110, 50), INK)
    p.ell(0, -.05, 1.4, .34, G((240, 180, 90), (200, 130, 50)), None)
    p.poly([(-.8, -.02), (.8, -.02), (.62, .72), (-.62, .72)], G((200, 130, 80), (140, 84, 44), (96, 56, 28)), INK)
    p.ell(0, .76, 1.0, .2, (96, 56, 28), INK)
    p.ln(.2, -.2, .86, -.78, (150, 110, 70), .07)
    p.ell(.9, -.84, .2, .26, (150, 110, 70), INK)


def i_tisana(p, c, t):
    for i in range(3):
        ph = (t * .6 + i * .33) % 1
        p.circ(-.1 + i * .2 + math.sin((t + i) * 2) * .05, -.4 - ph * .5, .07 + ph * .05, (240, 240, 246), None)
    p.poly([(-.62, -.2), (.62, -.2), (.5, .6), (-.5, .6)], G((250, 252, 250), (206, 220, 214), (150, 170, 164)), INK)
    p.ell(0, -.2, 1.24, .26, (120, 150, 70), INK)
    p.arc(.66, .12, .5, .5, -1.5, 1.5, (200, 214, 208), .1)
    p.ell(0, .66, .9, .16, (200, 214, 208), INK)
    for x, y, a in ((-.2, -.22, -.4), (.15, -.2, .5)):
        p.poly([(x, y - .1), (x + .12, y), (x, y + .1), (x - .12, y)], (90, 150, 70), None)


def i_ervas(p, c, t):
    for k, (ax, col) in enumerate(((-.5, (90, 160, 80)), (-.2, (120, 180, 90)), (.1, (80, 140, 90)), (.4, (110, 170, 70)), (.65, (96, 150, 80)))):
        p.pl([(0, .6), (ax * .5, .0), (ax, -.7)], col, .08)
        for j in range(3):
            yy = -.5 + j * .3
            p.poly([(ax * (1 - (yy + .7) / 1.3 * .3), yy), (ax - .18 + j * .02, yy - .1), (ax - .1, yy + .1)], col, None)
    p.rect(-.34, .4, .68, .16, (200, 170, 110), INK, .03)
    p.ln(-.3, .46, .3, .5, (140, 100, 50), .03)
    p.circ(0, .48, .05, (190, 40, 50), None)


def i_pena(p, c, t):
    p.poly([(.88, -.92), (.5, -.86), (.1, -.62), (-.3, -.2), (-.5, .3), (-.46, .55), (-.2, .4), (.2, .1), (.6, -.3), (.8, -.6)], G((255, 255, 255), (226, 232, 244), (186, 196, 220)), (120, 130, 160))
    p.ln(.9, -.95, -.7, .9, (200, 196, 180), .05)
    p.ln(-.46, .5, -.78, .92, (240, 236, 220), .06)
    p.poly([(-.78, .92), (-.66, .8), (-.7, .96)], INKD, None)
    for k in range(5):
        p.ln(.6 - k * .22, -.7 + k * .26, .34 - k * .22, -.55 + k * .26, (210, 218, 236), .02)


def i_tinteiro(p, c, t):
    p.poly([(-.7, .95), (.7, .95), (.8, .3), (.4, .05), (-.4, .05), (-.8, .3)], G((70, 70, 88), (30, 30, 42), (12, 12, 18)), INK)
    p.rect(-.34, -.1, .68, .24, G((190, 150, 90), (120, 84, 44)), INK, .04)
    p.ell(0, -.1, .68, .16, (30, 24, 20), INK)
    p.hl([(-.6, .3), (-.5, .8), (-.64, .4)], 80)
    p.circ(.6, -.5, .22, G((150, 100, 60), (90, 56, 28)), INK)
    p.circ(.55, -.55, .05, (190, 150, 100), None)


def i_mel(p, c, t):
    p.poly([(-.6, -.35), (.6, -.35), (.7, .2), (.5, .8), (-.5, .8), (-.7, .2)], G((255, 220, 90), (226, 160, 30), (170, 100, 10)), INK)
    p.rect(-.66, -.5, 1.32, .22, G((200, 150, 100), (140, 96, 56)), INK, .04)
    p.poly([(-.5, -.5), (-.5, -.2), (.5, -.2), (.5, -.5)], None, None)
    p.pl([(-.2, -.2), (-.18, .05), (-.1, .2)], (255, 240, 170), .05) if False else None
    p.hl([(-.5, -.1), (-.4, .5), (-.55, .2)], 120)
    p.ln(.2, -.5, .8, -.95, (170, 120, 70), .07)
    p.ell(.86, -.98, .24, .2, (230, 170, 40), INK)
    p.text("mel", 0, .26, .5, (140, 80, 10))


def i_cappa(p, c, t):
    p.curva([(-.9, .98), (-.7, .1), (-.4, -.5), (0, -.7), (.4, -.5), (.7, .1), (.9, .98)], G((70, 70, 78), (28, 26, 30), (10, 10, 12)), INK)
    p.poly([(-.3, -.6), (0, .98), (.3, -.6), (.0, -.4)], G((255, 252, 244), (226, 220, 204)), INK)
    p.curva([(-.5, -.6), (-.3, -.92), (.3, -.92), (.5, -.6), (.0, -.35)], G((70, 70, 78), (24, 22, 26)), INK)
    p.hl([(-.7, .2), (-.5, -.3), (-.4, .6)], 40)


def i_ars_magna(p, c, t):
    cor = (176, 60, 60)
    for r, col in ((.95, (70, 100, 190)), (.66, (200, 160, 60)), (.38, (180, 70, 70))):
        p.circ(0, 0, r, G(lt(col, .4), col, dkc(col, .4)), INK)
        for k in range(8):
            a = math.tau * k / 8 + r * 2 + t * .4
            p.circ(math.cos(a) * (r - .13), math.sin(a) * (r - .13), .04, (255, 250, 220), None)
    p.circ(0, 0, .12, OURO, INK)
    p.ln(-.95, -.2, .95, .2, (30, 24, 20), .02)


def i_cruz_inscrita(p, c, t):
    icones_sacros.i_cruz_latina(p, c, t)


# ================================================================== catalogo
ICONES = {}
for _mod in (icones_sacros, icones_saber):
    for _n, _v in list(vars(_mod).items()):
        if _n.startswith("i_") and callable(_v):
            ICONES[_n[2:]] = _v
for _n, _v in list(globals().items()):
    if _n.startswith("i_") and callable(_v):
        ICONES[_n[2:]] = _v

# nomes antigos -> desenho novo
ALIAS = dict(cordeiro="agnus_dei", calice="calice_hostia", vela="vela_cera", escudo_trindade="scutum_fidei", aureola="nimbo",
             corda_tres_nos="cordao_tres_nos", boi_sol="sol_tomas", arco_ogival="ogiva", pena="pena", tinteiro="tinteiro")
for _a, _b in ALIAS.items():
    if _a not in ICONES:
        ICONES[_a] = ICONES[_b]

COR = dict(
    cruz_latina=GOLD, crucifixo=BROWN, cruz_tau=GOLD, cruz_patriarcal=GOLD, crismon=GOLD, ihs=GOLD, alfa_omega=GOLD, agnus_dei=WHITE, ichthys=(120, 160, 190),
    pelicano=WHITE, calice_hostia=GOLD, pixide=GOLD, custodia=GOLD, vela_cera=PARCH, turibulo=GOLD, livro=(158, 40, 46), rolo=GOLD,
    pergaminho=(240, 224, 180), pena_tinteiro=WHITE, tabua_cera=BROWN, chaves=GOLD, mitra=WHITE, baculo=GOLD, galero=(176, 20, 28), pileus=(30, 28, 34),
    sino=(190, 144, 84), estrela=GOLD_L, coroa=GOLD, nimbo=GOLD, nimbo_crucifero=GOLD, balanca=GOLD, sol_tomas=GOLD, coracao_flamejante=(220, 60, 70),
    astrolabio=(201, 162, 74), serpente=(62, 107, 46), ratio=(90, 150, 235), auctoritas=(232, 184, 70), distinguo=(176, 118, 226), apoio=(96, 206, 126),
    florim=GOLD, animo=(226, 70, 80), tinta=(70, 110, 230), balao=(250, 240, 215), mochila=(150, 100, 56), pessoa=(80, 110, 190), interrogacao=(190, 150, 230),
    mao=(240, 205, 170), duelo=GOLD, joystick=(200, 160, 70), play=(255, 228, 140), seta_esq=GOLD_L, seta_dir=GOLD_L, olho=(110, 170, 230), pausa=PARCH,
    menu=PARCH, gema=(150, 120, 220), porta_aberta=BROWN, porta=BROWN, bau=BROWN, escada=(150, 140, 160), check=(70, 200, 100), x=(220, 70, 60),
    ponto_de_exclamacao=(250, 210, 60), frasco=(210, 70, 90), escudo=(60, 100, 190), seta_fuga=(150, 210, 250), cadeado=GOLD, tinteiro=(40, 50, 100),
    pena=WHITE, caveira_adao=WHITE, ancora=GOLD, espada=WHITE, fenix=GOLD, compasso=GOLD, ferula=BROWN, monocordio=BROWN,
)

# animados: redesenhados em ate 12 quadros/s (cacheados)
ANIM = {"vela_cera", "cirio_pascal", "turibulo", "coracao_flamejante", "cao_tocha", "sino", "chama", "colmeia", "astrolabio", "tigela", "tisana", "ars_magna",
        "vela", "calice", "boi_sol"}
_cache = {}


def existe(iid):
    return iid in ICONES


def _render(iid, tam, col, tq):
    ss = 4 if tam <= 40 else (3 if tam <= 110 else 2)
    pad = max(2, int(tam * 0.07) + 2)
    W = tam + 2 * pad
    hi = pygame.Surface((W * ss, W * ss), pygame.SRCALPHA)
    pen = Pen(hi, W * ss / 2.0, W * ss / 2.0, tam / 2.0 * 0.94 * ss, tq)
    ICONES[iid](pen, col, tq)
    m = pygame.mask.from_surface(hi, 24)
    out = pygame.Surface(hi.get_size(), pygame.SRCALPHA)
    ow = max(1, int(round(tam / 34.0 * ss)))
    if tam >= 20:
        sh = m.to_surface(setcolor=(0, 0, 0, 80), unsetcolor=(0, 0, 0, 0))
        out.blit(sh, (ow * 0.9, ow * 1.7))
    sil = m.to_surface(setcolor=(24, 15, 9, 255), unsetcolor=(0, 0, 0, 0))
    for dx, dy in ((ow, 0), (-ow, 0), (0, ow), (0, -ow), (ow * .7, ow * .7), (-ow * .7, ow * .7), (ow * .7, -ow * .7), (-ow * .7, -ow * .7)):
        out.blit(sil, (dx, dy))
    out.blit(hi, (0, 0))
    return pygame.transform.smoothscale(out, (W, W))


def desenhar_icone(superficie, id, centro, tamanho, cor_principal=None, tempo=0.0):
    """Desenha o icone `id` centrado em `centro` com `tamanho` px (lado). Id desconhecido -> gema generica."""
    iid = id if id in ICONES else "gema"
    tam = max(6, int(tamanho))
    col = tuple(cor_principal) if cor_principal is not None else COR.get(iid, GOLD)
    tq = 0
    if iid in ANIM:
        tq = int(tempo * 10) % 40 / 10.0
    k = (iid, tam, col, tq)
    s = _cache.get(k)
    if s is None:
        if len(_cache) > 900:
            _cache.clear()
        s = _cache[k] = _render(iid, tam, col, tq)
    superficie.blit(s, (int(centro[0] - s.get_width() / 2), int(centro[1] - s.get_height() / 2)))


# ================================================================== itens (61)
# receita: (base, cor, selo) ; base/selo sao ids de icone
RECEITA = dict(
    pao_centeio=("pao", None, None), queijo_brie=("queijo", None, None), sopa_sao_vitor=("tigela", None, "pao_bento"),
    tisana_salvia=("tisana", None, None), ervas_enfermeiro=("ervas", None, "horto"), pena_ganso=("pena", None, None),
    tinteiro_galha=("tinteiro", None, None), vela_sebo=("vela_cera", (214, 180, 120), None), tabua_cera=("tabua_cera", None, None),
    pecia_alugada=("pergaminho", (214, 200, 168), "pena"), florilegio=("rosa", None, "livro"), reportatio=("tabua_cera", (150, 150, 160), "pena"),
    agua_fonte=("poco", None, None), mel_abelhas=("mel", None, "colmeia"), sino_vesperas=("sino", None, None), agua_benta=("agua_benta", None, None),
    pao_bento=("pao_bento", None, None), vela_cera_abelha=("vela_cera", (250, 240, 200), "lirio"), incenso_turibulo=("turibulo", None, None),
    organon=("livro", (60, 92, 150), "compasso"), isagoge=("livro", (46, 110, 70), "arvore_porfirio"), sic_et_non_livro=("livro", (130, 34, 50), "balanca"),
    sentencas=("livro", (112, 44, 36), "cruz_latina"), suma_teologica=("livro", (226, 212, 170), "sol_tomas"), suma_gentios=("livro", (44, 70, 140), "sol_tomas"),
    consolacao=("livro", (100, 60, 140), "escada_filosofia"), confissoes=("livro", (150, 30, 40), "coracao_flamejante"), proslogion=("livro", (40, 40, 52), "palio"),
    etimologias=("livro", (110, 120, 50), "colmeia"), didascalicon=("livro", (140, 96, 56), "estrela"), metalogicon=("livro", (96, 70, 130), "ferula"),
    summulae=("livro", (56, 104, 104), "arvore_porfirio"), euclides=("livro", (54, 60, 136), "compasso"), canon_avicena=("livro", (30, 120, 110), "horto"),
    guia_perplexos=("rolo", (214, 170, 60), None), comentario_averrois=("livro", (170, 110, 40), "pena_tinteiro"), opus_maius=("livro", (110, 84, 44), "oculos"),
    ars_magna=("ars_magna", None, None), itinerarium=("serafim", None, None), decreto_graciano=("livro", (120, 30, 30), "selo"),
    glosa_ordinaria=("livro", (196, 170, 120), "pena"), evangeliario=("evangeliario", None, None), salterio=("salterio", None, None), breviario=("breviario", None, None),
    contas_paternoster=("contas_paternoster", None, None), concha_peregrino=("concha", None, None), agnus_dei_cera=("agnus_dei", None, None),
    relicario_limoges=("relicario", None, None), cirio_pascal=("cirio_pascal", None, None), barrete_mestre=("pileus", (30, 28, 34), "selo"),
    capa_dominicana=("cappa", None, "cao_tocha"), cordao_franciscano=("cordao_tres_nos", None, "cruz_tau"), selo_universidade=("selo", None, None),
    bolsa_nacao=("mochila", (60, 90, 170), "flor_de_lis"), oculos=("oculos", None, None), astrolabio=("astrolabio", None, None), monocordio=("monocordio", None, None),
    resposta_anselmo=("pergaminho", (232, 214, 170), "palio"), unitate_intellectus=("livro", (84, 56, 120), "sol_tomas"), contra_impugnantes=("livro", (44, 44, 50), "cao_tocha"),
    barrete_doutor=("pileus", (150, 24, 30), "estrela"),
)
_item_por_nome = {}
_placas = {}


def _id_item(it):
    if not _item_por_nome:
        try:
            import conteudo as C
            for k, v in C.ITENS.items():
                _item_por_nome[v.get("nome")] = k
        except Exception:
            pass
    return _item_por_nome.get((it or {}).get("nome"))


def _placa(tam, cor, passivo):
    k = (tam, cor, passivo)
    s = _placas.get(k)
    if s is None:
        ss = 2
        W = tam + 8
        hi = pygame.Surface((W * ss, W * ss), pygame.SRCALPHA)
        c = (W * ss // 2, W * ss // 2)
        r = tam // 2 * ss
        for i in range(r, 0, -2):
            f = i / r
            col = mixc((70, 52, 36), (24, 16, 10), 1 - f) if passivo else mixc((40, 70, 76), (14, 26, 34), 1 - f)
            pygame.draw.circle(hi, col + (235,), c, i)
        pygame.draw.circle(hi, GOLD if passivo else (150, 214, 220), c, r, max(2, tam // 14 * ss))
        pygame.draw.circle(hi, (24, 15, 9), c, r, max(1, ss))
        pygame.draw.circle(hi, lt(cor, .3) + (160,), c, r - max(2, tam // 14 * ss), max(1, ss))
        s = pygame.transform.smoothscale(hi, (W, W))
        _placas[k] = s
    return s


def desenhar_item_icone(superficie, id_item, centro, tamanho, tempo=0.0, it=None, placa=True):
    """Arte propria de cada item: base + selo (pequeno emblema) sobre uma placa circular."""
    rec = RECEITA.get(id_item) or RECEITA.get(_id_item(it))
    cx, cy = centro
    tam = int(tamanho)
    if rec is None:
        sim = (it or {}).get("simbolo")
        rec = (sim if sim in ICONES else "gema", None, None)
    base, cor, selo = rec
    passivo = (it or {}).get("tipo", "passivo") != "consumivel"
    if placa:
        pl = _placa(int(tam * 1.18), cor or COR.get(base, GOLD), passivo)
        superficie.blit(pl, (int(cx - pl.get_width() / 2), int(cy - pl.get_height() / 2)))
    if selo:
        desenhar_icone(superficie, base, (cx - tam * .04, cy - tam * .05), tam * .86, cor, tempo)
        r = tam * .22
        sx, sy = cx + tam * .27, cy + tam * .27
        pygame.draw.circle(superficie, (24, 15, 9), (int(sx), int(sy)), int(r + 2))
        pygame.draw.circle(superficie, (60, 44, 28) if passivo else (28, 52, 58), (int(sx), int(sy)), int(r))
        desenhar_icone(superficie, selo, (sx, sy), tam * .42, None, tempo)
    else:
        desenhar_icone(superficie, base, (cx, cy), tam * .9, cor, tempo)


# ================================================================== verificacao de cobertura
def ids_usados_sem_desenho():
    """Ids `simbolo` de conteudo (itens, habilidades, inimigos, chefes, npcs, andares) sem desenho proprio."""
    import conteudo as C
    usados = set()
    for nome in ("HABILIDADES", "ITENS", "INIMIGOS", "CHEFES", "NPCS"):
        for v in getattr(C, nome, {}).values():
            if v.get("simbolo"):
                usados.add(v["simbolo"])
    for a in getattr(C, "ANDARES", []):
        if a.get("simbolo"):
            usados.add(a["simbolo"])
    usados |= set(getattr(C, "SIMBOLOS", {}).keys())
    return sorted(u for u in usados if u not in ICONES)


NOMES_PADRAO = {
    "cruz_latina": ("Cruz latina", "Sinal central da fé cristã: a Paixão de Cristo."),
    "crucifixo": ("Crucifixo", "A cruz com a imagem de Cristo; lembra o sacrifício."),
    "crismon": ("Crismon", "As letras gregas Chi e Rô, iniciais de Cristo."),
    "ihs": ("IHS", "Monograma do nome de Jesus, em grego."),
    "alfa_omega": ("Alfa e Ômega", "Primeira e última letras gregas: Cristo, princípio e fim."),
    "cordeiro": ("Cordeiro de Deus", "Cristo oferecido em sacrifício; o estandarte indica vitória."),
    "pomba": ("Pomba", "Símbolo do Espírito Santo e da paz."),
    "pelicano": ("Pelicano", "Na tradição medieval, alimenta os filhotes com o próprio sangue."),
    "calice": ("Cálice", "Vaso da Eucaristia."),
    "custodia": ("Custódia", "Peça que expõe a hóstia consagrada."),
    "rosario": ("Rosário", "Contas para meditar a vida de Cristo e de Maria."),
    "vela": ("Vela", "Luz de Cristo; oração e vigília."),
    "turibulo": ("Turíbulo", "Incensório: a oração sobe como o incenso."),
    "livro": ("Livro", "Estudo e autoridade da palavra escrita."),
    "pergaminho": ("Pergaminho", "Texto copiado à mão: sentenças e autoridades."),
    "pena": ("Pena", "Instrumento do copista e do mestre."),
    "tinteiro": ("Tinteiro", "A tinta com que se escrevem os argumentos."),
    "balanca": ("Balança", "Justiça e equilíbrio entre razões."),
    "chaves": ("Chaves de Pedro", "O poder de ligar e desligar (Mt 16,19)."),
    "mitra": ("Mitra", "Chapéu do bispo; autoridade eclesiástica."),
    "baculo": ("Báculo", "Cajado do pastor: o bispo guia o rebanho."),
    "coracao_flamejante": ("Coração flamejante", "Emblema de Agostinho: amor ardente a Deus."),
    "boi_sol": ("Boi e sol", "Emblema de Tomás de Aquino: o 'boi mudo' e a luz."),
    "estrela": ("Estrela", "Orientação e luz da sabedoria."),
    "lirio": ("Lírio", "Pureza; atributo de vários santos."),
    "cao_tocha": ("Cão com tocha", "Emblema dominicano: Domini canes, os cães do Senhor."),
    "corda_tres_nos": ("Corda de três nós", "Cordão franciscano: pobreza, castidade e obediência."),
    "tetramorfo": ("Tetramorfo", "Os quatro evangelistas: homem, leão, boi e águia."),
    "escudo_trindade": ("Escudo da Trindade", "Pai, Filho e Espírito Santo: distintos, um só Deus."),
    "aureola": ("Auréola", "Círculo de luz que marca os santos."),
    "sino": ("Sino", "Chama às horas de oração e às aulas."),
    "vitral": ("Vitral", "Vidro colorido que ensina pela luz."),
    "rosacea": ("Rosácea", "Janela circular das catedrais góticas."),
    "arco_ogival": ("Arco ogival", "Arco em ponta, marca do estilo gótico."),
    "frasco": ("Frasco", "Poções e remédios do enfermeiro."),
    "escudo": ("Escudo", "Defesa contra a objeção."),
    "seta_fuga": ("Fuga", "Retirada estratégica da disputa."),
    "cadeado": ("Cadeado", "Porta trancada até a disputa terminar."),
    "porta": ("Porta", "Passagem entre as salas."),
    "bau": ("Baú", "Tesouro da universidade."),
    "escada": ("Escada", "Leva ao próximo andar."),
    "ratio": ("Ratio", "Argumento de razão: lógica e silogismo."),
    "auctoritas": ("Auctoritas", "Argumento de autoridade: citar os grandes mestres."),
    "distinguo": ("Distinguo", "Distinção: separar os sentidos de uma palavra."),
    "apoio": ("Apoio", "Cura e reforço para o disputante."),
}


def nome_padrao(iid):
    return NOMES_PADRAO.get(iid, (iid.replace("_", " ").capitalize(), ""))
