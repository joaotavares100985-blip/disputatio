# -*- coding: utf-8 -*-
"""Extras de interface: navegacao por FOCO (teclado/controle), glifos de botoes, aba "Comandos", controles de volume e tela cheia.
Nada de nomes de marca: o gamepad e sempre chamado de "Controle" e os botoes sao simbolos geometricos genericos."""
import math

import pygame

import audio
from desenho import *

_DIRS = {"up": (0, -1), "down": (0, 1), "left": (-1, 0), "right": (1, 0)}


# ------------------------------------------------------------------ foco
class FocoMixin:
    """Navegacao por foco sobre os 'hits' (botoes registrados) e as grades rolaveis da cena."""
    ok_direto = False        # True: Enter/confirmar ja age no primeiro toque de tecla
    fs_rect = None           # regiao do botao 'tela cheia' (para o JS do navegador)
    foco_key = None
    foco_pos = None
    foco_extra = ()

    def _cands(self):
        out = []
        big = W * H * 0.3
        for r, fn in self.hits:
            if r.w * r.h > big or r.w < 12 or r.h < 12:
                continue
            out.append((("h", r.center), r, fn, None))
        for li, l in enumerate(self.lists):
            if getattr(l, "on_tap", None):
                for i in range(l.n):
                    out.append((("l", li, i), l.cell(i), (lambda l=l, i=i: l.on_tap(i)), l))
        for r, fn in self.foco_extra:
            out.append((("e", r.center), pygame.Rect(r), fn, None))
        return out

    def foco_inicial(self, cs):
        return cs[0]

    def _atual(self, cs):
        if not cs:
            return None
        for c in cs:
            if c[0] == self.foco_key:
                return c
        if self.foco_pos is not None:
            px, py = self.foco_pos
            b = min(cs, key=lambda c: (c[1].centerx - px) ** 2 + (c[1].centery - py) ** 2)
            if (b[1].centerx - px) ** 2 + (b[1].centery - py) ** 2 < 70 * 70:
                self.foco_key = b[0]
                return b
        c = self.foco_inicial(cs)
        self.foco_key, self.foco_pos = c[0], c[1].center
        return c

    def _set(self, c):
        self.foco_key, self.foco_pos = c[0], c[1].center
        l = c[3]
        if l is not None:
            r = c[1]
            if r.top < l.rect.top:
                l.off = max(0, l.off - (l.rect.top - r.top) - 4)
            elif r.bottom > l.rect.bottom:
                l.off = min(l.maxoff(), l.off + (r.bottom - l.rect.bottom) + 4)

    def nav(self, d):
        cs = self._cands()
        cur = self._atual(cs)
        if cur is None or self.game.inp.foco_novo:
            return
        dx, dy = _DIRS[d]
        cx, cy = cur[1].center
        best = None
        for c in cs:
            if c[0] == cur[0]:
                continue
            vx, vy = c[1].centerx - cx, c[1].centery - cy
            prim = vx * dx + vy * dy
            if prim <= 2:
                continue
            sc = prim + 2.5 * (abs(vx * dy) + abs(vy * dx))
            if best is None or sc < best[0]:
                best = (sc, c)
        if best is None:
            if cur[3] is not None and dy:
                cur[3].wheel(dy)
            return
        self._set(best[1])
        audio.sfx("clique")

    def ok(self):
        cs = self._cands()
        cur = self._atual(cs)
        if cur is not None:
            if self.game.inp.foco_novo and not self.ok_direto and len(cs) > 1:
                return
            audio.sfx("clique")
            cur[2]()
            return
        self.key(pygame.K_RETURN)

    def voltar(self):
        self.key(pygame.K_ESCAPE)

    def abas(self, d):
        pass

    def menu(self):
        pass

    def ficha(self):
        pass

    def codex_(self):
        pass

    def acao(self, a):
        if a in _DIRS:
            self.nav(a)
        elif a == "ok":
            self.ok()
        elif a == "back":
            self.voltar()
        elif a == "L":
            self.abas(-1)
        elif a == "R":
            self.abas(1)
        elif a == "menu":
            self.menu()
        elif a == "ficha":
            self.ficha()
        elif a == "codex":
            self.codex_()

    def desenhar_foco(self, S, t):
        cs = self._cands()
        cur = self._atual(cs)
        if not cur:
            return
        r = cur[1]
        if cur[3] is not None:
            r = r.clip(cur[3].rect)
        if r.w < 4 or r.h < 4:
            return
        p = 0.5 + 0.5 * math.sin(t * 8)
        r = r.inflate(10 + int(4 * p), 10 + int(4 * p))
        col = mix(GOLD, (255, 255, 255), 0.2 + 0.5 * p)
        pygame.draw.rect(S, (30, 16, 0), r.inflate(6, 6), 3, 20)
        pygame.draw.rect(S, col, r, 4, 18)
        pygame.draw.rect(S, mix(col, (255, 255, 255), .5), r.inflate(-6, -6), 1, 14)


# ------------------------------------------------------------------ glifos
COR_SIMB = {"cruz": (130, 180, 255), "circulo": (255, 130, 130), "quadrado": (240, 160, 230), "triangulo": (130, 230, 170)}


def g_simbolo(S, c, sz, kind):
    r = sz // 2
    pygame.draw.circle(S, (30, 22, 14), c, r)
    pygame.draw.circle(S, (190, 160, 90), c, r, 3)
    col = COR_SIMB[kind]
    s = int(r * .5)
    x, y = c
    if kind == "cruz":
        pygame.draw.line(S, col, (x - s, y - s), (x + s, y + s), 5)
        pygame.draw.line(S, col, (x + s, y - s), (x - s, y + s), 5)
    elif kind == "circulo":
        pygame.draw.circle(S, col, c, s + 1, 4)
    elif kind == "quadrado":
        pygame.draw.rect(S, col, (x - s, y - s, 2 * s, 2 * s), 4)
    else:
        pygame.draw.polygon(S, col, [(x, y - s - 1), (x + s + 2, y + s), (x - s - 2, y + s)], 4)


def g_gatilho(S, c, sz, letra):
    w, h = int(sz * .9), int(sz * .56)
    r = pygame.Rect(0, 0, w, h)
    r.center = c
    pygame.draw.rect(S, (50, 40, 30), r, 0, h // 2)
    pygame.draw.rect(S, (200, 170, 100), r, 3, h // 2)
    draw_text(S, letra, int(sz * .46), PARCH, c, bold=True, shadow=None)


def g_manipulo(S, c, sz):
    r = sz // 2
    pygame.draw.circle(S, (30, 22, 14), c, r)
    pygame.draw.circle(S, (190, 160, 90), c, r, 3)
    pygame.draw.circle(S, (214, 180, 100), c, int(r * .52))
    pygame.draw.circle(S, (255, 240, 190), (c[0] - int(r * .15), c[1] - int(r * .15)), int(r * .18))
    for dx, dy in ((0, -1), (0, 1), (-1, 0), (1, 0)):
        pygame.draw.circle(S, (190, 160, 90), (c[0] + dx * int(r * .82), c[1] + dy * int(r * .82)), 3)


def g_direcional(S, c, sz):
    a = int(sz * .2)
    L = int(sz * .48)
    x, y = c
    col = (60, 48, 36)
    pygame.draw.rect(S, col, (x - a, y - L, 2 * a, 2 * L), 0, 6)
    pygame.draw.rect(S, col, (x - L, y - a, 2 * L, 2 * a), 0, 6)
    pygame.draw.rect(S, (200, 170, 100), (x - a, y - L, 2 * a, 2 * L), 2, 6)
    pygame.draw.rect(S, (200, 170, 100), (x - L, y - a, 2 * L, 2 * a), 2, 6)
    pygame.draw.rect(S, col, (x - a + 2, y - a + 2, 2 * a - 4, 2 * a - 4))
    for d, (dx, dy) in {"u": (0, -1), "d": (0, 1), "l": (-1, 0), "r": (1, 0)}.items():
        draw_arrow(S, x + dx * int(L * .68), y + dy * int(L * .68), d, (255, 230, 150), 5)


def g_menu(S, c, sz):
    w, h = int(sz * .9), int(sz * .5)
    r = pygame.Rect(0, 0, w, h)
    r.center = c
    pygame.draw.rect(S, (50, 40, 30), r, 0, h // 2)
    pygame.draw.rect(S, (200, 170, 100), r, 3, h // 2)
    for k in (-1, 0, 1):
        pygame.draw.line(S, PARCH, (c[0] - int(w * .22), c[1] + k * 5), (c[0] + int(w * .22), c[1] + k * 5), 3)


def g_tecla(S, c, label, sz=40):
    """Tecla de teclado (largura se ajusta ao texto)."""
    fs = 26 if len(label) <= 3 else 22
    f = font(fs, True)
    w = max(sz, f.size(label)[0] + 18)
    r = pygame.Rect(0, 0, min(w, 120), sz)
    r.center = c
    pygame.draw.rect(S, (30, 22, 14), r.move(0, 3), 0, 8)
    pygame.draw.rect(S, (244, 232, 200), r, 0, 8)
    pygame.draw.rect(S, (110, 84, 40), r, 3, 8)
    S.blit(txt(label, fs, INK, True), txt(label, fs, INK, True).get_rect(center=c))


def g_mouse(S, c, sz):
    x, y = c
    r = pygame.Rect(0, 0, int(sz * .6), int(sz * .9))
    r.center = c
    pygame.draw.rect(S, (244, 232, 200), r, 0, int(sz * .28))
    pygame.draw.rect(S, (110, 84, 40), r, 3, int(sz * .28))
    pygame.draw.line(S, (110, 84, 40), (r.left + 2, y - int(sz * .1)), (r.right - 2, y - int(sz * .1)), 2)
    pygame.draw.line(S, (110, 84, 40), (x, r.top + 2), (x, y - int(sz * .1)), 2)
    pygame.draw.rect(S, (255, 200, 80), (r.left + 4, r.top + 4, r.w // 2 - 4, int(sz * .3)), 0, 6)


def g_expandir(S, c, sz, col=(255, 240, 200)):
    x, y = c
    s = int(sz * .32)
    k = int(sz * .16)
    for sx in (-1, 1):
        for sy in (-1, 1):
            px, py = x + sx * s, y + sy * s
            pygame.draw.line(S, col, (px, py), (px - sx * k, py), 4)
            pygame.draw.line(S, col, (px, py), (px, py - sy * k), 4)


def g_som(S, c, sz, mudo=False, col=(255, 240, 200)):
    x, y = c
    s = int(sz * .22)
    pygame.draw.polygon(S, col, [(x - s * 1.6, y - s * .7), (x - s * .6, y - s * .7), (x + s * .5, y - s * 1.6), (x + s * .5, y + s * 1.6),
                                 (x - s * .6, y + s * .7), (x - s * 1.6, y + s * .7)])
    if mudo:
        pygame.draw.line(S, (240, 90, 80), (x + s * .9, y - s), (x + s * 2.4, y + s), 4)
        pygame.draw.line(S, (240, 90, 80), (x + s * .9, y + s), (x + s * 2.4, y - s), 4)
    else:
        pygame.draw.arc(S, col, (x - s * .2, y - s * 1.1, s * 2.2, s * 2.2), -1.0, 1.0, 3)
        pygame.draw.arc(S, col, (x - s * .2 - s * .7, y - s * 1.9, s * 3.6, s * 3.8), -0.9, 0.9, 3)


def g_arrastar(S, c, sz):
    x, y = c
    draw_arrow(S, x, y - int(sz * .32), "u", (255, 230, 150), 8)
    draw_arrow(S, x, y + int(sz * .32), "d", (255, 230, 150), 8)
    pygame.draw.circle(S, PARCH, c, 6)


def glifo(S, kind, c, sz=48, t=0.0):
    """Desenha o glifo 'kind' (generico) centrado em c."""
    x, y = c
    if kind in COR_SIMB:
        g_simbolo(S, c, sz, kind)
    elif kind in ("L", "R"):
        g_gatilho(S, c, sz, kind)
    elif kind == "LR":
        g_gatilho(S, (x - int(sz * .46), y), int(sz * .8), "L")
        g_gatilho(S, (x + int(sz * .46), y), int(sz * .8), "R")
    elif kind == "stick":
        g_manipulo(S, c, sz)
    elif kind == "dpad":
        g_direcional(S, c, sz)
    elif kind == "menu":
        g_menu(S, c, sz)
    elif kind == "mouse":
        g_mouse(S, c, sz)
    elif kind == "expandir":
        draw_round(S, c, sz // 2, None, None, "dark", False, False, t)
        g_expandir(S, c, sz)
    elif kind == "som":
        draw_round(S, c, sz // 2, None, None, "dark", False, False, t)
        g_som(S, c, sz)
    elif kind == "arrastar":
        g_arrastar(S, c, sz)
    elif kind == "joystick":
        import arte_ui
        b = arte_ui.joy_base(sz // 2)
        S.blit(b, b.get_rect(center=c))
        k = arte_ui.joy_knob()
        k = pygame.transform.smoothscale(k, (int(sz * .5), int(sz * .5)))
        S.blit(k, k.get_rect(center=c))
    elif kind == "btnA":
        draw_round(S, c, sz // 2, "mao", None, "gold", False, False, t)
    elif kind == "btnFicha":
        draw_round(S, c, sz // 2, "pessoa", None, "normal", False, False, t)
    elif kind == "btnPausa":
        draw_round(S, c, sz // 2, "pausa", None, "normal", False, False, t)
    elif kind == "toque":
        desenhar_icone(S, "mao", c, int(sz * .9))
    elif kind == "wasd":
        g_tecla(S, c, "WASD", int(sz * .8))
    else:
        g_tecla(S, c, kind, int(sz * .8))


# --------------------------------------------------------------- comandos
COMANDOS = (
    ("CONTROLE", "stick", [("stick", "Andar"), ("dpad", "Navegar"), ("cruz", "Interagir"), ("circulo", "Voltar"), ("quadrado", "Ficha"),
                           ("triangulo", "Códex"), ("LR", "Trocar abas"), ("menu", "Pausa")],
     "Combate: direcional escolhe Item, Defender ou Fugir; o botão de baixo confirma."),
    ("CELULAR", "toque", [("joystick", "Andar"), ("btnA", "Interagir"), ("btnFicha", "Ficha"), ("btnPausa", "Pausa"), ("toque", "Tocar cartões"),
                          ("arrastar", "Rolar listas"), ("expandir", "Tela cheia"), ("som", "Mudo (na Pausa)")],
     "Combate: toque nos botões redondos (Item, Defender, Fugir) e nos cartões."),
    ("PC", "mouse", [("wasd", "Andar"), ("E", "Interagir"), ("I", "Ficha"), ("C", "Códex"), ("Esc", "Pausa / voltar"), ("Enter", "Confirmar"),
                     ("Q  R", "Trocar abas"), ("F11", "Tela cheia"), ("M", "Mudo"), ("mouse", "Clicar em tudo")],
     "Combate: teclas 1 a 5 = Argumentar, Autoridade, Item, Defender, Fugir."),
)


def aba_comandos_padrao(inp):
    return {"controle": 0, "toque": 1}.get(inp.modo, 2)


def desenhar_comandos(cena, S, aba, t):
    """Pagina 'Comandos': 3 abas (Controle, Celular, PC) com icone do botao + 1 verbo."""
    for k, (nome, _, _, _) in enumerate(COMANDOS):
        cena.btn(S, (100 + k * 224, 76, 216, 52), nome, (lambda k=k: cena.set_aba_cmd(k)), "gold" if k == aba else "normal", 28)
    nome, _, rows, rodape = COMANDOS[aba]
    panel(S, pygame.Rect(40, 136, 880, 300), 240)
    n = len(rows)
    meio = (n + 1) // 2
    for i, (gk, verbo) in enumerate(rows):
        col, lin = (0, i) if i < meio else (1, i - meio)
        cx = 60 + col * 440
        cy = 136 + 36 + lin * 50
        glifo(S, gk, (cx + 64, cy), 44, t)
        draw_text(S, verbo, 28, PARCH, (cx + 140, cy), anchor="midleft", bold=True)
    draw_text(S, rodape, 22, (214, 190, 140), (480, 420), shadow=None)


# ------------------------------------------------------------ botoes extras
def rbtn_glifo(cena, S, c, r, fn_glifo, fn):
    rect = pygame.Rect(c[0] - r, c[1] - r, 2 * r, 2 * r)
    draw_round(S, c, r, None, None, "normal", cena.is_pressed(rect), False, cena.t)
    fn_glifo(S, c, int(r * 1.5), "dark")
    cena.reg(rect, fn)
    return rect


def glifo_expandir_b(S, c, sz, tom="dark"):
    g_expandir(S, c, sz, (60, 40, 14))


def glifo_som_b(S, c, sz, tom="dark", mudo=False):
    g_som(S, c, sz, mudo, (60, 40, 14))


def btn_tela_cheia(cena, S, rect, fn):
    """Botao 'Tela cheia' com icone de expandir; registra fs_rect para o JS (navegador)."""
    cena.btn(S, rect, "Tela cheia", fn, "normal", 26)
    r = pygame.Rect(rect)
    g_expandir(S, (r.x + 28, r.centery), 40, (60, 40, 14))
    cena.fs_rect = tuple(r)


def linha_volume(cena, S, y, rotulo, valor, fn):
    x0 = 272
    draw_text(S, rotulo, 26, PARCH, (x0, y + 20), anchor="midleft", bold=True)
    cena.btn(S, (394, y + 2, 44, 36), "-", lambda: fn(valor - .1), "normal", 32)
    draw_bar(S, pygame.Rect(446, y + 8, 160, 24), max(0.0, min(1.0, valor)), (230, 200, 90), (170, 130, 40))
    cena.btn(S, (614, y + 2, 44, 36), "+", lambda: fn(valor + .1), "normal", 32)
