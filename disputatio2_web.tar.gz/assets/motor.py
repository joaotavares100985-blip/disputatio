# -*- coding: utf-8 -*-
"""Motor: pilha de cenas, transicoes e fluxo geral do jogo."""
import math

import pygame

import audio
import estado as E
from desenho import *
from ui import Titulo, CartaoAndar, GameOver, Vitoria, desenhar_gire
from mundo import Mundo
from combate import Combate


class Game:
    def __init__(self, inp):
        self.inp = inp
        self.t = 0.0
        self.stack = []
        self.tr = None
        self.seen = set()
        self.run = None
        self.toasts = []
        self.retrato = False      # navegador em retrato: mostra a dica "Gire o celular"
        self.fs_fn = None         # (PC) callback de tela cheia, definido em main.py
        self.fs_on = lambda: False
        self.sessao = None        # modo online (online.Sessao) ou None
        self.push(Titulo(self))

    def tela_cheia(self):
        """PC: alterna tela cheia. No navegador o JS faz isso dentro do gesto (ver Entrada.set_fs)."""
        if self.fs_fn and not self.inp.web:
            try:
                self.fs_fn()
            except Exception:
                pass

    def fs_ativo(self):
        try:
            return bool(self.fs_on())
        except Exception:
            return False

    def toast(self, texto, icone="estrela"):
        """Aviso curto (1 linha) no topo, sem bloquear o jogo."""
        self.toasts.append(dict(t=0.0, texto=texto, icone=icone))
        self.toasts = self.toasts[-4:]

    # ---- pilha
    def push(self, scene):
        self.stack.append(scene)
        scene.enter()

    def pop(self, scene=None):
        if scene is None:
            if self.stack:
                self.stack.pop()
        elif scene in self.stack:
            self.stack.remove(scene)
        if self.stack:
            self.stack[-1].resume()

    def set_root(self, scene):
        self.stack = []
        self.push(scene)

    @property
    def top(self):
        return self.stack[-1] if self.stack else None

    # ---- transicoes
    def fade(self, fn, kind="fade"):
        if self.tr is None:
            self.tr = dict(t=0.0, fn=fn, done=False, kind=kind)
        else:
            fn()

    # ---- fluxo
    def novo_jogo(self):
        self.fade(self._novo)

    def _novo(self):
        self.run = E.Run()
        if self.sessao is not None and self.sessao.host:
            self.run.add_heroi2()
        self.entrar_andar()

    def entrar_andar(self):
        i = self.run.andar_i
        dados = self.run.andar.dados
        self.set_root(CartaoAndar(self, i, dados, lambda: self.push(Mundo(self))))

    def descer(self):
        def go():
            for j in self.run.herois:
                j.hp = min(j.hp_max, j.hp + j.hp_max // 3)
                j.tinta = j.tinta_max
            self.run.novo_andar(self.run.andar_i + 1)
            self.entrar_andar()
        self.fade(go)

    def iniciar_combate(self, ids, boss, cb):
        self.push(Combate(self, ids, boss, cb))

    def game_over(self):
        self.fade(lambda: self.set_root(GameOver(self, self.run)))

    def vitoria(self):
        self.fade(lambda: self.set_root(Vitoria(self, self.run)))

    def ir_titulo(self):
        self.coop_fechar()
        self.fade(lambda: self.set_root(Titulo(self)))

    # ---- online (coop)
    def coop_fechar(self):
        s, self.sessao = self.sessao, None
        if s is not None:
            s.fecha()

    def coop_caiu(self, msg="O amigo saiu."):
        self.coop_fechar()
        self.toast(msg, "porta")
        self.fade(lambda: self.set_root(Titulo(self)))

    def coop_host_comecar(self):
        def go():
            mundo = next((s for s in reversed(self.stack) if isinstance(s, Mundo)), None)
            if self.run is not None and mundo is not None:       # veio da pausa: o amigo entra na partida em andamento
                while self.stack and self.stack[-1] is not mundo:
                    self.stack.pop()
                if len(self.run.herois) < 2:
                    self.run.add_heroi2()
                mundo.resume()
            else:
                self._novo()
        self.fade(go)

    def coop_convidado(self):
        from ui_online import Terminal
        self.fade(lambda: self.set_root(Terminal(self)))

    def estado_terminal(self):
        t = self.top
        ex = bool(getattr(t, "coop_livre", False)) and self.tr is None
        return {"t": "st", "ex": ex, "a": t.icone_a2() if ex else None}

    def donos(self):
        f = getattr(self.top, "dono", None)
        return f() if f else (0, 1)

    def _online(self, dt):
        s = self.sessao
        s.pump(dt)
        if s.ativa and not s.iniciada:
            s.iniciada = True
            if s.host:
                self.coop_host_comecar()
            else:
                self.coop_convidado()
        elif s.iniciada and (s.caiu or s.rede.estado != "ok"):
            self.coop_caiu("O amigo saiu." if s.host else "A sala foi encerrada.")
        elif s.caiu and not s.iniciada:
            s.caiu = False
            if s.host:
                s.pareado = s.ver_ok = False       # o amigo desistiu antes de comecar: a sala continua aberta
            elif not s.erro:
                s.erro = "O anfitrião saiu." 

    # ---- laco
    def update(self, dt):
        self.t += dt
        inp = self.inp
        audio.tick()
        if self.sessao is not None:
            self._online(dt)
        top = self.top
        inp.texto = bool(getattr(top, "texto", False))
        srcs = [(inp, 0)]
        if self.sessao is not None and self.sessao.vinp is not None and self.sessao.iniciada:
            srcs.append((self.sessao.vinp, 1))
        if self.tr is None and top is not None:
            donos = self.donos() if len(srcs) > 1 else (0,)
            for src, idx in srcs:
                if idx not in donos:
                    continue
                if idx == 1 and getattr(self.top, "coop_livre", False):
                    for a in src.acoes:               # convidado na exploracao: so botoes (o joystick vem em teclas_dir)
                        self.top.acao_p2(a)
                    continue
                for kind, pid, pos in src.ev:
                    top = self.top
                    if self.tr is not None or top is None:
                        break
                    if kind == "d":
                        top.down(pid, pos)
                    elif kind == "m":
                        top.move(pid, pos)
                    else:
                        top.up(pid, pos)
                for k in src.keys_down:
                    if k == pygame.K_F11:
                        self.tela_cheia()
                    elif k == pygame.K_m:
                        audio.alternar_mudo()
                    elif self.top and self.tr is None:
                        self.top.key(k)
                for a in src.acoes:
                    if self.top and self.tr is None:
                        self.top.acao(a)
                if src.wheel and self.top:
                    self.top.wheel(src.wheel)
        if self.tr is not None:
            tr = self.tr
            tr["t"] += dt / 0.6
            if tr["t"] >= 0.5 and not tr["done"]:
                tr["done"] = True
                tr["fn"]()
            if tr["t"] >= 1:
                self.tr = None
        if self.top:
            self.top.update(dt)
        if self.toasts:
            self.toasts[0]["t"] += dt
            if self.toasts[0]["t"] > 2.4:
                self.toasts.pop(0)

    def _draw_toast(self, S):
        tt = self.toasts[0]
        k = tt["t"]
        a = min(1.0, k * 6) * min(1.0, (2.4 - k) * 5)
        f = font(28, True)
        w = f.size(tt["texto"])[0] + 84
        tmp = pygame.Surface((w, 52), pygame.SRCALPHA)
        pygame.draw.rect(tmp, (20, 12, 6, 235), tmp.get_rect(), 0, 26)
        pygame.draw.rect(tmp, GOLD, tmp.get_rect(), 3, 26)
        desenhar_icone(tmp, tt["icone"], (30, 26), 34)
        tmp.blit(txt(tt["texto"], 28, PARCH, True), (56, 26 - f.get_height() // 2))
        tmp.set_alpha(int(255 * a))
        S.blit(tmp, tmp.get_rect(midtop=(W // 2, 130 - int((1 - min(1, k * 6)) * 16))))

    def draw(self, S):
        if not self.stack:
            S.fill((0, 0, 0))
            return
        i = len(self.stack) - 1
        while i > 0 and not self.stack[i].opaque:
            i -= 1
        for sc in self.stack[i:]:
            sc.draw(S)
        if self.toasts:
            self._draw_toast(S)
        vi = self.sessao.vinp if self.sessao is not None else None
        if self.tr is None and (self.inp.foco_visivel() or (vi is not None and vi.foco_visivel())):
            self.top.desenhar_foco(S, self.t)
        self.inp.set_fs(getattr(self.top, "fs_rect", None))
        if self.retrato:
            desenhar_gire(S, self.t)
        if self.tr is not None:
            a = 1 - abs(2 * self.tr["t"] - 1)
            if self.tr["kind"] == "flash":
                ov = _overlay((250, 244, 220))
                ov.set_alpha(int(255 * min(1, a * 1.8)))
            else:
                ov = _overlay((8, 4, 2))
                ov.set_alpha(int(255 * min(1, a * 1.7)))
            S.blit(ov, (0, 0))
        if self.sessao is not None:
            self.sessao.pos_draw(S)


_ov = {}


def _overlay(col):
    if col not in _ov:
        s = pygame.Surface((W, H))
        s.fill(col)
        _ov[col] = s
    return _ov[col]
