# -*- coding: utf-8 -*-
"""
DISPUTATIO 2 - roguelite escolastico (exploracao estilo Isaac + combate por turnos estilo Final Fantasy).
Tela HORIZONTAL 960x540. Roda no PC (python main.py) e no celular via navegador (pygbag).
"""
import asyncio
import os
import sys

try:
    import conteudo  # noqa: F401
except ImportError:
    # sem conteudo.py (desenvolvimento): usa a amostra minima
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "tests"))
    import conteudo_amostra as conteudo  # noqa: F401
    sys.modules["conteudo"] = conteudo

import pygame

pygame.init()

from entrada import Entrada  # noqa: E402
from motor import Game  # noqa: E402

W, H = 960, 540


def _retrato():
    """Navegador em retrato (altura > largura)?"""
    try:
        import platform
        return float(platform.window.innerHeight) > float(platform.window.innerWidth)
    except Exception:
        return False


async def main():
    web = sys.platform == "emscripten"
    size = (W, H)
    if not web:
        try:
            dw, dh = pygame.display.get_desktop_sizes()[0]
            k = min(1.0, (dh - 120) / H, (dw - 40) / W)
            size = (int(W * k), int(H * k))
        except Exception:
            pass
    pygame.display.set_caption("Disputatio 2")
    if web:
        pygame.display.set_mode((W, H), pygame.SCALED)
    else:
        pygame.display.set_mode(size, pygame.RESIZABLE)
    canvas = pygame.Surface((W, H)).convert()
    inp = Entrada(web)
    game = Game(inp)
    fs = {"on": False}

    def alternar_fs():
        """PC: tela cheia 16:9 com barras pretas (o mapeamento do mouse usa inp.scale)."""
        try:
            if not fs["on"]:
                dw_, dh_ = pygame.display.get_desktop_sizes()[0]
                pygame.display.set_mode((dw_, dh_), pygame.FULLSCREEN)
                fs["on"] = True
            else:
                pygame.display.set_mode(size, pygame.RESIZABLE)
                fs["on"] = False
        except Exception:
            try:
                pygame.display.toggle_fullscreen()
                fs["on"] = not fs["on"]
            except Exception:
                pass

    if not web:
        try:
            import audio
            audio.iniciar()
            inp._audio_ok = True
        except Exception:
            pass
    game.fs_fn = alternar_fs
    game.fs_on = lambda: fs["on"]
    clock = pygame.time.Clock()
    frame = 0
    while True:
        frame += 1
        if web and frame in (2, 30):
            try:
                import platform
                platform.window.window_resize()
            except Exception:
                pass
        if web and frame % 20 == 1:
            game.retrato = _retrato()
        dt = min(clock.tick(60) / 1000.0, 0.05)
        win = pygame.display.get_surface()
        ww, wh = win.get_size()
        sc = min(ww / W, wh / H)           # mantem a proporcao 16:9 (barras nas sobras)
        dw, dh = int(W * sc), int(H * sc)
        ox, oy = (ww - dw) // 2, (wh - dh) // 2
        inp.scale = (sc, ox, oy)
        if inp.poll(pygame.event.get()):
            game.coop_fechar()
            pygame.quit()
            return
        game.update(dt)
        game.draw(canvas)
        win.fill((8, 5, 2))
        if (dw, dh) == (W, H):
            win.blit(canvas, (ox, oy))
        else:
            win.blit(pygame.transform.smoothscale(canvas, (dw, dh)), (ox, oy))
        pygame.display.flip()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
