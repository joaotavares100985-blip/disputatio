# -*- coding: utf-8 -*-
"""Entrada unificada: mouse/teclado no PC, Pointer Events (multitoque) no navegador, controle (gamepad).

Acoes normalizadas (self.acoes): up, down, left, right, ok, back, ficha, codex, L, R, menu.
Mapeamento do Controle: manipulo esquerdo/direcional = andar e navegar; botao de baixo = confirmar/interagir;
botao da direita = voltar; botao da esquerda = ficha/mochila; botao de cima = codice/ajuda; L/R = trocar abas; menu = pausa.
"""
import math
import time

import pygame

import audio

W, H = 960, 540

JS = """
window.ptrstate = {s: ""};
window.fsreg = null;
(function () {
  var c = document.getElementById('canvas');
  c.style.touchAction = 'none';
  var down = {};
  function add(t, e) {
    var r = c.getBoundingClientRect();
    window.ptrstate.s += t + ':' + e.pointerId + ':' + ((e.clientX - r.left) / r.width) + ':' +
                         ((e.clientY - r.top) / r.height) + ';';
  }
  function unlock() {
    try { var a = window.Module && Module.SDL2 && Module.SDL2.audioContext;
          if (a && a.state === 'suspended') a.resume(); } catch (_) {}
  }
  function fs(e) {
    var r = window.fsreg;
    if (!r) return;
    var b = c.getBoundingClientRect();
    var fx = (e.clientX - b.left) / b.width, fy = (e.clientY - b.top) / b.height;
    if (fx < r[0] || fx > r[2] || fy < r[1] || fy > r[3]) return;
    var d = document;
    try {
      if (d.fullscreenElement || d.webkitFullscreenElement) {
        var x = (d.exitFullscreen || d.webkitExitFullscreen);
        if (x) x.call(d);
      } else {
        var q = (c.requestFullscreen || c.webkitRequestFullscreen || c.msRequestFullscreen);
        if (q) {
          var p = q.call(c);
          var lock = function () { try { var o = screen.orientation.lock('landscape'); if (o && o.catch) o.catch(function () {}); } catch (_) {} };
          if (p && p.then) { p.then(lock).catch(function () {}); } else { lock(); }
        }
      }
    } catch (_) {}
  }
  window.addEventListener('pointerdown', function (e) { unlock(); down[e.pointerId] = 1; add('d', e); }, true);
  window.addEventListener('pointermove', function (e) { if (down[e.pointerId]) add('m', e); }, true);
  var up = function (e) { if (down[e.pointerId]) { delete down[e.pointerId]; add('u', e); fs(e); } };
  window.addEventListener('pointerup', up, true);
  window.addEventListener('pointercancel', function (e) { if (down[e.pointerId]) { delete down[e.pointerId]; add('u', e); } }, true);
  window.addEventListener('wheel', function (e) { window.ptrstate.s += 'w:0:' + e.deltaY + ':0;'; }, {passive: true});
  c.addEventListener('contextmenu', function (e) { e.preventDefault(); });
})();
"""

DEAD = 0.25
# botoes padrao (controle): 0 baixo, 1 direita, 2 esquerda, 3 cima, 4 select, 6 start, 9 L, 10 R, dpad 11-14
_BOT_CTRL = {0: "ok", 1: "back", 2: "ficha", 3: "codex", 6: "menu", 9: "L", 10: "R"}
# fallback joystick generico
_BOT_JOY = {0: "ok", 1: "back", 2: "ficha", 3: "codex", 4: "L", 5: "R", 7: "menu", 9: "menu"}
_TECLAS = {pygame.K_UP: "up", pygame.K_DOWN: "down", pygame.K_LEFT: "left", pygame.K_RIGHT: "right",
           pygame.K_w: "up", pygame.K_s: "down", pygame.K_a: "left", pygame.K_d: "right",
           pygame.K_RETURN: "ok", pygame.K_KP_ENTER: "ok", pygame.K_SPACE: "ok", pygame.K_e: "ok", pygame.K_z: "ok",
           pygame.K_ESCAPE: "back", pygame.K_q: "L", pygame.K_r: "R", pygame.K_PAGEUP: "L", pygame.K_PAGEDOWN: "R"}


class Entrada:
    def __init__(self, web=False):
        self.web = web
        self.plat = None
        self.ev = []            # eventos do frame: (tipo 'd'|'m'|'u', id, (x, y))
        self.keys_down = []     # teclas (nao traduzidas em acoes) neste frame
        self.acoes = []         # acoes normalizadas deste frame
        self.wheel = 0
        self.scale = (1.0, 0, 0)
        self.sim_ev = []        # eventos injetados (testes / bot)
        self.sim_acoes = []
        self.sim_dir = (0.0, 0.0)
        self.headless = False
        self.texto = False      # cena de digitacao: letras vao para keys_down (nao viram acoes)
        self.modo = "toque" if web else "mouse"   # toque | mouse | teclado | controle
        self.foco_novo = False  # o foco acabou de ser revelado neste frame
        self.pad_dir = (0.0, 0.0)
        self._joys = {}
        self._ctrls = {}
        self._dp = (0, 0)
        self._st = (0.0, 0.0)
        self._ndir = None
        self._nprox = 0.0
        self._fsreg = "?"
        self._audio_ok = False
        try:
            pygame.joystick.init()
            for i in range(pygame.joystick.get_count()):
                self._abrir(i)
        except Exception:
            pass
        if web:
            try:
                import platform as plat
                plat.window.eval(JS)
                self.plat = plat
            except Exception:
                self.plat = None

    # ----------------------------------------------------------- utilidades
    def injetar_toque(self, pos, pid="sim"):
        self.sim_ev.append(("d", pid, tuple(pos)))
        self.sim_ev.append(("u", pid, tuple(pos)))

    def injetar(self, tipo, pos, pid="sim"):
        self.sim_ev.append((tipo, pid, tuple(pos)))

    def injetar_acao(self, a, modo="controle"):
        self.sim_acoes.append((a, modo))

    def tolocal(self, p):
        sc, ox, oy = self.scale
        return ((p[0] - ox) / sc, (p[1] - oy) / sc)

    def foco_visivel(self):
        return self.modo in ("teclado", "controle")

    def nome_modo(self):
        return {"toque": "Celular", "mouse": "PC", "teclado": "PC", "controle": "Controle"}.get(self.modo, "PC")

    def dica_interagir(self):
        if self.modo == "controle":
            return "Manípulo para andar, botão de baixo interage."
        if self.modo == "teclado":
            return "Setas ou WASD andam, E interage."
        return "Joystick para andar, botão A para interagir."

    def set_fs(self, rect):
        """Informa ao JS a regiao (fracoes 0..1) do botao de tela cheia: o requestFullscreen precisa ocorrer no gesto."""
        if self.plat is None:
            return
        k = None if rect is None else (round(rect[0], 1), round(rect[1], 1), rect[2], rect[3])
        if k == self._fsreg:
            return
        self._fsreg = k
        try:
            if rect is None:
                self.plat.window.eval("window.fsreg=null;")
            else:
                x, y, w, h = rect
                self.plat.window.eval("window.fsreg=[%.4f,%.4f,%.4f,%.4f];" % (x / W, y / H, (x + w) / W, (y + h) / H))
        except Exception:
            pass

    # ----------------------------------------------------------- controle
    def _abrir(self, idx):
        try:
            j = pygame.joystick.Joystick(idx)
            iid = j.get_instance_id() if hasattr(j, "get_instance_id") else idx
            self._joys[iid] = j
            try:
                from pygame._sdl2 import controller as ct
                ct.init()
                if ct.is_controller(idx):
                    self._ctrls[iid] = ct.Controller(idx)
            except Exception:
                pass
        except Exception:
            pass

    def _acao(self, a, modo):
        self.acoes.append(a)
        self._modo(modo)

    def _modo(self, m):
        if m != self.modo:
            if m in ("teclado", "controle") and self.modo not in ("teclado", "controle"):
                self.foco_novo = True
            self.modo = m

    def _eixos(self):
        x, y = self._st
        n = math.hypot(x, y)
        if n < DEAD:
            x = y = 0.0
        else:
            k = min(1.0, (n - DEAD) / (1 - DEAD)) / n
            x, y = x * k, y * k
        dx, dy = self._dp
        if dx or dy:
            x, y = float(dx), float(dy)
        self.pad_dir = (x, y)
        if abs(x) > 0.55 or abs(y) > 0.55:
            if self.modo != "controle":
                self._modo("controle")
            d = ("right" if x > 0 else "left") if abs(x) >= abs(y) else ("down" if y > 0 else "up")
            ag = time.monotonic()
            if d != self._ndir:
                self._ndir = d
                self._nprox = ag + 0.4
                self.acoes.append(d)
            elif ag >= self._nprox:
                self._nprox = ag + 0.13
                self.acoes.append(d)
        else:
            self._ndir = None

    def _evento_pad(self, e):
        t = e.type
        iid = getattr(e, "instance_id", None)
        ctrl_t = (getattr(pygame, "CONTROLLERBUTTONDOWN", -1), getattr(pygame, "CONTROLLERAXISMOTION", -1))
        if t == getattr(pygame, "JOYDEVICEADDED", -1):
            self._abrir(getattr(e, "device_index", 0))
        elif t == getattr(pygame, "JOYDEVICEREMOVED", -1):
            self._joys.pop(iid, None)
            self._ctrls.pop(iid, None)
            self._dp, self._st = (0, 0), (0.0, 0.0)
        elif t == getattr(pygame, "CONTROLLERBUTTONDOWN", -2):
            b = e.button
            if b in _BOT_CTRL:
                self._acao(_BOT_CTRL[b], "controle")
            elif b in (11, 12, 13, 14):
                self._dpad_botao(b, True)
        elif t == getattr(pygame, "CONTROLLERBUTTONUP", -2):
            if e.button in (11, 12, 13, 14):
                self._dpad_botao(e.button, False)
        elif t == getattr(pygame, "CONTROLLERAXISMOTION", -2):
            v = e.value / 32767.0
            if e.axis == 0:
                self._st = (v, self._st[1])
            elif e.axis == 1:
                self._st = (self._st[0], v)
        elif t == pygame.JOYBUTTONDOWN and iid not in self._ctrls:
            b = e.button
            if b in _BOT_JOY:
                self._acao(_BOT_JOY[b], "controle")
        elif t == pygame.JOYHATMOTION and iid not in self._ctrls:
            self._dp = (e.value[0], -e.value[1])
        elif t == pygame.JOYAXISMOTION and iid not in self._ctrls:
            if e.axis == 0:
                self._st = (e.value, self._st[1])
            elif e.axis == 1:
                self._st = (self._st[0], e.value)

    def _dpad_botao(self, b, on):
        x, y = self._dp
        v = 1 if on else 0
        if b == 11:
            y = -v
        elif b == 12:
            y = v
        elif b == 13:
            x = -v
        elif b == 14:
            x = v
        if not on:
            if b in (11, 12):
                y = 0
            else:
                x = 0
        self._dp = (x, y)

    # ---------------------------------------------------------------- poll
    def poll(self, eventos):
        """Processa eventos pygame (PC), buffer JS (web) e controle. Preenche ev, keys_down, acoes."""
        self.ev = list(self.sim_ev)
        if self.sim_ev:
            self._modo("toque")
        self.sim_ev = []
        self.keys_down = []
        self.acoes = []
        self.foco_novo = False
        self.wheel = 0
        quit_ = False
        for a, m in self.sim_acoes:
            self._acao(a, m)
        self.sim_acoes = []
        if self.plat is not None:
            try:
                buf = str(self.plat.window.ptrstate.s)
                if buf:
                    self.plat.window.ptrstate.s = ""
                    ult = {}
                    for item in buf.split(";"):
                        if not item:
                            continue
                        kind, pid, fx, fy = item.split(":")
                        if kind == "w":
                            self.wheel += float(fx) / 100.0
                            continue
                        pos = (float(fx) * W, float(fy) * H)
                        if kind == "m":
                            if pid in ult:
                                self.ev[ult[pid]] = None
                            ult[pid] = len(self.ev)
                            self.ev.append(("m", pid, pos))
                        else:
                            if pid in ult and self.ev[ult[pid]] is not None:
                                self.ev[ult[pid]] = None   # descarta moves anteriores ao up
                            self.ev.append((kind, pid, pos))
                    self.ev = [e for e in self.ev if e is not None]
                    if self.ev:
                        self._modo("toque")
            except Exception:
                pass
        for e in eventos:
            t = e.type
            if t == pygame.QUIT:
                quit_ = True
            elif t == pygame.KEYDOWN:
                a = None if (self.texto and pygame.K_a <= e.key <= pygame.K_z) else _TECLAS.get(e.key)
                if a:
                    self._acao(a, "teclado")
                else:
                    self.keys_down.append(e.key)
                    self._modo("teclado")
            elif t in (getattr(pygame, "JOYDEVICEADDED", -1), getattr(pygame, "JOYDEVICEREMOVED", -1), pygame.JOYBUTTONDOWN,
                       pygame.JOYHATMOTION, pygame.JOYAXISMOTION, getattr(pygame, "CONTROLLERBUTTONDOWN", -2),
                       getattr(pygame, "CONTROLLERBUTTONUP", -2), getattr(pygame, "CONTROLLERAXISMOTION", -2)):
                self._evento_pad(e)
            if self.web:
                continue
            if t == pygame.MOUSEBUTTONDOWN and e.button == 1:
                self.ev.append(("d", "m", self.tolocal(e.pos)))
                self._modo("mouse")
            elif t == pygame.MOUSEMOTION and e.buttons[0]:
                self.ev.append(("m", "m", self.tolocal(e.pos)))
            elif t == pygame.MOUSEBUTTONUP and e.button == 1:
                self.ev.append(("u", "m", self.tolocal(e.pos)))
            elif t == pygame.MOUSEWHEEL:
                self.wheel -= e.y
        self._eixos()
        if not self._audio_ok and (self.ev or self.keys_down or self.acoes):
            self._audio_ok = True
            audio.iniciar()
        return quit_

    def teclas_dir(self):
        """Vetor de movimento por teclado (setas/WASD), controle ou simulado."""
        x, y = self.sim_dir
        try:
            k = pygame.key.get_pressed()
            x += (k[pygame.K_RIGHT] or k[pygame.K_d]) - (k[pygame.K_LEFT] or k[pygame.K_a])
            y += (k[pygame.K_DOWN] or k[pygame.K_s]) - (k[pygame.K_UP] or k[pygame.K_w])
        except Exception:
            pass
        x += self.pad_dir[0]
        y += self.pad_dir[1]
        n = math.hypot(x, y)
        if n > 1:
            x, y = x / n, y / n
        return x, y
