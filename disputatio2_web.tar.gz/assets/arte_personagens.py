# -*- coding: utf-8 -*-
"""Personagens do jogador e NPCs (fachada). O Bacharel vive em arte_heroi.py; os NPCs em arte_figuras.py.

API (inalterada):
    hero_sala(S, x, y, t, face, moving, nivel=1, estado="normal")   exploracao (4 direcoes)
    hero_combate(nivel, pose, s, flash=0) -> Surface (pes em HERO_ANCHOR)   combate, vista 3/4 voltada para os inimigos
    hero_sprite(which=0, nivel=1)  -> Surface frontal 150x200 (ficha)
    hero_retrato(size, nivel)      -> retrato redondo
    escudo_luz(S, cx, cy, t, r)
    npc_sprite / npc_frame / npc_portrait   (de arte_figuras)
"""
from arte_figuras import (sino_manto, hem_pts, mao, rot, pileus, livro_obj, pena_obj, pergaminho_obj, sombra_chao, cilindro, figura_frontal,  # noqa: F401
                          npc_sprite, npc_frame, npc_portrait, NPC_ESTILO)  # noqa: F401
from arte_heroi import (hero_combate, hero_sala, hero_sprite, hero_retrato, escudo_luz, HERO_ANCHOR, HERO_CW, HERO_CH, pose, tier)  # noqa: F401

TITULOS = ["Estudante", "Bacharel", "Licenciado", "Mestre", "Doutor"]
