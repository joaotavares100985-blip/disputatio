# -*- coding: utf-8 -*-
"""Vista: proxy de arte_kit.Tela com origem, escala e espelhamento (desenhar em coordenadas locais)."""
from arte_kit import arco


class Vista:
    def __init__(self, T, ox, oy, k=1.0, flip=False):
        self.T, self.ox, self.oy, self.k, self.f = T, ox, oy, k, (-1 if flip else 1)

    def pt(self, x, y):
        return (self.ox + x * self.k * self.f, self.oy + y * self.k)

    def pts(self, pts):
        return [self.pt(x, y) for x, y in pts]

    def _ow(self, ow):
        return ow * max(.6, self.k)

    def poly(self, pts, fill=None, ol=None, ow=1.0):
        self.T.poly(self.pts(pts), fill, ol, self._ow(ow))

    def gpoly(self, pts, stops, ol=None, ow=1.0, horizontal=False):
        self.T.gpoly(self.pts(pts), stops, ol, self._ow(ow), horizontal)

    def circ(self, x, y, r, fill=None, ol=None, ow=1.0):
        X, Y = self.pt(x, y)
        self.T.circ(X, Y, r * self.k, fill, ol, self._ow(ow))

    def ell(self, x, y, w, h, fill=None, ol=None, ow=1.0, rot=0.0):
        X, Y = self.pt(x, y)
        self.T.ell(X, Y, w * self.k, h * self.k, fill, ol, self._ow(ow), rot * self.f)

    def gell(self, x, y, w, h, stops, ol=None, ow=1.0, horizontal=False, rot=0.0):
        X, Y = self.pt(x, y)
        self.T.gell(X, Y, w * self.k, h * self.k, stops, ol, self._ow(ow), horizontal, rot * self.f)

    def gcirc(self, x, y, r, stops, ol=None, ow=1.0, horizontal=False):
        self.gell(x, y, 2 * r, 2 * r, stops, ol, ow, horizontal)

    def rect(self, x, y, w, h, fill=None, ol=None, ow=1.0, rad=0):
        a = self.pt(x, y)
        b = self.pt(x + w, y + h)
        self.T.rect(min(a[0], b[0]), min(a[1], b[1]), abs(b[0] - a[0]), abs(b[1] - a[1]), fill, ol, self._ow(ow), rad * self.k)

    def line(self, a, b, col, w=1.0):
        self.T.line(self.pt(*a), self.pt(*b), col, w * self.k)

    def pline(self, pts, col, w=1.0, closed=False):
        self.T.pline(self.pts(pts), col, w * self.k, closed)

    def tube(self, pts, w0, w1, fill, ol=None, ow=1.0, smooth=True, caps=True):
        return self.T.tube(self.pts(pts), w0 * self.k, w1 * self.k, fill, ol, self._ow(ow), smooth, caps)

    def arc(self, cx, cy, rx, ry, a0, a1, col, w=1.0, n=20):
        self.pline(arco(cx, cy, rx, ry, a0, a1, n), col, w)

    def clip_poly(self, pts, fn):
        self.T.clip_poly(self.pts(pts), lambda tmp: fn(Vista(tmp, self.ox, self.oy, self.k, self.f < 0)))

    def luz(self, x, y, r, col, a=200):
        X, Y = self.pt(x, y)
        self.T.luz(X, Y, r * self.k, col, a)

    def luz_add(self, x, y, r, col, a=200):
        X, Y = self.pt(x, y)
        self.T.luz_add(X, Y, r * self.k, col, a)

    def icone(self, iid, x, y, tam, cor=None, t=0.0):
        X, Y = self.pt(x, y)
        self.T.icone(iid, X, Y, tam * self.k, cor, t)

    def sub(self, ox, oy, k=1.0):
        X, Y = self.pt(ox, oy)
        return Vista(self.T, X, Y, self.k * k, self.f < 0)
