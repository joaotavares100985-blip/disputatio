﻿# -*- coding: utf-8 -*-
"""Telas do modo online: menu, criar sala (codigo grande), entrar (teclado na tela) e o Terminal do convidado."""
import math
import time

import pygame

import audio
import online as O
from desenho import *
from ui import Cena, clamp, tela_escura
from mundo import BTN_A, R_A, BTN_FICHA, JOY_R, _joy_base, _joy_knob

AGUARDE = "Acordando o servidor... (pode levar até 1 minuto)"
ALFA = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"


def _fundo(S):
    tela_escura(S, (34, 24, 12), (6, 3, 2))


class MenuOnline(Cena):
    def __init__(self, game):
        super().__init__(game)
        self.url = O.url_servidor()
        O.acordar(self.url)          # cutuca o servidor (dorme quando ninguem usa)

    def key(self, k):
        if k == pygame.K_ESCAPE:
            self.game.pop(self)

    def draw(self, S):
        self.hits = []
        g = self.game
        _fundo(S)
        outlined(S, "JOGAR ONLINE", 56, GOLD, (480, 70), th=3, hi=GOLD_L)
        draw_text(S, "Dois jogadores, cada um no seu aparelho.", 26, PARCH, (480, 124), shadow=None)
        draw_text(S, "Um cria a sala e passa o código de 4 letras; o outro entra com ele.", 22, (214, 190, 140), (480, 156), shadow=None)
        if O.WEB:
            self.btn(S, (280, 200, 400, 76), "Criar sala", None, "dim", 38, icone="pessoa")
            draw_text(S, "O anfitrião precisa do app de PC.", 22, (230, 150, 120), (480, 292), shadow=None)
        else:
            self.btn(S, (280, 200, 400, 76), "Criar sala", lambda: g.push(SalaEspera(g)), "gold", 38, icone="pessoa")
        self.btn(S, (280, 320, 400, 76), "Entrar", lambda: g.push(Entrar(g)), "gold", 38, icone="porta")
        self.btn(S, (330, 430, 300, 60), "Voltar", lambda: g.pop(self), "normal", 30)
        draw_text(S, "O servidor grátis pode demorar a acordar na primeira vez.", 20, (176, 150, 104), (480, 516), shadow=None)


class SalaEspera(Cena):
    """Anfitriao: cria a sala e mostra o codigo."""

    def __init__(self, game):
        super().__init__(game)
        game.coop_fechar()
        self.ses = O.Sessao(game, "host", O.url_servidor())
        game.sessao = self.ses

    def key(self, k):
        if k == pygame.K_ESCAPE:
            self.cancelar()

    def cancelar(self):
        self.game.coop_fechar()
        self.game.pop(self)

    def draw(self, S):
        self.hits = []
        s = self.ses
        _fundo(S)
        outlined(S, "CRIAR SALA", 52, GOLD, (480, 60), th=3, hi=GOLD_L)
        if s.erro:
            draw_text(S, s.erro, 30, (255, 140, 120), (480, 250), bold=True)
        elif s.codigo:
            draw_text(S, "Código da sala", 30, PARCH, (480, 140), shadow=None)
            panel(S, pygame.Rect(210, 170, 540, 170), 240)
            draw_text(S, " ".join(s.codigo), 130, GOLD_L, (480, 255), bold=True)
            if s.pareado:
                draw_text(S, "Amigo conectado! Iniciando...", 32, (150, 240, 160), (480, 380), bold=True)
            else:
                pts = "." * (1 + int(self.t * 2) % 3)
                draw_text(S, "Aguardando amigo" + pts, 34, PARCH, (480, 380), bold=True)
                draw_text(S, "Passe o código; ele escolhe \"Entrar\".", 22, (214, 190, 140), (480, 418), shadow=None)
        else:
            draw_text(S, AGUARDE if s.rede.estado == "conectando" else "Criando a sala...", 28, PARCH, (480, 250), bold=True)
        self.btn(S, (330, 450, 300, 62), "Cancelar", self.cancelar, "normal", 32)


class Entrar(Cena):
    """Convidado: teclado na tela (toque/mouse/teclado/controle) com 4 caracteres."""
    texto = True

    def __init__(self, game):
        super().__init__(game)
        game.coop_fechar()
        self.cod = ""
        self.ses = None

    def key(self, k):
        if k == pygame.K_ESCAPE:
            self.voltar_()
        elif self.ses is None:
            if k == pygame.K_BACKSPACE:
                self.apaga()
            else:
                c = pygame.key.name(k).upper()
                if len(c) == 1 and c in ALFA:
                    self.digita(c)

    def digita(self, c):
        if self.ses is None and len(self.cod) < 4:
            self.cod += c

    def apaga(self):
        if self.ses is None:
            self.cod = self.cod[:-1]

    def conectar(self):
        if self.ses is None and len(self.cod) == 4:
            self.ses = O.Sessao(self.game, "convidado", O.url_servidor())
            self.game.sessao = self.ses
            self.ses.entrar(self.cod)

    def voltar_(self):
        self.game.coop_fechar()
        self.game.pop(self)

    def de_novo(self):
        self.game.coop_fechar()
        self.ses = None

    def draw(self, S):
        self.hits = []
        s = self.ses
        _fundo(S)
        outlined(S, "ENTRAR NA SALA", 48, GOLD, (480, 44), th=3, hi=GOLD_L)
        for i in range(4):
            r = pygame.Rect(0, 0, 90, 84)
            r.center = (480 + (i - 1.5) * 106, 118)
            pygame.draw.rect(S, (24, 15, 8), r, 0, 12)
            pygame.draw.rect(S, GOLD if i == len(self.cod) and s is None else (120, 90, 40), r, 3, 12)
            if i < len(self.cod):
                draw_text(S, self.cod[i], 64, GOLD_L, r.center, bold=True)
        if s is not None:
            if s.erro:
                draw_text(S, s.erro, 30, (255, 140, 120), (480, 250), bold=True)
                self.btn(S, (330, 330, 300, 64), "Tentar de novo", self.de_novo, "gold", 32)
            else:
                est = s.rede.estado
                draw_text(S, AGUARDE if est == "conectando" else ("Amigo encontrado! Iniciando..." if s.pareado else "Entrando..."),
                          30, PARCH, (480, 250), bold=True)
            self.btn(S, (330, 430, 300, 62), "Cancelar", self.voltar_, "normal", 32)
            return
        for n, c in enumerate(ALFA):
            row, col = divmod(n, 8)
            x = 116 + col * 92
            y = 184 + row * 66
            self.btn(S, (x, y, 84, 58), c, (lambda c=c: self.digita(c)), "normal", 34)
        self.btn(S, (116, 450, 200, 56), "Apagar", self.apaga, "normal", 28)
        self.btn(S, (330, 450, 300, 56), "Entrar", self.conectar, "gold" if len(self.cod) == 4 else "dim", 32)
        self.btn(S, (644, 450, 200, 56), "Voltar", self.voltar_, "normal", 28)


class Terminal(Cena):
    """Convidado: mostra o quadro recebido do anfitriao e devolve entradas (joystick, botoes, toques)."""

    def __init__(self, game):
        super().__init__(game)
        self.ses = game.sessao
        self.quadro = None
        self.pend_a, self.pend_p = [], []
        self.cli = set()
        self.joy = None
        self.joy_o = (150, 430)
        self.joyvec = (0.0, 0.0)
        self.a_t = 0.0
        self.ult = (0.0, 0.0)
        self.t_env = 0.0
        self.moveu = False

    def enter(self):
        audio.musica(None)

    def ex(self):
        return bool(self.ses.st.get("ex"))

    def acao(self, a):
        self.pend_a.append(a)

    def key(self, k):
        pass

    def set_joy(self, pos):
        dx, dy = (pos[0] - self.joy_o[0]) / 60.0, (pos[1] - self.joy_o[1]) / 60.0
        n = math.hypot(dx, dy)
        if n > 1:
            dx, dy = dx / n, dy / n
        self.joyvec = (dx, dy) if n > 0.16 else (0.0, 0.0)

    def down(self, i, pos):
        if self.ex():
            if math.hypot(pos[0] - BTN_A[0], pos[1] - BTN_A[1]) < R_A + 10:
                self.a_t = 0.18
                self.pend_a.append("ok")
            elif math.hypot(pos[0] - BTN_FICHA[0], pos[1] - BTN_FICHA[1]) < 44:
                self.pend_a.append("ficha")
            elif pos[0] < 560 and pos[1] > 90 and self.joy is None:
                self.joy = i
                self.joy_o = (clamp(pos[0], 80, 480), clamp(pos[1], 190, 480))
                self.set_joy(pos)
                self.moveu = True
            return
        self.cli.add(str(i))
        self.pend_p.append(["d", str(i), round(pos[0] / W, 4), round(pos[1] / H, 4)])

    def move(self, i, pos):
        if i == self.joy:
            self.set_joy(pos)
        elif str(i) in self.cli:
            self.pend_p.append(["m", str(i), round(pos[0] / W, 4), round(pos[1] / H, 4)])

    def up(self, i, pos):
        if i == self.joy:
            self.joy = None
            self.joyvec = (0.0, 0.0)
        elif str(i) in self.cli:
            self.cli.discard(str(i))
            self.pend_p.append(["u", str(i), round(pos[0] / W, 4), round(pos[1] / H, 4)])

    def update(self, dt):
        self.t += dt
        self.a_t = max(0.0, self.a_t - dt)
        s = self.ses
        q = s.decodifica()
        if q is not None:
            self.quadro = pygame.transform.scale(q, (W, H))
        if not self.ex() and self.joy is not None:
            self.joy, self.joyvec = None, (0.0, 0.0)
        kx, ky = self.game.inp.teclas_dir()
        d = (self.joyvec[0] + kx, self.joyvec[1] + ky)
        n = math.hypot(*d)
        if n > 1:
            d = (d[0] / n, d[1] / n)
        now = time.time()
        mudou = abs(d[0] - self.ult[0]) > 0.04 or abs(d[1] - self.ult[1]) > 0.04
        if self.pend_a or self.pend_p or (mudou and now - self.t_env > 0.04) or now - self.t_env > 0.25:
            s.envia_entrada(d, self.pend_a, self.pend_p, self.game.inp.modo)
            self.pend_a, self.pend_p, self.ult, self.t_env = [], [], d, now

    def draw(self, S):
        self.hits = []
        if self.quadro is not None:
            S.blit(self.quadro, (0, 0))
        else:
            _fundo(S)
            draw_text(S, "Conectando ao jogo do amigo...", 32, PARCH, (480, 270), bold=True)
        if self.quadro is not None and self.ex():
            if self.joy is not None:
                ox, oy = self.joy_o
                S.blit(_joy_base(), (ox - JOY_R - 4, oy - JOY_R - 4))
                S.blit(_joy_knob(), (int(ox + self.joyvec[0] * 46) - 30, int(oy + self.joyvec[1] * 46) - 30))
            a = self.ses.st.get("a")
            r = R_A + (4 if self.a_t > 0 else 0)
            draw_round(S, BTN_A, r, a or "mao", "Interagir", "gold" if a else "dim", self.a_t > 0, bool(a), self.t, lsz=22, isz=int(R_A * 1.3))
