# -*- coding: utf-8 -*-
"""Figuras humanas de frente (NPCs, mestres, estudantes, chefes humanos) com trajes de epoca (Paris, c. 1250-1277).

figura_frontal(T, cx, gy, e, ph, esc): desenha em Tela T com os pes em (cx, gy); e = dicionario de estilo (ver ESTILO_BASE).
Coordenadas locais: x para a direita, y para cima = negativo (chao em y=0; ombros em -130; cabeca em -160).
"""
import math

import pygame

from arte_kit import Tela, mix, lit, dk, catmull, arco, ik2, olho, boca, INK, PELE, OURO, OURO_L, OURO_D, BRANCO
from arte_vista import Vista

ESTILO_BASE = dict(
    tunica=(80, 70, 90), capa=None, forro=(201, 185, 160), escap=None, capuz=None, capuz_cor=None, pele=(236, 196, 160), cabelo=(110, 80, 50),
    barba=None, barba_cor=(226, 226, 226), tonsura=False, chapeu=None, chapeu_cor=(28, 26, 30), mao_e=None, mao_d=None, cinto=None, avental=None,
    humor="sereno", trim=OURO, olhos=(70, 46, 30), sobr=None, peitoral=None, colete=None, bigode=False, jovem=False, mulher=False, largura=1.0,
    medalha=None, altura=1.0, bolsa=False)


def _est(e):
    d = dict(ESTILO_BASE)
    d.update(e or {})
    return d


def rot(pts, ang, cx=0.0, cy=0.0):
    c, s = math.cos(ang), math.sin(ang)
    return [(cx + x * c - y * s, cy + x * s + y * c) for x, y in pts]


def cilindro(c, k=1.0):
    return [dk(c, .5 * k), dk(c, .22 * k), lit(c, .14 * k), c, dk(c, .3 * k), dk(c, .55 * k)]


# ---------------------------------------------------------------- partes do corpo
def sombra_chao(V, w=120, h=20, y=2):
    V.ell(0, y, w, h, (0, 0, 0, 80))
    V.ell(0, y, w * .7, h * .6, (0, 0, 0, 60))


def hem_pts(w_hem, y_hem, sway=0.0, wave=2.2, dy=0.0, dx=0.0):
    return [(-w_hem + 2 * w_hem * i / 14 + sway + dx, y_hem + dy + math.sin(i * 1.7 + sway * .3) * wave) for i in range(0, 15)]


def sino_manto(V, y_top, y_hem, w_top, w_hem, cor, sway=0.0, ol=INK, folds=4, flare=1.35, hem_wave=2.2, base_ol=1.3, lean=0.0, folds_on=True):
    n = 12
    L, Rr = [], []
    for i in range(n + 1):
        f = i / n
        y = y_top + (y_hem - y_top) * f
        w = w_top + (w_hem - w_top) * (f ** flare)
        sh = sway * f * f + lean * (1 - f) ** 1.2
        L.append((-w + sh, y))
        Rr.append((w + sh, y))
    hem = [(-w_hem + 2 * w_hem * i / 14 + sway, y_hem + math.sin(i * 1.7 + sway * .3) * hem_wave) for i in range(1, 14)]
    top = [(w_top * math.cos(math.pi * i / 8) + lean, y_top - 7 * math.sin(math.pi * i / 8)) for i in range(1, 8)]
    pts = L + hem + Rr[::-1] + top
    V.gpoly(pts, cilindro(cor), ol, base_ol, horizontal=True)
    fcol = dk(cor, .42)
    for k in range(folds if folds_on else 0):
        fx = -.62 + 1.24 * k / max(1, folds - 1)
        V.pline([(fx * w_top * .85 + lean, y_top + 12), (fx * (w_top + w_hem) * .5 * .96 + sway * .4 + lean * .3, (y_top + y_hem) * .5), (fx * w_hem * .94 + sway, y_hem - 4)], fcol, .9)
        V.pline([(fx * w_top * .85 + 2 + lean, y_top + 14), (fx * w_hem * .94 + 2 + sway, y_hem - 6)], lit(cor, .18), .7)
    return pts


def mao(V, x, y, pele, r=6.0, ang=0.0, dedo=False, punho=False):
    V.circ(x, y, r, mix(pele, (255, 255, 255), .05), dk(pele, .62), 1.0)
    V.circ(x - r * .25, y - r * .3, r * .35, lit(pele, .3))
    if dedo:
        a = ang
        V.tube([(x, y - r * .3), (x + math.cos(a) * r * 1.6, y + math.sin(a) * r * 1.6), (x + math.cos(a) * r * 3.0, y + math.sin(a) * r * 3.0)], r * .62, r * .46, pele, dk(pele, .62), 1.0, False)
    elif not punho:
        V.tube([(x - r * .3, y - r * .6), (x - r * .1, y - r * 1.5)], r * .45, r * .4, pele, dk(pele, .62), .9, False)


def braco(V, sh, hand, cor, pele, l1=36, l2=34, lado=1, w0=20, w1=15, punho=None, ol=INK):
    dist = math.hypot(hand[0] - sh[0], hand[1] - sh[1])
    l1 = l2 = max(dist * .6, 22)
    el = ik2(sh, hand, l1, l2, lado)
    wm = (w0 + w1) / 2
    for col, add in ((ol, 2.6), (cor, 0)):
        V.line(sh, el, col, w0 * .5 + wm * .5 + add)
        V.line(el, hand, col, wm * .5 + w1 * .5 + add)
        V.circ(el[0], el[1], wm / 2 + add / 2, col)
    V.line((sh[0] - 3, sh[1] + 2), (el[0] - 2, el[1]), lit(cor, .22), 2.0)
    V.line((el[0] - 2, el[1]), (hand[0] - 2, hand[1] - 2), lit(cor, .18), 1.6)
    if punho:
        V.circ(hand[0], hand[1], w1 * .56, punho, dk(punho, .5), .8)
    return el


# ---------------------------------------------------------------- cabeca e rosto
def rosto(V, x, y, r, e, mood=None, blink=False, look=(0, 0), abre=0.0, giro=0.0):
    mood = mood or e["humor"]
    pele = e["pele"]
    sk = [lit(pele, .18), pele, dk(pele, .16)]
    # orelhas
    for s in (-1, 1):
        V.ell(x + s * r * .92, y + r * .08, r * .24, r * .34, pele, dk(pele, .6), .9)
    # cabelo atras
    if e["cabelo"] is not None and not e["mulher"] and e["chapeu"] not in ("veu", "touca"):
        V.gell(x, y - r * .08, r * 2.12, r * 2.1, [dk(e["cabelo"], .1), e["cabelo"], dk(e["cabelo"], .35)], dk(e["cabelo"], .6), 1.0)
    V.gell(x, y + r * .04, r * 1.82, r * 2.0, sk, dk(pele, .62), 1.1)
    if e["cabelo"] is not None and not e["mulher"] and e["chapeu"] not in ("veu", "touca"):
        if e["tonsura"]:
            # coroa de cabelo em volta, topo raspado
            V.poly([(x - r * .98, y - r * .1), (x - r * .9, y - r * .55), (x - r * .55, y - r * .86), (x - r * .3, y - r * .7), (x - r * .22, y - r * .45), (x, y - r * .36),
                    (x + r * .22, y - r * .45), (x + r * .3, y - r * .7), (x + r * .55, y - r * .86), (x + r * .9, y - r * .55), (x + r * .98, y - r * .1),
                    (x + r * .8, y - r * .2), (x + r * .5, y - r * .5), (x, y - r * .56), (x - r * .5, y - r * .5), (x - r * .8, y - r * .2)],
                   [dk(e["cabelo"], .1)] * 1 + [], None) if False else None
            V.poly([(x - r * 1.0, y), (x - r * .94, y - r * .5), (x - r * .6, y - r * .82), (x - r * .3, y - r * .6), (x - r * .55, y - r * .36), (x - r * .78, y - r * .2)],
                   e["cabelo"], dk(e["cabelo"], .6), .9)
            V.poly([(x + r * 1.0, y), (x + r * .94, y - r * .5), (x + r * .6, y - r * .82), (x + r * .3, y - r * .6), (x + r * .55, y - r * .36), (x + r * .78, y - r * .2)],
                   e["cabelo"], dk(e["cabelo"], .6), .9)
            V.arc(x, y - r * .46, r * 1.1, r * .5, math.pi * 1.08, math.pi * 1.92, dk(pele, .3), .8)
        else:
            V.poly([(x - r * .96, y + r * .1), (x - r * .98, y - r * .45), (x - r * .55, y - r * .92), (x, y - r * 1.0), (x + r * .55, y - r * .92), (x + r * .98, y - r * .45),
                    (x + r * .96, y + r * .1), (x + r * .74, y - r * .34), (x + r * .2, y - r * .62), (x - r * .3, y - r * .56), (x - r * .72, y - r * .3)],
                   [lit(e["cabelo"], .1), e["cabelo"], dk(e["cabelo"], .3)], dk(e["cabelo"], .6), 1.0) if False else None
            V.gpoly([(x - r * .96, y + r * .1), (x - r * .98, y - r * .45), (x - r * .55, y - r * .92), (x, y - r * 1.0), (x + r * .55, y - r * .92), (x + r * .98, y - r * .45),
                     (x + r * .96, y + r * .1), (x + r * .74, y - r * .34), (x + r * .2, y - r * .62), (x - r * .3, y - r * .56), (x - r * .72, y - r * .3)],
                    [lit(e["cabelo"], .1), dk(e["cabelo"], .3)], dk(e["cabelo"], .6), 1.0)
    # bochechas
    for s in (-1, 1):
        V.ell(x + s * r * .52, y + r * .38, r * .34, r * .2, (226, 120, 110, 90))
    # nariz
    V.poly([(x - r * .06, y - r * .04), (x + r * .06, y - r * .04), (x + r * .14, y + r * .3), (x, y + r * .38), (x - r * .14, y + r * .3)], mix(pele, (190, 110, 90), .18), None)
    V.pline([(x + r * .14, y + r * .3), (x, y + r * .38), (x - r * .14, y + r * .3)], dk(pele, .5), .9)
    # olhos
    er = r * .15
    sobr = e["sobr"]
    for s in (-1, 1):
        olho(V, x + s * r * .38, y + r * .0, er, mood if mood != "sereno" else "neutro", look, e["olhos"], s, blink, sobr=sobr if sobr else None)
    # boca
    my = y + r * .62
    if e["barba"] == "longa":
        pass
    else:
        boca(V, x, my, r * .5, "feliz" if mood in ("feliz", "sorriso") else ("bravo" if mood == "bravo" else "neutro"), abre)
    if e["bigode"]:
        V.poly([(x - r * .5, my - r * .08), (x - r * .1, my - r * .2), (x, my - r * .12), (x + r * .1, my - r * .2), (x + r * .5, my - r * .08), (x + r * .3, my + r * .12), (x, my - r * .02),
                (x - r * .3, my + r * .12)], e["barba_cor"] if e["barba"] else e["cabelo"], dk(e["barba_cor"], .5), .8)
    if e["barba"] == "longa":
        bc = e["barba_cor"]
        V.gpoly([(x - r * .92, y + r * .2), (x - r * .8, y + r * .9), (x - r * .45, y + r * 1.5), (x, y + r * 1.85), (x + r * .45, y + r * 1.5), (x + r * .8, y + r * .9), (x + r * .92, y + r * .2),
                 (x + r * .6, y + r * .5), (x + r * .3, y + r * .45), (x, y + r * .52), (x - r * .3, y + r * .45), (x - r * .6, y + r * .5)],
                [lit(bc, .1), bc, dk(bc, .28)], dk(bc, .55), 1.0)
        V.poly([(x - r * .3, y + r * .55), (x, y + r * .46), (x + r * .3, y + r * .55), (x, y + r * .68)], dk(bc, .08), None)
        V.arc(x, my + r * .05, r * .34, r * .2, math.pi * 1.1, math.pi * 1.9, dk(bc, .6), .9) if mood != "bravo" else None
        for k in range(5):
            xx = -.5 + k * .25
            V.pline([(x + xx * r, y + r * .9), (x + xx * r * 1.1, y + r * 1.5 + abs(xx) * -.2 * r)], dk(bc, .2), .7)
    elif e["barba"] == "curta":
        bc = e["barba_cor"]
        V.gpoly([(x - r * .86, y + r * .2), (x - r * .8, y + r * .7), (x - r * .4, y + r * 1.05), (x, y + r * 1.15), (x + r * .4, y + r * 1.05), (x + r * .8, y + r * .7), (x + r * .86, y + r * .2),
                 (x + r * .5, y + r * .5), (x, y + r * .5), (x - r * .5, y + r * .5)], [lit(bc, .1), dk(bc, .25)], dk(bc, .55), 1.0)
        boca(V, x, my + r * .02, r * .4, "neutro")


def sobrancelhas_grossas(V, x, y, r, cor):
    for s in (-1, 1):
        V.poly([(x + s * r * .14, y - r * .3), (x + s * r * .66, y - r * .36), (x + s * r * .66, y - r * .26), (x + s * r * .14, y - r * .18)], cor, None)


# ---------------------------------------------------------------- chapeus e toucas
def pileus(V, x, y, w, cor, botao=True, brilho=True):
    pts = [(x - w * .5, y), (x - w * .47, y - w * .26), (x - w * .22, y - w * .43), (x, y - w * .47), (x + w * .22, y - w * .43), (x + w * .47, y - w * .26), (x + w * .5, y)]
    V.ell(x, y + 1, w * 1.06, w * .24, dk(cor, .25), INK, 1.0)
    V.gpoly(catmull(pts, 5) + [(x + w * .5, y), (x - w * .5, y)], [lit(cor, .3), cor, dk(cor, .45)], INK, 1.1)
    V.ell(x, y - w * .02, w * .96, w * .2, dk(cor, .45), None)
    if botao:
        V.circ(x, y - w * .5, w * .06, lit(cor, .2), INK, .9)
    if brilho:
        V.poly([(x - w * .3, y - w * .2), (x - w * .12, y - w * .38), (x + w * .02, y - w * .4), (x - w * .15, y - w * .2)], lit(cor, .5) + (0,) if False else lit(cor, .35), None)


def mitra_baixa(V, x, y, w, cor=(246, 242, 230)):
    """Mitra de duas pontas do seculo XIII: BAIXA (altura ~ largura), galao dourado em T."""
    h = w * .95
    pts = [(x - w * .5, y), (x - w * .5, y - h * .32), (x - w * .36, y - h * .62), (x - w * .1, y - h * .9), (x, y - h), (x + w * .1, y - h * .9), (x + w * .36, y - h * .62),
           (x + w * .5, y - h * .32), (x + w * .5, y)]
    V.gpoly(catmull(pts, 4), [lit(cor, .2), cor, dk(cor, .22)], INK, 1.2, True)
    V.poly([(x - w * .07, y), (x + w * .07, y), (x + w * .05, y - h * .94), (x - w * .05, y - h * .94)], [OURO_L] * 1 if False else OURO, OURO_D, .8)
    V.rect(x - w * .5, y - h * .2, w, h * .13, OURO, OURO_D, .8)
    for s in (-1, 1):
        V.circ(x + s * w * .5, y - h * .135, w * .03, OURO_L, None)
    V.circ(x, y - h * .5, w * .05, (200, 40, 56), OURO_D, .7)
    V.poly([(x - w * .1, y - h * .84), (x + w * .1, y - h * .84), (x, y - h * .96)], (200, 40, 56), None) if False else None


def chaperon(V, x, y, r, cor, liripipe=True, ph=0.0):
    """Capuz com rolo (chaperon) de leigo."""
    V.gell(x, y - r * .22, r * 2.28, r * 1.95, [lit(cor, .2), cor, dk(cor, .4)], dk(cor, .65), 1.1)
    V.gell(x, y - r * .62, r * 1.9, r * .6, [lit(cor, .32), dk(cor, .12)], dk(cor, .65), 1.0)
    if liripipe:
        V.tube([(x + r * .9, y - r * .5), (x + r * 1.4, y + r * .3 + math.sin(ph * 6.28) * 2), (x + r * 1.5, y + r * 1.7)], r * .34, r * .16, cor, dk(cor, .65), 1.0)


def touca_veu(V, x, y, r, e):
    preto = e["capuz_cor"] or (22, 20, 28)
    # veu preto cai ate os ombros
    V.gpoly([(x - r * 1.2, y + r * 2.5), (x - r * 1.18, y - r * .5), (x - r * .8, y - r * 1.2), (x, y - r * 1.38), (x + r * .8, y - r * 1.2), (x + r * 1.18, y - r * .5),
             (x + r * 1.2, y + r * 2.5), (x + r * .9, y + r * 2.0), (x + r * .86, y + r * .2), (x - r * .86, y + r * .2), (x - r * .9, y + r * 2.0)],
            [lit(preto, .1), preto, dk(preto, .3)], INK, 1.1, True)


def touca_frente(V, x, y, r, e):
    preto = e["capuz_cor"] or (22, 20, 28)
    br = BRANCO
    # faixa branca na testa e gola branca
    V.poly([(x - r * .92, y - r * .28), (x - r * .6, y - r * .62), (x, y - r * .72), (x + r * .6, y - r * .62), (x + r * .92, y - r * .28), (x + r * .86, y - r * .06), (x + r * .5, y - r * .34),
            (x, y - r * .4), (x - r * .5, y - r * .34), (x - r * .86, y - r * .06)], [br] * 1 if False else br, dk(br, .4), 1.0)
    V.poly([(x - r * .98, y - r * .0), (x - r * .96, y + r * .9), (x - r * .6, y + r * 1.35), (x, y + r * 1.5), (x + r * .6, y + r * 1.35), (x + r * .96, y + r * .9), (x + r * .98, y - r * .0),
            (x + r * .86, y + r * .5), (x + r * .5, y + r * .95), (x, y + r * 1.05), (x - r * .5, y + r * .95), (x - r * .86, y + r * .5)], br, dk(br, .4), 1.0)
    V.poly([(x - r * 1.2, y - r * .2), (x - r * .94, y - r * .5), (x - r * .88, y + r * .1), (x - r * 1.1, y + r * .3)], preto, None) if False else None


# ---------------------------------------------------------------- objetos
def livro_obj(V, x, y, ang=0.0, w=26, h=32, cor=(120, 40, 44), aberto=False, fecho=True, t=0.0):
    if aberto:
        pg = [(-w * .62, -h * .5), (0, -h * .42), (w * .62, -h * .5), (w * .62, h * .5), (0, h * .58), (-w * .62, h * .5)]
        V.poly(rot([(-w * .66, -h * .54), (w * .66, -h * .54), (w * .66, h * .56), (-w * .66, h * .56)], ang, x, y), dk(cor, .3), INK, 1.0)
        V.gpoly(rot([(-w * .6, -h * .5), (-.02 * w, -h * .43), (-.02 * w, h * .55), (-w * .6, h * .5)], ang, x, y), [lit((250, 242, 214), .1), (230, 214, 170)], INK, .8)
        V.gpoly(rot([(w * .6, -h * .5), (.02 * w, -h * .43), (.02 * w, h * .55), (w * .6, h * .5)], ang, x, y), [lit((250, 242, 214), .1), (222, 204, 160)], INK, .8)
        for k in range(5):
            yy = -h * .3 + k * h * .17
            V.pline(rot([(-w * .5, yy), (-w * .1, yy + 1)], ang, x, y), (110, 90, 70), .7)
            V.pline(rot([(w * .1, yy + 1), (w * .5, yy)], ang, x, y), (110, 90, 70), .7)
        V.poly(rot([(-w * .5, -h * .36), (-w * .34, -h * .36), (-w * .34, -h * .24), (-w * .5, -h * .24)], ang, x, y), (190, 34, 40), None)
        return
    p = rot([(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)], ang, x, y)
    V.gpoly(p, [lit(cor, .25), cor, dk(cor, .4)], INK, 1.1, True)
    sp = rot([(-w / 2, -h / 2), (-w * .3, -h / 2), (-w * .3, h / 2), (-w / 2, h / 2)], ang, x, y)
    V.poly(sp, dk(cor, .45), INK, .8)
    pg = rot([(w / 2, -h * .44), (w / 2 + 3, -h * .44), (w / 2 + 3, h * .44), (w / 2, h * .44)], ang, x, y)
    V.poly(pg, (240, 230, 196), dk((240, 230, 196), .4), .7)
    V.pline(rot([(-w * .14, -h * .34), (w * .36, -h * .34)], ang, x, y), OURO_L, 1.4)
    V.pline(rot([(w * .1, -h * .45), (w * .1, -h * .05)], ang, x, y), OURO_L, 1.6)
    V.pline(rot([(-w * .1, -h * .27), (w * .32, -h * .27)], ang, x, y), OURO_L, 1.6)
    if fecho:
        V.poly(rot([(w / 2 - 1, -h * .1), (w / 2 + 4, -h * .06), (w / 2 + 4, h * .06), (w / 2 - 1, h * .1)], ang, x, y), OURO, OURO_D, .7)


def pena_obj(V, x, y, ang=-1.0, comp=34, cor=(246, 246, 250)):
    dx, dy = math.cos(ang), math.sin(ang)
    px, py = x + dx * comp, y + dy * comp
    V.poly([(x, y), (x + dx * comp * .3 - dy * 4, y + dy * comp * .3 + dx * 4), (px - dy * 5, py + dx * 5), (px + dx * 5, py + dy * 5), (px + dy * 5, py - dx * 5),
            (x + dx * comp * .3 + dy * 3, y + dy * comp * .3 - dx * 3)], [lit(cor, .1)] * 1 if False else cor, dk(cor, .5), .9)
    V.pline([(x, y), (px, py)], dk(cor, .35), .9)
    V.poly([(x - dx * 4, y - dy * 4), (x + dx * 4 + dy * 1.5, y + dy * 4 - dx * 1.5), (x + dy * 2, y - dx * 2)], (40, 30, 24), None)


def vara_obj(V, x, y, topo, cor=(190, 194, 206), pomo=True):
    V.line((x, y + 8), (x, topo), dk(cor, .45), 5.2)
    V.line((x - .8, y + 8), (x - .8, topo), cor, 3.2)
    V.line((x - 1.4, y), (x - 1.4, topo + 6), lit(cor, .6), 1.0)
    if pomo:
        V.circ(x, topo - 4, 6.5, [cor] * 1 if False else lit(cor, .1), INK, 1.0)
        V.circ(x - 2, topo - 6, 2.2, (255, 255, 255))
        V.ell(x, topo + 4, 10, 4, dk(cor, .2), INK, .8)


def pergaminho_obj(V, x, y, ang=0.3, w=34, h=14):
    V.poly(rot([(-w / 2, -h / 2), (w / 2, -h / 2), (w / 2, h / 2), (-w / 2, h / 2)], ang, x, y), [(250, 240, 208)] * 1 if False else (244, 232, 196), INK, 1.0)
    for s in (-1, 1):
        V.ell(x + s * (w / 2) * math.cos(ang), y + s * (w / 2) * math.sin(ang), 8, h + 3, (176, 130, 80), INK, .9, ang + math.pi / 2)
    V.pline(rot([(-w * .3, -2), (w * .28, -2)], ang, x, y), (80, 60, 50), .8)
    V.pline(rot([(-w * .3, 2), (w * .1, 2)], ang, x, y), (80, 60, 50), .8)


def cruz_peitoral(V, x, y, k=1.0):
    V.line((x - 12 * k, y - 24 * k), (x, y - 2 * k), OURO, 1.0)
    V.line((x + 12 * k, y - 24 * k), (x, y - 2 * k), OURO, 1.0)
    V.poly([(x - 2.2 * k, y - 4 * k), (x + 2.2 * k, y - 4 * k), (x + 2.2 * k, y + 2 * k), (x + 6 * k, y + 2 * k), (x + 6 * k, y + 6 * k), (x + 2.2 * k, y + 6 * k), (x + 2.2 * k, y + 14 * k),
            (x - 2.2 * k, y + 14 * k), (x - 2.2 * k, y + 6 * k), (x - 6 * k, y + 6 * k), (x - 6 * k, y + 2 * k), (x - 2.2 * k, y + 2 * k)], [OURO_L] * 1 if False else OURO, OURO_D, .8)


def medalha_selo(V, x, y, cor=(176, 30, 36), k=1.0):
    V.line((x - 14 * k, y - 26 * k), (x, y), OURO, 1.0)
    V.line((x + 14 * k, y - 26 * k), (x, y), OURO, 1.0)
    V.circ(x, y + 5 * k, 9 * k, [cor] * 1 if False else cor, dk(cor, .6), 1.0)
    V.circ(x, y + 5 * k, 6 * k, lit(cor, .1), dk(cor, .5), .6)
    V.circ(x - 2.5 * k, y + 2.5 * k, 2 * k, lit(cor, .5))


def cesto(V, x, y, k=1.0, t=0.0):
    V.gpoly([(x - 18 * k, y - 8 * k), (x + 18 * k, y - 8 * k), (x + 14 * k, y + 12 * k), (x - 14 * k, y + 12 * k)], [(200, 160, 100), (150, 106, 56), (110, 74, 38)], INK, 1.0)
    for i in range(1, 4):
        V.pline([(x - 17 * k + i * 8 * k, y - 8 * k), (x - 13 * k + i * 6.5 * k, y + 12 * k)], (96, 64, 30), .8)
    V.pline([(x - 17 * k, y + 1 * k), (x + 17 * k, y + 1 * k)], (96, 64, 30), .8)
    for i, (dx, col) in enumerate(((-10, (90, 160, 80)), (-3, (120, 180, 90)), (4, (80, 140, 90)), (10, (110, 170, 70)))):
        V.pline([(x + dx * k, y - 7 * k), (x + (dx + (i - 1.5) * 2) * k, y - 20 * k)], col, 2.2)
        V.ell(x + (dx + (i - 1.5) * 2) * k, y - 20 * k, 6 * k, 9 * k, col, dk(col, .5), .7, (i - 1.5) * .4)
    V.pline([(x - 18 * k, y - 8 * k), (x, y - 24 * k), (x + 18 * k, y - 8 * k)], (130, 92, 50), 1.4)


# ---------------------------------------------------------------- figura principal
def figura_frontal(T, cx, gy, e, ph=0.0, esc=1.0, mood=None, blink=False, abre=0.0, flip=False, sombra=True):
    e = _est(e)
    V = Vista(T, cx, gy, esc * e["altura"], flip)
    sw = math.sin(ph * math.tau)
    bob = sw * 1.1
    W = e["largura"]
    if sombra:
        sombra_chao(V, 124 * W, 22)
    # pes
    for s in (-1, 1):
        V.ell(s * 17 * W, -4, 24, 12, [(70, 50, 36)] * 1 if False else (66, 46, 32), INK, 1.0)
        V.ell(s * 17 * W - 2, -6, 12, 4, (120, 88, 60))
    cor_t = e["tunica"]
    capa = e["capa"]
    ytop = -126 + bob * .5
    # ---- tunica (por baixo)
    wt, wh = 38 * W, (52 if capa else 58) * W
    sino_manto(V, ytop, -6, wt, wh, cor_t, sway=sw * .8, folds=3 if capa else 4)
    # ---- capa (cappa) com abertura em V
    if capa:
        sino_manto(V, ytop - 2, -4, 41 * W, 66 * W, capa, sway=-sw * .8, folds=5)
        gap_t, gap_h = 9 * W, 30 * W
        V.gpoly([(-gap_t, ytop + 8), (gap_t, ytop + 8), (gap_h, -5), (-gap_h, -5)], cilindro(cor_t, .8), None, 1.0, True)
        for s in (-1, 1):
            V.pline([(s * gap_t, ytop + 8), (s * gap_h, -6)], e["forro"], 3.0)
            V.pline([(s * gap_t, ytop + 8), (s * gap_h, -6)], dk(e["forro"], .5), .8)
        V.pline([(-gap_h, -5), (gap_h, -5)], e["forro"], 2.5)
    if e["colete"]:
        c = e["colete"]
        V.gpoly([(-28 * W, ytop + 8), (-10 * W, ytop + 8), (-8 * W, -40), (-14 * W, -46), (14 * W, -46), (8 * W, -40), (10 * W, ytop + 8), (28 * W, ytop + 8), (34 * W, -48), (-34 * W, -48)],
                [lit(c, .15), c, dk(c, .35)], dk(c, .6), 1.0, True)
        V.pline([(-34 * W, -48), (34 * W, -48)], dk(c, .55), 1.2)
    if e["escap"]:
        c = e["escap"]
        V.gpoly([(-15 * W, ytop + 4), (15 * W, ytop + 4), (17 * W, -8), (-17 * W, -8)], [lit(c, .1), c, dk(c, .3)], dk(c, .55), 1.1, True)
        V.pline([(0, ytop + 10), (0, -10)], dk(c, .3), .8)
    if e["avental"]:
        c = e["avental"]
        V.gpoly([(-24 * W, -82), (24 * W, -82), (30 * W, -18), (-30 * W, -18)], [lit(c, .1), c, dk(c, .3)], dk(c, .55), 1.1, True)
        V.pline([(-24 * W, -82), (24 * W, -82)], dk(c, .45), 1.4)
    # cinto
    if e["cinto"] == "couro":
        V.rect(-34 * W, -88, 68 * W, 7, (70, 46, 30), INK, 1.0)
        V.rect(-5, -89, 10, 9, OURO, OURO_D, .8)
    elif e["cinto"] == "cordao":
        V.pline([(-34 * W, -86), (0, -81), (34 * W, -86)], (216, 206, 172), 3.4)
        V.pline([(-34 * W, -86), (0, -81), (34 * W, -86)], dk((216, 206, 172), .4), .8)
        V.pline([(10, -81), (14, -56), (12, -40)], (216, 206, 172), 3.0)
        for yy in (-70, -56, -42):
            V.circ(13, yy, 3.4, (232, 222, 188), dk((216, 206, 172), .5), .8)
    elif e["cinto"] == "corda":
        V.pline([(-34 * W, -86), (0, -81), (34 * W, -86)], (190, 170, 120), 3.0)
    # ---- capuz baixo sobre os ombros
    if e["capuz"] in ("baixo", "forrado"):
        c = e["capuz_cor"] or (e["capa"] or cor_t)
        V.gell(0, ytop - 2 + bob * .4, 74 * W, 24, [lit(c, .14), c, dk(c, .4)], dk(c, .65), 1.2)
        V.gell(0, ytop - 4 + bob * .4, 40 * W, 12, dk(c, .6), None)
        if e["capuz"] == "forrado":
            V.arc(0, ytop - 2, 36 * W, 11, math.pi * .04, math.pi * .96, e["forro"], 3.0)
    elif e["capuz"] == "tras":
        c = e["capuz_cor"] or cor_t
        V.gell(0, ytop - 3, 74 * W, 24, [lit(c, .14), c, dk(c, .4)], dk(c, .65), 1.2)
    # ---- pescoco
    V.rect(-9, ytop - 22 + bob, 18, 20, dk(e["pele"], .12), dk(e["pele"], .6), .9, 4)
    # ---- cabeca
    hy = -160 + bob
    r = 25 if not e["jovem"] else 23
    if e["chapeu"] == "veu":
        touca_veu(V, 0, hy, r, e)
    rosto(V, 0, hy, r, e, mood, blink, abre=abre)
    if e["sobr"] is None and e["barba"] == "longa":
        sobrancelhas_grossas(V, 0, hy, r, lit(e["barba_cor"], .1))
    ch = e["chapeu"]
    if ch == "veu":
        touca_frente(V, 0, hy, r, e)
    elif ch == "pileus":
        pileus(V, 0, hy - r * .66, 52, e["chapeu_cor"])
    elif ch == "mitra":
        mitra_baixa(V, 0, hy - r * .55, 52)
    elif ch == "chaperon":
        chaperon(V, 0, hy - r * .35, r * 1.02, e["chapeu_cor"], True, ph)
    elif ch == "touca":
        V.gell(0, hy - r * .6, r * 2.1, r * 1.0, [lit(e["chapeu_cor"], .3), e["chapeu_cor"]], dk(e["chapeu_cor"], .5), 1.0)
    elif ch == "galero":
        V.ell(0, hy - r * .6, 74, 18, (176, 20, 28), INK, 1.0)
        V.gpoly(catmull([(-18, hy - r * .6), (-16, hy - r * 1.3), (0, hy - r * 1.46), (16, hy - r * 1.3), (18, hy - r * .6)], 4), [(220, 60, 66), (176, 20, 28)], INK, 1.0)
    if e["peitoral"]:
        cruz_peitoral(V, 0, ytop + 22)
    if e["medalha"]:
        medalha_selo(V, 0, ytop + 20, e["medalha"])
    # ---- bracos e objetos
    _bracos(V, e, ph, ytop, cor_t, capa)
    return V


def _bracos(V, e, ph, ytop, cor_t, capa):
    pele = e["pele"]
    sw = math.sin(ph * math.tau)
    W = e["largura"]
    mang = capa or cor_t
    mang_in = cor_t
    md, me = e["mao_d"], e["mao_e"]
    # mao esquerda do desenho (x<0) = e ; direita (x>0) = d
    ombro_e, ombro_d = (-37 * W, ytop + 8), (37 * W, ytop + 8)
    pos_e, pos_d = (-34 * W, -78 + sw * .8), (34 * W, -78 + sw * .8)
    if e.get("pos_e"):
        pos_e = e["pos_e"]
    if e.get("pos_d"):
        pos_d = e["pos_d"]
    if me in ("livro", "livro_a"):
        pos_e = (-12, -100 + sw * .6)
    if me == "pilha":
        pos_e = (-30 * W, -84)
    if me == "cesto":
        pos_e = (-38 * W, -66)
    if me == "pergaminho":
        pos_e = (-16, -96)
    if md == "dedo":
        pos_d = (58 * W, -112 - 5 * max(0, sw))
    if md == "pena":
        pos_d = (30 * W, -98 + sw * 3)
    if md == "vara":
        pos_d = (46 * W, -84 + sw * 1.5)
    if md == "livro":
        pos_d = (20, -100)
    # braco esquerdo
    braco(V, ombro_e, pos_e, mang, pele, lado=1, w0=19, w1=15, punho=mang_in if capa else None)
    braco(V, ombro_d, pos_d, mang, pele, lado=1, w0=19, w1=15, punho=mang_in if capa else None)
    # objetos ANTES das maos para parecer seguro
    if me in ("livro", "livro_a"):
        livro_obj(V, pos_e[0] + 4, pos_e[1] - 4, -.1, 30, 36, e.get("livro_cor", (130, 40, 46)), aberto=(me == "livro_a"))
    if me == "pilha":
        for i, c in enumerate(((120, 60, 40), (60, 90, 130), (140, 110, 50), (70, 110, 80))):
            livro_obj(V, pos_e[0] + 2 + (i % 2) * 2, pos_e[1] - 6 - i * 9, 0, 34, 9, c, fecho=False)
    if me == "cesto":
        cesto(V, pos_e[0] - 2, pos_e[1] + 4, 1.0)
    if me == "pergaminho":
        pergaminho_obj(V, pos_e[0] + 6, pos_e[1] - 6, -.4, 36, 15)
    if md == "livro":
        livro_obj(V, pos_d[0] - 4, pos_d[1] - 4, .1, 30, 36, e.get("livro_cor", (130, 40, 46)))
    mao(V, pos_e[0], pos_e[1], pele, 6.4, punho=True)
    if md == "dedo":
        mao(V, pos_d[0], pos_d[1], pele, 6.4, -math.pi / 2 + .25, dedo=True)
    else:
        mao(V, pos_d[0], pos_d[1], pele, 6.4, punho=True)
    if md == "pena":
        pena_obj(V, pos_d[0] + 1, pos_d[1] - 2, -1.0 + sw * .12, 34)
    if md == "vara":
        vara_obj(V, pos_d[0], pos_d[1], -184, e.get("vara_cor", (190, 194, 206)))
        mao(V, pos_d[0], pos_d[1], pele, 6.4, punho=True)
    if md == "baculo":
        pass


# ================================================================== NPCs
NPC_ESTILO = {
    "mestre_guia": dict(tunica=(70, 52, 92), capa=(38, 32, 46), forro=(214, 200, 170), capuz="forrado", capuz_cor=(38, 32, 46), chapeu="pileus", chapeu_cor=(26, 24, 30),
                        barba="longa", barba_cor=(236, 236, 240), cabelo=(220, 220, 224), pele=(232, 190, 154), mao_e="livro_a", mao_d="dedo", humor="feliz",
                        livro_cor=(120, 40, 44), cinto="couro"),
    "livreiro": dict(tunica=(96, 122, 70), colete=(184, 138, 66), chapeu="chaperon", chapeu_cor=(150, 60, 50), pele=(240, 200, 164), cabelo=(96, 62, 34), bigode=True,
                     barba_cor=(96, 62, 34), mao_e="pilha", mao_d="pena", humor="feliz", cinto="couro", medalha=(176, 30, 36), olhos=(60, 90, 50)),
    "monge_enfermeiro": dict(tunica=(34, 30, 36), capa=(26, 22, 28), forro=(60, 52, 60), capuz="baixo", capuz_cor=(26, 22, 28), avental=(226, 216, 190), tonsura=True,
                             cabelo=(120, 80, 46), pele=(240, 196, 160), mao_e="cesto", mao_d=None, humor="feliz", cinto="cordao", largura=1.04),
    "reitor": dict(tunica=(74, 36, 40), capa=(150, 28, 30), forro=(222, 208, 176), capuz="forrado", capuz_cor=(150, 28, 30), chapeu="pileus", chapeu_cor=(150, 24, 28),
                   barba="curta", barba_cor=(180, 180, 186), cabelo=(180, 180, 186), pele=(228, 186, 150), mao_d="vara", mao_e=None, humor="bravo", medalha=(214, 170, 60),
                   vara_cor=(214, 176, 70), cinto="couro", sobr=(90, 90, 96)),
    "bedel": dict(tunica=(70, 62, 78), capa=(36, 34, 42), forro=(150, 150, 160), capuz="baixo", capuz_cor=(36, 34, 42), chapeu="chaperon", chapeu_cor=(40, 38, 48),
                  bigode=True, barba_cor=(70, 50, 34), cabelo=(70, 50, 34), pele=(226, 184, 148), mao_d="vara", mao_e=None, humor="bravo", vara_cor=(206, 210, 224), cinto="couro"),
    "copista": dict(tunica=(24, 22, 30), capa=(20, 18, 26), forro=(70, 64, 76), capuz=None, capuz_cor=(22, 20, 28), chapeu="veu", mulher=True, cabelo=None, pele=(242, 206, 176),
                    mao_e="pergaminho", mao_d="pena", humor="sereno", cinto="cordao", escap=(24, 22, 30), jovem=True, olhos=(80, 70, 50)),
}

_cache_npc = {}


def _quadro(nid, i):
    k = (nid, i)
    s = _cache_npc.get(k)
    if s is None:
        T = Tela(230, 240, 2)
        e = NPC_ESTILO.get(nid, NPC_ESTILO["mestre_guia"])
        ph = i / 8.0
        blink = (i == 5)
        figura_frontal(T, 115, 224, e, ph, 1.0, None, blink)
        s = _cache_npc[k] = T.final()
    return s


def npc_sprite(npc):
    """Corpo inteiro do NPC (230x240) - quadro de repouso."""
    return _quadro(npc if npc in NPC_ESTILO else "mestre_guia", 0)


def npc_frame(npc, t, h=None):
    """Quadro animado (idle) do NPC; se h for dado, devolve ja escalado para essa altura."""
    nid = npc if npc in NPC_ESTILO else "mestre_guia"
    i = int(t * 5) % 8
    s = _quadro(nid, i)
    if h:
        k = (nid, i, h)
        if k not in _cache_npc:
            if len(_cache_npc) > 200:
                _cache_npc.clear()
            _cache_npc[k] = pygame.transform.smoothscale(s, (int(230 * h / 240), h))
        return _cache_npc[k]
    return s


def npc_portrait(npc, size=120):
    k = ("p", npc, size)
    if k not in _cache_npc:
        nid = npc if npc in NPC_ESTILO else "mestre_guia"
        spr = _quadro(nid, 0)
        crop = spr.subsurface(pygame.Rect(115 - 64, 6, 128, 128)).copy()
        out = pygame.Surface((size, size), pygame.SRCALPHA)
        for i in range(size):
            c = mix((70, 54, 84), (30, 22, 40), i / size)
            pygame.draw.line(out, c, (0, i), (size, i))
        out.blit(pygame.transform.smoothscale(crop, (size, size)), (0, 0))
        mask = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), (0, 0, size, size), 0, 14)
        out.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        pygame.draw.rect(out, (214, 170, 60), (0, 0, size, size), 4, 14)
        pygame.draw.rect(out, (60, 40, 10), (0, 0, size, size), 1, 14)
        _cache_npc[k] = out
    return _cache_npc[k]
