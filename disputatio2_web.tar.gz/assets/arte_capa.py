﻿# -*- coding: utf-8 -*-
"""Capa do jogo (960x540), gotico classico LIMPO e simetrico: nave em perspectiva de um ponto, arco triunfal ogival com uma ROSACEA grande,
altar com cruz de luz no centro, dois mestres (dominicano e franciscano, de habito correto) nos flancos e o logo 'DISPUTATIO' em letras de ouro.

API: desenhar_capa(S, t)  -- camada estatica em cache + animacoes leves (chamas, feixes, brilho da rosacea, poeira).
O logo ocupa y=14..112; os botoes do menu ficam no centro (x 320..640, y 366..510), entre os mestres.
"""
import math
import random

import pygame

import arte_base as B
from arte_base import mix, esc, surf, conv, luz_add, PI

W, H = 960, 540
VPX, VPY = 480, 232
XP = 330.0
YF, YS = 250.0, -300.0           # piso e arranque dos arcos (mundo)
ROSE = (480, 220)                # centro da rosacea
ROSE_R = 90
ALTAR_Y = 338                    # tampo do altar
_C = {}


def P(X, Y, z):
    return (VPX + X / z, VPY + Y / z)


def poly(S, pts, col, lw=0):
    pygame.draw.polygon(S, col, [(int(x), int(y)) for x, y in pts], lw)


def _arco_plano(side, z0, z1, ybase, altura, rise_frac=.82, n=14):
    pts = B.ogiva(0.5, 1.0, 1.0, 1.0 * rise_frac, 1.0 - rise_frac, n)
    out = []
    for (u, v) in pts:
        z = z0 + (z1 - z0) * u
        out.append(P(side * XP, ybase - (1.0 - v) * altura, z))
    return out


def _hstrip(S, x, y, w, h, c0, c1, c2):
    for i in range(int(w)):
        t = i / max(1.0, w - 1)
        c = mix(c0, c1, t * 2) if t < .5 else mix(c1, c2, (t - .5) * 2)
        pygame.draw.line(S, c, (x + i, y), (x + i, y + h))


# ----------------------------------------------------------------------------- mestres (figura frontal de epoca)
def _mestre(tipo, lado):
    import arte_figuras as AF
    from arte_kit import Tela
    T = Tela(280, 290, 2)
    if tipo == "dom":
        e = dict(tunica=(238, 234, 222), capa=(26, 24, 30), forro=(238, 234, 222), capuz="baixo", capuz_cor=(26, 24, 30), tonsura=True, cabelo=(70, 50, 36), cinto="couro", mao_e="livro_a",
                 mao_d="dedo", livro_cor=(120, 34, 40), humor="sereno", largura=1.02, jovem=False, pele=(236, 196, 160))
    else:
        e = dict(tunica=(124, 108, 86), capa=None, forro=(150, 134, 108), capuz="baixo", capuz_cor=(112, 96, 76), tonsura=True, cabelo=(120, 90, 58), cinto="cordao", mao_e="livro",
                 mao_d="dedo", livro_cor=(70, 52, 36), humor="sereno", largura=1.02, jovem=False, barba="curta", barba_cor=(120, 90, 58), pele=(232, 190, 152))
    AF.figura_frontal(T, 140, 280, e, 0.0, 1.16, "sereno", flip=(lado > 0), sombra=False)
    s = T.final()
    # contra-luz do altar: escurece de leve e acende um fio de luz no lado voltado ao centro
    veil = surf(s.get_width(), s.get_height())
    for x in range(s.get_width()):
        t = x / float(s.get_width())
        a = int(105 * ((1 - t) if lado > 0 else t) ** 1.2) + 28
        pygame.draw.line(veil, (6, 4, 18, a), (x, 0), (x, s.get_height()))
    dark = s.copy()
    dark.blit(veil, (0, 0), special_flags=pygame.BLEND_RGBA_SUB if False else 0)
    cut = surf(s.get_width(), s.get_height())
    cut.blit(veil, (0, 0))
    cut.blit(s, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    out = s.copy()
    out.blit(cut, (0, 0))
    m = pygame.mask.from_surface(s, 40)
    edge = m.to_surface(setcolor=(255, 214, 150, 235), unsetcolor=(0, 0, 0, 0))
    inner = m.copy()
    shifted = pygame.Surface(s.get_size(), pygame.SRCALPHA)
    off = -3 if lado > 0 else 3
    shifted.blit(m.to_surface(setcolor=(255, 255, 255, 255), unsetcolor=(0, 0, 0, 0)), (off, 0))
    inner.erase(pygame.mask.from_surface(shifted), (0, 0))
    out.blit(inner.to_surface(setcolor=(255, 214, 150, 200), unsetcolor=(0, 0, 0, 0)), (0, 0))
    return conv(out)


# ----------------------------------------------------------------------------- cena estatica
def _fundo_estatico():
    old = B.set_estilo(1)
    try:
        return _fundo_est()
    finally:
        B.ESTILO[0] = old


def _fundo_est():
    S = pygame.Surface((W, H))
    rnd = random.Random(4)
    S.blit(B.vgrad(W, H, (8, 8, 24), (28, 20, 30)), (0, 0))
    pedra = (150, 140, 128)

    # ---- parede do fundo (arco triunfal ogival) com a rosacea
    cx = 480
    arco = B.ogiva(cx, ALTAR_Y, 408, 262, 0)
    pygame.draw.polygon(S, (14, 14, 40), arco)
    # vidro de fundo da rosacea e halo
    halo = B.halo_a(210, (90, 110, 230), 150, 1.4)
    S.blit(halo, (ROSE[0] - 210, ROSE[1] - 210))
    ros = B.rosacea(ROSE_R, 3, 12, "azul")
    S.blit(ros, (ROSE[0] - ros.get_width() // 2, ROSE[1] - ros.get_height() // 2))
    # lancetas sob a rosacea (rayonnant): tres vitrais estreitos
    # molduras do arco triunfal: tres arquivoltas em pedra com colunetas
    for ins, col, lw in ((0, esc(pedra, .5), 8), (6, esc(pedra, 1.1), 3), (12, esc(pedra, .78), 6), (20, esc(pedra, 1.22), 2), (26, esc(pedra, .5), 5)):
        pygame.draw.polygon(S, col, B.ogiva(cx, ALTAR_Y, 408 - 2 * ins, 262 - ins, 0), lw)
    for sg in (-1, 1):
        for k, cc in enumerate((1.25, .95, .7)):
            pygame.draw.rect(S, esc(pedra, cc), (cx + sg * (204 + k * 5) - 3, 120, 6, ALTAR_Y - 120))
    # parede lateral ao arco (escura, com juntas)
    for sg in (-1, 1):
        x0 = cx + sg * 216
        pts = [(x0, 0), (x0 + sg * 300, 0), (x0 + sg * 300, ALTAR_Y + 6), (x0, ALTAR_Y + 6)]
        poly(S, pts, (22, 20, 36))

    # ---- nave: arcadas em perspectiva
    zs = [.95, 1.3, 1.75]
    for side in (-1, 1):
        for i in range(len(zs) - 1):
            z0, z1 = zs[i], zs[i + 1]
            arc = _arco_plano(side, z0, z1, YS, 190)
            lim = [P(side * XP, -470, z0), P(side * XP, -470, z1)]
            # clerestorio acima dos arcos (parede escura com janelinhas acesas)
            poly(S, arc + [lim[1], lim[0]], (24 + i * 3, 22 + i * 3, 40 + i * 4))
            poly(S, arc, esc(pedra, .26 + .04 * i))
            poly(S, arc, esc(pedra, 1.1 - .1 * i), 5)
            poly(S, arc, esc(pedra, .45), 1)
            # vao da arcada: profundidade escura
            inner = [(VPX + (x - VPX) * .93, VPY + (y - VPY) * .93) for (x, y) in arc]
            poly(S, inner, (10, 10, 24))
        for z in zs:
            xb, yb = P(side * XP, YF, z)
            xt, yt = P(side * XP, YS, z)
            w = 50 / z
            for k, cc in enumerate((.6, 1.12, .8)):
                pygame.draw.rect(S, esc(pedra, cc * (1.12 - .1 * z)), (xb - w / 2 + k * w / 3, yt, w / 3 + 1, yb - yt))
            pygame.draw.rect(S, esc(pedra, .5), (xb - w * .7, yb - 14 / z, w * 1.4, 14 / z), 0, 2)
            pygame.draw.rect(S, esc(pedra, .85), (xb - w * .62, yt - 10 / z, w * 1.24, 12 / z), 0, 2)
    # ---- abobada: nervuras simples que convergem ao fecho (discreta, para o logo respirar)
    for sg in (-1, 1):
        for k in range(3):
            a = (cx + sg * 460, -10)
            b = (cx + sg * (120 - k * 30), 128)
            pts = [(a[0] + (b[0] - a[0]) * t, a[1] + (b[1] - a[1]) * t + math.sin(PI * t) * (-30 - k * 12)) for t in [i / 16.0 for i in range(17)]]
            pygame.draw.lines(S, esc(pedra, .32), False, pts, 4 - k // 2)
    # ---- piso: lajes e tapete em perspectiva
    yfl = int(VPY + YF / 2.4)
    fl = pygame.Rect(0, ALTAR_Y + 16, W, H - ALTAR_Y - 16)
    S.blit(B.vgrad(W, fl.h, (46, 38, 54), (14, 10, 22)), fl.topleft)
    for i in range(-14, 15):
        xa, xb = VPX + i * 28, VPX + i * 150
        pygame.draw.line(S, (30, 24, 40), (xa, fl.y), (xb, H), 1)
    for z in (1.05, 1.2, 1.4, 1.7, 2.1, 2.7):
        y = VPY + YF / z
        if fl.y < y < H:
            pygame.draw.line(S, (34, 28, 44), (0, y), (W, y), 1)
    car = [(VPX - 46, fl.y), (VPX + 46, fl.y), (VPX + 190, H), (VPX - 190, H)]
    poly(S, car, (96, 20, 30))
    poly(S, [(VPX - 40, fl.y), (VPX + 40, fl.y), (VPX + 164, H), (VPX - 164, H)], (122, 26, 38))
    for sg in (-1, 1):
        pygame.draw.line(S, B.OURO, (VPX + sg * 46, fl.y), (VPX + sg * 190, H), 3)
        pygame.draw.line(S, B.OURO_S, (VPX + sg * 40, fl.y), (VPX + sg * 164, H), 1)
    # ---- altar: degraus, mesa, frontal dourado e cruz
    for k in range(3):
        w = 280 - k * 0
        pygame.draw.rect(S, esc(pedra, .85 - .1 * k), (cx - 150 - k * 22, ALTAR_Y + 14 + k * 6, 300 + k * 44, 8), 0, 2)
        pygame.draw.rect(S, esc(pedra, 1.2 - .15 * k), (cx - 150 - k * 22, ALTAR_Y + 14 + k * 6, 300 + k * 44, 2))
    pygame.draw.rect(S, (236, 224, 196), (cx - 112, ALTAR_Y - 6, 224, 10), 0, 2)               # toalha
    pygame.draw.rect(S, (250, 244, 224), (cx - 112, ALTAR_Y - 6, 224, 3))
    pygame.draw.rect(S, esc(pedra, .8), (cx - 104, ALTAR_Y + 4, 208, 22))
    pygame.draw.rect(S, B.OURO_S, (cx - 104, ALTAR_Y + 4, 208, 22), 2)
    for k in range(5):
        B.cruz_latina(S, cx - 80 + k * 40, ALTAR_Y + 15, 14, B.OURO, None, 3)
    cr = 108
    for r_, a_ in ((40, 40), (26, 70)):
        pass
    B.cruz_latina(S, cx, ALTAR_Y - 6 - cr // 2, cr, (34, 20, 6), None, 15)
    B.cruz_latina(S, cx, ALTAR_Y - 6 - cr // 2, cr, B.OURO_S, None, 12)
    B.cruz_latina(S, cx, ALTAR_Y - 6 - cr // 2, cr - 4, B.OURO, None, 8)
    pygame.draw.line(S, B.OURO_C, (cx - 3, ALTAR_Y - 6 - cr + 4), (cx - 3, ALTAR_Y - 12), 2)
    for sg in (-1, 1):                                                                   # castiçais
        x = cx + sg * 84
        pygame.draw.rect(S, B.OURO_S, (x - 3, ALTAR_Y - 40, 6, 36))
        pygame.draw.polygon(S, B.OURO, [(x - 10, ALTAR_Y - 4), (x + 10, ALTAR_Y - 4), (x + 5, ALTAR_Y - 16), (x - 5, ALTAR_Y - 16)])
        pygame.draw.rect(S, (244, 236, 208), (x - 4, ALTAR_Y - 64, 8, 26))
    _C["velas"] = [(cx - 84, ALTAR_Y - 66), (cx + 84, ALTAR_Y - 66)]
    # ---- vinheta e escurecimento do piso para legibilidade dos botoes
    S.blit(_vinheta(), (0, 0))
    # ---- mestres nos flancos
    for tipo, lado, x in (("dom", -1, 138), ("fra", 1, 822)):
        m = _mestre(tipo, lado)
        B.sombra_elipse(S, x, H - 8, 170, 24, 170)
        S.blit(m, (x - m.get_width() // 2, H - 8 - (m.get_height() - 10)))
    _C["altar"] = (cx, ALTAR_Y)
    return S


_VC = []


def _vinheta():
    if not _VC:
        s = surf(W, H)
        n = 110
        for i in range(n):
            a = int(205 * (1 - i / n) ** 2.2)
            pygame.draw.rect(s, (0, 0, 8, a), (i, i, W - 2 * i, H - 2 * i), 1)
        for y in range(350, H):
            a = int(120 * ((y - 350) / 190.0) ** 1.3)
            pygame.draw.line(s, (4, 2, 8, a), (0, y), (W, y))
        # veu escuro suave atras do logo
        for r in range(150, 0, -6):
            a = int(120 * (1 - r / 150.0) ** 1.2)
            pygame.draw.ellipse(s, (4, 4, 14, a // 4 + 2), (W // 2 - r * 3, 62 - r * .5, r * 6, r))
        _VC.append(conv(s))
    return _VC[0]


# ----------------------------------------------------------------------------- logo
_GL = {}
_GLW = {"I": .5, "D": 1.0, "S": .78, "P": .85, "U": 1.02, "T": .95, "A": 1.0, "O": 1.08}


def _arc(cx, cy, rx, ry, a0, a1, n=24):
    return [(cx + math.cos(math.radians(a0 + (a1 - a0) * i / n)) * rx, cy + math.sin(math.radians(a0 + (a1 - a0) * i / n)) * ry) for i in range(n + 1)]


def _tracos(ch):
    """Tracos (polilinhas em unidades 0..1 x 0..1) de cada capital."""
    if ch == "I":
        return [[(.25, 0), (.75, 0)], [(.5, 0), (.5, 1)], [(.25, 1), (.75, 1)]]
    if ch == "D":
        return [[(.12, 0), (.12, 1)], [(.0, 0), (.4, 0)] + _arc(.42, .5, .5, .5, -90, 90, 20) + [(.0, 1)], [(.0, 1), (.4, 1)]]
    if ch == "S":
        up = _arc(.5, .27, .34, .26, -30, -270, 22)
        lo = _arc(.5, .73, .34, .26, -90, 150, 22)
        return [up + lo[1:]]
    if ch == "P":
        return [[(.12, 0), (.12, 1)], [(.0, 0), (.4, 0)] + _arc(.4, .28, .36, .28, -90, 90, 18) + [(.12, .56)], [(0, 1), (.3, 1)]]
    if ch == "U":
        return [[(.0, 0), (.3, 0)], [(.7, 0), (1, 0)], [(.15, 0), (.15, .68)] + _arc(.5, .68, .35, .32, 180, 0, 18) + [(.85, 0)]]
    if ch == "T":
        return [[(.0, 0), (1, 0)], [(.0, 0), (.0, .18)], [(1, 0), (1, .18)], [(.5, 0), (.5, 1)], [(.25, 1), (.75, 1)]]
    if ch == "A":
        return [[(.5, 0), (.05, 1)], [(.5, 0), (.95, 1)], [(.22, .66), (.78, .66)], [(.0, 1), (.2, 1)], [(.8, 1), (1, 1)]]
    if ch == "O":
        return [_arc(.5, .5, .46, .5, 0, 360, 36)]
    return []


def _glifo(ch, h, nib=15, ang=30):
    k = (ch, h, nib, ang)
    if k in _GL:
        return _GL[k]
    w = int(_GLW[ch] * h) + nib * 2
    m = surf(w, int(h) + nib * 2)
    ca, sa = math.cos(math.radians(ang)), math.sin(math.radians(ang))
    ox, oy = nib, nib
    for tr in _tracos(ch):
        pts = [(ox + x * _GLW[ch] * h, oy + y * h) for x, y in tr]
        for (a, b) in zip(pts[:-1], pts[1:]):
            L = max(1, int(math.hypot(b[0] - a[0], b[1] - a[1])))
            for i in range(L + 1):
                u = i / float(L)
                px, py = a[0] + (b[0] - a[0]) * u, a[1] + (b[1] - a[1]) * u
                pygame.draw.line(m, (255, 255, 255, 255), (px - ca * nib / 2, py + sa * nib / 2), (px + ca * nib / 2, py - sa * nib / 2), 2)
    _GL[k] = m
    return m


def _logo():
    """Logo limpo: so as letras (ouro com contorno e brilho), cruz-fleuron acima e subtitulo com filetes. Sem fita."""
    if "logo" in _C:
        return _C["logo"]
    h = 64
    letras = "DISPUTATIO"
    gap = 4
    nib = 15
    widths = [int(_GLW[c] * h) + gap for c in letras]
    wtxt = sum(widths)
    Wl, Hl = wtxt + 40, 130
    S = surf(Wl, Hl)
    mask = surf(Wl, Hl)
    x = 20
    ytop = 24
    for c, wd in zip(letras, widths):
        mask.blit(_glifo(c, h, nib), (x - nib, ytop - nib))
        x += wd
    m = pygame.mask.from_surface(mask)
    ol = m.to_surface(setcolor=(18, 8, 4, 255), unsetcolor=(0, 0, 0, 0))
    sh = m.to_surface(setcolor=(0, 0, 0, 170), unsetcolor=(0, 0, 0, 0))
    S.blit(sh, (4, 6))
    for dx in range(-3, 4):
        for dy in range(-3, 4):
            if dx * dx + dy * dy <= 9:
                S.blit(ol, (dx, dy))
    gold = surf(Wl, Hl)
    gr = surf(Wl, Hl)
    for y in range(Hl):
        t = (y - ytop) / float(h)
        c = mix((255, 248, 204), (238, 192, 72), max(0, min(1, t * 2))) if t < .5 else mix((238, 192, 72), (150, 100, 24), max(0, min(1, (t - .5) * 2)))
        pygame.draw.line(gr, c, (0, y), (Wl, y))
    gold.blit(gr, (0, 0))
    gold.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    S.blit(gold, (0, 0))
    # filete de luz no topo das letras
    hi = m.to_surface(setcolor=(255, 255, 230, 120), unsetcolor=(0, 0, 0, 0))
    S.blit(hi, (-1, -2), special_flags=pygame.BLEND_RGBA_MIN) if False else None
    # subtitulo com filetes
    from desenho import font
    f = font(26, True)
    txt = "UNIVERSIDADE DE PARIS  ·  SÉCULO XIII"
    t1 = f.render(txt, True, (250, 232, 170))
    t0 = f.render(txt, True, (24, 8, 8))
    yy = ytop + h + 16
    tx = Wl // 2 - t1.get_width() // 2
    S.blit(t0, (tx + 2, yy + 2))
    S.blit(t1, (tx, yy))
    for sg in (-1, 1):
        xa = Wl // 2 + sg * (t1.get_width() // 2 + 14)
        xb = Wl // 2 + sg * (t1.get_width() // 2 + 150)
        pygame.draw.line(S, B.OURO, (xa, yy + t1.get_height() // 2), (xb, yy + t1.get_height() // 2), 2)
        pygame.draw.circle(S, B.OURO_C, (xb, yy + t1.get_height() // 2), 3)
    # cruz-fleuron no alto
    B.cruz_latina(S, Wl // 2, 10, 18, B.OURO, (90, 60, 10), 4)
    _C["logo"] = conv(S)
    return _C["logo"]


# ----------------------------------------------------------------------------- feixes e rosacea animada
def _feixes():
    if "feixes" in _C:
        return _C["feixes"]
    out = []
    cols = [(90, 130, 255), (255, 90, 90), (190, 130, 255), (255, 210, 120)]
    for k, (a, b, c_, d) in enumerate((
            ((430, 270), (470, 280), (300, 505), (150, 505)),
            ((490, 280), (530, 270), (810, 505), (660, 505)),
            ((455, 290), (480, 290), (420, 505), (350, 505)),
            ((480, 290), (505, 290), (610, 505), (540, 505)))):
        s, o = B.feixe([a, b, c_, d], cols[k % 4], 70 if k < 2 else 46)
        out.append((s, o, k * 1.7))
    _C["feixes"] = out
    return out


def _estatico():
    if "bg" not in _C:
        _C["bg"] = conv(_fundo_estatico())
    return _C["bg"]


_ROS_RAYS = []


def _rays():
    if not _ROS_RAYS:
        R = ROSE_R
        s = pygame.Surface((2 * R, 2 * R))
        for i in range(12):
            a = i * PI / 6
            pts = [(R, R), (R + math.cos(a - .09) * R, R + math.sin(a - .09) * R), (R + math.cos(a + .09) * R, R + math.sin(a + .09) * R)]
            pygame.draw.polygon(s, (40, 34, 20), pts)
        m = pygame.Surface((2 * R, 2 * R))
        pygame.draw.circle(m, (255, 255, 255), (R, R), R - 6)
        s.blit(m, (0, 0), special_flags=pygame.BLEND_RGB_MIN)
        _ROS_RAYS.append(conv(s))
    return _ROS_RAYS[0]


def desenhar_capa(S, t):
    """Desenha a capa inteira (menos os botoes). ~1 blit grande + poucas animacoes."""
    S.blit(_estatico(), (0, 0))
    ax, ay = _C["altar"]
    luz_add(S, (ax, ay - 60), 170, (46, 34, 16), 1 + .08 * math.sin(t * 2.3))
    for (s, o, ph) in _feixes():
        s.set_alpha(int(170 + 80 * math.sin(t * .55 + ph)))
        S.blit(s, o)
    rx, ry = ROSE
    r = pygame.transform.rotozoom(_rays(), (t * 5) % 360, 1.0)
    S.blit(r, (rx - r.get_width() // 2, ry - r.get_height() // 2), special_flags=pygame.BLEND_RGB_ADD)
    luz_add(S, (rx, ry), 120, (50, 44, 96), 1 + .1 * math.sin(t * 1.7))
    for i, (x, y) in enumerate(_C["velas"]):
        f = 1 + math.sin(t * 14 + i * 2.1) * .12 + math.sin(t * 23 + i) * .07
        luz_add(S, (x, y - 6), 46, (255, 170, 70), f)
        h = 12 * f
        pygame.draw.ellipse(S, (255, 150, 40), (x - 4 + math.sin(t * 5 + i) * 1.2, y - h, 8, h + 3))
        pygame.draw.ellipse(S, (255, 226, 130), (x - 2, y - h * .6, 4, h * .65))
    for i in range(40):
        rr = random.Random(i * 17 + 3)
        x0, y0 = rr.uniform(160, 800), rr.uniform(120, 500)
        sp = rr.uniform(5, 14)
        x = x0 + math.sin(t * .5 + i) * 22
        y = 520 - ((520 - y0 + t * sp) % 420)
        a = int(90 + 100 * (0.5 + 0.5 * math.sin(t * 1.4 + i * 1.9)))
        pygame.draw.circle(S, (min(255, a + 40), min(255, a + 20), a), (int(x), int(y)), 1 if i % 3 else 2)
    lg = _logo()
    S.blit(lg, (W // 2 - lg.get_width() // 2, 8))
    gx = (W // 2 - 340) + int(((t * 130) % 780))
    if 150 < gx < 810:
        luz_add(S, (gx, 52), 28, (110, 90, 40), 1.0)
