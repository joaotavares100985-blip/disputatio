# -*- coding: utf-8 -*-
"""Transporte do modo online no NAVEGADOR (pygbag): o modulo websockets nao existe la, entao o WebSocket nativo do
navegador e criado por JS (platform.window.eval). O JS acumula mensagens de texto (uma por linha) e o ultimo quadro
binario (base64) em buffers que o Python le e zera a cada frame. Mesma interface da classe Rede (PC)."""
import base64
import json

JS = r"""
window.rw = {t: "", b: "", bn: 0, st: "conectando", er: "", ws: null};
window.rw_open = function (url) {
  var r = window.rw;
  try {
    var w = new WebSocket(url);
    w.binaryType = 'arraybuffer';
    w.onopen = function () { r.st = 'ok'; };
    w.onerror = function () { if (r.st === 'conectando') { r.st = 'erro'; r.er = 'Sem conexão com o servidor'; } };
    w.onclose = function () {
      if (r.st === 'ok') { r.st = 'fechado'; r.t += '{"t":"caiu"}\n'; }
      else if (r.st === 'conectando') { r.st = 'erro'; r.er = 'Sem conexão com o servidor'; }
    };
    w.onmessage = function (e) {
      if (typeof e.data === 'string') { r.t += e.data + '\n'; }
      else {
        var u = new Uint8Array(e.data), s = '';
        for (var i = 0; i < u.length; i += 32768) { s += String.fromCharCode.apply(null, u.subarray(i, i + 32768)); }
        r.b = btoa(s); r.bn += 1;
      }
    };
    r.ws = w;
  } catch (x) { r.st = 'erro'; r.er = 'Sem conexão com o servidor'; }
};
window.rw_send = function (s) { var w = window.rw.ws; if (w && w.readyState === 1) { w.send(s); } };
window.rw_close = function () { try { if (window.rw.ws) { window.rw.ws.close(); } } catch (_) {} };
"""


class RedeWeb:
    def __init__(self, url):
        import platform
        self.plat = platform
        self.url = url
        self.estado = "conectando"
        self.erro = ""
        self.rx = []
        self.cid = 0
        self.vistos = set()
        self._quadro = None
        self._bn = 0
        self.fila_tx = []                 # mensagens ate o socket abrir
        platform.window.eval(JS)
        platform.window.eval("rw_open(%s);" % json.dumps(url))

    def _js(self, cod):
        try:
            self.plat.window.eval(cod)
        except Exception:
            pass

    def envia(self, d):
        self.cid += 1
        s = json.dumps(dict(d, _i=self.cid))
        if self.estado == "ok":
            self._js("rw_send(%s);" % json.dumps(s))
        else:
            self.fila_tx.append(s)

    def envia_quadro(self, b):      # o anfitriao e sempre o app de PC: nao usado no navegador
        pass

    def _le(self):
        """chamado a cada frame: puxa os buffers do JS"""
        w = self.plat.window
        try:
            st = str(w.rw.st)
            if st != self.estado and self.estado in ("conectando", "ok"):
                self.estado = st
                if st == "erro":
                    self.erro = str(w.rw.er)
                elif st == "ok":
                    for s in self.fila_tx:
                        self._js("rw_send(%s);" % json.dumps(s))
                    self.fila_tx = []
            buf = str(w.rw.t)
            if buf:
                w.rw.t = ""
                for ln in buf.split("\n"):
                    if not ln:
                        continue
                    d = json.loads(ln)
                    i = d.get("_i")
                    if i is not None:
                        if i in self.vistos:
                            continue
                        self.vistos.add(i)
                    self.rx.append(d)
            bn = int(w.rw.bn)
            if bn != self._bn:
                self._bn = bn
                self._quadro = base64.b64decode(str(w.rw.b))
                self._novo_q = True
        except Exception:
            pass

    _novo_q = False

    def mensagens(self):
        self._le()
        out, self.rx = self.rx, []
        return out

    def quadro(self):
        if self._novo_q:
            self._novo_q = False
            return self._quadro
        return None

    def fecha(self):
        self._js("rw_close();")
