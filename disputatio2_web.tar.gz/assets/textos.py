# -*- coding: utf-8 -*-
"""Textos curtos: truncamento inteligente e leitura dos campos opcionais de conteudo.py (sempre com fallback)."""
import re

LIM_CURTO = 85
LIM_OPCAO = 26
LIM_EXPL = 95


def curto_txt(s, n):
    """Corta em fim de frase ou palavra, com reticencias, ate n caracteres."""
    s = " ".join(str(s or "").split())
    if len(s) <= n:
        return s
    cut = s[:n]
    fim = max(cut.rfind(". "), cut.rfind("? "), cut.rfind("! "), cut.rfind("; "))
    if fim >= n * 0.45:
        return cut[:fim + 1].rstrip(";")
    cut = s[:max(1, n - 3)]
    i = cut.rfind(" ")
    if i >= n * 0.5:
        cut = cut[:i]
    return cut.rstrip(" ,;:.-") + "..."


def _lista3(v, ref):
    if isinstance(v, (list, tuple)) and len(v) >= len(ref) and all(isinstance(x, str) and x for x in v[:len(ref)]):
        return [curto_txt(x, LIM_OPCAO) for x in v[:len(ref)]]
    return None


def obj_curto(o):
    c = o.get("curto")
    return curto_txt(c if isinstance(c, str) and c else (o.get("texto") or o.get("enunciado") or ""), LIM_CURTO)


def obj_opcoes(o):
    ops = list(o.get("opcoes", []))
    return _lista3(o.get("opcoes_curtas"), ops) or [curto_txt(x, LIM_OPCAO) for x in ops]


def obj_expl(o):
    c = o.get("explicacao_curta")
    return curto_txt(c if isinstance(c, str) and c else o.get("explicacao", ""), LIM_EXPL)


def fala_curta(s, n=70):
    return curto_txt(s, n)


def romano(i):
    return ["I", "II", "III", "IV", "V", "VI"][max(0, min(i, 5))]


def so_alnum(s):
    return re.sub(r"\W+", "", s or "")
