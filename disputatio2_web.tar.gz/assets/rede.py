# -*- coding: utf-8 -*-
"""Cliente de rede (PC) do modo online. Dois caminhos ao mesmo tempo:
  1) servidor de salas (WebSocket): sempre funciona, mas e lento (plano B e meio de trocar enderecos);
  2) conexao DIRETA entre os dois PCs (UDP, furando o NAT com ajuda de um servidor STUN publico): bem mais rapida.
Mensagens importantes (json com _i) vao pelos dois caminhos e o receptor ignora a repetida; quadros de imagem so
valem o mais novo: vao direto (fragmentados em UDP) quando der e pelo servidor quando nao der."""
import itertools
import json
import os
import queue
import socket
import struct
import threading
import time
import zlib
from collections import deque

from websockets.sync.client import connect

STUN_SERVIDORES = (("stun.l.google.com", 19302), ("stun1.l.google.com", 19302), ("stun.cloudflare.com", 3478))
LOCAL = bool(os.environ.get("DISPUTATIO_UDP_LOCAL"))      # so pros testes automaticos: tudo em 127.0.0.1, sem STUN
K_PUNCH, K_PUNCH_OK, K_SNAP, K_ENTRADA, K_CONF, K_PING, K_PONG = 1, 2, 0x20, 0x21, 0x22, 0x30, 0x31
PEDACO = 1100


def _ip_local():
    if LOCAL:
        return "127.0.0.1"
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("8.8.8.8", 80))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _le_stun(d, tx):
    if len(d) < 20 or d[8:20] != tx:
        return None
    if struct.unpack("!H", d[:2])[0] != 0x0101:
        return None
    i = 20
    while i + 4 <= len(d):
        t, ln = struct.unpack("!HH", d[i:i + 4])
        v = d[i + 4:i + 4 + ln]
        if t == 0x0020 and ln >= 8 and v[1] == 1:
            porta = struct.unpack("!H", v[2:4])[0] ^ 0x2112
            ip = bytes(a ^ b for a, b in zip(v[4:8], b"\x21\x12\xa4\x42"))
            return socket.inet_ntoa(ip), porta
        if t == 0x0001 and ln >= 8 and v[1] == 1:
            return socket.inet_ntoa(v[4:8]), struct.unpack("!H", v[2:4])[0]
        i += 4 + ((ln + 3) & ~3)
    return None


def _stun(sock):
    """descobre o endereco publico (ip, porta) deste socket UDP perguntando a um servidor STUN"""
    if LOCAL:
        return None
    for host, porta in STUN_SERVIDORES:
        try:
            end = socket.gethostbyname(host)
        except Exception:
            continue
        tx = os.urandom(12)
        req = struct.pack("!HHI", 0x0001, 0, 0x2112A442) + tx
        for _ in range(2):
            try:
                sock.sendto(req, (end, porta))
            except OSError:
                break
            fim = time.time() + 0.9
            while time.time() < fim:
                sock.settimeout(max(0.05, fim - time.time()))
                try:
                    dados, _o = sock.recvfrom(2048)
                except socket.timeout:
                    break
                except OSError:
                    return None
                r = _le_stun(dados, tx)
                if r:
                    return r
    return None


class Rede:
    def __init__(self, url):
        self.url = url
        self.estado = "conectando"        # conectando, ok, erro, fechado
        self.erro = ""
        self.ws = None
        self.codigo = None
        self.rx = queue.Queue()
        self.tx = queue.Queue()
        self.slot_q = None                # so o quadro mais novo importa
        self._quadro = None
        self.quadro_n = 0
        self._visto = 0
        self.vivo = True
        self._cnt = itertools.count(1)    # numerador das mensagens importantes (atomico entre threads)
        self.vistos = set()
        self.vistos_ordem = deque()
        # conexao direta
        self.udp = None
        self.meu_ext = None
        self.lp = 0
        self.token = b"\0\0\0\0"
        self.peer = None                  # enderecos do outro lado (vem pelo servidor)
        self.dest = None                  # endereco direto que esta funcionando
        self.udp_last = 0.0
        self.p2p_estado = "nao"           # nao, tentando, direto, falhou
        self.rtt = None                   # ms, do ping UDP
        self.useq = 0
        self.ult_seq = -1
        self.pedacos = {}
        self.anuncio = threading.Event()  # "o outro entrou na sala": hora de anunciar meu endereco UDP
        threading.Thread(target=self._corre, daemon=True).start()

    # ---------- envio ----------
    def p2p_ok(self):
        return self.dest is not None and (time.time() - self.udp_last) < 1.5

    def _udp_envia(self, tipo, corpo=b""):
        try:
            self.udp.sendto(bytes([tipo]) + self.token + corpo, self.dest)
        except Exception:
            pass

    def envia(self, d, so_servidor=False):
        """mensagem importante: vai pelo servidor (sempre chega) e tambem direto (chega logo); o receptor ignora a repetida"""
        s = json.dumps(dict(d, _i=next(self._cnt)))
        self.tx.put(s)
        if not so_servidor and self.p2p_ok():
            self._udp_envia(K_CONF, s.encode())

    def envia_estado(self, d):
        """estado que so vale o mais novo (direcional do convidado): direto = 1 pacote UDP; senao, pelo servidor"""
        if self.p2p_ok():
            self._udp_envia(K_ENTRADA, json.dumps(d).encode())
        else:
            self.envia(d)

    def envia_quadro(self, b):
        if self.p2p_ok():
            self.useq += 1
            n = (len(b) + PEDACO - 1) // PEDACO
            for i in range(min(n, 255)):
                self._udp_envia(K_SNAP, struct.pack("!IBB", self.useq, i, n) + b[i * PEDACO:(i + 1) * PEDACO])
        else:
            self.slot_q = b

    def mensagens(self):
        out = []
        try:
            while True:
                out.append(self.rx.get_nowait())
        except queue.Empty:
            return out

    def quadro(self):
        """bytes do quadro mais novo (uma vez), ou None"""
        if self.quadro_n != self._visto:
            self._visto = self.quadro_n
            return self._quadro
        return None

    def fecha(self):
        self.vivo = False
        self.anuncio.set()
        try:
            if self.ws is not None:
                self.ws.close()
        except Exception:
            pass
        try:
            if self.udp is not None:
                self.udp.close()
        except Exception:
            pass

    def _novo(self, d):
        i = d.get("_i")
        if i is None:
            return True
        if i in self.vistos:
            return False
        self.vistos.add(i)
        self.vistos_ordem.append(i)
        if len(self.vistos_ordem) > 800:
            self.vistos.discard(self.vistos_ordem.popleft())
        return True

    # ---------- servidor (WebSocket) ----------
    def _corre(self):
        try:
            self.ws = connect(self.url, open_timeout=80, max_size=2 ** 21, compression=None)
        except Exception as e:
            self.estado, self.erro = "erro", "Sem conexão com o servidor"
            return
        if not self.vivo:
            return
        try:                                                    # sem Nagle: mensagens pequenas saem na hora
            self.ws.socket.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except Exception:
            pass
        self.estado = "ok"
        threading.Thread(target=self._envia_loop, daemon=True).start()
        try:
            for m in self.ws:
                if isinstance(m, bytes):
                    if not self.p2p_ok():
                        self._quadro = m
                        self.quadro_n += 1
                else:
                    d = json.loads(m)
                    if not self._novo(d):
                        continue
                    if d.get("t") == "udp":
                        self.peer = d
                    else:
                        self.rx.put(d)
        except Exception:
            pass
        self.estado = "fechado"
        self.rx.put({"t": "caiu"})

    def _envia_loop(self):
        try:
            while self.vivo and self.estado == "ok":
                enviou = False
                try:
                    while True:
                        self.ws.send(self.tx.get_nowait())
                        enviou = True
                except queue.Empty:
                    pass
                q, self.slot_q = self.slot_q, None
                if q:
                    self.ws.send(q)
                    enviou = True
                if not enviou:
                    time.sleep(0.002)
        except Exception:
            self.estado = "fechado"

    # ---------- conexao direta (UDP) ----------
    def inicia_p2p(self):
        """chamado ao criar/entrar na sala: abre o socket e descobre o endereco publico (STUN) em segundo plano"""
        if self.udp is not None or self.p2p_estado != "nao":
            return
        if os.environ.get("DISPUTATIO_UDP_OFF"):
            self.p2p_estado = "falhou"
            return
        self.p2p_estado = "tentando"
        threading.Thread(target=self._p2p, daemon=True).start()

    def pareou(self):
        self.anuncio.set()

    def _alvos(self):
        p = self.peer
        if not p:
            return []
        alvos = []
        mesmo_nat = p.get("ip") and p.get("ip") == (self.meu_ext[0] if self.meu_ext else None)
        if p.get("ip") and not mesmo_nat and not LOCAL:
            alvos.append((p["ip"], int(p["p"])))
        if p.get("lip") and (mesmo_nat or not p.get("ip") or LOCAL):
            alvos.append((p["lip"], int(p["lp"])))
        if p.get("ip") and mesmo_nat and not LOCAL:
            alvos.append((p["ip"], int(p["p"])))
        return alvos

    def _p2p(self):
        try:
            self.token = struct.pack("!I", zlib.crc32((self.codigo or "").encode()) & 0xffffffff)
            self.udp = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            for opt in (socket.SO_RCVBUF, socket.SO_SNDBUF):
                try:
                    self.udp.setsockopt(socket.SOL_SOCKET, opt, 1 << 21)
                except Exception:
                    pass
            try:
                self.udp.ioctl(socket.SIO_UDP_CONNRESET, False)    # Windows: ignora "porta fechada" do outro lado
            except Exception:
                pass
            self.udp.bind(("127.0.0.1" if LOCAL else "0.0.0.0", 0))
            self.lp = self.udp.getsockname()[1]
            self.meu_ext = _stun(self.udp)
            msg = {"t": "udp", "lip": _ip_local(), "lp": self.lp}
            if self.meu_ext:
                msg["ip"], msg["p"] = self.meu_ext
            while self.vivo and not (self.anuncio.is_set() and self.estado == "ok"):
                if self.estado in ("erro", "fechado"):
                    self.p2p_estado = "falhou"
                    return
                self.anuncio.wait(0.05)
            self.envia(msg, so_servidor=True)
        except Exception:
            self.p2p_estado = "falhou"
            return
        inicio = ult_anuncio = time.time()
        ult_punch = ult_ping = 0.0
        while self.vivo and self.estado != "fechado":
            agora = time.time()
            if self.peer is None and agora - ult_anuncio > 1.5:
                ult_anuncio = agora                              # o outro pode ter entrado depois: anuncia de novo
                self.envia(msg, so_servidor=True)
            if not self.p2p_ok() and self.peer and agora - ult_punch > 0.08:
                ult_punch = agora
                for dest in self._alvos():                       # fura o NAT: os dois mandam pacotes um pro outro ao mesmo tempo
                    try:
                        self.udp.sendto(bytes([K_PUNCH]) + self.token, dest)
                    except Exception:
                        pass
            if self.p2p_ok():
                self.p2p_estado = "direto"
                if agora - ult_ping > 0.5:
                    ult_ping = agora
                    self._udp_envia(K_PING, struct.pack("!d", agora))
            elif self.p2p_estado == "direto":
                self.p2p_estado = "tentando"                      # perdeu a direta: volta pro servidor e tenta de novo
                inicio = agora
            elif agora - inicio > 15 and self.p2p_estado == "tentando":
                self.p2p_estado = "falhou"
            self._recebe(0.05)

    def _recebe(self, tmo):
        try:
            self.udp.settimeout(tmo)
            dados, orig = self.udp.recvfrom(4096)
        except socket.timeout:
            return
        except OSError:
            time.sleep(0.05)
            return
        if len(dados) < 5 or dados[1:5] != self.token:
            return
        tipo, corpo = dados[0], dados[5:]
        self.dest = orig
        self.udp_last = time.time()
        if tipo == K_PUNCH:
            try:
                self.udp.sendto(bytes([K_PUNCH_OK]) + self.token, orig)
            except Exception:
                pass
        elif tipo == K_SNAP and len(corpo) > 6:
            seq, i, n = struct.unpack("!IBB", corpo[:6])
            if seq <= self.ult_seq:
                return
            if n == 1:
                self.ult_seq, self._quadro = seq, corpo[6:]
                self.quadro_n += 1
                return
            grupo = self.pedacos.setdefault(seq, {})
            grupo[i] = corpo[6:]
            if len(grupo) == n:
                self.ult_seq = seq
                self._quadro = b"".join(grupo[k] for k in range(n))
                self.quadro_n += 1
                for s in [s for s in self.pedacos if s <= seq]:
                    del self.pedacos[s]
            elif len(self.pedacos) > 6:
                for s in sorted(self.pedacos)[:-3]:
                    del self.pedacos[s]
        elif tipo == K_ENTRADA:
            try:
                self.rx.put(json.loads(corpo))
            except Exception:
                pass
        elif tipo == K_CONF:
            try:
                d = json.loads(corpo)
                if self._novo(d):
                    self.rx.put(d)
            except Exception:
                pass
        elif tipo == K_PING:
            self._udp_envia(K_PONG, corpo)
        elif tipo == K_PONG and len(corpo) >= 8:
            ms = (time.time() - struct.unpack("!d", corpo[:8])[0]) * 1000
            self.rtt = ms if self.rtt is None else self.rtt * 0.7 + ms * 0.3
