# -*- coding: utf-8 -*-
"""Cliente de rede (PC) do modo online: servidor de salas por WebSocket (thread + websockets.sync).
Mensagens importantes (json) levam _i e sao deduplicadas; quadros de imagem vao como bytes (so o mais novo importa)."""
import json
import queue
import threading
import time
from collections import deque

from websockets.sync.client import connect


class Rede:
    def __init__(self, url):
        self.url = url
        self.estado = "conectando"        # conectando, ok, erro, fechado
        self.erro = ""
        self.ws = None
        self.rx = queue.Queue()
        self.tx = queue.Queue()
        self.slot_q = None                # so o quadro mais novo importa
        self._quadro = None
        self.quadro_n = 0
        self._visto = 0
        self.vivo = True
        self.cid = 0
        self.vistos = set()
        self.vistos_ordem = deque()
        threading.Thread(target=self._corre, daemon=True).start()

    # ---------- envio ----------
    def envia(self, d):
        self.cid += 1
        self.tx.put(json.dumps(dict(d, _i=self.cid)))

    def envia_quadro(self, b):
        self.slot_q = b

    def mensagens(self):
        out = []
        try:
            while True:
                out.append(self.rx.get_nowait())
        except queue.Empty:
            return out

    def quadro(self):
        """bytes do quadro mais novo (uma vez), ou None"""
        if self.quadro_n != self._visto:
            self._visto = self.quadro_n
            return self._quadro
        return None

    def fecha(self):
        self.vivo = False
        try:
            if self.ws is not None:
                self.ws.close()
        except Exception:
            pass

    def _novo(self, d):
        i = d.get("_i")
        if i is None:
            return True
        if i in self.vistos:
            return False
        self.vistos.add(i)
        self.vistos_ordem.append(i)
        if len(self.vistos_ordem) > 800:
            self.vistos.discard(self.vistos_ordem.popleft())
        return True

    # ---------- threads ----------
    def _corre(self):
        try:
            self.ws = connect(self.url, open_timeout=80, max_size=2 ** 21, compression=None)
        except Exception as e:
            self.estado, self.erro = "erro", "Sem conexão com o servidor"
            return
        if not self.vivo:
            return
        self.estado = "ok"
        threading.Thread(target=self._envia_loop, daemon=True).start()
        try:
            for m in self.ws:
                if isinstance(m, bytes):
                    self._quadro = m
                    self.quadro_n += 1
                else:
                    d = json.loads(m)
                    if self._novo(d):
                        self.rx.put(d)
        except Exception:
            pass
        self.estado = "fechado"
        self.rx.put({"t": "caiu"})

    def _envia_loop(self):
        try:
            while self.vivo and self.estado == "ok":
                enviou = False
                try:
                    while True:
                        self.ws.send(self.tx.get_nowait())
                        enviou = True
                except queue.Empty:
                    pass
                q, self.slot_q = self.slot_q, None
                if q:
                    self.ws.send(q)
                    enviou = True
                if not enviou:
                    time.sleep(0.003)
        except Exception:
            self.estado = "fechado"
