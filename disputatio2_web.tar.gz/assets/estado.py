# -*- coding: utf-8 -*-
"""Estado da partida: jogador, mapa dos andares, regras de nivel e itens."""
import random

import conteudo as C


def g(nome, padrao):
    return getattr(C, nome, padrao)


HAB = g("HABILIDADES", {})
ITENS = g("ITENS", {})
OBJ = g("OBJECOES", {})
INIM = g("INIMIGOS", {})
CHEFES = g("CHEFES", {})
ANDARES = g("ANDARES", [])
PERGUNTAS = g("PERGUNTAS", [])
NPCS = g("NPCS", {})
NIVEIS = g("NIVEIS", ["Estudante", "Bacharel", "Licenciado", "Mestre", "Doutor"])
NIVEL_MAX = max(1, len(NIVEIS))

from icones import NOMES_PADRAO, existe as icone_existe  # noqa: E402
from textos import curto_txt  # noqa: E402

# campos opcionais do pesquisador (sempre com fallback)
SALAS_ESTILO = g("SALAS_ESTILO", {}) or {}
TUTORIAL_CARTOES = g("TUTORIAL_CARTOES", None)
SIMBOLOS = {k: dict(nome=v[0], significado=v[1], curto=v[1]) for k, v in NOMES_PADRAO.items()}
for _k, _v in (g("SIMBOLOS", {}) or {}).items():
    if isinstance(_v, dict):
        _sig = _v.get("significado") or _v.get("curto") or ""
        SIMBOLOS[_k] = dict(nome=_v.get("nome", _k), significado=_sig, curto=_v.get("curto") or curto_txt(_sig, 70))


def icone(d, padrao):
    """Icone de um dicionario de conteudo: campo 'simbolo' se existir no catalogo, senao o padrao."""
    s = (d or {}).get("simbolo")
    return s if s and icone_existe(s) else padrao


def icone_hab(h):
    return icone(h, {"ratio": "ratio", "auctoritas": "auctoritas", "distinguo": "distinguo", "apoio": "apoio"}.get(h.get("categoria"), "ratio"))


def nome_sala(tipo, padrao=""):
    return (SALAS_ESTILO.get(tipo) or {}).get("nome") or padrao


DIRS = {"N": (0, -1), "S": (0, 1), "W": (-1, 0), "E": (1, 0)}
OPOSTO = {"N": "S", "S": "N", "W": "E", "E": "W"}
ATRS = ("razao", "autoridade", "eloquencia", "humildade")
ATR_NOME = {"razao": "Razão", "autoridade": "Autoridade", "eloquencia": "Eloquência", "humildade": "Humildade"}

EFEITO_FMT = [("cura_hp", "Cura {} de Ânimo"), ("cura_tinta", "Recupera {} de Tinta"),
              ("bonus_razao", "+{} Razão"), ("bonus_autoridade", "+{} Autoridade"),
              ("bonus_eloquencia", "+{} Eloquência"), ("bonus_humildade", "+{} Humildade"),
              ("hp_max", "+{} Ânimo máximo"), ("tinta_max", "+{} Tinta máxima"),
              ("bonus_florins_pct", "+{}% de florins"), ("bonus_dano_pct", "+{}% de dano"),
              ("bonus_critico_pct", "+{}% de crítico"), ("reduz_dano_pct", "-{}% de dano sofrido")]


def efeito_texto(ef):
    out = []
    for k, fmt in EFEITO_FMT:
        if k in (ef or {}):
            out.append(fmt.format(ef[k]))
    return ", ".join(out) if out else "Sem efeito direto"


def npc(nid):
    d = NPCS.get(nid)
    if d:
        return d
    return dict(nome={"mestre_guia": "Mestre Guia", "livreiro": "Livreiro", "monge_enfermeiro": "Irmão Enfermeiro",
                      "reitor": "Reitor"}.get(nid, "Mestre"), papel="", desc="", falas=[])


def npc_fala(nid, i=0, padrao="..."):
    f = npc(nid).get("falas") or []
    return f[i % len(f)] if f else padrao


class Jogador:
    def __init__(self):
        j = g("JOGADOR_INICIAL", {})
        self.nome = j.get("nome", "Bacharel")
        self.nivel = 1
        self.xp = 0
        self.base = dict(hp=j.get("hp", 40), tinta=j.get("tinta", 12), razao=j.get("razao", 5),
                         autoridade=j.get("autoridade", 5), eloquencia=j.get("eloquencia", 5),
                         humildade=j.get("humildade", 5))
        self.habilidades = [h for h in j.get("habilidades", []) if h in HAB]
        self.consumiveis = {}
        self.passivos = []
        self.florins = j.get("florins", 10)
        self.hp = self.base["hp"]
        self.tinta = self.base["tinta"]
        for iid in j.get("itens", []):
            self.add_item(iid, inicial=True)
        self.hp = self.hp_max
        self.tinta = self.tinta_max

    # ---- atributos
    def bonus(self, chave):
        return sum((ITENS.get(i, {}).get("efeito", {}) or {}).get(chave, 0) for i in self.passivos)

    @property
    def hp_max(self):
        return self.base["hp"] + self.bonus("hp_max")

    @property
    def tinta_max(self):
        return self.base["tinta"] + self.bonus("tinta_max")

    def atr(self, nome):
        return self.base.get(nome, 5) + self.bonus("bonus_" + nome)

    def xp_prox(self):
        return 30 + 40 * (self.nivel - 1) + 10 * (self.nivel - 1) ** 2

    @property
    def titulo(self):
        return NIVEIS[min(self.nivel, len(NIVEIS)) - 1]

    # ---- itens
    def add_item(self, iid, inicial=False):
        it = ITENS.get(iid)
        if not it:
            return
        if it.get("tipo") == "consumivel":
            self.consumiveis[iid] = self.consumiveis.get(iid, 0) + 1
        else:
            self.passivos.append(iid)
            ef = it.get("efeito", {}) or {}
            if not inicial:
                self.hp = min(self.hp_max, self.hp + ef.get("hp_max", 0))
                self.tinta = min(self.tinta_max, self.tinta + ef.get("tinta_max", 0))

    def usar(self, iid):
        """Usa consumivel. Retorna texto de resultado ou None."""
        if self.consumiveis.get(iid, 0) <= 0:
            return None
        ef = ITENS.get(iid, {}).get("efeito", {}) or {}
        partes = []
        if "cura_hp" in ef:
            n = min(ef["cura_hp"], self.hp_max - self.hp)
            self.hp += n
            partes.append("+%d Ânimo" % n)
        if "cura_tinta" in ef:
            n = min(ef["cura_tinta"], self.tinta_max - self.tinta)
            self.tinta += n
            partes.append("+%d Tinta" % n)
        for a in ATRS:
            if ("bonus_" + a) in ef:
                self.base[a] += ef["bonus_" + a]
                partes.append("+%d %s" % (ef["bonus_" + a], ATR_NOME[a]))
        if "hp_max" in ef:
            self.base["hp"] += ef["hp_max"]
            self.hp += ef["hp_max"]
            partes.append("+%d Ânimo máx." % ef["hp_max"])
        if "tinta_max" in ef:
            self.base["tinta"] += ef["tinta_max"]
            self.tinta += ef["tinta_max"]
            partes.append("+%d Tinta máx." % ef["tinta_max"])
        self.consumiveis[iid] -= 1
        if self.consumiveis[iid] <= 0:
            del self.consumiveis[iid]
        return ", ".join(partes) if partes else "Nada aconteceu."

    # ---- experiencia
    def ganhar_xp(self, n):
        subidas = []
        self.xp += n
        while self.nivel < NIVEL_MAX and self.xp >= self.xp_prox():
            self.xp -= self.xp_prox()
            self.nivel += 1
            ganhos = dict(hp=5, tinta=2, razao=1)
            alvo = ATRS[(self.nivel + 1) % 4] if ATRS[(self.nivel + 1) % 4] != "razao" else "eloquencia"
            ganhos[alvo] = ganhos.get(alvo, 0) + 1
            self.base["hp"] += ganhos["hp"]
            self.base["tinta"] += ganhos["tinta"]
            for a in ATRS:
                self.base[a] += ganhos.get(a, 0)
            self.hp = min(self.hp_max, self.hp + ganhos["hp"] + self.hp_max // 4)
            self.tinta = min(self.tinta_max, self.tinta + ganhos["tinta"] + 3)
            novas = [h for h, d in HAB.items() if d.get("nivel_minimo", 1) <= self.nivel and h not in self.habilidades]
            self.habilidades.extend(novas)
            subidas.append(dict(nivel=self.nivel, titulo=self.titulo, novas=novas, ganhos=ganhos))
        if self.nivel >= NIVEL_MAX:
            self.xp = min(self.xp, self.xp_prox())
        return subidas


class Sala:
    def __init__(self, pos):
        self.pos = pos
        self.tipo = "combate"
        self.portas = {}
        self.vista = False       # aparece no minimapa (adjacente a uma visitada)
        self.visitada = False
        self.limpa = False
        self.inimigos = []       # ids
        self.itens = []          # dict(id, preco, pego)
        self.usada = False
        self.pergunta = None
        self.stairs = False


class Andar:
    def __init__(self, idx, rng, owned=()):
        self.idx = idx
        self.owned = set(owned)
        self.dados = ANDARES[idx] if idx < len(ANDARES) else dict(nome="Andar %d" % (idx + 1), subtitulo="", descricao="",
                                                                   cor_fundo=(80, 60, 46), cor_piso=(100, 80, 60),
                                                                   inimigos=list(INIM)[:4], chefe=list(CHEFES)[0] if CHEFES else None,
                                                                   loja_itens=[], tesouros=[], fala_chegada="")
        self.salas = {}
        self.gerar(rng)

    def gerar(self, rng):
        n = rng.randint(7, 8)  # andares curtos: partida inteira em ~12-15 min
        cells = [(2, 2)]
        tries = 0
        while len(cells) < n and tries < 800:
            tries += 1
            b = rng.choice(cells)
            dx, dy = DIRS[rng.choice(list(DIRS))]
            c = (b[0] + dx, b[1] + dy)
            if not (0 <= c[0] < 5 and 0 <= c[1] < 5) or c in cells:
                continue
            nb = sum(1 for d in DIRS.values() if (c[0] + d[0], c[1] + d[1]) in cells)
            if nb > 1 and rng.random() < 0.88:
                continue
            cells.append(c)
        for c in cells:
            self.salas[c] = Sala(c)
        for c, s in self.salas.items():
            for d, (dx, dy) in DIRS.items():
                o = (c[0] + dx, c[1] + dy)
                if o in self.salas:
                    s.portas[d] = o
        self.inicio = (2, 2)
        dist = {self.inicio: 0}
        fila = [self.inicio]
        while fila:
            c = fila.pop(0)
            for o in self.salas[c].portas.values():
                if o not in dist:
                    dist[o] = dist[c] + 1
                    fila.append(o)
        self.dist = dist
        pontas = [c for c in cells if len(self.salas[c].portas) == 1 and c != self.inicio]
        pontas.sort(key=lambda c: -dist[c] - rng.random())
        outros = [c for c in cells if c != self.inicio and c not in pontas]
        outros.sort(key=lambda c: -dist[c] - rng.random() * 2)
        ordem = pontas + outros
        self.boss = ordem[0]
        self.salas[self.boss].tipo = "chefe"
        esp = ["tesouro", "loja", "cura", "enigma"]
        livres = ordem[1:]
        # tesouro/loja preferem pontas; cura e enigma vao para o que sobrar
        for tipo in esp:
            if livres:
                c = livres.pop(0) if tipo in ("tesouro", "loja") else livres.pop(rng.randrange(len(livres)))
                self.salas[c].tipo = tipo
        self.salas[self.inicio].tipo = "inicio"
        self.salas[self.inicio].limpa = True
        self.salas[self.inicio].visitada = True
        self.salas[self.inicio].vista = True
        # conteudo das salas
        d = self.dados
        pool = [i for i in d.get("inimigos", []) if i in INIM] or list(INIM)
        for c, s in self.salas.items():
            if s.tipo == "combate":
                k = rng.choice([1, 2, 2, 3] if self.idx >= 1 else [1, 1, 2, 2, 3])
                s.inimigos = [rng.choice(pool) for _ in range(k)]
            elif s.tipo == "chefe":
                s.inimigos = [d.get("chefe")]
            elif s.tipo == "tesouro":
                tes = [i for i in d.get("tesouros", []) if i in ITENS and i not in self.owned] or [i for i in d.get("tesouros", []) if i in ITENS]
                rng.shuffle(tes)
                s.itens = [dict(id=i, preco=0, pego=False) for i in tes[:3]]
                s.limpa = True
            elif s.tipo == "loja":
                lj = [i for i in d.get("loja_itens", []) if i in ITENS and not (ITENS[i].get("tipo") != "consumivel" and i in self.owned)][:4]
                cons = [i for i, v in ITENS.items() if v.get("tipo") == "consumivel" and i not in lj]
                rng.shuffle(cons)
                lista = lj + cons[:max(2, 5 - len(lj))]
                s.itens = [dict(id=i, preco=int(ITENS[i].get("preco", 20)), pego=False) for i in lista[:5]]
                s.limpa = True
            elif s.tipo == "enigma":
                s.pergunta = rng.randrange(len(PERGUNTAS)) if PERGUNTAS else None
                s.limpa = True
            else:
                s.limpa = True


class Run:
    def __init__(self, seed=None):
        self.rng = random.Random(seed)
        self.herois = [Jogador()]
        self.foco = 0             # indice do heroi "da vez" (coop); solo = sempre 0
        self.andar_i = 0
        self.stats = dict(inimigos=0, salas=0, acertos=0, erros=0, florins=0, chefes=0, fugas=0)
        self.usadas = set()
        self.andar = None
        self.pos = None
        self.novo_andar(0)

    @property
    def j(self):
        return self.herois[self.foco if self.foco < len(self.herois) else 0]

    def add_heroi2(self):
        """Coop: segundo heroi (alcanca o nivel do primeiro)."""
        h = Jogador()
        h.nome = h.nome + " II"
        h1 = self.herois[0]
        while h.nivel < h1.nivel:
            h.ganhar_xp(h.xp_prox() - h.xp)
        self.herois.append(h)

    def novo_andar(self, i):
        self.andar_i = i
        self.andar = Andar(i, self.rng, [x for h in self.herois for x in h.passivos])
        self.pos = self.andar.inicio

    @property
    def n_andares(self):
        return max(1, len(ANDARES))

    def sala(self):
        return self.andar.salas[self.pos]

    def proxima_objecao(self, ids):
        val = [i for i in ids if i in OBJ]
        if not val:
            return None, None
        livres = [i for i in val if i not in self.usadas]
        if not livres:
            for i in val:
                self.usadas.discard(i)
            livres = val
        oid = self.rng.choice(livres)
        self.usadas.add(oid)
        return oid, OBJ[oid]
