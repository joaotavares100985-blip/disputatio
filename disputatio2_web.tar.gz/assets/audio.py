﻿# -*- coding: utf-8 -*-
"""Som e musica 100% sintetizados por codigo (sem arquivos). Tolerante a falhas: sem mixer, o jogo segue mudo.

API: iniciar(), musica(nome, loop=None), sfx(nome), volume(musica, efeitos), mudo(bool), alternar_mudo(), tick(), estado().
A musica e gerada SOB DEMANDA em pedacos (tick() gasta ~6 ms por quadro) para nao travar o navegador.
"""
import math
import time
from array import array
from itertools import cycle, islice

try:
    import pygame
except Exception:  # pragma: no cover
    pygame = None

RATE = 11025
_ok = False
_falhou = False
_mudo = False
_vm = 0.7
_ve = 0.9
_nch = 1
_atual = None
_pedido = None
_pedido_loop = None
_gen = None
_gen_nome = None
_mus = {}          # nome -> (Sound, loop)
_sfx = {}          # nome -> Sound
_chs = []
_prox_ch = 0
_ult_sfx = {}
_pre = ["combate"]  # musicas geradas em segundo plano
_pre_sfx = ["clique", "acerto", "certa", "errada", "porta", "moeda", "dano", "golpe_ratio", "golpe_auctoritas",
            "golpe_distinguo", "golpe_apoio", "critico", "item", "cura", "levelup", "vitoria", "derrota", "erro"]
BUDGET = 0.006

# ------------------------------------------------------------------ sintese
HARM = {"orgao": (1, .7, .55, .4, .3, .2, .12, .08), "voz": (1, .6, .2, .45, .15, .1), "cravo": (1, .85, .65, .5, .35, .22, .14, .1, .06),
        "baixo": (1, .45, .2, .1), "flauta": (1, .2, .06)}
ENVT = {"orgao": "sus", "baixo": "sus", "flauta": "sus", "voz": "voz", "cravo": "pluck"}
PERC = ("bumbo", "tom", "chimbal", "ruido", "zing", "swish", "sino", "blip")
_T = {}
_E = {}
_P = {}


def _hz(m):
    return 440.0 * 2 ** ((m - 69) / 12.0)


def _tab(tim, f):
    k = (tim, round(f, 2))
    t = _T.get(k)
    if t is not None:
        return t
    best = None
    for per in range(1, 9):
        n = int(round(per * RATE / f))
        if n < 4:
            break
        err = abs(per * RATE / n / f - 1)
        if best is None or err < best[0]:
            best = (err, per, n)
        if err < 0.002:
            break
    if best is None:
        best = (0, 1, 4)
    _, per, n = best
    hs = [(h, a) for h, a in enumerate(HARM[tim], 1) if h * f < RATE * 0.45] or [(1, 1.0)]
    tot = sum(a for _, a in hs)
    w = 2 * math.pi * per / n
    t = [sum(a * math.sin(w * h * i) for h, a in hs) / tot for i in range(n)]
    _T[k] = t
    return t


def _env(tim, N):
    tipo = ENVT[tim]
    k = (tipo, N)
    e = _E.get(k)
    if e is not None:
        return e
    if tipo == "pluck":
        d = math.exp(-5.5 / RATE)
        e = array("d", bytes(8 * N))
        v = 1.0
        rel = max(1, min(N // 4, int(.02 * RATE)))
        for i in range(N):
            e[i] = v * (1.0 if i < N - rel else (N - i) / rel)
            v *= d
    else:
        a = max(1, min(N // 4, int((.1 if tipo == "voz" else .03) * RATE)))
        r = max(1, min(N // 3, int((.25 if tipo == "voz" else .1) * RATE)))
        e = array("d", [1.0]) * N
        for i in range(a):
            e[i] = i / a
        for i in range(r):
            e[N - 1 - i] = min(e[N - 1 - i], i / r)
        if tipo == "voz":
            w = 2 * math.pi * 5.2 / RATE
            for i in range(0, N):
                e[i] *= 0.93 + 0.07 * math.sin(w * i)
    _E[k] = e
    return e


class _Rnd:
    """LCG barato para ruido deterministico."""

    def __init__(self, s=12345):
        self.s = s

    def __call__(self):
        self.s = (self.s * 1103515245 + 12345) & 0x7FFFFFFF
        return self.s / 1073741823.5 - 1.0


def _perc(kind, f):
    k = (kind, int(f) if kind in ("tom", "sino", "zing", "blip", "ruido") else 0)
    s = _P.get(k)
    if s is not None:
        return s
    R = RATE
    tp = 2 * math.pi
    if kind in ("bumbo", "tom"):
        f1, f0 = (45.0, 110.0) if kind == "bumbo" else (f, f * 2.2)
        N = int(R * (.22 if kind == "bumbo" else .3))
        ph = 0.0
        s = []
        for i in range(N):
            t = i / R
            ph += tp * (f1 + (f0 - f1) * math.exp(-t * 25)) / R
            s.append(math.sin(ph) * math.exp(-t * (14 if kind == "bumbo" else 9)))
    elif kind == "chimbal":
        rn = _Rnd(7)
        N = int(R * .05)
        pv = 0.0
        s = []
        for i in range(N):
            x = rn()
            s.append((x - pv) * .5 * math.exp(-i / R * 70))
            pv = x
    elif kind == "ruido":
        rn = _Rnd(3)
        N = int(R * .14)
        a = min(0.9, max(0.05, f / 600.0))
        y = 0.0
        s = []
        for i in range(N):
            y += a * (rn() - y)
            s.append(y * 2.2 * math.exp(-i / R * 18))
    elif kind == "zing":
        N = int(R * .32)
        ph = 0.0
        s = []
        for i in range(N):
            t = i / N
            ph += tp * f * (1 - 0.65 * t) / R
            s.append((math.sin(ph) + .35 * math.sin(2 * ph)) * math.exp(-t * 4) * min(1, i / 60.0))
    elif kind == "swish":
        rn = _Rnd(9)
        N = int(R * .26)
        pv = 0.0
        s = []
        for i in range(N):
            t = i / N
            x = rn()
            s.append((x - pv) * .55 * math.sin(math.pi * t) ** 2)
            pv = x
    elif kind == "blip":
        N = int(R * .07)
        s = [math.sin(tp * f * i / R) * math.exp(-i / R * 55) for i in range(N)]
    else:  # sino: parciais inarmonicos
        dur = 1.2 if f < 600 else 0.55
        N = int(R * dur)
        par = [(1.0, 1.0, 2.2), (2.0, .6, 3.0), (2.76, .45, 3.8), (4.07, .25, 5.0)]
        par = [p for p in par if f * p[0] < R * .45]
        s = []
        for i in range(N):
            t = i / R
            v = 0.0
            for r_, a, d in par:
                v += a * math.sin(tp * f * r_ * t) * math.exp(-t * d * (1.8 if dur < 1 else 1))
            s.append(v * .55 * min(1, i / 30.0))
    _P[k] = s
    return s


def _mix(buf, i0, tv, env, N, L, loop):
    n = len(tv)
    if i0 >= L:
        return
    first = N
    if i0 + N > L:
        first = L - i0
    for i, x, e in zip(range(i0, i0 + first), cycle(tv), env):
        buf[i] += x * e
    if first < N and loop:
        for i, x, e in zip(range(0, N - first), islice(cycle(tv), first, None), islice(env, first, None)):
            buf[i] += x * e


def _mixp(buf, i0, samp, vol, L, loop):
    N = len(samp)
    if i0 >= L:
        return
    first = N
    if i0 + N > L:
        first = L - i0
    for i, x in zip(range(i0, i0 + first), samp):
        buf[i] += x * vol
    if first < N and loop:
        for i, x in zip(range(0, N - first), islice(samp, first, None)):
            buf[i] += x * vol


def _render(eventos, bpm, tbeats, loop, pico, cauda=0.0):
    """Gerador: renderiza eventos (t_beats, dur_beats, midi, timbre, vol) em um buffer int16 (array 'h')."""
    global RATE
    sb = 60.0 / bpm
    L = int((tbeats * sb + cauda) * RATE)
    buf = array("d", bytes(8 * L))
    ult = time.perf_counter()
    for tb, db, m, tim, vol in sorted(eventos, key=lambda e: e[0]):
        i0 = int(tb * sb * RATE)
        f = _hz(m)
        if tim in PERC:
            _mixp(buf, i0, _perc(tim, f), vol, L, loop)
        else:
            N = max(8, int(db * sb * RATE))
            tab = _tab(tim, f)
            tv = [x * vol for x in tab]
            _mix(buf, i0, tv, _env(tim, N), N, L, loop)
        if time.perf_counter() - ult > 0.004:
            yield
            ult = time.perf_counter()
    pk = max(max(buf), -min(buf)) or 1.0
    g = 32767.0 * pico / pk
    out = array("h", bytes(2 * L))
    for a in range(0, L, 12000):
        b = min(L, a + 12000)
        out[a:b] = array("h", [int(x * g) for x in buf[a:b]])
        yield
    _E.clear()
    yield out


# ---------------------------------------------------------------- composicao
DOR = (0, 2, 3, 5, 7, 9, 10)
FRI = (0, 1, 3, 5, 7, 8, 10)
EOL = (0, 2, 3, 5, 7, 8, 10)
HAR = (0, 2, 3, 5, 7, 8, 11)
MAJ = (0, 2, 4, 5, 7, 9, 11)


def _nt(root, esc, g):
    return root + 12 * (g // 7) + esc[g % 7]


def _tema(bpm, nb, root, esc, seed, prog=(), cl=4, pad=None, pad_vol=.2, mel=None, rit=(1, 2), mel_vol=.3, mel_oct=1, lo=-1, hi=6,
          pausa=.15, vies=0, drone=None, drone_vol=.25, arp=None, arp_vol=.18, baixo=None, baixo_vol=.3, perc=None, sinos=(), sino_vol=.25,
          g0=0):
    ev = []
    rnd = _Rnd(seed * 7919 + 11)
    if drone:
        ev.append((0, nb, root - 12, drone, drone_vol))
        ev.append((0, nb, root - 5, drone, drone_vol * .7))
    for ci, g in enumerate(prog):
        t = ci * cl
        if t >= nb:
            break
        tr = [_nt(root, esc, g + k) for k in (0, 2, 4)]
        if pad:
            for m in tr:
                ev.append((t, cl, m, pad, pad_vol))
        if arp:
            pat = (0, 1, 2, 1, 2, 1, 0, 1)
            for k in range(int(cl * 2)):
                ev.append((t + k * .5, .6, tr[pat[k % 8]] + 12, arp, arp_vol))
        if baixo:
            r0 = _nt(root, esc, g) - 12
            for k in range(int(cl * 2)):
                ev.append((t + k * .5, .45, r0 + (7 if k % 4 == 3 else (12 if k % 2 else 0)), "baixo", baixo_vol))
    if mel:
        g = g0
        t = 0.0
        steps = (-2, -1, -1, -1, 0, 1, 1, 1, 2)
        while t < nb - 0.01:
            d = min(rit[int((rnd() + 1) * 0.5 * len(rit)) % len(rit)], nb - t)
            if (nb - t - d) < 0.01:
                ev.append((t, d * .97, _nt(root + 12 * mel_oct, esc, 0), mel, mel_vol))
                break
            if (rnd() + 1) * 0.5 < pausa:
                t += d
                continue
            s = steps[int((rnd() + 1) * 0.5 * len(steps)) % len(steps)] - vies * (1 if (rnd() + 1) * 0.5 < .4 else 0)
            g = max(lo, min(hi, g + s))
            ev.append((t, d * .97, _nt(root + 12 * mel_oct, esc, g), mel, mel_vol))
            t += d
    if perc:
        for k in range(int(nb)):
            if perc in ("luta", "chefe"):
                if k % 2 == 0 or perc == "chefe":
                    ev.append((k, .3, 40, "bumbo", .7))
                ev.append((k + .5, .1, 80, "chimbal", .25))
                if perc == "chefe" and k % 4 == 3:
                    ev.append((k + .5, .3, 43, "tom", .5))
    for b, g in sinos:
        ev.append((b, 1, _nt(root + 24, esc, g), "sino", sino_vol))
    return ev, bpm, nb


TEMAS = {
    "titulo": (True, dict(bpm=60, nb=16, root=50, esc=EOL, seed=3, prog=(0, 5, 3, 4), pad="orgao", pad_vol=.2, mel="voz", rit=(2, 1, 1, 4),
                          mel_vol=.3, drone="baixo", sinos=((0, 0), (8, 4), (12, 2)))),
    "andar0": (True, dict(bpm=56, nb=12, root=50, esc=DOR, seed=11, mel="voz", rit=(2, 2, 1, 3), mel_vol=.33, mel_oct=1, pausa=.1, drone="voz",
                          drone_vol=.22, sinos=((0, 0),))),
    "andar1": (True, dict(bpm=60, nb=16, root=52, esc=FRI, seed=21, prog=(0, 3, 1, 0), pad="orgao", pad_vol=.2, mel="orgao", rit=(2, 1, 4, 2),
                          mel_vol=.22, drone="baixo", sinos=((0, 0), (8, 0)))),
    "andar2": (True, dict(bpm=64, nb=16, root=48, esc=HAR, seed=31, prog=(0, 5, 3, 4), pad="voz", pad_vol=.24, mel="voz", rit=(1, 2, 2, 4),
                          mel_vol=.26, drone="orgao", drone_vol=.14, sinos=((0, 0), (4, 2), (8, 4)))),
    "andar3": (True, dict(bpm=96, nb=16, root=50, esc=HAR, seed=41, prog=(0, 3, 4, 0), pad=None, arp="cravo", arp_vol=.2, baixo=True,
                          baixo_vol=.22, mel="cravo", rit=(1, .5, .5, 2), mel_vol=.22, mel_oct=1, pausa=.3)),
    "combate": (True, dict(bpm=120, nb=16, root=45, esc=EOL, seed=51, prog=(0, 5, 3, 4), pad="orgao", pad_vol=.13, baixo=True, baixo_vol=.3,
                           perc="luta", mel="flauta", rit=(1, .5, .5, 2), mel_vol=.22, pausa=.3)),
    "chefe": (True, dict(bpm=140, nb=20, root=38, esc=FRI, seed=61, prog=(0, 1, 0, 5, 1), pad="orgao", pad_vol=.16, baixo=True, baixo_vol=.32,
                         perc="chefe", mel="voz", rit=(1, 1, .5, .5, 2), mel_vol=.3, mel_oct=2, pausa=.25, sinos=((0, 0), (8, 1)))),
    "vitoria": (False, dict(bpm=100, nb=16, root=48, esc=MAJ, seed=71, prog=(0, 3, 4, 0), pad="orgao", pad_vol=.2, mel="orgao", rit=(1, .5, .5, 2),
                            mel_vol=.25, mel_oct=1, vies=-1, pausa=.1, sinos=((0, 0), (4, 2), (8, 4), (12, 0)))),
    "derrota": (False, dict(bpm=50, nb=12, root=45, esc=EOL, seed=81, prog=(0, 3, 0), pad="voz", pad_vol=.22, mel="voz", rit=(2, 2, 4),
                            mel_vol=.25, vies=1, pausa=.1, drone="baixo", drone_vol=.2, sinos=((0, 0), (8, 0)))),
}


def _gerar_musica(nome):
    loop, kw = TEMAS[nome]
    ev, bpm, nb = _tema(**kw)
    out = None
    for r in _render(ev, bpm, nb, loop, 0.5):
        if r is None:
            yield
        else:
            out = r
    yield ("fim", out, loop)


# ------------------------------------------------------------------ efeitos
def _s(*notas):
    return list(notas)


def _sfx_ev(nome):
    n = nome
    if n == "clique":
        return [(0, .1, 88, "blip", .5)]
    if n == "passo":
        return [(0, .1, 50, "ruido", .3)]
    if n == "porta":
        return [(0, .3, 40, "ruido", .5), (0, .4, 38, "tom", .5), (.16, .3, 55, "ruido", .35)]
    if n == "moeda":
        return [(0, .5, 88, "sino", .35), (.07, .5, 95, "sino", .35)]
    if n == "item":
        return [(0, .5, 79, "sino", .3), (.09, .5, 83, "sino", .3), (.18, .5, 88, "sino", .35)]
    if n == "acerto":
        return [(0, .3, 45, "bumbo", .9), (0, .2, 60, "ruido", .5)]
    if n == "critico":
        return [(0, .3, 45, "bumbo", .9), (0, .2, 70, "ruido", .5), (.03, .5, 91, "sino", .4), (.08, .5, 96, "sino", .35)]
    if n == "erro":
        return [(0, .25, 38, "baixo", .6), (0, .25, 39, "orgao", .35), (0, .3, 40, "tom", .4)]
    if n == "certa":
        return [(0, .5, 79, "sino", .35), (.1, .6, 86, "sino", .4)]
    if n == "errada":
        return [(0, .2, 52, "orgao", .5), (.18, .35, 47, "orgao", .5), (.18, .4, 40, "tom", .4)]
    if n == "cura":
        return [(i * .07, .6, m, "sino", .25) for i, m in enumerate((72, 76, 79, 84, 88))]
    if n == "levelup":
        return [(0, .15, 60, "orgao", .4), (.12, .15, 64, "orgao", .4), (.24, .15, 67, "orgao", .4), (.36, .6, 72, "orgao", .45),
                (.36, .8, 84, "sino", .4)]
    if n == "golpe_ratio":
        return [(0, .35, 84, "zing", .55), (.02, .3, 60, "swish", .2)]
    if n == "golpe_auctoritas":
        return [(0, 1.2, 52, "sino", .6), (0, .3, 40, "bumbo", .8)]
    if n == "golpe_distinguo":
        return [(0, .25, 70, "swish", .7), (.14, .2, 90, "blip", .4), (.14, .2, 52, "tom", .3)]
    if n == "golpe_apoio":
        return [(i * .08, .5, m, "cravo", .3) for i, m in enumerate((72, 76, 79, 84, 88))]
    if n == "dano":
        return [(0, .3, 40, "bumbo", .8), (0, .15, 55, "ruido", .5)]
    if n == "derrota":
        return [(0, .5, 57, "orgao", .4), (.45, .5, 53, "orgao", .4), (.9, 1.2, 50, "orgao", .45), (.9, .3, 38, "bumbo", .6)]
    if n == "vitoria":
        return [(0, .25, 60, "orgao", .35), (.2, .25, 64, "orgao", .35), (.4, .25, 67, "orgao", .35), (.6, .9, 72, "orgao", .45),
                (.6, .8, 84, "sino", .4), (.6, .8, 79, "sino", .3)]
    return None


def _som(arr):
    if not _ok:
        return None
    if _nch == 2:
        a2 = array("h", bytes(4 * len(arr)))
        a2[0::2] = arr
        a2[1::2] = arr
        arr = a2
    return pygame.mixer.Sound(buffer=arr.tobytes())


def _montar_sfx(nome):
    ev = _sfx_ev(nome)
    if not ev:
        return None
    fim = max(t + d for t, d, *_ in ev)
    out = None
    for r in _render(ev, 60, fim, False, 0.8, 0.9 if fim < 1.5 else 0.2):
        if r is not None:
            out = r
    _E.clear()
    return _som(out)


def gerar_tudo_sem_mixer():
    """Uso em testes: gera amostras de todos os temas/efeitos e devolve {nome: segundos}."""
    tempos = {}
    for nome in TEMAS:
        t = time.process_time()
        for r in _gerar_musica(nome):
            pass
        tempos["musica:" + nome] = time.process_time() - t
        _E.clear()
    t = time.process_time()
    for nome in _pre_sfx + ["passo"]:
        ev = _sfx_ev(nome)
        fim = max(a + d for a, d, *_ in ev)
        for r in _render(ev, 60, fim, False, 0.8, 0.5):
            pass
    tempos["efeitos(todos)"] = time.process_time() - t
    return tempos


# ------------------------------------------------------------------- API
def iniciar():
    """Inicia o mixer (chamar no primeiro toque/tecla). Seguro para chamar varias vezes."""
    global _ok, _falhou, RATE, _nch, _chs
    if _ok or _falhou or pygame is None:
        return
    try:
        try:
            pygame.mixer.quit()
        except Exception:
            pass
        try:
            pygame.mixer.init(frequency=RATE, size=-16, channels=1, buffer=1024, allowedchanges=0)
        except TypeError:
            pygame.mixer.init(frequency=RATE, size=-16, channels=1, buffer=1024)
        gi = pygame.mixer.get_init()
        if not gi:
            raise RuntimeError("sem mixer")
        f, fmt, ch = gi
        if fmt != -16:
            raise RuntimeError("formato")
        if f != RATE and f <= 22050:
            RATE = f
        _nch = 2 if ch >= 2 else 1
        pygame.mixer.set_num_channels(12)
        pygame.mixer.set_reserved(2)
        _chs = [pygame.mixer.Channel(0), pygame.mixer.Channel(1)]
        _ok = True
        _aplicar_vol()
    except Exception:
        _falhou = True
        _ok = False


def ativo():
    return _ok


def _aplicar_vol():
    if not _ok:
        return
    v = 0.0 if _mudo else _vm * 0.8
    for c in _chs:
        try:
            c.set_volume(v)
        except Exception:
            pass


def volume(musica=None, efeitos=None):
    global _vm, _ve
    if musica is not None:
        _vm = max(0.0, min(1.0, float(musica)))
    if efeitos is not None:
        _ve = max(0.0, min(1.0, float(efeitos)))
    _aplicar_vol()


def mudo(v=None):
    global _mudo
    if v is None:
        v = not _mudo
    _mudo = bool(v)
    _aplicar_vol()
    return _mudo


def alternar_mudo():
    return mudo(not _mudo)


def estado():
    return dict(musica=_vm, efeitos=_ve, mudo=_mudo, ok=_ok)


def musica(nome, loop=None):
    """Pede a trilha 'nome' (None = silencio). A troca ocorre quando a amostra estiver pronta."""
    global _pedido, _pedido_loop
    _pedido = nome
    _pedido_loop = loop


def _tocar(nome):
    global _atual, _prox_ch
    snd, loop = _mus[nome]
    novo = _chs[_prox_ch]
    velho = _chs[1 - _prox_ch]
    _prox_ch = 1 - _prox_ch
    try:
        velho.fadeout(500)
        novo.set_volume(0.0 if _mudo else _vm * 0.8)
        novo.play(snd, loops=-1 if (_pedido_loop if _pedido_loop is not None else loop) else 0, fade_ms=500)
    except Exception:
        pass
    _atual = nome


def _parar():
    global _atual
    for c in _chs:
        try:
            c.fadeout(400)
        except Exception:
            pass
    _atual = None


def sfx(nome):
    if not _ok or _mudo or _ve <= 0:
        return
    try:
        agora = time.perf_counter()
        if agora - _ult_sfx.get(nome, 0) < 0.04:
            return
        _ult_sfx[nome] = agora
        s = _sfx.get(nome)
        if s is None:
            s = _montar_sfx(nome)
            if s is None:
                return
            _sfx[nome] = s
        s.set_volume(_ve)
        s.play()
    except Exception:
        pass


def tick(budget=BUDGET):
    """Chamar a cada quadro: avanca a geracao incremental e troca a trilha quando pronta."""
    global _gen, _gen_nome
    if not _ok:
        return
    try:
        if _pedido != _atual:
            if _pedido is None:
                _parar()
            elif _pedido in _mus:
                _tocar(_pedido)
        alvo = _pedido if (_pedido is not None and _pedido not in _mus) else None
        if alvo is None and _pre and _atual is not None:
            alvo = next((p for p in _pre if p not in _mus), None)
            if alvo is None and _pre_sfx:
                # efeitos pre-gerados 1 por quadro em tempo ocioso
                nm = _pre_sfx.pop(0)
                if nm not in _sfx:
                    s = _montar_sfx(nm)
                    if s is not None:
                        _sfx[nm] = s
                return
        if alvo is None:
            return
        if _gen is None or _gen_nome != alvo:
            if _pedido is not None and _pedido == alvo and _atual is not None:
                _parar()
            _gen = _gerar_musica(alvo)
            _gen_nome = alvo
        t0 = time.perf_counter()
        while time.perf_counter() - t0 < budget:
            r = next(_gen)
            if isinstance(r, tuple):
                _, arr, loop = r
                _mus[alvo] = (_som(arr), loop)
                _gen = None
                _gen_nome = None
                break
    except StopIteration:
        _gen = None
    except Exception:
        _gen = None
        _gen_nome = None

