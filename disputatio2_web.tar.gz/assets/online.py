# -*- coding: utf-8 -*-
"""Modo online cooperativo (2 jogadores), no mesmo metodo do Firewall: o ANFITRIAO (app de PC) roda a partida e manda o
ESTADO do jogo (poucos KB, ~20 vezes por segundo); o CONVIDADO (app de PC ou navegador/celular) DESENHA na propria tela
(sync.py), o heroi dele anda na hora e ele so devolve as entradas.
Entre dois PCs tudo vai DIRETO por UDP (rede.py); o servidor de salas e o plano B (e o unico caminho do navegador).
Protocolo (json; _i = numero p/ deduplicar):
  servidor: {"t":"criar"} -> {"t":"codigo","c":"ABCD"} | {"t":"entrar","c":"ABCD"} -> {"t":"pronto"} | {"t":"erro","m":..} | {"t":"saiu"}
  ambos:    {"t":"ver","v":VERSAO}, {"t":"pg","ts":x} -> {"t":"pn","ts":x} (ping, so pelo servidor)
  host->conv: bytes = foto do estado (zlib+json)
  conv->host: {"t":"udp",...} (enderecos p/ a conexao direta);
              {"t":"in","d":[x,y],"m":modo,"a":["ok",..],"p":[["d"|"m"|"u",id,fx,fy],..]}  (d = direcional; p = toques em fracao 0..1)"""
import os
import sys
import time

import sync

VERSAO = "disputatio-online-3"
URL_PADRAO = "wss://firewall-trojan-salas.onrender.com"
WEB = sys.platform == "emscripten"
# O anfitriao manda o ESTADO do jogo (poucos KB) e o convidado desenha na propria tela, como no Firewall.
FOTOS_POR_S = 20.0
W, H = 960, 540
_AQUI = os.path.dirname(os.path.abspath(__file__))


def url_servidor():
    """variavel DISPUTATIO_SERVIDOR > servidor.txt ao lado do jogo > constante"""
    u = os.environ.get("DISPUTATIO_SERVIDOR", "").strip()
    if not u and not WEB:
        try:
            with open(os.path.join(_AQUI, "servidor.txt"), encoding="utf-8-sig") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        u = ln
                        break
        except Exception:
            pass
    u = u or URL_PADRAO
    if "://" not in u:
        u = "wss://" + u
    return u


def url_http(u):
    return u.replace("wss://", "https://", 1).replace("ws://", "http://", 1)


_acordou = {"t": 0.0}


def acordar(url):
    """o servidor gratis dorme: cutuca por HTTP em segundo plano (desktop: urllib em thread; web: fetch no-cors)"""
    if time.time() - _acordou["t"] < 20:
        return
    _acordou["t"] = time.time()
    h = url_http(url)
    if WEB:
        try:
            import platform
            import json
            platform.window.eval("try{fetch(%s,{mode:'no-cors'}).catch(function(){});}catch(_){}" % json.dumps(h))
        except Exception:
            pass
        return
    import threading

    def corre():
        try:
            import urllib.request
            urllib.request.urlopen(h, timeout=70).read(16)
        except Exception:
            pass
    threading.Thread(target=corre, daemon=True).start()


def nova_rede(url):
    if WEB:
        from rede_web import RedeWeb
        return RedeWeb(url)
    from rede import Rede
    return Rede(url)


class EntradaVirtual:
    """Entrada do convidado, vista pelo anfitriao (mesmos campos que Entrada usa nas cenas)."""
    web = False

    def __init__(self):
        self.ev, self.keys_down, self.acoes = [], [], []
        self.wheel = 0
        self.modo = "mouse"
        self.foco_novo = False
        self.sim_dir = (0.0, 0.0)

    def foco_visivel(self):
        return self.modo in ("teclado", "controle")

    def teclas_dir(self):
        x, y = self.sim_dir
        n = (x * x + y * y) ** 0.5
        if n > 1:
            x, y = x / n, y / n
        return x, y


class Sessao:
    def __init__(self, game, papel, url):
        self.game = game
        self.host = papel == "host"
        self.rede = nova_rede(url)
        self.vinp = EntradaVirtual() if self.host else None
        self.codigo = None
        self.pareado = False
        self.ver_ok = False
        self.iniciada = False
        self.caiu = False
        self.erro = ""
        self.rtt = None                   # ping pelo servidor
        self.t_in = 0.0
        self._t_ping = 0.0
        self._t_foto = 0.0
        self.n_foto = 0
        self.ult_tam = 0
        if self.host:
            self.rede.envia({"t": "criar"})

    def entrar(self, codigo):
        self.rede.codigo = codigo.strip().upper()
        self.rede.inicia_p2p()
        self.rede.envia({"t": "entrar", "c": codigo})

    @property
    def ativa(self):
        return self.pareado and self.ver_ok

    def fecha(self):
        if self.host:
            sync.EVENTOS.ativo = False
        self.rede.fecha()

    def direto(self):
        return self.rede.p2p_ok()

    def rtt_atual(self):
        """(texto do caminho, ms) para o indicador"""
        r = self.rede
        if r.p2p_ok() and r.rtt is not None:
            return "Direto", r.rtt
        return "Via servidor", self.rtt

    # ---------------------------------------------------------- mensagens
    def pump(self, dt):
        r = self.rede
        v = self.vinp
        if v is not None:
            v.ev, v.acoes = [], []
            if self.t_in and time.time() - self.t_in > 2.0:
                v.sim_dir = (0.0, 0.0)
        for d in r.mensagens():
            t = d.get("t")
            if t == "in" and v is not None:
                self._entrada(d)
            elif t == "codigo":
                self.codigo = d.get("c")
                r.codigo = self.codigo
                r.inicia_p2p()              # ja abre o socket UDP e descobre o endereco publico enquanto espera o amigo
            elif t == "pronto":
                self.pareado = True
                r.pareou()
                r.envia({"t": "ver", "v": VERSAO})
            elif t == "erro":
                self.erro = d.get("m", "Erro")
            elif t == "ver":
                if d.get("v") != VERSAO:
                    self.erro = "Versões diferentes: atualize o jogo dos dois lados."
                    self.fecha()
                else:
                    self.ver_ok = True
            elif t in ("saiu", "caiu"):
                self.caiu = True
            elif t == "pg":
                r.envia({"t": "pn", "ts": d.get("ts")}, so_servidor=True)
            elif t == "pn":
                try:
                    ms = (time.time() - float(d.get("ts"))) * 1000.0
                    self.rtt = ms if self.rtt is None else self.rtt * 0.7 + ms * 0.3
                except Exception:
                    pass
        if r.estado == "erro" and not self.erro:
            self.erro = r.erro or "Sem conexão com o servidor"
        elif r.estado == "fechado" and not self.iniciada and not self.erro:
            self.erro = "Conexão perdida."
        now = time.time()
        if self.pareado and now - self._t_ping > 2.0:
            self._t_ping = now
            r.envia({"t": "pg", "ts": now}, so_servidor=True)

    def _entrada(self, d):
        v = self.vinp
        self.t_in = time.time()
        try:
            dx, dy = d.get("d", (0, 0))
            v.sim_dir = (float(dx), float(dy))
        except Exception:
            v.sim_dir = (0.0, 0.0)
        v.modo = d.get("m", v.modo)
        v.acoes.extend(a for a in d.get("a", ()) if isinstance(a, str))
        for k, pid, fx, fy in d.get("p", ()):
            v.ev.append((k, "g%s" % pid, (float(fx) * W, float(fy) * H)))

    # ---------------------------------------------------------- anfitriao
    def pos_draw(self, S):
        """chamado no fim do Game.draw: o anfitriao fotografa o estado e manda; os dois desenham o indicador"""
        if self.host and self.iniciada:
            sync.EVENTOS.ativo = True
            now = time.time()
            passo = 1.0 / FOTOS_POR_S
            if now - self._t_foto >= passo * 0.85:
                self._t_foto = now
                self.n_foto += 1
                try:
                    b = sync.foto(self.game, self.n_foto)
                    self.ult_tam = len(b)
                    self.rede.envia_quadro(b)
                except Exception:
                    import traceback
                    traceback.print_exc()
        self.indicador(S)

    def indicador(self, S):
        from desenho import draw_text
        via, ms = self.rtt_atual()
        if ms is None:
            tx, cor = via + "...", (220, 210, 170)
        else:
            tx = "%s, %d ms" % (via, int(ms))
            cor = (130, 230, 140) if ms < 150 else ((240, 210, 100) if ms < 350 else (250, 120, 100))
        draw_text(S, tx, 18, cor, (W - 8, H - 10), anchor="midright", shadow=(0, 0, 0))

    # ---------------------------------------------------------- convidado
    def envia_entrada(self, d, acoes, ptrs, modo):
        m = {"t": "in", "d": [round(d[0], 2), round(d[1], 2)], "m": modo, "a": acoes, "p": ptrs}
        if acoes or ptrs:
            self.rede.envia(m)              # toques/botoes nao podem se perder: vao pelos dois caminhos
        else:
            self.rede.envia_estado(m)       # so o direcional: UDP direto quando der
