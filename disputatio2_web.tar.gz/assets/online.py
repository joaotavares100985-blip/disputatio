# -*- coding: utf-8 -*-
"""Modo online cooperativo (2 jogadores). O ANFITRIAO (app de PC) roda o jogo inteiro e manda quadros JPEG; o CONVIDADO
(app de PC ou navegador/celular) e um terminal: mostra a imagem e devolve entradas.
Protocolo (json, uma mensagem por linha de dados; _i = numero p/ deduplicar):
  servidor: {"t":"criar"} -> {"t":"codigo","c":"ABCD"} | {"t":"entrar","c":"ABCD"} -> {"t":"pronto"} | {"t":"erro","m":..} | {"t":"saiu"}
  ambos:    {"t":"ver","v":VERSAO}, {"t":"pg","ts":x} -> {"t":"pn","ts":x} (ping)
  host->conv: bytes = quadro JPEG 640x360; {"t":"st","ex":bool,"a":icone|None}  (ex = exploracao: o convidado mostra joystick e botao A)
  conv->host: {"t":"in","d":[x,y],"m":modo,"a":["ok",..],"p":[["d"|"m"|"u",id,fx,fy],..]}  (d = direcional; p = toques em fracao 0..1)"""
import io
import os
import sys
import threading
import time

import pygame

import estado as E

VERSAO = "disputatio-online-1"
URL_PADRAO = "wss://firewall-trojan-salas.onrender.com"
WEB = sys.platform == "emscripten"
QW, QH = 480, 270      # ~35 KB por quadro JPEG (640x360 dava ~55 KB: pesado pro upload domestico)
FPS_QUADRO = 10.0
W, H = 960, 540
_AQUI = os.path.dirname(os.path.abspath(__file__))


def url_servidor():
    """variavel DISPUTATIO_SERVIDOR > servidor.txt ao lado do jogo > constante"""
    u = os.environ.get("DISPUTATIO_SERVIDOR", "").strip()
    if not u and not WEB:
        try:
            with open(os.path.join(_AQUI, "servidor.txt"), encoding="utf-8-sig") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        u = ln
                        break
        except Exception:
            pass
    u = u or URL_PADRAO
    if "://" not in u:
        u = "wss://" + u
    return u


def url_http(u):
    return u.replace("wss://", "https://", 1).replace("ws://", "http://", 1)


_acordou = {"t": 0.0}


def acordar(url):
    """o servidor gratis dorme: cutuca por HTTP em segundo plano (desktop: urllib em thread; web: fetch no-cors)"""
    if time.time() - _acordou["t"] < 20:
        return
    _acordou["t"] = time.time()
    h = url_http(url)
    if WEB:
        try:
            import platform
            import json
            platform.window.eval("try{fetch(%s,{mode:'no-cors'}).catch(function(){});}catch(_){}" % json.dumps(h))
        except Exception:
            pass
        return

    def corre():
        try:
            import urllib.request
            urllib.request.urlopen(h, timeout=70).read(16)
        except Exception:
            pass
    threading.Thread(target=corre, daemon=True).start()


def nova_rede(url):
    if WEB:
        from rede_web import RedeWeb
        return RedeWeb(url)
    from rede import Rede
    return Rede(url)


class EntradaVirtual:
    """Entrada do convidado, vista pelo anfitriao (mesmos campos que Entrada usa nas cenas)."""
    web = False

    def __init__(self):
        self.ev, self.keys_down, self.acoes = [], [], []
        self.wheel = 0
        self.modo = "mouse"
        self.foco_novo = False
        self.sim_dir = (0.0, 0.0)

    def foco_visivel(self):
        return self.modo in ("teclado", "controle")

    def teclas_dir(self):
        x, y = self.sim_dir
        n = (x * x + y * y) ** 0.5
        if n > 1:
            x, y = x / n, y / n
        return x, y


class Sessao:
    def __init__(self, game, papel, url):
        self.game = game
        self.host = papel == "host"
        self.rede = nova_rede(url)
        self.vinp = EntradaVirtual() if self.host else None
        self.codigo = None
        self.pareado = False
        self.ver_ok = False
        self.iniciada = False
        self.caiu = False
        self.erro = ""
        self.rtt = None
        self.st = {"ex": False, "a": None}
        self.t_in = 0.0
        self._t_ping = 0.0
        self._t_quadro = 0.0
        self._t_st = 0.0
        self._pend_in = None
        self.quadros = 0
        self.enviados = 0
        if self.host:
            self.rede.envia({"t": "criar"})

    def entrar(self, codigo):
        self.rede.envia({"t": "entrar", "c": codigo})

    @property
    def ativa(self):
        return self.pareado and self.ver_ok

    def fecha(self):
        self.rede.fecha()

    # ---------------------------------------------------------- mensagens
    def pump(self, dt):
        r = self.rede
        v = self.vinp
        if v is not None:
            v.ev, v.acoes = [], []
            if self.t_in and time.time() - self.t_in > 2.0:
                v.sim_dir = (0.0, 0.0)
        for d in r.mensagens():
            t = d.get("t")
            if t == "codigo":
                self.codigo = d.get("c")
            elif t == "pronto":
                self.pareado = True
                r.envia({"t": "ver", "v": VERSAO})
            elif t == "erro":
                self.erro = d.get("m", "Erro")
            elif t == "ver":
                if d.get("v") != VERSAO:
                    self.erro = "Versões diferentes: atualize o jogo dos dois lados."
                    self.fecha()
                else:
                    self.ver_ok = True
            elif t in ("saiu", "caiu"):
                self.caiu = True
            elif t == "in" and v is not None:
                self._entrada(d)
            elif t == "st":
                self.st = d
            elif t == "pg":
                r.envia({"t": "pn", "ts": d.get("ts")})
            elif t == "pn":
                try:
                    ms = (time.time() - float(d.get("ts"))) * 1000.0
                    self.rtt = ms if self.rtt is None else self.rtt * 0.7 + ms * 0.3
                except Exception:
                    pass
        if r.estado == "erro" and not self.erro:
            self.erro = r.erro or "Sem conexão com o servidor"
        elif r.estado == "fechado" and not self.iniciada and not self.erro:
            self.erro = "Conexão perdida."
        now = time.time()
        if self.pareado and now - self._t_ping > 2.0:
            self._t_ping = now
            r.envia({"t": "pg", "ts": now})

    def _entrada(self, d):
        v = self.vinp
        self.t_in = time.time()
        try:
            dx, dy = d.get("d", (0, 0))
            v.sim_dir = (float(dx), float(dy))
        except Exception:
            v.sim_dir = (0.0, 0.0)
        v.modo = d.get("m", v.modo)
        v.acoes.extend(a for a in d.get("a", ()) if isinstance(a, str))
        for k, pid, fx, fy in d.get("p", ()):
            v.ev.append((k, "g%s" % pid, (float(fx) * W, float(fy) * H)))

    # ---------------------------------------------------------- anfitriao
    def pos_draw(self, S):
        """chamado no fim do Game.draw: o anfitriao manda o quadro; os dois desenham o indicador"""
        now = time.time()
        if self.host and self.iniciada:
            if now - self._t_st > 0.2:
                self._t_st = now
                self.rede.envia(self.game.estado_terminal())
            if now - self._t_quadro >= 1.0 / FPS_QUADRO:
                self._t_quadro = now
                try:
                    pq = pygame.transform.scale(S, (QW, QH))
                    bio = io.BytesIO()
                    pygame.image.save(pq, bio, "jpg")
                    self.rede.envia_quadro(bio.getvalue())
                    self.enviados += 1
                except Exception:
                    pass
        self.indicador(S)

    def indicador(self, S):
        from desenho import draw_text
        if self.rtt is None:
            tx, cor = "Online...", (220, 210, 170)
        else:
            tx = "Online %d ms" % int(self.rtt)
            cor = (130, 230, 140) if self.rtt < 150 else ((240, 210, 100) if self.rtt < 350 else (250, 120, 100))
        draw_text(S, tx, 18, cor, (W - 8, H - 10), anchor="midright", shadow=(0, 0, 0))

    # ---------------------------------------------------------- convidado
    def envia_entrada(self, d, acoes, ptrs, modo):
        self.rede.envia({"t": "in", "d": [round(d[0], 2), round(d[1], 2)], "m": modo, "a": acoes, "p": ptrs})

    def decodifica(self):
        """convidado: devolve a Surface do quadro mais novo (ou None)"""
        b = self.rede.quadro()
        if not b:
            return None
        try:
            self.quadros += 1
            return pygame.image.load(io.BytesIO(b), "quadro.jpg")
        except Exception:
            return None
