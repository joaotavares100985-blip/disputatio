# -*- coding: utf-8 -*-
"""Modo online cooperativo (2 jogadores). O ANFITRIAO (app de PC) roda o jogo inteiro e manda quadros JPEG; o CONVIDADO
(app de PC ou navegador/celular) e um terminal: mostra a imagem e devolve entradas.
Entre dois PCs os quadros e as entradas vao DIRETO por UDP (rede.py); o servidor de salas e o plano B (e o unico
caminho do convidado no navegador, que nao tem UDP).
Protocolo (json, uma mensagem por linha de dados; _i = numero p/ deduplicar):
  servidor: {"t":"criar"} -> {"t":"codigo","c":"ABCD"} | {"t":"entrar","c":"ABCD"} -> {"t":"pronto"} | {"t":"erro","m":..} | {"t":"saiu"}
  ambos:    {"t":"ver","v":VERSAO}, {"t":"pg","ts":x} -> {"t":"pn","ts":x} (ping, so pelo servidor)
  conv->host: {"t":"perfil","p":"leve"|"pleno"} (navegador/celular = leve); {"t":"udp",...} (enderecos p/ a conexao direta)
  host->conv: bytes = quadro JPEG (direto por UDP fragmentado, ou pelo servidor); {"t":"st","ex":bool,"a":icone|None}
  conv->host: {"t":"in","d":[x,y],"m":modo,"a":["ok",..],"p":[["d"|"m"|"u",id,fx,fy],..]}  (d = direcional; p = toques em fracao 0..1)"""
import io
import os
import sys
import time

import pygame

import estado as E

VERSAO = "disputatio-online-2"
URL_PADRAO = "wss://firewall-trojan-salas.onrender.com"
WEB = sys.platform == "emscripten"
# Tamanhos dos quadros (o JPEG do pygame nao tem controle de qualidade: o tamanho em bytes se controla pela resolucao).
# Direto (UDP): 960x540 (800x450 se passar de ~90 KB). Pelo servidor: 640x360 a ~10 fps em movimento (480x270 no perfil
# leve) e UM quadro nitido 960x540 (800x450 no perfil leve) quando a tela fica estavel.
RES_PLENO = ((640, 360), (960, 540))
RES_LEVE = ((480, 270), (800, 450))
RES_DIRETO, RES_DIRETO2, MAX_DIRETO = (960, 540), (800, 450), 90000
FPS_DIRETO, FPS_SERV = 18.0, 10.0
LIM_MOV = 0.01          # fracao de pixels (amostra 80x45) que mudou entre dois quadros = "movimento"
W, H = 960, 540
_AQUI = os.path.dirname(os.path.abspath(__file__))


def url_servidor():
    """variavel DISPUTATIO_SERVIDOR > servidor.txt ao lado do jogo > constante"""
    u = os.environ.get("DISPUTATIO_SERVIDOR", "").strip()
    if not u and not WEB:
        try:
            with open(os.path.join(_AQUI, "servidor.txt"), encoding="utf-8-sig") as f:
                for ln in f:
                    ln = ln.strip()
                    if ln and not ln.startswith("#"):
                        u = ln
                        break
        except Exception:
            pass
    u = u or URL_PADRAO
    if "://" not in u:
        u = "wss://" + u
    return u


def url_http(u):
    return u.replace("wss://", "https://", 1).replace("ws://", "http://", 1)


_acordou = {"t": 0.0}


def acordar(url):
    """o servidor gratis dorme: cutuca por HTTP em segundo plano (desktop: urllib em thread; web: fetch no-cors)"""
    if time.time() - _acordou["t"] < 20:
        return
    _acordou["t"] = time.time()
    h = url_http(url)
    if WEB:
        try:
            import platform
            import json
            platform.window.eval("try{fetch(%s,{mode:'no-cors'}).catch(function(){});}catch(_){}" % json.dumps(h))
        except Exception:
            pass
        return
    import threading

    def corre():
        try:
            import urllib.request
            urllib.request.urlopen(h, timeout=70).read(16)
        except Exception:
            pass
    threading.Thread(target=corre, daemon=True).start()


def nova_rede(url):
    if WEB:
        from rede_web import RedeWeb
        return RedeWeb(url)
    from rede import Rede
    return Rede(url)


class EntradaVirtual:
    """Entrada do convidado, vista pelo anfitriao (mesmos campos que Entrada usa nas cenas)."""
    web = False

    def __init__(self):
        self.ev, self.keys_down, self.acoes = [], [], []
        self.wheel = 0
        self.modo = "mouse"
        self.foco_novo = False
        self.sim_dir = (0.0, 0.0)

    def foco_visivel(self):
        return self.modo in ("teclado", "controle")

    def teclas_dir(self):
        x, y = self.sim_dir
        n = (x * x + y * y) ** 0.5
        if n > 1:
            x, y = x / n, y / n
        return x, y


def _jpg(S, tam):
    q = S if S.get_size() == tam else pygame.transform.smoothscale(S, tam)
    bio = io.BytesIO()
    pygame.image.save(q, bio, "jpg")
    return bio.getvalue()


class EnvioQuadros:
    """Anfitriao: codifica o JPEG e envia numa thread propria (o laco do jogo so entrega uma COPIA da tela). Slot de um
    unico quadro: se a thread ainda esta ocupada, o quadro velho e descartado (nada de fila crescendo)."""

    def __init__(self, ses):
        import threading
        self.ses = ses
        self.slot = None
        self.mov_in = 0.0                 # ultima vez que um direcional estava ativo (exploracao)
        self.ev = threading.Event()
        self.vivo = True
        threading.Thread(target=self._loop, daemon=True).start()

    def livre(self):
        return self.slot is None

    def oferece(self, surf):
        self.slot = surf
        self.ev.set()

    def fecha(self):
        self.vivo = False
        self.ev.set()

    def _envia(self, S, tam, direto=False):
        b = _jpg(S, tam)
        if direto and len(b) > MAX_DIRETO and tam != RES_DIRETO2:
            tam = RES_DIRETO2
            b = _jpg(S, tam)
            self.grande = time.time()
        self.ses.rede.envia_quadro(b)
        s = self.ses
        s.enviados += 1
        s.ult_tam, s.ult_res = len(b), tam

    grande = 0.0

    def _loop(self):
        s = self.ses
        ant = None
        ult_dir = ult_peq = ult_nit = 0.0
        quieto = None
        sujo = False
        pend = True
        modo_ant = None
        while self.vivo:
            self.ev.wait(0.5)
            self.ev.clear()
            S, self.slot = self.slot, None
            if S is None:
                continue
            try:
                now = time.time()
                am = pygame.image.tobytes(pygame.transform.scale(S, (80, 45)), "RGB")
                if ant is None:
                    dif = 1.0
                else:
                    dif = sum(1 for a, b in zip(am, ant) if a - b > 10 or b - a > 10) / (len(am) / 3.0)
                ant = am
                if dif > 0:
                    sujo = True
                direto = s.rede.p2p_ok()
                if direto != modo_ant:
                    modo_ant, pend = direto, True
                    ult_nit = 0.0
                if direto:
                    if dif == 0 and not pend and now - ult_dir < 1.0:
                        continue
                    pend = False
                    ult_dir = now
                    tam = RES_DIRETO2 if now - self.grande < 3.0 else RES_DIRETO
                    self._envia(S, tam, True)
                    continue
                peq, nit = RES_LEVE if s.perfil == "leve" else RES_PLENO
                mov = dif > LIM_MOV or now - self.mov_in < 0.3
                if mov:
                    quieto = None
                    pend = True
                    if now - ult_peq >= 0.85 / FPS_SERV:
                        ult_peq = now
                        self._envia(S, peq)
                else:
                    if quieto is None:
                        quieto = now
                    if now - quieto >= 0.25 and (pend or (sujo and now - ult_nit >= 1.2) or now - ult_nit >= 5.0):
                        pend, sujo, ult_nit = False, False, now
                        self._envia(S, nit)
            except Exception:
                pass


class Sessao:
    def __init__(self, game, papel, url):
        self.game = game
        self.host = papel == "host"
        self.rede = nova_rede(url)
        self.vinp = EntradaVirtual() if self.host else None
        self.codigo = None
        self.pareado = False
        self.ver_ok = False
        self.iniciada = False
        self.caiu = False
        self.erro = ""
        self.rtt = None                   # ping pelo servidor
        self.perfil = "pleno"             # perfil do convidado (so o anfitriao usa): "leve" (navegador) ou "pleno" (PC)
        self.st = {"ex": False, "a": None}
        self.t_in = 0.0
        self._t_ping = 0.0
        self._t_quadro = 0.0
        self._t_st = 0.0
        self.quadros = 0
        self.enviados = 0
        self.ult_tam = 0
        self.ult_res = (0, 0)
        self.env = EnvioQuadros(self) if self.host else None
        if self.host:
            self.rede.envia({"t": "criar"})

    def entrar(self, codigo):
        self.rede.codigo = codigo.strip().upper()
        self.rede.inicia_p2p()
        self.rede.envia({"t": "entrar", "c": codigo})

    @property
    def ativa(self):
        return self.pareado and self.ver_ok

    def fecha(self):
        if self.env is not None:
            self.env.fecha()
        self.rede.fecha()

    def direto(self):
        return self.rede.p2p_ok()

    def rtt_atual(self):
        """(texto do caminho, ms) para o indicador"""
        r = self.rede
        if r.p2p_ok() and r.rtt is not None:
            return "Direto", r.rtt
        return "Via servidor", self.rtt

    # ---------------------------------------------------------- mensagens
    def pump(self, dt):
        r = self.rede
        v = self.vinp
        if v is not None:
            v.ev, v.acoes = [], []
            if self.t_in and time.time() - self.t_in > 2.0:
                v.sim_dir = (0.0, 0.0)
        for d in r.mensagens():
            t = d.get("t")
            if t == "in" and v is not None:
                self._entrada(d)
            elif t == "codigo":
                self.codigo = d.get("c")
                r.codigo = self.codigo
                r.inicia_p2p()              # ja abre o socket UDP e descobre o endereco publico enquanto espera o amigo
            elif t == "pronto":
                self.pareado = True
                r.pareou()
                r.envia({"t": "ver", "v": VERSAO})
                if not self.host:
                    r.envia({"t": "perfil", "p": "leve" if WEB else "pleno"})
            elif t == "perfil":
                self.perfil = "leve" if d.get("p") == "leve" else "pleno"
            elif t == "erro":
                self.erro = d.get("m", "Erro")
            elif t == "ver":
                if d.get("v") != VERSAO:
                    self.erro = "Versões diferentes: atualize o jogo dos dois lados."
                    self.fecha()
                else:
                    self.ver_ok = True
            elif t in ("saiu", "caiu"):
                self.caiu = True
            elif t == "st":
                self.st = d
            elif t == "pg":
                r.envia({"t": "pn", "ts": d.get("ts")}, so_servidor=True)
            elif t == "pn":
                try:
                    ms = (time.time() - float(d.get("ts"))) * 1000.0
                    self.rtt = ms if self.rtt is None else self.rtt * 0.7 + ms * 0.3
                except Exception:
                    pass
        if r.estado == "erro" and not self.erro:
            self.erro = r.erro or "Sem conexão com o servidor"
        elif r.estado == "fechado" and not self.iniciada and not self.erro:
            self.erro = "Conexão perdida."
        now = time.time()
        if self.pareado and now - self._t_ping > 2.0:
            self._t_ping = now
            r.envia({"t": "pg", "ts": now}, so_servidor=True)

    def _entrada(self, d):
        v = self.vinp
        self.t_in = time.time()
        try:
            dx, dy = d.get("d", (0, 0))
            v.sim_dir = (float(dx), float(dy))
        except Exception:
            v.sim_dir = (0.0, 0.0)
        v.modo = d.get("m", v.modo)
        v.acoes.extend(a for a in d.get("a", ()) if isinstance(a, str))
        for k, pid, fx, fy in d.get("p", ()):
            v.ev.append((k, "g%s" % pid, (float(fx) * W, float(fy) * H)))

    # ---------------------------------------------------------- anfitriao
    def pos_draw(self, S):
        """chamado no fim do Game.draw: o anfitriao entrega uma copia da tela pra thread de envio; os dois desenham o indicador"""
        now = time.time()
        if self.host and self.iniciada:
            if now - self._t_st > 0.2:
                self._t_st = now
                st = self.game.estado_terminal()
                if st != getattr(self, "_ult_st", None) or now - getattr(self, "_t_st_tx", 0.0) > 1.0:
                    self._ult_st, self._t_st_tx = st, now
                    self.rede.envia(st)
            vi = self.vinp
            if vi is not None and (abs(vi.sim_dir[0]) > 0.1 or abs(vi.sim_dir[1]) > 0.1 or
                                   (self.env and any(abs(x) > 0.1 for x in self.game.inp.teclas_dir()))):
                self.env.mov_in = now
            if now - self._t_quadro >= 1.0 / FPS_DIRETO and self.env.livre():
                self._t_quadro = now
                try:
                    self.env.oferece(S.copy())
                except Exception:
                    pass
        self.indicador(S)

    def indicador(self, S):
        from desenho import draw_text
        via, ms = self.rtt_atual()
        if ms is None:
            tx, cor = via + "...", (220, 210, 170)
        else:
            tx = "%s, %d ms" % (via, int(ms))
            cor = (130, 230, 140) if ms < 150 else ((240, 210, 100) if ms < 350 else (250, 120, 100))
        draw_text(S, tx, 18, cor, (W - 8, H - 10), anchor="midright", shadow=(0, 0, 0))

    # ---------------------------------------------------------- convidado
    def envia_entrada(self, d, acoes, ptrs, modo):
        m = {"t": "in", "d": [round(d[0], 2), round(d[1], 2)], "m": modo, "a": acoes, "p": ptrs}
        if acoes or ptrs:
            self.rede.envia(m)              # toques/botoes nao podem se perder: vao pelos dois caminhos
        else:
            self.rede.envia_estado(m)       # so o direcional: UDP direto quando der

    def decodifica(self):
        """convidado: devolve a Surface do quadro mais novo (ou None); quadros atrasados nem sao decodificados"""
        b = self.rede.quadro()
        if not b:
            return None
        try:
            self.quadros += 1
            return pygame.image.load(io.BytesIO(b), "quadro.jpg")
        except Exception:
            return None
