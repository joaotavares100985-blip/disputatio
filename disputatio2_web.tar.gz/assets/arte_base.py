# -*- coding: utf-8 -*-
"""Primitivas de arte procedural (cenarios + capa + UI): cores, gradientes, granulado, pedra, ogivas,
vitrais, rosaceas, luz aditiva e pequenos simbolos (lis, estrela, cruz). So pygame + stdlib."""
import math
import random

import pygame

AZUL = (30, 63, 140)
AZUL_C = (47, 91, 183)
RUBI = (200, 40, 46)
OURO = (212, 175, 55)
OURO_S = (160, 125, 28)
OURO_C = (255, 228, 140)
PERG = (232, 217, 181)
TINTA = (42, 33, 27)
BRANCO = (244, 241, 232)
VERDE = (46, 107, 58)
VIOLETA = (91, 44, 111)

PI = math.pi


def mix(a, b, t):
    return (max(0, min(255, int(a[0] + (b[0] - a[0]) * t))),
            max(0, min(255, int(a[1] + (b[1] - a[1]) * t))),
            max(0, min(255, int(a[2] + (b[2] - a[2]) * t))))


def esc(c, k):
    return (max(0, min(255, int(c[0] * k))), max(0, min(255, int(c[1] * k))), max(0, min(255, int(c[2] * k))))


def somar(c, d):
    return (max(0, min(255, c[0] + d)), max(0, min(255, c[1] + d)), max(0, min(255, c[2] + d)))


def surf(w, h):
    return pygame.Surface((max(1, int(w)), max(1, int(h))), pygame.SRCALPHA)


def conv(s):
    try:
        if pygame.display.get_surface():
            return s.convert_alpha() if s.get_flags() & pygame.SRCALPHA else s.convert()
    except Exception:
        pass
    return s


# --------------------------------------------------------------------- gradientes
def vgrad(w, h, c1, c2):
    s = pygame.Surface((w, h))
    for y in range(h):
        pygame.draw.line(s, mix(c1, c2, y / max(1, h - 1)), (0, y), (w, y))
    return s


def hgrad(w, h, c1, c2):
    s = pygame.Surface((w, h))
    for x in range(w):
        pygame.draw.line(s, mix(c1, c2, x / max(1, w - 1)), (x, 0), (x, h))
    return s


def vgrad_a(w, h, c1, a1, c2, a2):
    s = surf(w, h)
    for y in range(h):
        t = y / max(1, h - 1)
        c = mix(c1, c2, t)
        pygame.draw.line(s, (c[0], c[1], c[2], int(a1 + (a2 - a1) * t)), (0, y), (w, y))
    return s


_G = {}


def brilho(r, col, pot=2.0):
    """Disco radial preto->cor (para BLEND_RGB_ADD). Cache por (r, cor)."""
    k = (r, col, pot)
    g = _G.get(k)
    if g is None:
        g = pygame.Surface((2 * r, 2 * r))
        for rr in range(r, 0, -2):
            kk = (1 - rr / r) ** pot
            pygame.draw.circle(g, (int(col[0] * kk), int(col[1] * kk), int(col[2] * kk)), (r, r), rr)
        g = conv(g)
        _G[k] = g
    return g


def luz_add(S, pos, r, col, k=1.0, pot=2.0):
    r = int(max(4, r * k))
    r = (r // 4) * 4 or 4
    g = brilho(r, col, pot)
    S.blit(g, (int(pos[0]) - r, int(pos[1]) - r), special_flags=pygame.BLEND_RGB_ADD)


_HA = {}


def halo_a(r, col, amax=120, pot=2.0):
    """Disco radial com alfa (SRCALPHA) para mistura normal."""
    k = (r, col, amax, pot)
    h = _HA.get(k)
    if h is None:
        h = surf(2 * r, 2 * r)
        for rr in range(r, 0, -2):
            a = int(amax * (1 - rr / r) ** pot)
            pygame.draw.circle(h, (col[0], col[1], col[2], a), (r, r), rr)
        h = conv(h)
        _HA[k] = h
    return h


_SOM = {}


def sombra_elipse(S, cx, cy, w, h, a=90):
    k = (w, h, a)
    s = _SOM.get(k)
    if s is None:
        s = surf(w, h)
        n = 6
        for i in range(n):
            pygame.draw.ellipse(s, (0, 0, 0, a // n + 4),
                                (i * w // (2 * n), i * h // (2 * n), w - i * w // n, h - i * h // n))
        s = conv(s)
        _SOM[k] = s
    S.blit(s, (int(cx - w / 2), int(cy - h / 2)))


# --------------------------------------------------------------------- granulado
_NT = [None]


def _tile():
    if _NT[0] is None:
        rnd = random.Random(99)
        s = surf(256, 256)
        for _ in range(3200):
            x, y = rnd.randrange(256), rnd.randrange(256)
            if rnd.random() < .55:
                c = (0, 0, 0, rnd.randint(10, 38))
            else:
                c = (255, 255, 255, rnd.randint(6, 22))
            pygame.draw.rect(s, c, (x, y, rnd.choice((1, 1, 2, 3)), rnd.choice((1, 1, 2))))
        for _ in range(60):          # riscos finos
            x, y = rnd.randrange(256), rnd.randrange(256)
            pygame.draw.line(s, (0, 0, 0, 22), (x, y), (x + rnd.randint(-9, 9), y + rnd.randint(-5, 9)))
        _NT[0] = conv(s)
    return _NT[0]


def granulado(S, rect, k=1.0, seed=0):
    t = _tile()
    r = pygame.Rect(rect)
    old = S.get_clip()
    S.set_clip(r.clip(old) if old else r)
    rnd = random.Random(seed)
    t.set_alpha(int(255 * k))
    ox, oy = rnd.randrange(256), rnd.randrange(256)
    y = r.y - oy
    while y < r.bottom:
        x = r.x - ox
        while x < r.right:
            S.blit(t, (x, y))
            x += 256
        y += 256
    t.set_alpha(255)
    S.set_clip(old)


# --------------------------------------------------------------------- pedra
def parede_pedra(S, rect, base, rnd, bh=24, bw=62, var=9, fiadas_irregulares=True):
    r = pygame.Rect(rect)
    old = S.get_clip()
    S.set_clip(r)
    junta = esc(base, .42)
    pygame.draw.rect(S, junta, r)
    y = r.y
    row = 0
    while y < r.bottom:
        h = bh + (rnd.randint(-2, 3) if fiadas_irregulares else 0)
        x = r.x - (row % 2) * bw // 2 - rnd.randint(0, 10)
        while x < r.right:
            w = int(bw * rnd.uniform(.78, 1.3))
            t = rnd.randint(-var, var)
            c = (max(0, min(255, base[0] + t)), max(0, min(255, base[1] + t)), max(0, min(255, base[2] + int(t * .7))))
            b = pygame.Rect(x + 1, y + 1, w - 2, h - 2)
            pygame.draw.rect(S, c, b, 0, 2)
            pygame.draw.rect(S, esc(c, 1.1), (b.x + 2, b.y + 2, b.w - 4, max(2, b.h // 3)), 0, 2)
            pygame.draw.line(S, esc(c, 1.25), (b.x, b.y), (b.right - 1, b.y))
            pygame.draw.line(S, esc(c, .66), (b.x, b.bottom - 1), (b.right - 1, b.bottom - 1))
            pygame.draw.line(S, esc(c, .8), (b.right - 1, b.y), (b.right - 1, b.bottom - 1))
            u = rnd.random()
            if u < .22:
                px, py = b.x + rnd.randint(4, max(5, b.w - 6)), b.y + rnd.randint(3, max(4, b.h - 5))
                pygame.draw.line(S, esc(c, .6), (px, py), (px + rnd.randint(-6, 6), py + rnd.randint(2, 8)))
            elif u < .34:
                pygame.draw.circle(S, esc(c, 1.15 if rnd.random() < .5 else .8), (b.x + rnd.randint(3, max(4, b.w - 4)), b.y + rnd.randint(3, max(4, b.h - 4))), rnd.randint(1, 3))
            x += w
        y += h
        row += 1
    S.set_clip(old)


# --------------------------------------------------------------------- ogivas
# Estilo arquitetonico em construcao (indice do andar): 0 romanico, 1 gotico classico (rayonnant), 2 gotico flamejante, 3 barroco.
# As funcoes de arco abaixo mudam de forma conforme o estilo, assim portas, janelas e arcaturas acompanham o andar.
ESTILO = [1]


def set_estilo(i):
    old = ESTILO[0]
    ESTILO[0] = int(i) % 4
    return old


def ogiva(cx, y_base, w, rise, spring=0.0, n=14):
    """Arco do vao: volta perfeita (romanico/barroco), ogiva (gotico) ou lanceta alta (flamejante). Base em y_base, parte reta 'spring'; rise = altura do arco."""
    e = ESTILO[0]
    if e in (0, 3):
        hw = w / 2.0
        ry = min(rise, hw)
        sp = spring + max(0.0, rise - ry)
        ysp = y_base - sp
        pts = [(cx - hw, y_base), (cx - hw, ysp)]
        for i in range(1, 2 * n):
            a = PI + PI * i / (2.0 * n)
            pts.append((cx + hw * math.cos(a), ysp + ry * math.sin(a)))
        pts.append((cx + hw, ysp))
        pts.append((cx + hw, y_base))
        return pts
    if e == 2:
        r2 = rise * 1.14
        return _ogiva_gotica(cx, y_base, w, r2, max(0.0, spring - (r2 - rise)), n)
    return _ogiva_gotica(cx, y_base, w, rise, spring, n)


def conopial(cx, y_base, w, rise, spring=0.0, n=8):
    """Arco conopial (ogee) do gotico flamejante: curva em S ate uma ponta fina."""
    hw = w / 2.0
    ysp = y_base - spring
    L = [(cx - hw, ysp), (cx - hw * .98, ysp - rise * .22), (cx - hw * .82, ysp - rise * .46), (cx - hw * .5, ysp - rise * .64), (cx - hw * .2, ysp - rise * .84), (cx, ysp - rise)]
    from arte_kit import catmull
    c = catmull(L, n)
    pts = [(cx - hw, y_base)] + c + [(2 * cx - x, y) for (x, y) in reversed(c[:-1])] + [(cx + hw, y_base)]
    return pts


def _ogiva_gotica(cx, y_base, w, rise, spring=0.0, n=14):
    """Pontos de um arco quebrado (ogiva). Base em y_base, parte reta 'spring', depois arcos que se
    encontram no vertice. rise = altura do arco acima da linha de arranque (>= w/2)."""
    hw = w / 2.0
    rise = max(rise, hw * 1.02)
    d = (rise * rise - hw * hw) / w
    R = hw + d
    ysp = y_base - spring
    th = math.atan2(-rise, -d)
    if th < 0:
        th += 2 * PI
    pts = [(cx - hw, y_base), (cx - hw, ysp)]
    L = []
    for i in range(1, n + 1):
        a = PI + (th - PI) * i / n
        L.append((cx + d + R * math.cos(a), ysp + R * math.sin(a)))
    pts += L
    for (x, y) in reversed(L[:-1]):
        pts.append((2 * cx - x, y))
    pts.append((cx + hw, ysp))
    pts.append((cx + hw, y_base))
    return pts


def arco_moldurado(S, cx, y_base, w, rise, spring, camadas, fundo=None):
    """camadas: lista de (inset, cor, largura_linha). Desenha ogivas concentricas (molduras)."""
    if fundo is not None:
        pygame.draw.polygon(S, fundo, ogiva(cx, y_base, w, rise, spring))
    for ins, col, lw in camadas:
        pygame.draw.polygon(S, col, ogiva(cx, y_base, w - 2 * ins, rise - ins, spring), lw)


# --------------------------------------------------------------------- simbolos
_LIS_C = [(0, -.5), (.06, -.38), (.12, -.22), (.13, -.08), (.09, .04), (0, .08), (-.09, .04), (-.13, -.08), (-.12, -.22), (-.06, -.38)]
_LIS_S = [(.05, .07), (.13, -.0), (.26, -.04), (.37, -.14), (.39, -.3), (.3, -.22), (.22, -.17), (.14, -.16), (.06, -.1)]
_LIS_B = [(-.08, .14), (.08, .14), (.12, .3), (0, .5), (-.12, .3)]


def lis(S, cx, cy, s, col, borda=None):
    """Flor-de-lis heraldica (s = altura total)."""
    def P(pts, sg=1):
        return [(cx + sg * x * s, cy + y * s) for x, y in pts]
    polys = [P(_LIS_C), P(_LIS_S, 1), P(_LIS_S, -1), P(_LIS_B)]
    for p in polys:
        pygame.draw.polygon(S, col, p)
    pygame.draw.rect(S, col, (cx - .2 * s, cy + .06 * s, .4 * s, max(2, .08 * s)), 0, 1)
    if borda:
        for p in polys:
            pygame.draw.polygon(S, borda, p, 1)
        pygame.draw.rect(S, borda, (cx - .2 * s, cy + .06 * s, .4 * s, max(2, .08 * s)), 1, 1)


def estrela8(S, cx, cy, r, col, borda=None, raio_int=.46):
    pts = []
    for i in range(16):
        a = PI * i / 8 - PI / 2
        rr = r if i % 2 == 0 else r * raio_int
        pts.append((cx + math.cos(a) * rr, cy + math.sin(a) * rr))
    pygame.draw.polygon(S, col, pts)
    if borda:
        pygame.draw.polygon(S, borda, pts, 1)


def cruz_latina(S, cx, cy, h, col, borda=None, esp=None):
    """Cruz latina centrada; h = altura total."""
    e = esp or max(2, int(h * .13))
    v = pygame.Rect(0, 0, e, h)
    v.midtop = (cx, cy - h // 2)
    hh = pygame.Rect(0, 0, int(h * .6), e)
    hh.center = (cx, cy - h // 2 + int(h * .3))
    for r in (v, hh):
        pygame.draw.rect(S, col, r)
    if borda:
        pygame.draw.rect(S, borda, v, 1)
        pygame.draw.rect(S, borda, hh, 1)


def trifolio(S, cx, cy, r, col, lw=0):
    for a in (-90, 30, 150):
        pygame.draw.circle(S, col, (int(cx + math.cos(math.radians(a)) * r * .6), int(cy + math.sin(math.radians(a)) * r * .6)), int(r * .52), lw)


def quadrifolio(S, cx, cy, r, col, lw=0):
    for a in (0, 90, 180, 270):
        pygame.draw.circle(S, col, (int(cx + math.cos(math.radians(a)) * r * .5), int(cy + math.sin(math.radians(a)) * r * .5)), int(r * .5), lw)


def crucifixo(S, cx, cy, h, madeira=(96, 62, 34), pele=(226, 201, 166)):
    """Crucifixo do seculo XIII: Cristo patiens (corpo em S), perizonio branco, 3 cravos, titulus INRI, caveira de Adao."""
    h = int(h)
    e = max(3, h // 9)
    top = cy - h // 2
    pygame.draw.rect(S, esc(madeira, .55), (cx - e // 2 - 1, top - 1, e + 2, h + 2))
    pygame.draw.rect(S, esc(madeira, .55), (cx - int(h * .33) - 1, top + int(h * .22) - 1, int(h * .66) + 2, e + 2))
    pygame.draw.rect(S, madeira, (cx - e // 2, top, e, h))
    pygame.draw.rect(S, madeira, (cx - int(h * .33), top + int(h * .22), int(h * .66), e))
    pygame.draw.line(S, esc(madeira, 1.3), (cx - e // 2 + 1, top), (cx - e // 2 + 1, top + h), 1)
    # titulus
    pygame.draw.rect(S, (236, 224, 190), (cx - int(h * .1), top + int(h * .07), int(h * .2), max(3, h // 16)))
    # corpo
    s = h / 40.0
    bx = cx
    by = top + int(h * .22) + e // 2
    pele_s = esc(pele, .75)
    pygame.draw.circle(S, pele, (int(bx - s * .8), int(by - s * 1.5)), max(2, int(s * 2.1)))      # cabeca inclinada
    pygame.draw.polygon(S, pele, [(bx - s * 1.8, by + s * .6), (bx + s * 1.8, by + s * .6), (bx + s * 1.3, by + s * 7.5),
                                  (bx + s * .6, by + s * 13), (bx - s * 1.2, by + s * 13), (bx - s * 1.1, by + s * 7.5)])
    pygame.draw.line(S, pele, (bx - s * 1.5, by + s * .6), (cx - int(h * .31), by + s * .2), max(2, int(s * 1.4)))
    pygame.draw.line(S, pele, (bx + s * 1.5, by + s * .6), (cx + int(h * .31), by + s * .2), max(2, int(s * 1.4)))
    pygame.draw.polygon(S, (240, 236, 224), [(bx - s * 1.9, by + s * 7.6), (bx + s * 1.9, by + s * 7.4), (bx + s * 1.5, by + s * 11.5), (bx - s * 2, by + s * 11)])
    pygame.draw.line(S, pele_s, (bx - s * .2, by + s * 1.2), (bx - s * .2, by + s * 7), 1)
    for (nx, ny) in ((cx - int(h * .31), by + s * .2), (cx + int(h * .31), by + s * .2), (bx - s * .1, by + s * 13)):
        pygame.draw.circle(S, (150, 40, 40), (int(nx), int(ny)), max(1, int(s * .6)))
    # caveira de Adao
    pygame.draw.circle(S, (222, 214, 190), (cx, top + h + max(2, int(s * 1.4))), max(2, int(s * 1.9)))
    pygame.draw.rect(S, (222, 214, 190), (cx - int(s * 1.2), top + h + int(s * 1.6), max(2, int(s * 2.4)), max(1, int(s * 1.4))))


# --------------------------------------------------------------------- vitrais
TEMAS = {
    "azul": dict(fundo=[AZUL, (160, 30, 40), AZUL_C], medalhao=[(200, 40, 46), (235, 205, 120), (46, 107, 58)], motivo=("cruz", "lis", "estrela", "rosa")),
    "rubi": dict(fundo=[(150, 26, 34), AZUL, (170, 36, 40)], medalhao=[AZUL_C, (235, 205, 120), (46, 107, 58)], motivo=("lis", "cruz", "estrela", "rosa")),
    "violeta": dict(fundo=[VIOLETA, AZUL, (120, 36, 90)], medalhao=[(236, 210, 130), (200, 40, 46), AZUL_C], motivo=("estrela", "cruz", "rosa", "lis")),
    "grisalha": dict(fundo=[(214, 200, 150), (224, 212, 168), (200, 190, 140)], medalhao=[(170, 120, 50), (150, 170, 120), (190, 80, 60)], motivo=("cruz", "rosa", "estrela", "lis")),
    "ouro": dict(fundo=[(214, 170, 60), (170, 120, 36), (200, 150, 50)], medalhao=[RUBI, AZUL_C, (46, 107, 58)], motivo=("cruz", "lis", "estrela", "rosa")),
    "verde": dict(fundo=[(36, 100, 70), (30, 63, 140), (80, 140, 80)], medalhao=[(236, 220, 150), (200, 40, 46), (200, 160, 220)], motivo=("rosa", "lis", "cruz", "estrela")),
}


def _motivo(S, cx, cy, r, kind, col):
    if kind == "cruz":
        cruz_latina(S, cx, cy, int(r * 1.5), col, None, max(2, int(r * .3)))
    elif kind == "lis":
        lis(S, cx, cy, r * 1.5, col)
    elif kind == "estrela":
        estrela8(S, cx, cy, r * .85, col)
    else:
        for a in range(5):
            aa = a * 2 * PI / 5 - PI / 2
            pygame.draw.circle(S, col, (int(cx + math.cos(aa) * r * .5), int(cy + math.sin(aa) * r * .5)), max(2, int(r * .36)))
        pygame.draw.circle(S, OURO_C, (cx, cy), max(2, int(r * .25)))


def vitral(w, h, seed, tema="azul", med=True, pad=7):
    """Lanceta ogival de vitral (SRCALPHA, w+2pad x h+pad): losangos chumbados, medalhoes, oculo trifoliado e moldura."""
    rnd = random.Random(seed)
    T = TEMAS.get(tema, TEMAS["azul"])
    S = surf(w + 2 * pad, h + pad)
    cx = S.get_width() / 2.0
    rise = min(w * 1.15, h * .55)
    spring = h - rise
    pts = ogiva(cx, pad + h, w, rise, spring)
    glass = surf(w + 2 * pad, h + pad)
    cw, ch = max(10, w // 3), max(14, int(w * .42))
    nrow = int(h / (ch / 2)) + 4
    ncol = int(w / cw) + 4
    for row in range(-1, nrow):
        for col in range(-1, ncol):
            x = pad + col * cw + (cw / 2 if row % 2 else 0)
            y = pad + row * ch / 2
            c = T["fundo"][(row + col * 2) % len(T["fundo"])] if T["fundo"][0] != (214, 200, 150) else rnd.choice(T["fundo"])
            f = rnd.uniform(.82, 1.15) * (1.15 - .4 * min(1, max(0, (y - pad) / h)))
            c = esc(c, f)
            d = [(x, y - ch / 2), (x + cw / 2, y), (x, y + ch / 2), (x - cw / 2, y)]
            pygame.draw.polygon(glass, c, d)
            pygame.draw.polygon(glass, (22, 16, 12), d, 2)
    # medalhoes empilhados
    if med and w >= 36:
        mr = int(w * .30)
        step = int(mr * 2.75)
        y = pad + h - int(mr * 1.7)
        k = 0
        while y > pad + rise + mr * 0.5:
            mc = T["medalhao"][k % len(T["medalhao"])]
            pygame.draw.circle(glass, (22, 16, 12), (int(cx), y), mr + 3)
            pygame.draw.circle(glass, esc(T["medalhao"][(k + 1) % 3], .9), (int(cx), y), mr)
            pygame.draw.circle(glass, (22, 16, 12), (int(cx), y), int(mr * .78))
            pygame.draw.circle(glass, esc(mc, .8), (int(cx), y), int(mr * .72))
            pygame.draw.circle(glass, esc(mc, 1.2), (int(cx - mr * .15), int(y - mr * .15)), int(mr * .42))
            _motivo(glass, int(cx), y, int(mr * .6), T["motivo"][k % 4], (240, 232, 205) if tema != "grisalha" else (110, 70, 40))
            k += 1
            y -= step
    # oculo na cabeca
    oy = int(pad + rise * .46)
    orr = int(w * .26)
    pygame.draw.circle(glass, (22, 16, 12), (int(cx), oy), orr + 3)
    pygame.draw.circle(glass, esc(T["medalhao"][0], 1.0), (int(cx), oy), orr)
    quadrifolio(glass, int(cx), oy, orr * 1.7, esc(T["medalhao"][1], 1.0), 0)
    quadrifolio(glass, int(cx), oy, orr * 1.7, (22, 16, 12), 2)
    pygame.draw.circle(glass, OURO_C, (int(cx), oy), max(2, orr // 3))
    mask = surf(S.get_width(), S.get_height())
    pygame.draw.polygon(mask, (255, 255, 255, 255), pts)
    glass.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    S.blit(glass, (0, 0))
    # montante central e moldura de pedra
    pygame.draw.line(S, (30, 22, 16), (cx, pad + spring + rise * .55), (cx, pad + h), 3)
    for yy in range(pad + int(h * .3), pad + h, int(ch * 1.7)):
        pygame.draw.line(S, (30, 22, 16), (pad + 1, yy), (pad + w - 1, yy), 2)
    if ESTILO[0] == 2 and w >= 30:                       # rendilhado flamejante: montantes e mouchettes na cabeca
        for fx in (-.33, .33):
            pygame.draw.line(S, (30, 22, 16), (cx + fx * w, pad + spring + rise * .5), (cx + fx * w, pad + h), 2)
        for sg in (-1, 1):
            mx = cx + sg * w * .2
            pts_m = [(mx, pad + spring + rise * .72), (mx + sg * w * .12, pad + spring + rise * .52), (mx + sg * w * .05, pad + spring + rise * .3), (mx - sg * w * .06, pad + spring + rise * .5)]
            pygame.draw.polygon(S, (30, 22, 16), pts_m, 2)
    pygame.draw.polygon(S, (60, 50, 38), pts, 5)
    pygame.draw.polygon(S, (150, 138, 116), pts, 2)
    pygame.draw.polygon(S, (24, 18, 12), ogiva(cx, pad + h, w + 10, rise + 5, spring), 2)
    return S


def roda_romanica(R, tema="azul"):
    """Roda romanica (oculo com raios de colunetas e arquinhos), vidro simples e moldura grossa."""
    pad = 6
    S = surf(2 * R + 2 * pad, 2 * R + 2 * pad)
    c = (R + pad, R + pad)
    pedra = (150, 128, 96)
    pygame.draw.circle(S, (22, 16, 12), c, R)
    n = 8
    for i in range(n):
        a0, a1 = 2 * PI * i / n, 2 * PI * (i + 1) / n
        col = (AZUL if i % 2 == 0 else RUBI)
        col = esc(col, 1.0 + .08 * (i % 3))
        pts = [c, (c[0] + R * .92 * math.cos(a0), c[1] + R * .92 * math.sin(a0)), (c[0] + R * .92 * math.cos(a1), c[1] + R * .92 * math.sin(a1))]
        pygame.draw.polygon(S, col, pts)
        am = (a0 + a1) / 2
        pygame.draw.circle(S, (236, 205, 120), (int(c[0] + R * .6 * math.cos(am)), int(c[1] + R * .6 * math.sin(am))), max(2, int(R * .1)))
    for i in range(n):
        a = 2 * PI * i / n
        pygame.draw.line(S, pedra, c, (c[0] + R * math.cos(a), c[1] + R * math.sin(a)), 4)
        qx, qy = c[0] + R * .7 * math.cos(a + PI / n), c[1] + R * .7 * math.sin(a + PI / n)
        pygame.draw.circle(S, pedra, (int(qx), int(qy)), max(3, int(R * .17)), 2)
    pygame.draw.circle(S, pedra, c, int(R * .26))
    pygame.draw.circle(S, OURO_C, c, max(2, int(R * .1)))
    pygame.draw.circle(S, (60, 50, 38), c, R + 2, 6)
    pygame.draw.circle(S, pedra, c, R - 1, 4)
    return S


def gloria_barroca(R):
    """Gloria barroca: raios dourados em leque, nuvem e pomba (Espirito Santo) dentro de um oculo oval com moldura dourada."""
    pad = 6
    S = surf(2 * R + 2 * pad, int(1.5 * R) + 2 * pad)
    cx, cy = S.get_width() // 2, S.get_height() // 2
    el = pygame.Rect(0, 0, 2 * R, int(1.5 * R))
    el.center = (cx, cy)
    pygame.draw.ellipse(S, (250, 226, 150), el)
    for i in range(16):
        a = 2 * PI * i / 16
        pts = [(cx, cy), (cx + R * 1.3 * math.cos(a - .09), cy + R * math.sin(a - .09)), (cx + R * 1.3 * math.cos(a + .09), cy + R * math.sin(a + .09))]
        pygame.draw.polygon(S, (222, 168, 60) if i % 2 else (255, 244, 190), pts)
    mask = surf(S.get_width(), S.get_height())
    pygame.draw.ellipse(mask, (255, 255, 255, 255), el)
    S.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
    pygame.draw.circle(S, (255, 255, 255), (cx, cy), max(3, int(R * .22)))
    pygame.draw.ellipse(S, (255, 255, 255), (cx - R * .2, cy - R * .08, R * .4, R * .16))
    pygame.draw.polygon(S, (255, 255, 255), [(cx - R * .1, cy), (cx - R * .36, cy - R * .22), (cx - R * .18, cy + R * .02)])
    pygame.draw.polygon(S, (255, 255, 255), [(cx + R * .1, cy), (cx + R * .36, cy - R * .22), (cx + R * .18, cy + R * .02)])
    pygame.draw.ellipse(S, OURO_S, el, 5)
    pygame.draw.ellipse(S, OURO, el.inflate(-4, -4), 3)
    pygame.draw.ellipse(S, (30, 20, 8), el.inflate(10, 10), 2)
    return S


def rosacea(R, seed=3, n=12, tema="azul", brilho_k=1.0, moldura=True):
    """Rosacea com rendilhado: aneis, petalas com trifolios, aneis de quadrifolios, centro em rosa. SRCALPHA.
    No andar romanico vira uma roda simples; no barroco, uma gloria oval."""
    if ESTILO[0] == 0:
        return roda_romanica(R, tema)
    if ESTILO[0] == 3:
        return gloria_barroca(R)
    rnd = random.Random(seed)
    T = TEMAS.get(tema, TEMAS["azul"])
    pad = 6
    S = surf(2 * R + 2 * pad, 2 * R + 2 * pad)
    c = (R + pad, R + pad)
    chumbo = (22, 16, 12)
    pedra = (118, 104, 84)
    cores = [AZUL, RUBI, (214, 170, 60), AZUL_C, (46, 120, 70), VIOLETA] if tema != "grisalha" else [(214, 200, 150), (224, 212, 168)]
    if tema == "violeta":
        cores = [VIOLETA, AZUL, RUBI, (214, 170, 60), AZUL_C, (130, 50, 110)]
    # fundo de vidro em setores finos
    pygame.draw.circle(S, chumbo, c, R)
    nseg = n * 2
    for ring, (r0, r1) in enumerate(((R * .12, R * .36), (R * .36, R * .62), (R * .62, R * .96))):
        for i in range(nseg * (1 + ring // 2)):
            m = nseg * (1 + ring // 2)
            a0, a1 = 2 * PI * i / m, 2 * PI * (i + 1) / m
            col = (AZUL if (i // 2 + ring) % 2 == 0 else (RUBI if ring != 1 else (170, 36, 40))) if tema != 'grisalha' else cores[i % 2]
            if tema == 'violeta':
                col = (VIOLETA if (i // 2 + ring) % 2 == 0 else AZUL)
            col = esc(col, rnd.uniform(.9, 1.12) * (1.15 - ring * .1))
            pts = [(c[0] + r1 * math.cos(a), c[1] + r1 * math.sin(a)) for a in (a0, a1)] + \
                  [(c[0] + r0 * math.cos(a), c[1] + r0 * math.sin(a)) for a in (a1, a0)]
            pygame.draw.polygon(S, col, pts)
            pygame.draw.polygon(S, chumbo, pts, 1)
    # petalas externas: circulos pontiagudos com trifolio interno
    pr = R * .2
    for i in range(n):
        a = 2 * PI * i / n + PI / n
        px, py = c[0] + math.cos(a) * R * .72, c[1] + math.sin(a) * R * .72
        col = (AZUL_C if i % 2 else (190, 36, 44)) if tema != 'grisalha' else cores[0]
        pygame.draw.circle(S, chumbo, (int(px), int(py)), int(pr + 3))
        pygame.draw.circle(S, esc(col, 1.1), (int(px), int(py)), int(pr))
        trifolio(S, px, py, pr * 1.05, (236, 200, 90) if tema != 'grisalha' else (190, 170, 110), 0)
        trifolio(S, px, py, pr * 1.05, chumbo, 1)
        pygame.draw.circle(S, pedra, (int(px), int(py)), int(pr + 3), 3)
    # aneis de pedra e raios
    for rr, lw in ((R * .96, 5), (R * .56, 4), (R * .36, 4), (R * .14, 3)):
        pygame.draw.circle(S, pedra, c, int(rr), lw)
        pygame.draw.circle(S, (170, 154, 128), c, int(rr) + lw // 2 - 1, 1)
    for i in range(n):
        a = 2 * PI * i / n
        p0 = (c[0] + math.cos(a) * R * .14, c[1] + math.sin(a) * R * .14)
        p1 = (c[0] + math.cos(a) * R * .96, c[1] + math.sin(a) * R * .96)
        pygame.draw.line(S, pedra, p0, p1, 5)
        pygame.draw.line(S, (170, 154, 128), (p0[0] - 1, p0[1] - 1), (p1[0] - 1, p1[1] - 1), 1)
        # quadrifolio entre raios (anel medio)
        a2 = a + PI / n
        qx, qy = c[0] + math.cos(a2) * R * .46, c[1] + math.sin(a2) * R * .46
        quadrifolio(S, qx, qy, R * .15, (236, 200, 90) if i % 2 else (240, 236, 220), 0)
        quadrifolio(S, qx, qy, R * .15, chumbo, 1)
    # centro: rosa mistica
    pygame.draw.circle(S, chumbo, c, int(R * .15))
    for i in range(8):
        a = 2 * PI * i / 8
        pygame.draw.circle(S, RUBI if i % 2 else (214, 170, 60), (int(c[0] + math.cos(a) * R * .075), int(c[1] + math.sin(a) * R * .075)), max(2, int(R * .05)))
    pygame.draw.circle(S, OURO_C, c, max(2, int(R * .045)))
    if moldura:
        pygame.draw.circle(S, (60, 50, 38), c, R + 2, 5)
        pygame.draw.circle(S, pedra, c, R - 1, 4)
        pygame.draw.circle(S, (170, 154, 128), c, R - 3, 1)
    return S


def feixe(pts, col, amax=70, w=None, h=None):
    """Superficie SRCALPHA com um feixe de luz (poligono) com degrade de alfa vertical."""
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    x0, y0 = int(min(xs)), int(min(ys))
    w = int(max(xs) - x0) + 2
    h = int(max(ys) - y0) + 2
    s = surf(w, h)
    pygame.draw.polygon(s, (col[0], col[1], col[2], amax), [(p[0] - x0, p[1] - y0) for p in pts])
    g = surf(w, h)
    for y in range(h):
        a = int(255 * (1 - .65 * y / h))
        pygame.draw.line(g, (255, 255, 255, a), (0, y), (w, y))
    s.blit(g, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    # suaviza as bordas
    sw, sh = max(2, w // 3), max(2, h // 3)
    s = pygame.transform.smoothscale(pygame.transform.smoothscale(s, (sw, sh)), (w, h))
    return conv(s), (x0, y0)


# --------------------------------------------------------------------- 3D barato
def caixa(S, rect, topo, frente, prof, lado=None, borda=(20, 14, 10)):
    """Caixa vista de cima/3-4: 'rect' = face frontal; 'prof' = altura da face superior (acima da frente)."""
    r = pygame.Rect(rect)
    top = pygame.Rect(r.x, r.y - prof, r.w, prof)
    pygame.draw.rect(S, frente, r)
    pygame.draw.rect(S, topo, top)
    pygame.draw.line(S, esc(topo, 1.25), (top.x, top.y), (top.right - 1, top.y))
    pygame.draw.line(S, esc(frente, .6), (r.x, r.bottom - 1), (r.right - 1, r.bottom - 1))
    pygame.draw.rect(S, esc(frente, 1.12), (r.x, r.y, r.w, 2))
    pygame.draw.rect(S, borda, (r.x, r.y - prof, r.w, r.h + prof), 1)
    pygame.draw.line(S, borda, (r.x, r.y), (r.right - 1, r.y))


def chama_estatica(S, x, y, h, col=(255, 200, 90)):
    pygame.draw.ellipse(S, col, (x - h * .22, y - h, h * .44, h * 1.05))
    pygame.draw.ellipse(S, (255, 244, 200), (x - h * .1, y - h * .55, h * .2, h * .55))


# --------------------------------------------------------------------- pecas de estilo
def coluna_torsa(S, x, y0, y1, w, marmore=(176, 120, 104), ouro=OURO):
    """Coluna salomonica (barroco): fuste torcido com folhas de videira douradas, base e capitel compositos."""
    h = y1 - y0
    sh = pygame.Rect(x - w // 2, y0, w, h)
    pygame.draw.rect(S, esc(marmore, .55), sh)
    k = 0
    for yy in range(int(y0), int(y1) - 4, 5):
        t = (yy - y0) / 6.0
        off = math.sin(t) * w * .32
        col = esc(marmore, 1.18 if k % 2 == 0 else .74)
        pygame.draw.line(S, col, (x - w // 2 + 1, yy + 3 + off * .3), (x + w // 2 - 1, yy - 1 - off * .3), 3)
        k += 1
    for i in range(0, int(h), 11):
        yy = y0 + i
        xx = x + math.sin(i / 6.0) * w * .38
        pygame.draw.ellipse(S, ouro, (xx - 3, yy, 7, 4))
    pygame.draw.rect(S, (20, 12, 8), sh, 1)
    pygame.draw.rect(S, esc(ouro, .8), (x - w // 2 - 3, y1 - 5, w + 6, 7), 0, 2)
    pygame.draw.rect(S, ouro, (x - w // 2 - 3, y1 - 5, w + 6, 2))
    pygame.draw.rect(S, esc(ouro, .8), (x - w // 2 - 4, y0 - 6, w + 8, 8), 0, 2)
    for dx in (-w // 2, w // 2 - 2):
        pygame.draw.circle(S, OURO_C, (x + dx + 1, y0 - 2), 3)
    pygame.draw.rect(S, ouro, (x - w // 2 - 4, y0 - 6, w + 8, 2))


def putto(S, x, y, s=1.0):
    """Anjinho barroco (putto): cabeca de querubim com cachos e asinhas."""
    for sg in (-1, 1):
        pygame.draw.ellipse(S, (250, 244, 232), (x + sg * 11 * s - 7 * s, y - 2 * s, 14 * s, 8 * s))
        pygame.draw.ellipse(S, (170, 150, 120), (x + sg * 11 * s - 7 * s, y - 2 * s, 14 * s, 8 * s), 1)
    pygame.draw.circle(S, (240, 196, 160), (int(x), int(y)), int(7 * s))
    pygame.draw.circle(S, (150, 100, 60), (int(x), int(y - 4 * s)), int(7 * s), 2, draw_top_left=True, draw_top_right=True)
    for sg in (-1, 1):
        pygame.draw.circle(S, (30, 20, 20), (int(x + sg * 2.6 * s), int(y)), max(1, int(1 * s)))
        pygame.draw.circle(S, (230, 120, 110), (int(x + sg * 4.4 * s), int(y + 2.6 * s)), max(1, int(1.6 * s)))


def pinaculo(S, x, y_base, h, w, col):
    """Pinaculo gotico com cogulhos (crockets)."""
    pygame.draw.rect(S, esc(col, .8), (x - w // 2, y_base - h * .45, w, h * .45))
    pygame.draw.polygon(S, col, [(x - w // 2 - 1, y_base - h * .45), (x, y_base - h), (x + w // 2 + 1, y_base - h * .45)])
    pygame.draw.polygon(S, esc(col, .45), [(x - w // 2 - 1, y_base - h * .45), (x, y_base - h), (x + w // 2 + 1, y_base - h * .45)], 1)
    pygame.draw.line(S, esc(col, 1.3), (x - w // 4, y_base - h * .5), (x - 1, y_base - h * .93))
    for k in range(1, 5):
        yy = y_base - h * (.45 + k * .1)
        pygame.draw.circle(S, esc(col, 1.15), (int(x - w * (.42 - k * .06)), int(yy)), 2)
        pygame.draw.circle(S, esc(col, 1.15), (int(x + w * (.42 - k * .06)), int(yy)), 2)
    pygame.draw.circle(S, esc(col, 1.2), (int(x), int(y_base - h) - 1), 2)


def capitel_historiado(S, x, y, w, col):
    """Capitel romanico em almofada com figurinhas esculpidas."""
    pygame.draw.polygon(S, esc(col, .8), [(x - w // 2 + 3, y + 10), (x + w // 2 - 3, y + 10), (x + w // 2 + 4, y), (x - w // 2 - 4, y)])
    pygame.draw.rect(S, esc(col, 1.1), (x - w // 2 - 5, y - 5, w + 10, 6))
    pygame.draw.rect(S, esc(col, .5), (x - w // 2 - 5, y - 5, w + 10, 6), 1)
    for k in range(3):
        xx = x - w // 3 + k * w // 3
        pygame.draw.circle(S, esc(col, 1.25), (xx, y + 3), 2)
        pygame.draw.line(S, esc(col, .45), (xx, y + 5), (xx, y + 9))
        pygame.draw.line(S, esc(col, .45), (xx - 2, y + 7), (xx + 2, y + 7))
