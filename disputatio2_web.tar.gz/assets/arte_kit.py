# -*- coding: utf-8 -*-
"""Kit de desenho procedural com supersampling (apenas pygame + stdlib).

`Tela` e uma superficie SRCALPHA em escala `ss` (2 ou 3); todas as coordenadas sao LOGICAS (px finais).
`final()` reduz com smoothscale -> bordas suavizadas. Usado por arte_personagens, arte_inimigos, arte_fx.
"""
import math

import pygame

INK = (28, 19, 14)
PELE = (232, 190, 152)
BRANCO = (248, 245, 236)
OURO = (214, 170, 60)
OURO_L = (255, 228, 140)
OURO_D = (150, 108, 30)


def mix(a, b, k):
    k = 0.0 if k < 0 else (1.0 if k > 1 else k)
    return (int(a[0] + (b[0] - a[0]) * k), int(a[1] + (b[1] - a[1]) * k), int(a[2] + (b[2] - a[2]) * k))


def lit(c, k=.3):
    return mix(c, (255, 255, 255), k)


def dk(c, k=.3):
    return mix(c, (0, 0, 0), k)


def clamp(v, a, b):
    return a if v < a else (b if v > b else v)


_strips = {}


def strip(stops, n=32, horizontal=False):
    """Superficie 1xN (ou Nx1) com gradiente multi-parada; stops = [cores] igualmente espacadas."""
    k = (tuple(stops), n, horizontal)
    s = _strips.get(k)
    if s is None:
        s = pygame.Surface((n, 1) if horizontal else (1, n), pygame.SRCALPHA)
        m = len(stops) - 1
        for i in range(n):
            f = i / max(1, n - 1) * m
            j = min(m - 1, int(f)) if m > 0 else 0
            c = mix(stops[j], stops[min(m, j + 1)], f - j) if m > 0 else stops[0]
            s.set_at((i, 0) if horizontal else (0, i), (c[0], c[1], c[2], 255))
        _strips[k] = s
    return s


def _grad_surface(st, w, h, horizontal):
    """Gradiente (w,h) a partir de uma 'strip', desenhado linha a linha.
    Substitui smoothscale de superficie 1xN, que causa access violation (crash) no pygame."""
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    n = st.get_width() if horizontal else st.get_height()
    span = w if horizontal else h
    cols = [st.get_at((i, 0) if horizontal else (0, i)) for i in range(n)]
    for i in range(span):
        t = i / max(1, span - 1) * (n - 1)
        i0 = int(t)
        i1 = min(n - 1, i0 + 1)
        f = t - i0
        c0, c1 = cols[i0], cols[i1]
        c = (int(c0[0] + (c1[0] - c0[0]) * f), int(c0[1] + (c1[1] - c0[1]) * f),
             int(c0[2] + (c1[2] - c0[2]) * f), int(c0[3] + (c1[3] - c0[3]) * f))
        if horizontal:
            pygame.draw.line(s, c, (i, 0), (i, h))
        else:
            pygame.draw.line(s, c, (0, i), (w, i))
    return s


_glows = {}


def glow_surf(r, col, a=255):
    k = (r, col, a)
    s = _glows.get(k)
    if s is None:
        s = pygame.Surface((2 * r, 2 * r), pygame.SRCALPHA)
        for i in range(r, 0, -2):
            f = (1 - i / r) ** 2
            pygame.draw.circle(s, (col[0], col[1], col[2], int(a * f)), (r, r), i)
        _glows[k] = s
    return _glows[k]


def catmull(pts, n=8, closed=False):
    """Curva suave passando pelos pontos (Catmull-Rom)."""
    if len(pts) < 3:
        return list(pts)
    P = list(pts)
    if closed:
        P = [P[-1]] + P + [P[0], P[1]]
    else:
        P = [P[0]] + P + [P[-1]]
    out = []
    for i in range(1, len(P) - 2):
        p0, p1, p2, p3 = P[i - 1], P[i], P[i + 1], P[i + 2]
        for k in range(n):
            t = k / n
            t2, t3 = t * t, t * t * t
            out.append((0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t + (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 + (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3),
                        0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t + (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 + (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)))
    if not closed:
        out.append(P[-2])
    return out


def arco(cx, cy, rx, ry, a0, a1, n=16):
    return [(cx + rx * math.cos(a0 + (a1 - a0) * i / n), cy + ry * math.sin(a0 + (a1 - a0) * i / n)) for i in range(n + 1)]


def ik2(sh, hand, l1, l2, lado=1):
    """Cotovelo de um braco de 2 segmentos (lado=+-1 escolhe a dobra)."""
    dx, dy = hand[0] - sh[0], hand[1] - sh[1]
    d = math.hypot(dx, dy)
    d = max(1e-3, min(d, l1 + l2 - 0.01))
    a = (l1 * l1 - l2 * l2 + d * d) / (2 * d)
    h = math.sqrt(max(0.0, l1 * l1 - a * a))
    ux, uy = dx / math.hypot(dx, dy) if (dx or dy) else 1, dy / math.hypot(dx, dy) if (dx or dy) else 0
    mx, my = sh[0] + ux * a, sh[1] + uy * a
    return (mx - uy * h * lado, my + ux * h * lado)


class Tela:
    def __init__(self, w, h, ss=2):
        self.w, self.h, self.ss = w, h, ss
        self.S = pygame.Surface((int(w * ss), int(h * ss)), pygame.SRCALPHA)

    # ---------------------------------------------------------------- basico
    def P(self, pts):
        s = self.ss
        return [(x * s, y * s) for x, y in pts]

    def poly(self, pts, fill=None, ol=None, ow=1.0):
        p = self.P(pts)
        if len(p) < 3:
            return
        if fill is not None:
            pygame.draw.polygon(self.S, fill, p)
        if ol is not None:
            pygame.draw.polygon(self.S, ol, p, max(1, int(ow * self.ss)))

    def circ(self, x, y, r, fill=None, ol=None, ow=1.0):
        s = self.ss
        if fill is not None:
            pygame.draw.circle(self.S, fill, (x * s, y * s), max(1, r * s))
        if ol is not None:
            pygame.draw.circle(self.S, ol, (x * s, y * s), max(1, r * s), max(1, int(ow * s)))

    def ell(self, x, y, w, h, fill=None, ol=None, ow=1.0, rot=0.0):
        """Elipse por CENTRO e tamanho total."""
        if rot:
            pts = []
            cr, sr = math.cos(rot), math.sin(rot)
            for i in range(28):
                a = math.tau * i / 28
                ex, ey = math.cos(a) * w / 2, math.sin(a) * h / 2
                pts.append((x + ex * cr - ey * sr, y + ex * sr + ey * cr))
            self.poly(pts, fill, ol, ow)
            return
        s = self.ss
        r = pygame.Rect(0, 0, max(2, int(w * s)), max(2, int(h * s)))
        r.center = (int(x * s), int(y * s))
        if fill is not None:
            pygame.draw.ellipse(self.S, fill, r)
        if ol is not None:
            pygame.draw.ellipse(self.S, ol, r, max(1, int(ow * s)))

    def rect(self, x, y, w, h, fill=None, ol=None, ow=1.0, rad=0):
        s = self.ss
        r = pygame.Rect(int(x * s), int(y * s), max(1, int(w * s)), max(1, int(h * s)))
        if fill is not None:
            pygame.draw.rect(self.S, fill, r, 0, int(rad * s))
        if ol is not None:
            pygame.draw.rect(self.S, ol, r, max(1, int(ow * s)), int(rad * s))

    def line(self, a, b, col, w=1.0):
        s = self.ss
        wi = max(1, int(w * s))
        pygame.draw.line(self.S, col, (a[0] * s, a[1] * s), (b[0] * s, b[1] * s), wi)
        if wi > 3:
            pygame.draw.circle(self.S, col, (a[0] * s, a[1] * s), wi / 2)
            pygame.draw.circle(self.S, col, (b[0] * s, b[1] * s), wi / 2)

    def pline(self, pts, col, w=1.0, closed=False):
        p = self.P(pts)
        wi = max(1, int(w * self.ss))
        if len(p) > 1:
            pygame.draw.lines(self.S, col, closed, p, wi)
            if wi > 3:
                for q in (p if closed else (p[0], p[-1])):
                    pygame.draw.circle(self.S, col, q, wi / 2)

    def tube(self, pts, w0, w1, fill, ol=None, ow=1.0, smooth=True, caps=True):
        """Tubo de largura variavel ao longo de uma polilinha (membros, caudas, serpentes)."""
        c = catmull(pts, 6) if smooth and len(pts) > 2 else list(pts)
        n = len(c)
        L, R = [], []
        for i, (x, y) in enumerate(c):
            a = c[max(0, i - 1)]
            b = c[min(n - 1, i + 1)]
            dx, dy = b[0] - a[0], b[1] - a[1]
            d = math.hypot(dx, dy) or 1
            nx, ny = -dy / d, dx / d
            w = (w0 + (w1 - w0) * i / max(1, n - 1)) / 2
            L.append((x + nx * w, y + ny * w))
            R.append((x - nx * w, y - ny * w))
        poly = L + R[::-1]
        if ol is not None:
            self.poly(poly, ol, ol, ow * 1.6)
            if caps:
                for (x, y), w in ((c[0], w0), (c[-1], w1)):
                    self.circ(x, y, w / 2 + ow * .8, ol)
        self.poly(poly, fill, None)
        if caps:
            for (x, y), w in ((c[0], w0), (c[-1], w1)):
                self.circ(x, y, w / 2, fill)
        return c

    def arc(self, cx, cy, rx, ry, a0, a1, col, w=1.0, n=20):
        self.pline(arco(cx, cy, rx, ry, a0, a1, n), col, w)

    # ------------------------------------------------------------ gradientes
    def _clip_fill(self, pts_scaled, surf_fn):
        xs = [p[0] for p in pts_scaled]
        ys = [p[1] for p in pts_scaled]
        x0, y0 = int(max(0, min(xs) - 2)), int(max(0, min(ys) - 2))
        x1, y1 = int(min(self.S.get_width(), max(xs) + 3)), int(min(self.S.get_height(), max(ys) + 3))
        w, h = x1 - x0, y1 - y0
        if w < 2 or h < 2:
            return
        mask = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(mask, (255, 255, 255, 255), [(x - x0, y - y0) for x, y in pts_scaled])
        g = surf_fn(w, h)
        g.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        self.S.blit(g, (x0, y0))

    def gpoly(self, pts, stops, ol=None, ow=1.0, horizontal=False):
        """Poligono com gradiente (stops = lista de cores)."""
        if not isinstance(stops, (list, tuple)) or (stops and isinstance(stops[0], int)):
            stops = [stops, stops]
        p = self.P(pts)
        st = strip(stops, 32, horizontal)
        self._clip_fill(p, lambda w, h: _grad_surface(st, w, h, horizontal))
        if ol is not None:
            pygame.draw.polygon(self.S, ol, p, max(1, int(ow * self.ss)))

    def gell(self, x, y, w, h, stops, ol=None, ow=1.0, horizontal=False, rot=0.0):
        pts = []
        cr, sr = math.cos(rot), math.sin(rot)
        for i in range(32):
            a = math.tau * i / 32
            ex, ey = math.cos(a) * w / 2, math.sin(a) * h / 2
            pts.append((x + ex * cr - ey * sr, y + ex * sr + ey * cr))
        self.gpoly(pts, stops, ol, ow, horizontal)

    def gcirc(self, x, y, r, stops, ol=None, ow=1.0, horizontal=False):
        self.gell(x, y, 2 * r, 2 * r, stops, ol, ow, horizontal)

    def clip_poly(self, pts, draw_fn):
        """Executa draw_fn(tela_temp) e so mantem o que cair dentro do poligono."""
        p = self.P(pts)
        tmp = Tela(self.w, self.h, self.ss)

        def fn(w, h):
            return None
        draw_fn(tmp)
        mask = pygame.Surface(self.S.get_size(), pygame.SRCALPHA)
        pygame.draw.polygon(mask, (255, 255, 255, 255), p)
        tmp.S.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        self.S.blit(tmp.S, (0, 0))

    def luz(self, x, y, r, col, a=200):
        g = glow_surf(int(r * self.ss), col, a)
        self.S.blit(g, (x * self.ss - g.get_width() / 2, y * self.ss - g.get_height() / 2))

    def luz_add(self, x, y, r, col, a=200):
        g = glow_surf(int(r * self.ss), col, a)
        tmp = pygame.Surface(g.get_size(), pygame.SRCALPHA)
        tmp.blit(g, (0, 0))
        self.S.blit(tmp, (x * self.ss - g.get_width() / 2, y * self.ss - g.get_height() / 2), special_flags=pygame.BLEND_RGBA_ADD)

    def blit_surf(self, surf, x, y, escala=None, rot=0.0, centro=True):
        """Desenha uma Surface logica (ja em px finais) na tela, centrada em (x,y)."""
        s = self.ss
        im = surf
        if escala or rot:
            im = pygame.transform.rotozoom(surf, rot, (escala or 1.0))
        if s != 1:
            im = pygame.transform.smoothscale(im, (max(1, int(im.get_width() * s)), max(1, int(im.get_height() * s))))
        r = im.get_rect(center=(x * s, y * s)) if centro else im.get_rect(topleft=(x * s, y * s))
        self.S.blit(im, r)

    def icone(self, iid, x, y, tam, cor=None, t=0.0):
        from icones import desenhar_icone
        tmp = pygame.Surface((int(tam) + 8, int(tam) + 8), pygame.SRCALPHA)
        desenhar_icone(tmp, iid, (tmp.get_width() / 2, tmp.get_height() / 2), tam, cor, t)
        self.blit_surf(tmp, x, y)

    def final(self, tam=None):
        if self.ss == 1 and tam is None:
            return self.S
        return pygame.transform.smoothscale(self.S, tam or (int(self.w), int(self.h)))


# =================================================================== rostos
def olho(T, x, y, r, mood="neutro", look=(0.0, 0.0), iris=(70, 46, 30), lado=1, fechado=False, esc=(250, 248, 240),
         cilio=None, sobr=None):
    """Olho expressivo. mood: neutro|bravo|triste|surpreso|feliz|cansado|louco. lado=-1/+1 para sobrancelha."""
    if fechado or mood == "feliz":
        if mood == "feliz" and not fechado:
            T.arc(x, y + r * .4, r * 2, r * 1.6, math.pi * 1.1, math.pi * 1.9, INK, max(1.0, r * .45))
        else:
            T.arc(x, y - r * .3, r * 2, r * 1.3, math.pi * .12, math.pi * .88, INK, max(1.0, r * .4))
    else:
        hh = r * (1.15 if mood in ("surpreso", "louco") else (.62 if mood in ("cansado", "bravo") else .95))
        T.ell(x, y, r * 2.1, hh * 2, esc, INK, max(.8, r * .2))
        px = x + look[0] * r * .55
        py = y + look[1] * r * .45 + (r * .12 if mood == "cansado" else 0)
        ir = r * (.42 if mood in ("surpreso", "louco") else .62)
        T.circ(px, py, ir, iris)
        T.circ(px, py, ir * .5, INK)
        T.circ(px - ir * .35, py - ir * .4, max(.5, ir * .28), (255, 255, 255))
    if sobr is not False:
        by = y - r * (1.7 if mood != "surpreso" else 2.2)
        bw = r * 1.3
        if mood == "bravo":
            T.line((x + lado * bw, by - r * .55), (x - lado * bw, by + r * .4), INK if sobr is None else sobr, max(1.2, r * .55))
        elif mood == "triste":
            T.line((x + lado * bw, by + r * .5), (x - lado * bw, by - r * .35), INK if sobr is None else sobr, max(1.2, r * .5))
        elif mood == "surpreso":
            T.arc(x, by + r * .6, bw * 2, r * 1.3, math.pi * 1.1, math.pi * 1.9, INK if sobr is None else sobr, max(1.2, r * .45))
        elif mood == "louco":
            T.line((x - lado * bw, by - r * .6), (x + lado * bw, by + r * .2), INK if sobr is None else sobr, max(1.2, r * .55))
        else:
            T.line((x - bw, by + r * .1), (x + bw, by - r * .1), INK if sobr is None else sobr, max(1.2, r * .45))


def boca(T, x, y, w, mood="neutro", abre=0.0, dentes=False, col=(110, 36, 30)):
    if abre > 0.05 or mood in ("grito", "surpreso"):
        h = max(w * .35, w * (abre or .6))
        T.ell(x, y + h * .3, w, h, (70, 14, 16), INK, max(.8, w * .09))
        if dentes:
            T.poly([(x - w * .38, y + h * .02), (x + w * .38, y + h * .02), (x + w * .3, y + h * .34), (x - w * .3, y + h * .34)], (250, 248, 235))
        T.ell(x, y + h * .6, w * .6, h * .4, (190, 70, 80))
    elif mood in ("feliz", "sorriso"):
        T.arc(x, y - w * .2, w, w * .8, math.pi * .12, math.pi * .88, INK, max(1.0, w * .12))
    elif mood in ("bravo", "triste"):
        T.arc(x, y + w * .5, w, w * .8, math.pi * 1.12, math.pi * 1.88, INK, max(1.0, w * .12))
    elif mood == "sorriso_mau":
        T.arc(x, y - w * .25, w * 1.2, w * .9, math.pi * .1, math.pi * .9, INK, max(1.0, w * .12))
        T.poly([(x - w * .5, y + w * .12), (x - w * .33, y + w * .36), (x - w * .17, y + w * .2)], (250, 248, 235))
        T.poly([(x + w * .5, y + w * .12), (x + w * .33, y + w * .36), (x + w * .17, y + w * .2)], (250, 248, 235))
    else:
        T.line((x - w * .5, y), (x + w * .5, y), INK, max(1.0, w * .12))


# ============================================================ efeitos de imagem
def tint(surf, rgb, add=True):
    """Copia da superficie com cor somada (flash)."""
    s = surf.copy()
    s.fill((rgb[0], rgb[1], rgb[2], 0), special_flags=pygame.BLEND_RGB_ADD if add else pygame.BLEND_RGB_MULT)
    return s


def contorno(surf, col=INK, esp=2, sombra=False):
    """Retorna superficie com contorno externo (silhueta deslocada) em volta."""
    m = pygame.mask.from_surface(surf, 40)
    sil = m.to_surface(setcolor=col + (255,) if len(col) == 3 else col, unsetcolor=(0, 0, 0, 0))
    w, h = surf.get_size()
    out = pygame.Surface((w + 2 * esp + 2, h + 2 * esp + 2), pygame.SRCALPHA)
    if sombra:
        sh = m.to_surface(setcolor=(0, 0, 0, 90), unsetcolor=(0, 0, 0, 0))
        out.blit(sh, (esp + 1 + esp, esp + 1 + esp))
    for dx in range(-esp, esp + 1):
        for dy in range(-esp, esp + 1):
            if dx * dx + dy * dy <= esp * esp + 1 and (dx or dy):
                out.blit(sil, (esp + 1 + dx, esp + 1 + dy))
    out.blit(surf, (esp + 1, esp + 1))
    return out
