# -*- coding: utf-8 -*-
"""Desenho procedural (resolucao logica 960x540, paisagem): texto, paineis, botoes, cenarios, personagens.

Organizacao (para a arte ser refinada depois, funcao a funcao):
  texto/UI ........ font, txt, draw_text, outlined, fit_text, panel, draw_button, draw_round, balao, draw_bar
  cenarios ........ make_hall (combate/titulo), make_room_bg (exploracao), draw_door, desenhar_cena_titulo
  personagens ..... draw_scholar, hero_sprite, hero_sala, sprites dos inimigos (FORMAS)
  icones .......... icones.py (desenhar_icone)
"""
import math
import random

import pygame

from icones import desenhar_icone, existe as icone_existe, nome_padrao  # noqa: F401

W, H = 960, 540
MIN_FONT = 22
GOLD = (214, 170, 60)
GOLD_L = (255, 228, 140)
INK = (43, 29, 14)
PARCH = (243, 230, 196)
RED = (214, 80, 70)
GREEN = (120, 210, 120)

CAT_COR = {"ratio": (90, 150, 235), "auctoritas": (232, 184, 70),
           "distinguo": (176, 118, 226), "apoio": (96, 206, 126)}
CAT_NOME = {"ratio": "Ratio", "auctoritas": "Auctoritas", "distinguo": "Distinguo", "apoio": "Apoio"}
CAT_ICONE = {"ratio": "ratio", "auctoritas": "auctoritas", "distinguo": "distinguo", "apoio": "apoio"}

# geometria da sala de exploracao (coordenadas de tela)
ROOM = pygame.Rect(0, 0, W, H)
FL = pygame.Rect(60, 120, 840, 380)          # piso caminhavel
DOOR_HW = 44
DOOR_C = {"N": (480, 120), "S": (480, 500), "W": (60, 310), "E": (900, 310)}

def cvt(s):
    try:
        if pygame.display.get_surface():
            return s.convert_alpha() if s.get_flags() & pygame.SRCALPHA else s.convert()
    except Exception:
        pass
    return s


# ------------------------------------------------------------------ texto
_fc = {}
_tc = {}


def font(sz, bold=False):
    sz = max(MIN_FONT, int(sz))
    k = (sz, bold)
    if k not in _fc:
        f = pygame.font.Font(None, sz)
        f.set_bold(bold)
        _fc[k] = f
    return _fc[k]


def txt(text, sz, col, bold=False):
    k = (text, sz, col, bold)
    s = _tc.get(k)
    if s is None:
        if len(_tc) > 1800:
            _tc.clear()
        s = font(sz, bold).render(text, True, col)
        _tc[k] = s
    return s


def draw_text(S, text, sz, col, pos, anchor="center", bold=False, shadow=(0, 0, 0), sh=2):
    img = txt(text, sz, col, bold)
    r = img.get_rect()
    setattr(r, anchor, pos)
    if shadow:
        S.blit(txt(text, sz, shadow, bold), (r.x + sh, r.y + sh))
    S.blit(img, r)
    return r


def outlined(S, text, sz, col, pos, th=3, anchor="center", hi=None, outline=(30, 14, 4)):
    f = font(sz, True)
    img = txt(text, sz, col, True)
    r = img.get_rect()
    setattr(r, anchor, pos)
    edge = txt(text, sz, outline, True)
    for a in range(0, 360, 30):
        S.blit(edge, (r.x + round(math.cos(math.radians(a)) * th), r.y + round(math.sin(math.radians(a)) * th)))
    S.blit(img, r)
    if hi:
        S.set_clip(pygame.Rect(r.x, r.y, r.w, int(r.h * 0.5)))
        S.blit(txt(text, sz, hi, True), r)
        S.set_clip(None)
    return r


def wrap(text, f, width):
    out = []
    for para in str(text).split("\n"):
        words = para.split()
        cur = ""
        for w in words:
            t = (cur + " " + w).strip()
            if f.size(t)[0] <= width or not cur:
                cur = t
            else:
                out.append(cur)
                cur = w
        out.append(cur)
    return out


_ft = {}


def fit_text(text, width, max_h, sz_max=28, sz_min=18, bold=False):
    """Escolhe o maior corpo (sz_max..sz_min) em que o texto cabe em width x max_h."""
    k = (text, width, max_h, sz_max, sz_min, bold)
    if k in _ft:
        return _ft[k]
    res = None
    for sz in range(sz_max, sz_min - 1, -2):
        f = font(sz, bold)
        lines = wrap(text, f, width)
        lh = f.get_linesize()
        if len(lines) * lh <= max_h:
            res = (sz, lines, lh)
            break
    if res is None:
        sz = sz_min
        f = font(sz, bold)
        lines = wrap(text, f, width)
        lh = f.get_linesize()
        n = max(1, max_h // lh)
        if len(lines) > n:
            lines = lines[:n]
            lines[-1] = lines[-1].rstrip(" .,;") + "..."
        res = (sz, lines, lh)
    if len(_ft) > 800:
        _ft.clear()
    _ft[k] = res
    return res


def draw_lines(S, lines, sz, col, x, y, lh, center=False, shadow=None, bold=False):
    for i, ln in enumerate(lines):
        img = txt(ln, sz, col, bold)
        if shadow:
            S.blit(txt(ln, sz, shadow, bold), ((x - img.get_width() // 2 if center else x) + 1, y + i * lh + 1))
        S.blit(img, (x - img.get_width() // 2 if center else x, y + i * lh))
    return y + len(lines) * lh


def trunc(text, sz, width):
    f = font(sz)
    if f.size(text)[0] <= width:
        return text
    while text and f.size(text + "...")[0] > width:
        text = text[:-1]
    return text.rstrip() + "..."


def lerp(a, b, t):
    return a + (b - a) * t


def mix(c1, c2, t):
    return tuple(max(0, min(255, int(lerp(c1[i], c2[i], t)))) for i in range(3))


def clampc(c):
    return tuple(max(0, min(255, int(v))) for v in c)


def vgrad(w, h, c1, c2):
    s = pygame.Surface((w, h))
    for y in range(h):
        pygame.draw.line(s, mix(c1, c2, y / max(1, h - 1)), (0, y), (w, y))
    return s


_glow = {}


def make_glow(r, col):
    k = (r, col)
    if k not in _glow:
        s = pygame.Surface((2 * r, 2 * r))
        s.fill((0, 0, 0))
        for rr in range(r, 0, -2):
            kk = (1 - rr / r) ** 2
            pygame.draw.circle(s, (int(col[0] * kk), int(col[1] * kk), int(col[2] * kk)), (r, r), rr)
        _glow[k] = cvt(s)
    return _glow[k]


def add_glow(S, pos, r, col, k=1.0):
    g = make_glow(r, col)
    if k != 1.0:
        sz = max(2, int(2 * r * k))
        g = pygame.transform.scale(g, (sz, sz))
    S.blit(g, g.get_rect(center=(int(pos[0]), int(pos[1]))), special_flags=pygame.BLEND_RGB_ADD)


_vig = {}


def vignette(w, h, n=70, amax=150):
    k = (w, h, n, amax)
    if k not in _vig:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        for i in range(n):
            a = int(amax * (1 - i / n) ** 2.2)
            pygame.draw.rect(s, (0, 0, 0, a), (i, i, w - 2 * i, h - 2 * i), 1)
        _vig[k] = cvt(s)
    return _vig[k]


_dim = {}


def dim_surface(alpha=170):
    if alpha not in _dim:
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        s.fill((6, 3, 2, alpha))
        _dim[alpha] = cvt(s)
    return _dim[alpha]


_sh = {}


def shadow(S, cx, cy, w, h, a=1.0):
    k = (w, h)
    if k not in _sh:
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        for i in range(4):
            pygame.draw.ellipse(s, (0, 0, 0, 38), (i * w // 12, i * h // 12, w - 2 * i * w // 12, h - 2 * i * h // 12))
        _sh[k] = cvt(s)
    S.blit(_sh[k], (cx - w // 2, cy - h // 2))


# ------------------------------------------------------------- paineis / botoes
_pc = {}


def panel(S, rect, alpha=236, estilo="couro"):
    import arte_ui
    S.blit(arte_ui.painel(rect.w, rect.h, alpha, estilo), rect.topleft)


BTN_COL = {
    "normal": ((250, 238, 208), (224, 202, 152)),
    "press": ((228, 210, 164), (200, 176, 120)),
    "ok": ((184, 236, 156), (112, 192, 102)),
    "bad": ((244, 166, 154), (208, 92, 82)),
    "dim": ((150, 136, 108), (116, 104, 82)),
    "gold": ((255, 224, 130), (214, 160, 50)),
    "sel": ((200, 226, 250), (140, 176, 226)),
}
_bc = {}


def _btn_surface(w, h, state, label, sz, letter, accent, icone):
    c1, c2 = BTN_COL[state]
    import arte_ui
    tmp = arte_ui.botao(w, h, c1, c2, state == "dim").copy()
    if accent:
        pygame.draw.rect(tmp, accent, (10, 10, 6, h - 20), 0, 3)
    tcol = INK if state != "dim" else (70, 60, 44)
    left = 0
    if icone:
        r = h // 2 - 7
        c = (r + 12, h // 2)
        pygame.draw.circle(tmp, (44, 28, 12), c, r)
        pygame.draw.circle(tmp, GOLD if state != "dim" else (110, 96, 70), c, r, 3)
        desenhar_icone(tmp, icone, c, int(r * 1.35))
        left = 2 * r + 10
    elif letter:
        c = (36, h // 2)
        pygame.draw.circle(tmp, (60, 40, 12), c, 20)
        pygame.draw.circle(tmp, GOLD if state not in ("ok", "bad") else (255, 255, 255), c, 17)
        if state == "ok":
            pygame.draw.lines(tmp, (30, 120, 40), False, [(c[0] - 8, c[1]), (c[0] - 2, c[1] + 7), (c[0] + 9, c[1] - 8)], 5)
        elif state == "bad":
            pygame.draw.line(tmp, (170, 30, 30), (c[0] - 7, c[1] - 7), (c[0] + 7, c[1] + 7), 5)
            pygame.draw.line(tmp, (170, 30, 30), (c[0] + 7, c[1] - 7), (c[0] - 7, c[1] + 7), 5)
        else:
            img = font(30, True).render(letter, True, INK)
            tmp.blit(img, img.get_rect(center=c))
        left = 62
    elif accent:
        left = 14
    width = w - left - 20
    if label:
        sz2, lines, lh = fit_text(label, width, h - 14, sz, 22)
        total = lh * len(lines)
        y0 = h // 2 - total // 2 + 1
        for i, ln in enumerate(lines):
            img = txt(ln, sz2, tcol)
            x = left + 10 + (width - img.get_width()) // 2 if not letter else left + 4
            tmp.blit(img, (x, y0 + i * lh))
    return cvt(tmp)


def draw_button(S, rect, label, state="normal", sz=28, pressed=False, letter=None, accent=None, icone=None):
    if pressed and state in ("normal", "gold"):
        state = "press" if state == "normal" else "gold"
    k = (rect.w, rect.h, state, label, sz, letter, accent, icone)
    s = _bc.get(k)
    if s is None:
        if len(_bc) > 500:
            _bc.clear()
        s = _bc[k] = _btn_surface(rect.w, rect.h, state, label, sz, letter, accent, icone)
    S.blit(s, (rect.x, rect.y + (2 if pressed else 0)))


_rb = {}
RB_COL = {"normal": ((255, 244, 214), (214, 180, 112)), "gold": ((255, 232, 150), (214, 150, 44)),
          "dim": ((150, 138, 112), (96, 86, 66)), "ok": ((190, 240, 160), (96, 180, 90)),
          "bad": ((246, 170, 156), (200, 84, 76)), "sel": ((210, 232, 252), (120, 160, 220)),
          "dark": ((70, 52, 34), (34, 22, 12))}


def _round_surface(r, state):
    k = (r, state)
    if k not in _rb:
        if len(_rb) > 60:
            _rb.clear()
        c1, c2 = RB_COL[state]
        import arte_ui
        _rb[k] = arte_ui.medalhao(r, c1, c2, state == "dim")
    return _rb[k]


def draw_round(S, c, r, icone=None, label=None, state="normal", pressed=False, pulse=False, t=0.0, cor=None, lsz=22,
               isz=None, label_dentro=False):
    """Botao redondo com icone grande e (opcional) rotulo de 1 palavra logo abaixo. c = centro."""
    if pulse and state != "dim":
        add_glow(S, c, int(r * 1.7), cor or GOLD, 0.55 + 0.45 * (0.5 + 0.5 * math.sin(t * 6)))
    s = _round_surface(r, "sel" if (pressed and state == "normal") else state)
    S.blit(s, (c[0] - r - 4, c[1] - r - 4 + (2 if pressed else 0)))
    if icone:
        sz = isz or int(r * (1.15 if label else 1.35))
        yy = c[1] + (2 if pressed else 0)
        if state == "dim":
            tmp = pygame.Surface((sz + 8, sz + 8), pygame.SRCALPHA)
            desenhar_icone(tmp, icone, (sz // 2 + 4, sz // 2 + 4), sz, cor, t)
            tmp.set_alpha(120)
            S.blit(tmp, (c[0] - sz // 2 - 4, yy - sz // 2 - 4))
        else:
            desenhar_icone(S, icone, (c[0], yy), sz, cor, t)
    if label:
        draw_text(S, label, lsz, PARCH if state != "dim" else (150, 138, 112), (c[0], c[1] + r + 14), bold=True, sh=1)


def balao(S, rect, linhas, sz, tail=None, col=(250, 242, 220), borda=(90, 60, 20), tcol=INK, lh=None):
    """Balao de fala: linhas (<=2). tail = ponto (x,y) para onde aponta."""
    rect = pygame.Rect(rect)
    import arte_ui
    arte_ui.caixa_balao(S, rect, tail, col, borda)
    f = font(sz)
    lh = lh or f.get_linesize()
    y = rect.centery - lh * len(linhas) // 2
    for ln in linhas:
        im = txt(ln, sz, tcol)
        S.blit(im, (rect.centerx - im.get_width() // 2, y))
        y += lh


def balao_texto(S, texto, cx, y, maxw, sz=26, tail=None, col=(250, 242, 220), minw=0):
    """Mede e desenha balao de ate 2 linhas centrado em cx, topo y. Retorna o Rect."""
    f = font(sz)
    linhas = wrap(texto, f, maxw)[:2]
    if len(wrap(texto, f, maxw)) > 2:
        linhas[1] = linhas[1].rstrip(" .,;") + "..."
    w = max(max(f.size(l)[0] for l in linhas) + 36, minw)
    lh = f.get_linesize()
    h = lh * len(linhas) + 22
    r = pygame.Rect(0, 0, w, h)
    r.midtop = (int(max(w // 2 + 8, min(W - w // 2 - 8, cx))), int(y))
    balao(S, r, linhas, sz, tail, col)
    return r




def draw_bar(S, rect, frac, c1, c2, label=None, lsz=20):
    import arte_ui
    arte_ui.barra(S, rect, frac, c1, c2)
    if label:
        draw_text(S, label, lsz, (255, 255, 255), rect.center, shadow=(0, 0, 0), sh=1)
    return
    frac = max(0.0, min(1.0, frac))
    pygame.draw.rect(S, (10, 6, 3), rect, 0, rect.h // 2 + 1)
    inner = rect.inflate(-4, -4)
    w = int(inner.w * frac)
    if w > 1:
        r = pygame.Rect(inner.x, inner.y, w, inner.h)
        pygame.draw.rect(S, c2, r, 0, inner.h // 2 + 1)
        pygame.draw.rect(S, c1, (r.x, r.y, r.w, max(2, r.h // 2)), 0, inner.h // 2)
        pygame.draw.line(S, (255, 255, 255), (r.x + 3, r.y + 1), (r.right - 4, r.y + 1), 1)
    pygame.draw.rect(S, (150, 116, 44), rect, 2, rect.h // 2 + 1)
    if label:
        draw_text(S, label, lsz, (255, 255, 255), rect.center, shadow=(0, 0, 0), sh=1)


def draw_coin(S, x, y, r=9):
    pygame.draw.circle(S, (120, 80, 14), (x, y), r + 1)
    pygame.draw.circle(S, GOLD, (x, y), r)
    pygame.draw.circle(S, GOLD_L, (x - r // 4, y - r // 4), max(2, r // 2))
    pygame.draw.circle(S, (160, 110, 20), (x, y), r, 1)


def draw_arrow(S, cx, cy, d, col, sz=10):
    """Seta triangular: d em 'l','r','u','d'."""
    p = {"l": [(cx + sz, cy - sz), (cx - sz, cy), (cx + sz, cy + sz)],
         "r": [(cx - sz, cy - sz), (cx + sz, cy), (cx - sz, cy + sz)],
         "u": [(cx - sz, cy + sz), (cx, cy - sz), (cx + sz, cy + sz)],
         "d": [(cx - sz, cy - sz), (cx, cy + sz), (cx + sz, cy - sz)]}[d]
    pygame.draw.polygon(S, col, p)


# --------------------------------------------------------- cenario (preparado em cache)
PAL = [(196, 44, 44), (44, 96, 200), (226, 176, 44), (54, 156, 84), (128, 66, 170), (236, 124, 44)]


def arch_pts(cx, top, w, h):
    spring = top + w * 0.866
    pts = [(cx - w / 2, top + h), (cx - w / 2, spring)]
    for i in range(1, 13):
        a = math.radians(180 - 60 * i / 12)
        pts.append((cx + w / 2 + w * math.cos(a), spring - w * math.sin(a)))
    for i in range(1, 13):
        a = math.radians(60 - 60 * i / 12)
        pts.append((cx - w / 2 + w * math.cos(a), spring - w * math.sin(a)))
    pts.append((cx + w / 2, top + h))
    return pts


def make_window(w, h, seed):
    rnd = random.Random(seed)
    pad = 8
    S = pygame.Surface((w + 2 * pad, h + pad), pygame.SRCALPHA)
    cx = S.get_width() / 2
    pts = arch_pts(cx, pad, w, h)
    glass = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    glass.fill((20, 14, 10, 255))
    cw, ch = 24, 34
    for row in range(-1, int(h / (ch / 2)) + 3):
        for col in range(-1, int(w / cw) + 3):
            x = pad + col * cw + (cw / 2 if row % 2 else 0)
            y = pad + row * ch / 2
            base = rnd.choice(PAL)
            f = 1.2 - 0.55 * min(1, max(0, y / h))
            c = tuple(min(255, int(v * f)) for v in base)
            d = [(x, y - ch / 2), (x + cw / 2, y), (x, y + ch / 2), (x - cw / 2, y)]
            pygame.draw.polygon(glass, c, d)
            pygame.draw.polygon(glass, (26, 18, 12), d, 2)
    mask = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    pygame.draw.polygon(mask, (255, 255, 255, 255), pts)
    glass.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    S.blit(glass, (0, 0))
    pygame.draw.polygon(S, (118, 98, 70), pts, 8)
    pygame.draw.polygon(S, (60, 46, 30), pts, 2)
    pygame.draw.line(S, (30, 22, 14), (cx, pad + w * 0.85), (cx, h + pad - 1), 4)
    return S


def make_rose(R=84):
    S = pygame.Surface((2 * R + 10, 2 * R + 10), pygame.SRCALPHA)
    c = (R + 5, R + 5)
    n = 12
    for ring, (r0, r1) in enumerate([(R * 0.62, R), (R * 0.3, R * 0.62)]):
        for i in range(n):
            a0 = 2 * math.pi * i / n
            a1 = 2 * math.pi * (i + 1) / n
            pts = [(c[0] + r1 * math.cos(a), c[1] + r1 * math.sin(a)) for a in (a0, a1)]
            pts += [(c[0] + r0 * math.cos(a), c[1] + r0 * math.sin(a)) for a in (a1, a0)]
            pygame.draw.polygon(S, PAL[(i + ring * 2) % len(PAL)], pts)
            pygame.draw.polygon(S, (28, 20, 14), pts, 2)
    pygame.draw.circle(S, (250, 216, 110), c, int(R * 0.3))
    pygame.draw.circle(S, (28, 20, 14), c, int(R * 0.3), 3)
    for i in range(6):
        a = math.pi * 2 * i / 6
        pygame.draw.circle(S, (190, 120, 30), (c[0] + R * 0.15 * math.cos(a), c[1] + R * 0.15 * math.sin(a)), 5)
    pygame.draw.circle(S, (118, 98, 70), c, R + 3, 8)
    return cvt(S)


_hall = {}


def make_hall(w, h, fy, cf, cp, rose=True, carpet=False, seed=7):
    """Salao gotico largo (combate / titulo): parede de fundo ate fy, piso em perspectiva ate h."""
    k = (w, h, fy, cf, cp, rose, carpet)
    if k in _hall:
        return _hall[k]
    S = pygame.Surface((w, h))
    S.blit(vgrad(w, fy + 12, mix(cf, (255, 255, 255), .06), mix(cf, (0, 0, 0), .45)), (0, 0))
    rnd = random.Random(seed)
    mortar = mix(cf, (0, 0, 0), .62)
    for row in range(fy // 30 + 1):
        y = row * 30
        off = (row % 2) * 36
        for x in range(-off, w, 72):
            tint = rnd.randint(-9, 9)
            c = clampc((cf[0] * .78 + tint, cf[1] * .78 + tint, cf[2] * .78 + tint // 2))
            pygame.draw.rect(S, c, (x + 1, y + 1, 70, 28), 0, 3)
    for row in range(fy // 30 + 1):
        pygame.draw.line(S, mortar, (0, row * 30), (w, row * 30), 2)
        off = (row % 2) * 36
        for x in range(-off, w, 72):
            pygame.draw.line(S, mortar, (x, row * 30), (x, row * 30 + 30), 2)
    sh = pygame.Surface((w, 160), pygame.SRCALPHA)
    for y in range(0, 160, 2):
        pygame.draw.line(sh, (0, 0, 0, int(170 * (1 - y / 160) ** 1.5)), (0, y), (w, y), 2)
    S.blit(sh, (0, 0))
    fh = h - fy
    floor = vgrad(w, fh, mix(cp, (255, 255, 255), .08), mix(cp, (0, 0, 0), .5))
    ln = mix(cp, (0, 0, 0), .65)
    for x in range(-1400, w + 1400, 90):
        pygame.draw.line(floor, ln, (w // 2, -60), (x, fh), 2)
    for kk in range(1, 9):
        pygame.draw.line(floor, ln, (0, fh * (kk / 8) ** 1.5), (w, fh * (kk / 8) ** 1.5), 2)
    S.blit(floor, (0, fy))
    pygame.draw.line(S, mix(cp, (255, 255, 255), .25), (0, fy), (w, fy), 3)
    if carpet:
        c0 = w // 2
        poly = [(c0 - 60, fy), (c0 + 60, fy), (c0 + 220, h), (c0 - 220, h)]
        pygame.draw.polygon(S, (134, 22, 24), poly)
        pygame.draw.polygon(S, GOLD, poly, 4)
    for fx in (0.27, 0.73):
        px = int(w * fx)
        p = pygame.Surface((26, fy - 10))
        for x in range(26):
            pygame.draw.line(p, mix(mix(cf, (255, 255, 255), .35), mix(cf, (0, 0, 0), .5), min(1, abs(x - 9) / 16)), (x, 0), (x, fy))
        S.blit(p, (px - 13, 0))
        pygame.draw.rect(S, mix(cf, (255, 255, 255), .4), (px - 19, fy - 24, 38, 14))
        pygame.draw.rect(S, mix(cf, (255, 255, 255), .4), (px - 19, 0, 38, 14))
    wh = max(150, fy - 120)
    for fx, sd in ((0.1, 1), (0.9, 2), (0.5, 3)) if not rose else ((0.1, 1), (0.9, 2)):
        win = make_window(84, wh, sd)
        S.blit(win, (int(w * fx) - win.get_width() // 2, 36))
        add_glow(S, (int(w * fx), 36 + wh // 2), 130, (70, 80, 130))
    if rose:
        r = make_rose(84)
        S.blit(r, r.get_rect(center=(w // 2, 100)))
    add_glow(S, (w // 2, 110), 230, (120, 84, 36))
    for fx, col in ((0.37, mix(cf, (150, 30, 34), .7)), (0.63, mix(cf, (30, 58, 130), .7))):
        bx = int(w * fx)
        pts = [(bx - 20, 20), (bx + 20, 20), (bx + 20, 150), (bx, 130), (bx - 20, 150)]
        pygame.draw.polygon(S, col, pts)
        pygame.draw.polygon(S, GOLD, pts, 3)
        pygame.draw.line(S, GOLD_L, (bx, 40), (bx, 100), 5)
        pygame.draw.line(S, GOLD_L, (bx - 14, 58), (bx + 14, 58), 5)
        pygame.draw.line(S, (90, 70, 40), (bx - 26, 18), (bx + 26, 18), 5)
    spill = make_glow(110, (50, 44, 66))
    for fx in (0.1, 0.9):
        S.blit(pygame.transform.scale(spill, (300, 90)), (int(w * fx) - 150, fy + 6), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(vignette(w, h, 90, 150), (0, 0))
    _hall[k] = cvt(S)
    return _hall[k]


def make_hall_combate(cf, cp, boss=False):
    """Fundo da cena de combate (960x540): horizonte em y=250."""
    if boss:
        cf = mix(cf, (120, 20, 20), .35)
    return make_hall(W, H, 250, cf, cp, rose=True, carpet=False)


TORCHES = [(30, 210), (930, 210), (30, 440), (930, 440), (330, 100), (630, 100)]
_room = {}


def _estante(S, rnd, x0, x1, y0, rows, hh, cf):
    for r in range(rows):
        yy = y0 + r * (hh + 6)
        pygame.draw.rect(S, (62, 40, 20), (x0 - 4, yy - 2, x1 - x0 + 8, hh + 5))
        x = x0
        while x < x1 - 8:
            bw = rnd.randint(7, 14)
            bh = rnd.randint(hh - 8, hh)
            c = rnd.choice(PAL)
            c = clampc((c[0] * .7, c[1] * .7, c[2] * .7))
            pygame.draw.rect(S, c, (x, yy + hh - bh, bw, bh), 0, 1)
            pygame.draw.line(S, GOLD, (x + 1, yy + hh - bh + 3), (x + bw - 2, yy + hh - bh + 3), 1)
            x += bw + 1
        pygame.draw.rect(S, (110, 72, 36), (x0 - 4, yy + hh, x1 - x0 + 8, 4))


def _tapete(S, rect, cor, borda=GOLD, rad=10):
    pygame.draw.rect(S, cor, rect, 0, rad)
    pygame.draw.rect(S, borda, rect, 3, rad)
    pygame.draw.rect(S, mix(cor, (0, 0, 0), .35), rect.inflate(-18, -18), 2, max(2, rad - 4))


def _decor_sala(S, tipo, rnd, cf, estilo):
    tap = None
    try:
        pal = (estilo or {}).get("paleta")
        if pal and len(pal[0]) == 3:
            tap = tuple(int(v) for v in pal[0])
    except Exception:
        tap = None
    if tipo == "inicio":
        _tapete(S, pygame.Rect(410, 120, 140, 380), tap or (120, 28, 34), rad=4)
        for y in range(150, 480, 60):
            desenhar_icone(S, "cruz_latina", (480, y), 22, (230, 190, 90))
    elif tipo == "combate":
        pygame.draw.circle(S, (170, 160, 140), (480, 320), 128, 3)
        pygame.draw.circle(S, (170, 160, 140), (480, 320), 100, 2)
        for a in range(0, 360, 45):
            x = 480 + 114 * math.cos(math.radians(a))
            y = 320 + 114 * math.sin(math.radians(a))
            pygame.draw.circle(S, (170, 160, 140), (int(x), int(y)), 4)
        for bx in (96, 826):
            pygame.draw.rect(S, (96, 62, 34), (bx, 200, 38, 150), 0, 5)
            pygame.draw.rect(S, (50, 30, 14), (bx, 200, 38, 150), 3, 5)
            pygame.draw.rect(S, (130, 88, 48), (bx + 4, 204, 30, 20), 0, 3)
        for bx, by in ((150, 440), (790, 440)):
            for i in range(3):
                pygame.draw.rect(S, rnd.choice(PAL), (bx - 22 + i * 4, by - i * 12, 46, 12), 0, 2)
    elif tipo == "tesouro":
        _tapete(S, pygame.Rect(240, 250, 480, 210), tap or (84, 52, 120))
        for cx, cy in ((100, 160), (860, 160), (100, 460), (860, 460)):
            for i in range(9):
                pygame.draw.circle(S, GOLD if i % 2 else GOLD_L, (cx + rnd.randint(-24, 24), cy + rnd.randint(-10, 10)), 6)
                pygame.draw.circle(S, (120, 80, 14), (cx + rnd.randint(-24, 24), cy + rnd.randint(-10, 10)), 6, 1)
    elif tipo == "loja":
        _tapete(S, pygame.Rect(130, 290, 700, 200), tap or (96, 50, 30))
        pygame.draw.rect(S, (112, 70, 36), (330, 168, 300, 56), 0, 6)
        pygame.draw.rect(S, (60, 34, 14), (330, 168, 300, 56), 3, 6)
        pygame.draw.rect(S, (170, 120, 64), (320, 160, 320, 14), 0, 4)
        for i, c in enumerate(((150, 40, 40), (40, 80, 150), (60, 120, 70), (200, 150, 40))):
            pygame.draw.rect(S, c, (356 + i * 62, 150, 38, 12), 0, 2)
    elif tipo == "cura":
        _tapete(S, pygame.Rect(320, 250, 320, 220), tap or (46, 96, 70))
        desenhar_icone(S, "cruz_latina", (480, 360), 96, (230, 240, 225))
        for by in (170, 300):
            pygame.draw.rect(S, (230, 226, 214), (96, by, 124, 66), 0, 8)
            pygame.draw.rect(S, (120, 100, 80), (96, by, 124, 66), 3, 8)
            pygame.draw.rect(S, (110, 150, 190), (96, by + 24, 124, 42), 0, 6)
            pygame.draw.ellipse(S, (250, 250, 245), (104, by + 6, 40, 24))
        for hx in range(720, 880, 40):
            pygame.draw.line(S, (60, 120, 60), (hx, 190), (hx - 6, 150), 3)
            pygame.draw.circle(S, (90, 170, 90), (hx - 6, 148), 9)
    elif tipo == "enigma":
        pygame.draw.circle(S, tap or (50, 34, 80), (480, 320), 150)
        for r, wd in ((150, 3), (118, 2), (84, 2)):
            pygame.draw.circle(S, (160, 120, 210), (480, 320), r, wd)
        for a in range(0, 360, 30):
            x = 480 + 134 * math.cos(math.radians(a))
            y = 320 + 134 * math.sin(math.radians(a))
            pygame.draw.circle(S, (200, 160, 250), (int(x), int(y)), 5, 2)
    elif tipo == "chefe":
        _tapete(S, pygame.Rect(420, 120, 120, 380), tap or (100, 22, 28), rad=4)
        pygame.draw.ellipse(S, (96, 20, 26), (300, 190, 360, 200))
        pygame.draw.ellipse(S, GOLD, (300, 190, 360, 200), 3)
        pygame.draw.ellipse(S, (70, 14, 20), (330, 210, 300, 160), 2)


def make_room_bg(cf, cp, tipo="combate", estilo=None):
    """Sala de exploracao 960x540 inteira (paredes, piso, decoracao do tipo, sombras). Tudo em cache."""
    k = (cf, cp, tipo)
    if k in _room:
        return _room[k]
    S = pygame.Surface((W, H))
    fl = FL
    rnd = random.Random(sum(cf) * 7 + sum(cp))
    S.fill(mix(cf, (0, 0, 0), .5))
    mortar = mix(cf, (0, 0, 0), .7)
    for row in range(H // 26 + 1):
        y = row * 26
        off = (row % 2) * 34
        for x in range(-off, W, 68):
            t = rnd.randint(-8, 8)
            c = clampc((cf[0] * .8 + t, cf[1] * .8 + t, cf[2] * .8 + t))
            pygame.draw.rect(S, c, (x + 1, y + 1, 66, 24), 0, 3)
        pygame.draw.line(S, mortar, (0, y), (W, y), 2)
    # piso (lajes com sombra de profundidade)
    for ty in range(fl.top, fl.bottom, 40):
        for tx in range(fl.left, fl.right, 40):
            alt = ((tx // 40) + (ty // 40)) % 2
            t = rnd.randint(-6, 6)
            c = mix(cp, (0, 0, 0), .14) if alt else cp
            c = clampc((c[0] + t, c[1] + t, c[2] + t))
            c = mix(c, (0, 0, 0), .32 * (1 - (ty - fl.top) / fl.h))
            pygame.draw.rect(S, c, (tx, ty, 40, 40))
            pygame.draw.rect(S, mix(c, (0, 0, 0), .35), (tx, ty, 40, 40), 1)
    # parede do fundo
    S.blit(vgrad(W, fl.top, mix(cf, (0, 0, 0), .55), mix(cf, (0, 0, 0), .12)), (0, 0))
    if tipo == "loja":
        _estante(S, rnd, 90, 330, 14, 3, 26, cf)
        _estante(S, rnd, 630, 870, 14, 3, 26, cf)
    elif tipo in ("combate", "inicio", "chefe", "enigma"):
        _estante(S, rnd, 90, 190, 20, 3, 24, cf)
        _estante(S, rnd, 770, 870, 20, 3, 24, cf)
    for cx, sd in ((250, 1), (710, 2)):
        win = make_window(60, 76, sd)
        S.blit(win, (cx - win.get_width() // 2, 14))
        lg = pygame.Surface((120, 330), pygame.SRCALPHA)
        pygame.draw.polygon(lg, (150, 170, 230, 26), [(30, 0), (90, 0), (120, 330), (0, 330)])
        S.blit(lg, (cx - 60 + (30 if cx < 480 else -30), fl.top))
    for bx, col in ((380, mix(cf, (150, 30, 34), .7)), (580, mix(cf, (30, 58, 130), .7))):
        pts = [(bx - 16, 8), (bx + 16, 8), (bx + 16, 100), (bx, 86), (bx - 16, 100)]
        pygame.draw.polygon(S, col, pts)
        pygame.draw.polygon(S, GOLD, pts, 3)
        pygame.draw.line(S, GOLD_L, (bx, 24), (bx, 66), 5)
        pygame.draw.line(S, GOLD_L, (bx - 10, 38), (bx + 10, 38), 5)
    pygame.draw.rect(S, (90, 70, 40), (0, fl.top - 6, W, 6))
    # laterais: colunas
    for sx in (0, fl.right):
        for xx in range(40):
            c = mix(mix(cf, (255, 255, 255), .22), mix(cf, (0, 0, 0), .55), abs(xx - 14) / 28.0)
            pygame.draw.line(S, c, (sx + 10 + xx, fl.top - 6), (sx + 10 + xx, fl.bottom), 1)
        for yy in range(fl.top, fl.bottom, 126):
            pygame.draw.rect(S, mix(cf, (255, 255, 255), .35), (sx + 6, yy, 48, 12), 0, 3)
    # parede da frente
    S.blit(vgrad(W, H - fl.bottom, mix(cf, (0, 0, 0), .55), mix(cf, (0, 0, 0), .8)), (0, fl.bottom))
    pygame.draw.rect(S, (110, 80, 40), (0, fl.bottom, W, 6))
    _decor_sala(S, tipo, rnd, cf, estilo)
    # sombras internas do piso
    sh = pygame.Surface((W, H), pygame.SRCALPHA)
    for i in range(0, 36, 2):
        a = int(150 * (1 - i / 36) ** 2)
        pygame.draw.rect(sh, (0, 0, 0, a), (fl.x + i, fl.y + i, fl.w - 2 * i, fl.h - 2 * i), 2)
    S.blit(sh, (0, 0))
    pygame.draw.rect(S, (150, 116, 56), fl.inflate(4, 4), 3)
    for (tx, ty) in TORCHES:
        pygame.draw.rect(S, (70, 52, 30), (tx - 5, ty - 4, 10, 26))
        pygame.draw.rect(S, (40, 30, 20), (tx - 10, ty + 16, 20, 7), 0, 2)
    S.blit(vignette(W, H, 100, 170), (0, 0))
    _room[k] = cvt(S)
    return _room[k]


def draw_flame(S, x, y, t, k=1.0):
    fl = 1 + math.sin(t * 17 + x) * 0.12 + math.sin(t * 29 + x * 2) * 0.08
    h = int(20 * fl * k)
    w = int(8 * k)
    pygame.draw.ellipse(S, (255, 150, 30), (x - w, y - h, 2 * w, h + 4))
    pygame.draw.ellipse(S, (255, 226, 130), (x - w // 2, y - h // 2 - 2, w, h // 2 + 4))


def draw_candle(S, x, y, t, lit=True, hgt=30):
    pygame.draw.rect(S, (236, 224, 190), (x - 5, y - hgt, 10, hgt))
    pygame.draw.rect(S, (170, 150, 110), (x - 5, y - hgt, 10, hgt), 1)
    pygame.draw.rect(S, (170, 138, 50), (x - 9, y, 18, 5), 0, 2)
    if lit:
        draw_flame(S, x, y - hgt - 2, t)
    else:
        pygame.draw.line(S, (40, 30, 20), (x, y - hgt), (x, y - hgt - 4), 2)


# --------------------------------------------------------------- portas
def door_rect(side):
    cx, cy = DOOR_C[side]
    if side == "N":
        return pygame.Rect(cx - DOOR_HW, 66, 2 * DOOR_HW, 56)
    if side == "S":
        return pygame.Rect(cx - DOOR_HW, 498, 2 * DOOR_HW, 42)
    if side == "W":
        return pygame.Rect(0, cy - DOOR_HW, 62, 2 * DOOR_HW)
    return pygame.Rect(898, cy - DOOR_HW, 62, 2 * DOOR_HW)


_doors = {}
DOOR_GLOW = {"chefe": (140, 30, 30), "tesouro": (150, 120, 30), "loja": (60, 120, 160),
             "cura": (60, 150, 90), "enigma": (110, 70, 150)}
DOOR_ICONE = {"chefe": "mitra", "tesouro": "bau", "loja": "livro", "cura": "cruz_latina", "enigma": "interrogacao"}


def _door_surface(side, locked, special):
    r = door_rect(side)
    s = pygame.Surface(r.size, pygame.SRCALPHA)
    w, h = r.size
    vertical = side in ("N", "S")
    if locked:
        pygame.draw.rect(s, (96, 60, 30), (0, 0, w, h), 0, 6)
        for i in range(1, 7):
            if vertical:
                pygame.draw.line(s, (60, 36, 16), (i * w // 7, 0), (i * w // 7, h), 2)
            else:
                pygame.draw.line(s, (60, 36, 16), (0, i * h // 7), (w, i * h // 7), 2)
        for i in (0.25, 0.75):
            if vertical:
                pygame.draw.rect(s, (60, 60, 70), (0, int(h * i) - 3, w, 6))
            else:
                pygame.draw.rect(s, (60, 60, 70), (int(w * i) - 3, 0, 6, h))
        pygame.draw.rect(s, (40, 26, 12), (0, 0, w, h), 3, 6)
        desenhar_icone(s, "cadeado", (w // 2, h // 2), min(w, h) - 14)
    else:
        pygame.draw.rect(s, (8, 5, 12), (0, 0, w, h), 0, 6)
        gc = DOOR_GLOW.get(special)
        if gc:
            g = pygame.Surface((w, h), pygame.SRCALPHA)
            for i in range(10):
                pygame.draw.rect(g, (*gc, 18), (i * 2, i * 2, w - i * 4, h - i * 4), 0, 6)
            s.blit(g, (0, 0))
            ic = DOOR_ICONE.get(special)
            if ic:
                desenhar_icone(s, ic, (w // 2, h // 2), min(w, h) - 22, mix(gc, (255, 255, 255), .5))
        pygame.draw.rect(s, (150, 116, 56), (0, 0, w, h), 3, 6)
    return cvt(s)


def draw_door(S, side, locked, special=None, estado=None):
    try:
        import arte_salas
        return arte_salas.draw_door(S, side, locked, special, estado)
    except Exception:
        pass
    k = (side, locked, special)
    if k not in _doors:
        _doors[k] = _door_surface(side, locked, special)
    S.blit(_doors[k], door_rect(side).topleft)


# ------------------------------------------------------------- personagens
def draw_scholar(S, cx, by, o, t, mood="idle", talk=False, shake=0.0):
    cx += shake
    bob = math.sin(t * 1.8) * 1.6
    robe = o["robe"]
    dark = tuple(int(v * 0.66) for v in robe)
    skin = o["skin"]
    top = by - 112 + bob
    hy = top - 20
    if o["hat"] == "hood":
        hood = [(cx - 42, top + 30), (cx - 40, hy - 6), (cx - 22, hy - 40), (cx, hy - 50),
                (cx + 22, hy - 40), (cx + 40, hy - 6), (cx + 42, top + 30)]
        pygame.draw.polygon(S, robe, hood)
        pygame.draw.polygon(S, dark, hood, 3)
    body = [(cx - 82, by + 8), (cx - 68, by - 74 + bob), (cx - 38, top + 8),
            (cx + 38, top + 8), (cx + 68, by - 74 + bob), (cx + 82, by + 8)]
    pygame.draw.polygon(S, robe, body)
    pygame.draw.polygon(S, dark, body, 3)
    for dx in (-44, -22, 22, 44):
        pygame.draw.line(S, dark, (cx + dx, top + 30), (cx + dx * 1.2, by), 2)
    if o.get("under"):
        up = [(cx - 20, top + 8), (cx + 20, top + 8), (cx + 28, by + 8), (cx - 28, by + 8)]
        pygame.draw.polygon(S, o["under"], up)
        pygame.draw.polygon(S, mix(o["under"], (0, 0, 0), .4), up, 2)
    pygame.draw.lines(S, o["trim"], False, [(cx - 38, top + 8), (cx - 16, top + 32), (cx + 16, top + 32), (cx + 38, top + 8)], 5)
    pygame.draw.rect(S, mix(skin, (0, 0, 0), .15), (cx - 11, hy + 16, 22, 26))
    if o["hat"] == "tonsure":
        pygame.draw.circle(S, o["hair"], (cx, int(hy + 2)), 33)
    pygame.draw.circle(S, skin, (cx, int(hy)), 30)
    pygame.draw.circle(S, mix(skin, (120, 60, 40), .35), (cx - 20, int(hy + 8)), 6)
    pygame.draw.circle(S, mix(skin, (120, 60, 40), .35), (cx + 20, int(hy + 8)), 6)
    if o["hat"] == "tonsure":
        pygame.draw.ellipse(S, skin, (cx - 20, hy - 31, 40, 28))
    ey = hy - 3
    blink = int(t * 10) % 47 == 0
    for sx in (-1, 1):
        ex = cx + sx * 11
        if mood == "hurt":
            pygame.draw.line(S, (40, 20, 10), (ex - 4, ey - 4), (ex + 4, ey + 4), 3)
            pygame.draw.line(S, (40, 20, 10), (ex + 4, ey - 4), (ex - 4, ey + 4), 3)
        elif blink:
            pygame.draw.line(S, (40, 20, 10), (ex - 5, ey), (ex + 5, ey), 2)
        else:
            pygame.draw.circle(S, (250, 250, 245), (ex, ey), 6)
            pygame.draw.circle(S, (40, 22, 12), (ex + 1, ey + 1), 3)
        by_ = ey - 11
        if mood == "angry":
            a, b = (ex + sx * 8, by_ - 5), (ex - sx * 6, by_ + 3)
        elif mood == "hurt":
            a, b = (ex + sx * 8, by_ + 2), (ex - sx * 6, by_ - 5)
        else:
            a, b = (ex + sx * 8, by_), (ex - sx * 6, by_)
        pygame.draw.line(S, o["hair"] if o["hair"][0] > 60 else (50, 30, 16), a, b, 4)
    pygame.draw.circle(S, mix(skin, (150, 80, 50), .4), (cx, int(hy + 6)), 4)
    if o.get("beard"):
        bd = [(cx - 28, hy + 4), (cx - 24, hy + 36), (cx - 8, hy + 52), (cx, hy + 56),
              (cx + 8, hy + 52), (cx + 24, hy + 36), (cx + 28, hy + 4), (cx + 14, hy + 16),
              (cx, hy + 12), (cx - 14, hy + 16)]
        pygame.draw.polygon(S, o["beard"], bd)
        pygame.draw.polygon(S, mix(o["beard"], (0, 0, 0), .35), bd, 2)
    my = hy + 20
    if talk:
        oh = 3 + abs(math.sin(t * 16)) * 7
        pygame.draw.ellipse(S, (90, 20, 20), (cx - 8, my - oh / 2, 16, oh))
    elif mood == "hurt":
        pygame.draw.circle(S, (90, 20, 20), (cx, my + 2), 6)
    elif mood == "angry":
        pygame.draw.arc(S, (90, 20, 20), (cx - 10, my - 2, 20, 14), 0.4, math.pi - 0.4, 3)
    else:
        pygame.draw.line(S, (110, 40, 30), (cx - 8, my), (cx + 8, my), 3)
    if o["hat"] == "hood":
        pygame.draw.arc(S, dark, (cx - 36, hy - 44, 72, 92), 0.15, math.pi - 0.15, 7)
    elif o["hat"] == "biretta":
        hat = mix(o["robe"], (0, 0, 0), .35)
        pts = [(cx - 34, hy - 18), (cx - 26, hy - 36), (cx + 26, hy - 36), (cx + 34, hy - 18)]
        pygame.draw.polygon(S, hat, pts)
        pygame.draw.polygon(S, o["trim"], pts, 2)
        pygame.draw.ellipse(S, mix(hat, (255, 255, 255), .15), (cx - 28, hy - 44, 56, 16))
        pygame.draw.circle(S, o["trim"], (cx + 22, hy - 40), 5)
    elif o["hat"] == "cap":
        hat = mix(o["robe"], (0, 0, 0), .15)
        dome = [(cx + 31 * math.cos(math.pi + math.pi * i / 16), hy - 8 + 36 * math.sin(math.pi + math.pi * i / 16)) for i in range(17)]
        pygame.draw.polygon(S, hat, dome)
        pygame.draw.polygon(S, o["trim"], dome, 2)
        pygame.draw.circle(S, o["trim"], (cx, int(hy - 44)), 5)
    gest = math.sin(t * 5) * 8 if talk else 0
    for sx in (-1, 1):
        sxp, syp = cx + sx * 62, by - 74 + bob
        hxp, hyp = cx + sx * 46, by - 6
        if talk and sx == 1:
            hxp, hyp = cx + 78, by - 46 + gest
        elif mood == "hurt":
            hxp, hyp = cx + sx * 40, by - 52
        pygame.draw.line(S, robe, (sxp, syp), (hxp, hyp), 24)
        pygame.draw.circle(S, robe, (int(hxp), int(hyp)), 12)
        pygame.draw.circle(S, skin, (int(hxp), int(hyp - 2)), 9)
    return hy


def draw_lectern(S, cx, by):
    pts = [(cx - 78, by + 6), (cx + 78, by + 6), (cx + 90, by + 62), (cx - 90, by + 62)]
    pygame.draw.polygon(S, (112, 70, 36), pts)
    pygame.draw.polygon(S, (46, 26, 11), pts, 3)
    pygame.draw.rect(S, (168, 116, 62), (cx - 86, by - 2, 172, 10), 0, 3)
    pygame.draw.rect(S, (46, 26, 11), (cx - 86, by - 2, 172, 10), 2, 3)
    pygame.draw.rect(S, (84, 50, 24), (cx - 52, by + 18, 104, 36), 0, 18)
    pygame.draw.rect(S, (210, 170, 80), (cx - 52, by + 18, 104, 36), 2, 18)
    pygame.draw.line(S, GOLD_L, (cx, by + 24), (cx, by + 48), 4)
    pygame.draw.line(S, GOLD_L, (cx - 9, by + 32), (cx + 9, by + 32), 4)


def draw_back(S, x, base, robe, hair, scale=1.0, tonsure=False, cap=None, bob=0.0):
    s = scale
    y = base + bob
    dark = tuple(int(v * 0.6) for v in robe)
    body = [(x - 34 * s, base + 40 * s), (x - 30 * s, y - 14 * s), (x - 12 * s, y - 26 * s),
            (x + 12 * s, y - 26 * s), (x + 30 * s, y - 14 * s), (x + 34 * s, base + 40 * s)]
    pygame.draw.polygon(S, robe, body)
    pygame.draw.polygon(S, dark, body, 2)
    pygame.draw.line(S, mix(robe, (255, 220, 160), .35), body[1], body[2], 2)
    pygame.draw.line(S, mix(robe, (255, 220, 160), .35), body[2], body[3], 2)
    pygame.draw.circle(S, hair, (int(x), int(y - 42 * s)), int(19 * s))
    if cap:
        pygame.draw.polygon(S, cap, [(x - 22 * s, y - 50 * s), (x - 16 * s, y - 64 * s),
                                     (x + 16 * s, y - 64 * s), (x + 22 * s, y - 50 * s)])
        pygame.draw.ellipse(S, mix(cap, (255, 255, 255), .12), (x - 18 * s, y - 70 * s, 36 * s, 12 * s))
    pygame.draw.arc(S, mix(hair, (255, 220, 150), .3), (x - 19 * s, y - 61 * s, 38 * s, 38 * s), 0.5, 2.6, 2)


def draw_hero_small(S, x, y, t, face, moving):
    """Heroi pequeno visto de cima/frente. y = pes."""
    bob = math.sin(t * 11) * 2 if moving else math.sin(t * 2) * 1
    shadow(S, x, y, 34, 12)
    sw = math.sin(t * 12) * 4 if moving else 0
    pygame.draw.ellipse(S, (30, 20, 12), (x - 11 + sw, y - 5, 10, 7))
    pygame.draw.ellipse(S, (30, 20, 12), (x + 1 - sw, y - 5, 10, 7))
    robe = (46, 76, 170)
    body = [(x - 14, y - 4), (x - 10, y - 28 + bob), (x + 10, y - 28 + bob), (x + 14, y - 4)]
    pygame.draw.polygon(S, robe, body)
    pygame.draw.polygon(S, (24, 38, 96), body, 2)
    pygame.draw.line(S, GOLD, (x - 12, y - 14), (x + 12, y - 14), 3)
    hy = y - 36 + bob
    skin = (238, 198, 162)
    pygame.draw.circle(S, skin, (x, int(hy)), 10)
    if face == "N":
        pygame.draw.circle(S, (70, 46, 26), (x, int(hy)), 10)
    else:
        ox = {"E": 3, "W": -3}.get(face, 0)
        pygame.draw.circle(S, (30, 20, 12), (x - 4 + ox, int(hy)), 2)
        pygame.draw.circle(S, (30, 20, 12), (x + 4 + ox, int(hy)), 2)
        pygame.draw.arc(S, (70, 46, 26), (x - 10, hy - 10, 20, 16), 0.2, math.pi - 0.2, 3)
    cap = (26, 26, 38)
    pygame.draw.polygon(S, cap, [(x - 11, hy - 4), (x - 7, hy - 15), (x + 7, hy - 15), (x + 11, hy - 4)])
    pygame.draw.ellipse(S, (46, 46, 62), (x - 9, hy - 19, 18, 7))
    # livro na mao
    bx = x + (14 if face != "W" else -14)
    pygame.draw.rect(S, (150, 40, 40), (bx - 5, y - 22 + bob, 10, 13), 0, 2)
    pygame.draw.rect(S, GOLD, (bx - 5, y - 22 + bob, 10, 13), 1, 2)


# --------------------------------------------------------- formas dos inimigos
SPR_W, SPR_H = 230, 240


def scholar_dict(col, forma):
    if forma == "estudante":
        return dict(robe=col, under=None, trim=mix(col, (255, 255, 255), .55), skin=(240, 205, 170),
                    hat="cap", beard=None, hair=(100, 70, 40))
    return dict(robe=col, under=(225, 215, 185), trim=(235, 205, 110), skin=(232, 190, 154), hat="biretta",
                beard=(215, 215, 215), hair=(215, 215, 215))


def _f_scholar(S, cx, by, col, forma):
    draw_scholar(S, cx, by - 6, scholar_dict(col, forma), 0.0, "angry", False)
    if forma == "estudante":
        pygame.draw.rect(S, (230, 214, 170), (cx - 22, by - 60, 44, 30), 0, 3)
        pygame.draw.rect(S, (110, 80, 40), (cx - 22, by - 60, 44, 30), 2, 3)
        pygame.draw.line(S, (110, 80, 40), (cx, by - 60), (cx, by - 30), 2)


def _f_capuz(S, cx, by, col):
    dark = mix(col, (0, 0, 0), .55)
    hem = [(cx + 60 - i * 15, by - 4 - (12 if i % 2 else 0)) for i in range(1, 8)]
    body = [(cx - 28, by - 118), (cx + 28, by - 118), (cx + 48, by - 70), (cx + 60, by - 4)] + hem + [(cx - 60, by - 4), (cx - 48, by - 70)]
    pygame.draw.polygon(S, col, body)
    pygame.draw.polygon(S, dark, body, 3)
    for dx in (-30, -12, 12, 30):
        pygame.draw.line(S, dark, (cx + dx * .4, by - 100), (cx + dx * 1.7, by - 10), 2)
    pygame.draw.circle(S, col, (cx, by - 134), 38)
    pygame.draw.circle(S, dark, (cx, by - 134), 38, 4)
    pygame.draw.polygon(S, col, [(cx - 14, by - 168), (cx + 8, by - 188), (cx + 22, by - 160)])
    pygame.draw.ellipse(S, (12, 6, 16), (cx - 22, by - 156, 44, 46))
    for sx in (-1, 1):
        pygame.draw.circle(S, (255, 220, 90), (cx + sx * 10, by - 136), 6)
        pygame.draw.circle(S, (255, 255, 230), (cx + sx * 10, by - 136), 2)
        pygame.draw.line(S, (12, 6, 16), (cx + sx * 18, by - 148), (cx + sx * 4, by - 142), 3)
    for sx in (-1, 1):
        pygame.draw.line(S, dark, (cx + sx * 42, by - 100), (cx + sx * 46, by - 52), 16)
        pygame.draw.circle(S, (214, 204, 184), (cx + sx * 46, by - 48), 8)
    pygame.draw.rect(S, (232, 220, 180), (cx - 26, by - 66, 52, 26), 0, 4)
    pygame.draw.rect(S, (110, 84, 44), (cx - 26, by - 66, 52, 26), 2, 4)
    for i in range(3):
        pygame.draw.line(S, (130, 100, 60), (cx - 18, by - 58 + i * 7), (cx + 18, by - 58 + i * 7), 2)


def _f_livro(S, cx, by, col):
    dark = mix(col, (0, 0, 0), .5)
    lite = mix(col, (255, 255, 255), .28)
    r = pygame.Rect(cx - 62, by - 196, 124, 164)
    pygame.draw.rect(S, (236, 226, 190), r.move(9, 7), 0, 6)
    for i in range(5):
        pygame.draw.line(S, (186, 172, 134), (r.right + 1 + i * 2, r.top + 12 + i), (r.right + 1 + i * 2, r.bottom + 2), 1)
    pygame.draw.rect(S, col, r, 0, 8)
    pygame.draw.rect(S, dark, r, 4, 8)
    pygame.draw.rect(S, dark, (r.x, r.y, 18, r.h), 0, 8)
    pygame.draw.line(S, lite, (r.x + 22, r.y + 8), (r.right - 8, r.y + 8), 2)
    for (x, y, dx, dy) in ((r.x + 18, r.y + 4, 1, 1), (r.right - 4, r.y + 4, -1, 1), (r.x + 18, r.bottom - 4, 1, -1), (r.right - 4, r.bottom - 4, -1, -1)):
        pygame.draw.polygon(S, GOLD, [(x, y), (x + 20 * dx, y), (x, y + 20 * dy)])
    pygame.draw.line(S, GOLD_L, (cx + 12, r.y + 22), (cx + 12, r.y + 56), 5)
    pygame.draw.line(S, GOLD_L, (cx, r.y + 32), (cx + 24, r.y + 32), 5)
    for sx in (0, 1):
        ex = cx - 10 + sx * 38
        pygame.draw.circle(S, (250, 250, 235), (ex, by - 112), 12)
        pygame.draw.circle(S, (150, 20, 20), (ex - 1, by - 110), 6)
        pygame.draw.circle(S, (0, 0, 0), (ex - 1, by - 110), 3)
    pygame.draw.line(S, (20, 10, 6), (cx - 24, by - 134), (cx - 2, by - 124), 5)
    pygame.draw.line(S, (20, 10, 6), (cx + 38, by - 134), (cx + 16, by - 124), 5)
    mouth = [(cx - 16, by - 80), (cx - 8, by - 70), (cx, by - 80), (cx + 8, by - 70), (cx + 16, by - 80), (cx + 16, by - 66), (cx - 16, by - 66)]
    pygame.draw.polygon(S, (60, 10, 10), [(cx - 18, by - 82), (cx + 34, by - 82), (cx + 30, by - 62), (cx - 14, by - 62)])
    for i in range(5):
        x = cx - 14 + i * 10
        pygame.draw.polygon(S, (255, 255, 240), [(x, by - 82), (x + 8, by - 82), (x + 4, by - 72)])
    pygame.draw.polygon(S, (170, 30, 40), [(cx - 30, r.bottom), (cx - 18, r.bottom), (cx - 18, r.bottom + 18), (cx - 24, r.bottom + 12), (cx - 30, r.bottom + 18)])


def _f_espirito(S, cx, by, col):
    lite = mix(col, (255, 255, 255), .45)
    pts = [(cx - 54, by - 40)]
    pts += [(cx + 54 * math.cos(math.pi + math.pi * i / 14), by - 130 + 66 * math.sin(math.pi + math.pi * i / 14)) for i in range(15)]
    pts += [(cx + 54, by - 40)]
    for i in range(9):
        x = cx + 54 - i * 13.5
        pts.append((x, by - 14 + (12 if i % 2 else 0)))
    aura = pygame.Surface((SPR_W, SPR_H), pygame.SRCALPHA)
    pygame.draw.polygon(aura, (*col, 70), [(x * 1.0, y * 1.0) for x, y in pts], 0)
    S.blit(aura, (0, 0))
    pygame.draw.polygon(S, (*mix(col, (255, 255, 255), .25), 205), pts)
    pygame.draw.polygon(S, (*lite, 255), pts, 3)
    for sx in (-1, 1):
        pygame.draw.ellipse(S, (10, 10, 30, 255), (cx + sx * 20 - 9, by - 152, 18, 26))
        pygame.draw.circle(S, (255, 255, 255, 255), (cx + sx * 20 - 2, by - 144), 3)
        pygame.draw.line(S, (10, 10, 30, 255), (cx + sx * 34, by - 168), (cx + sx * 8, by - 156), 3)
    pygame.draw.ellipse(S, (10, 10, 30, 255), (cx - 11, by - 112, 22, 30))
    for sx in (-1, 1):
        pygame.draw.polygon(S, (*lite, 220), [(cx + sx * 50, by - 100), (cx + sx * 84, by - 72), (cx + sx * 70, by - 56), (cx + sx * 46, by - 78)])


def _f_besta(S, cx, by, col):
    dark = mix(col, (0, 0, 0), .5)
    lite = mix(col, (255, 255, 255), .22)
    for lx in (cx - 46, cx - 22, cx + 28, cx + 52):
        pygame.draw.rect(S, dark, (lx - 8, by - 56, 16, 54), 0, 5)
        pygame.draw.ellipse(S, dark, (lx - 12, by - 10, 28, 12))
    pygame.draw.lines(S, col, False, [(cx + 66, by - 96), (cx + 92, by - 112), (cx + 100, by - 146)], 9)
    pygame.draw.polygon(S, GOLD, [(cx + 94, by - 146), (cx + 108, by - 160), (cx + 108, by - 138)])
    pygame.draw.ellipse(S, col, (cx - 72, by - 126, 154, 84))
    pygame.draw.ellipse(S, dark, (cx - 72, by - 126, 154, 84), 4)
    pygame.draw.ellipse(S, lite, (cx - 40, by - 116, 90, 26))
    for i in range(6):
        x = cx - 44 + i * 22
        pygame.draw.polygon(S, dark, [(x - 9, by - 118 + abs(i - 2.5) * 3), (x, by - 144 + abs(i - 2.5) * 6), (x + 9, by - 118 + abs(i - 2.5) * 3)])
    pygame.draw.circle(S, col, (cx - 74, by - 98), 32)
    pygame.draw.circle(S, dark, (cx - 74, by - 98), 32, 4)
    sn = [(cx - 96, by - 108), (cx - 124, by - 94), (cx - 118, by - 74), (cx - 84, by - 70)]
    pygame.draw.polygon(S, col, sn)
    pygame.draw.polygon(S, dark, sn, 3)
    for sx in (-1, 1):
        x = cx - 72 + sx * 16
        pygame.draw.polygon(S, (240, 232, 210), [(x - 7, by - 124), (x, by - 156), (x + 9, by - 124)])
    pygame.draw.circle(S, (255, 220, 80), (cx - 80, by - 108), 7)
    pygame.draw.circle(S, (160, 10, 10), (cx - 82, by - 108), 3)
    for i in range(4):
        x = cx - 118 + i * 9
        pygame.draw.polygon(S, (255, 255, 245), [(x, by - 80), (x + 7, by - 80), (x + 3, by - 70)])
    pygame.draw.circle(S, (30, 10, 10), (cx - 120, by - 96), 3)


FORMAS = {"capuz": _f_capuz, "livro": _f_livro, "espirito": _f_espirito, "besta": _f_besta}
_spr = {}


def get_sprite(forma, cor):
    """(normal, flash_branco, flash_vermelho) do sprite do inimigo, 230x240, chao em y=222."""
    k = (forma, tuple(cor))
    if k not in _spr:
        S = pygame.Surface((SPR_W, SPR_H), pygame.SRCALPHA)
        cx, by = SPR_W // 2, 222
        shadow(S, cx, by + 2, 150, 26)
        if forma in ("mestre", "estudante"):
            _f_scholar(S, cx, by, tuple(cor), forma)
        else:
            FORMAS.get(forma, _f_capuz)(S, cx, by, tuple(cor))
        wh = S.copy()
        wh.fill((150, 150, 150, 0), special_flags=pygame.BLEND_RGB_ADD)
        rd = S.copy()
        rd.fill((120, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
        _spr[k] = (cvt(S), cvt(wh), cvt(rd))
    return _spr[k]


_sprs = {}


def sprite_scaled(forma, cor, h, which=0):
    k = (forma, tuple(cor), h, which)
    if k not in _sprs:
        if len(_sprs) > 160:
            _sprs.clear()
        s = get_sprite(forma, cor)[which]
        w = int(SPR_W * h / SPR_H)
        _sprs[k] = cvt(pygame.transform.smoothscale(s, (w, h)))
    return _sprs[k]


_hero = {}


def hero_sprite(which=0):
    if which not in _hero:
        S = pygame.Surface((150, 200), pygame.SRCALPHA)
        shadow(S, 75, 184, 110, 22)
        draw_back(S, 75, 120, (46, 76, 170), (80, 52, 30), 1.55, False, (24, 24, 36), 0)
        # livro sob o braco
        pygame.draw.rect(S, (150, 40, 40), (104, 126, 26, 34), 0, 3)
        pygame.draw.rect(S, GOLD, (104, 126, 26, 34), 2, 3)
        pygame.draw.line(S, GOLD_L, (117, 132), (117, 154), 3)
        wh = S.copy()
        wh.fill((150, 150, 150, 0), special_flags=pygame.BLEND_RGB_ADD)
        rd = S.copy()
        rd.fill((130, 0, 0, 0), special_flags=pygame.BLEND_RGB_ADD)
        _hero[0], _hero[1], _hero[2] = cvt(S), cvt(wh), cvt(rd)
    return _hero[which]


_port = {}
NPC_LOOK = {
    "mestre_guia": dict(robe=(86, 46, 120), under=(230, 220, 190), trim=(238, 206, 110), skin=(228, 186, 150), hat="biretta", beard=(226, 226, 226), hair=(226, 226, 226)),
    "livreiro": dict(robe=(112, 78, 46), under=None, trim=(214, 184, 120), skin=(238, 198, 162), hat="cap", beard=None, hair=(90, 60, 30)),
    "monge_enfermeiro": dict(robe=(150, 130, 100), under=(240, 236, 224), trim=(120, 90, 50), skin=(236, 196, 160), hat="tonsure", beard=None, hair=(110, 70, 36)),
    "reitor": dict(robe=(176, 134, 34), under=(240, 232, 214), trim=(120, 24, 28), skin=(236, 196, 160), hat="cap", beard=(210, 210, 214), hair=(210, 210, 214)),
}


def npc_look(npc):
    return NPC_LOOK.get(npc, NPC_LOOK["mestre_guia"])


def npc_sprite(npc):
    """Corpo inteiro do NPC (230x240)."""
    k = ("full", npc)
    if k not in _port:
        S = pygame.Surface((SPR_W, SPR_H), pygame.SRCALPHA)
        shadow(S, SPR_W // 2, 224, 150, 26)
        draw_scholar(S, SPR_W // 2, 216, npc_look(npc), 0.0, "idle", False)
        _port[k] = cvt(S)
    return _port[k]


def npc_portrait(npc, size=120):
    k = ("p", npc, size)
    if k not in _port:
        S = pygame.Surface((SPR_W, SPR_H), pygame.SRCALPHA)
        draw_scholar(S, SPR_W // 2, 216, npc_look(npc), 0.0, "idle", False)
        crop = S.subsurface(pygame.Rect(SPR_W // 2 - 62, 8, 124, 124)).copy()
        out = pygame.Surface((size, size), pygame.SRCALPHA)
        pygame.draw.rect(out, (40, 28, 54, 255), (0, 0, size, size), 0, 14)
        out.blit(pygame.transform.smoothscale(crop, (size, size)), (0, 0))
        pygame.draw.rect(out, GOLD, (0, 0, size, size), 4, 14)
        _port[k] = cvt(out)
    return _port[k]


# ------------------------------------------------------------------ itens
def item_cor(it):
    ef = it.get("efeito", {}) or {}
    for key, col in (("cura_hp", (210, 70, 80)), ("cura_tinta", (70, 110, 220)), ("bonus_razao", (80, 140, 235)),
                     ("bonus_autoridade", (225, 170, 60)), ("bonus_eloquencia", (200, 120, 230)),
                     ("bonus_humildade", (110, 200, 120)), ("hp_max", (230, 110, 130)), ("tinta_max", (90, 90, 200)),
                     ("bonus_florins_pct", (230, 200, 70)), ("bonus_dano_pct", (236, 130, 50)),
                     ("bonus_critico_pct", (200, 90, 200)), ("reduz_dano_pct", (180, 190, 200))):
        if key in ef:
            return col
    return (150, 120, 80)


def draw_item_icon(S, cx, cy, it, size=40, t=0.0):
    col = item_cor(it)
    s = size / 40.0
    bob = math.sin(t * 2.4) * 2 * s
    cy = cy + bob
    add_glow(S, (cx, cy), int(size * 0.9), mix(col, (0, 0, 0), .55))
    if it.get("tipo") == "consumivel":
        pygame.draw.circle(S, (30, 20, 12), (cx, int(cy + 6 * s)), int(17 * s))
        pygame.draw.circle(S, mix(col, (255, 255, 255), .15), (cx, int(cy + 6 * s)), int(15 * s))
        pygame.draw.rect(S, (30, 20, 12), (cx - 6 * s, cy - 18 * s, 12 * s, 14 * s))
        pygame.draw.rect(S, (230, 230, 240), (cx - 4 * s, cy - 16 * s, 8 * s, 10 * s))
        pygame.draw.rect(S, (150, 100, 50), (cx - 7 * s, cy - 22 * s, 14 * s, 6 * s), 0, 2)
        pygame.draw.circle(S, (255, 255, 255), (int(cx - 6 * s), int(cy + 1 * s)), max(2, int(4 * s)))
    else:
        r = pygame.Rect(0, 0, 30 * s, 38 * s)
        r.center = (cx, cy)
        pygame.draw.rect(S, (36, 22, 12), r.inflate(4, 4), 0, 4)
        pygame.draw.rect(S, col, r, 0, 3)
        pygame.draw.rect(S, mix(col, (0, 0, 0), .45), (r.x, r.y, 6 * s, r.h), 0, 3)
        pygame.draw.rect(S, (236, 226, 190), (r.x + 4 * s, r.bottom - 3 * s, r.w - 6 * s, 3 * s))
        pygame.draw.line(S, GOLD_L, (cx + 4 * s, cy - 10 * s), (cx + 4 * s, cy + 6 * s), max(2, int(3 * s)))
        pygame.draw.line(S, GOLD_L, (cx - 2 * s, cy - 5 * s), (cx + 10 * s, cy - 5 * s), max(2, int(3 * s)))
        pygame.draw.rect(S, GOLD, r, max(1, int(2 * s)), 3)


_hs = {}


def hero_sala(S, x, y, t, face, moving):
    """Heroi da exploracao (ampliado e em cache). (x, y) = pes."""
    ph = int(t * 12) % 8 if moving else 0
    k = (face, moving, ph)
    if k not in _hs:
        tmp = pygame.Surface((76, 80), pygame.SRCALPHA)
        draw_hero_small(tmp, 38, 70, ph * 0.0714 if moving else 0.0, face, moving)
        _hs[k] = cvt(pygame.transform.smoothscale(tmp, (152, 160)))
    S.blit(_hs[k], (int(x) - 76, int(y) - 140))


class Particulas:
    """Particulas simples; limite global de 150 (as mais antigas saem)."""

    def __init__(self, maxn=150):
        self.p = []
        self.maxn = min(150, maxn)

    def burst(self, x, y, n, cols, v=(80, 280), g=420, life=(.6, 1.2), size=(3, 6), up=90):
        for _ in range(n):
            if len(self.p) >= self.maxn:
                self.p.pop(0)
            a = random.uniform(0, math.tau)
            sp = random.uniform(*v)
            self.p.append([x, y, math.cos(a) * sp, math.sin(a) * sp - up, random.uniform(*life), random.choice(cols),
                           random.randint(*size), g])

    def update(self, dt):
        for p in self.p:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += p[7] * dt
            p[4] -= dt
        self.p = [p for p in self.p if p[4] > 0]

    def draw(self, S):
        for p in self.p:
            pygame.draw.circle(S, p[5], (int(p[0]), int(p[1])), max(1, int(p[6] * min(1, p[4]))))


_os = {}


def outlined_surf(text, sz, col, th=3, hi=None):
    k = (text, sz, col, th, hi)
    s = _os.get(k)
    if s is None:
        if len(_os) > 160:
            _os.clear()
        im = txt(text, sz, col, True)
        edge = txt(text, sz, (30, 14, 4), True)
        s = pygame.Surface((im.get_width() + 2 * th + 2, im.get_height() + 2 * th + 2), pygame.SRCALPHA)
        for a in range(0, 360, 30):
            s.blit(edge, (th + 1 + round(math.cos(math.radians(a)) * th), th + 1 + round(math.sin(math.radians(a)) * th)))
        s.blit(im, (th + 1, th + 1))
        if hi:
            s.blit(txt(text, sz, hi, True), (th + 1, th + 1), pygame.Rect(0, 0, im.get_width(), im.get_height() // 2))
        _os[k] = cvt(s)
    return s


class Flutuantes:
    """Numeros/textos que saltam (fisica simples com 1 quique) e somem."""

    def __init__(self):
        self.l = []

    def add(self, text, x, y, col, big=False):
        self.l.append(dict(t=text, x=x, y0=y, y=y, vy=-440 if big else -360, col=col, age=0.0, big=big, b=0,
                           vx=random.uniform(-30, 30)))
        if len(self.l) > 14:
            self.l.pop(0)

    def update(self, dt):
        for f in self.l:
            f["age"] += dt
            f["vy"] += 1300 * dt
            f["y"] += f["vy"] * dt
            f["x"] += f["vx"] * dt
            if f["y"] > f["y0"] and f["vy"] > 0:
                if f["b"] < 1:
                    f["y"] = f["y0"]
                    f["vy"] *= -0.42
                    f["b"] += 1
                else:
                    f["y"] = f["y0"]
                    f["vy"] = 0
        self.l = [f for f in self.l if f["age"] < 1.5]

    def draw(self, S):
        for f in self.l:
            k = f["age"]
            sz = 74 if f["big"] else 52
            img = outlined_surf(f["t"], sz, f["col"], 3, (255, 255, 255))
            sc = 1 + 0.45 * max(0, 1 - k * 7)
            if sc > 1.02:
                img = pygame.transform.rotozoom(img, 0, sc)
            if k > 1.1:
                img = img.copy()
                img.set_alpha(int(255 * max(0, (1.5 - k) / 0.4)))
            S.blit(img, img.get_rect(center=(int(f["x"]), int(f["y"]))))


# ------------------------------------------------------------ cena do titulo
_tit = {}


def desenhar_cena_titulo(S, t):
    """Fundo da capa: salao + vitral + mestre no atril (direita). Substituivel pela arte final."""
    if "bg" not in _tit:
        _tit["bg"] = make_hall(W, H, 330, (70, 54, 42), (92, 64, 40), rose=False, carpet=True)
        _tit["rose"] = make_rose(110)
        ov = pygame.Surface((620, H), pygame.SRCALPHA)
        for x in range(0, 620, 4):
            pygame.draw.rect(ov, (8, 4, 2, int(238 * (1 - x / 620.0) ** 0.55)), (x, 0, 4, H))
        _tit["ov"] = cvt(ov)
    S.blit(_tit["bg"], (0, 0))
    r = pygame.transform.rotozoom(_tit["rose"], (t * 4) % 360, 1.0)
    S.blit(r, r.get_rect(center=(730, 150)))
    add_glow(S, (730, 150), 190, (90, 60, 20))
    draw_scholar(S, 730, 470, npc_look("mestre_guia"), t, "idle", False)
    draw_lectern(S, 730, 470)
    for cx in (610, 850):
        draw_candle(S, cx, 474, t + cx)
        add_glow(S, (cx, 440), 70, (255, 170, 60), 1 + math.sin(t * 13 + cx) * 0.08)
    S.blit(_tit["ov"], (0, 0))


def desenhar_logo(S, t, cx=300, cy=88):
    """Logo grande 'DISPUTATIO' + subtitulo. Substituivel pela arte final."""
    pygame.draw.line(S, GOLD, (cx - 250, cy + 52), (cx + 250, cy + 52), 3)
    outlined(S, "DISPUTATIO", 104, GOLD, (cx, cy), th=4, hi=GOLD_L)
    draw_text(S, "Universidade de Paris, século XIII", 28, (240, 214, 150), (cx, cy + 74))
    desenhar_icone(S, "cruz_latina", (cx - 292, cy - 6), 44, GOLD)
    desenhar_icone(S, "balanca", (cx + 292, cy - 6), 48, GOLD)


# --- arte nova (personagens/inimigos): sobrescreve as versoes antigas acima ---
from arte_personagens import hero_sala, hero_sprite, npc_sprite, npc_frame, npc_portrait, hero_combate, escudo_luz, hero_retrato  # noqa: E402,F401
from arte_inimigos import sprite_inimigo, escala_inimigo, miniatura_inimigo  # noqa: E402,F401

