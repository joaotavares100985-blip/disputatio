# -*- coding: utf-8 -*-
"""Base dos icones: cores, gradientes metalicos e a 'caneta' em coordenadas unitarias (-1..1, y para baixo).
Os desenhos sao feitos em alta resolucao (supersampling) por icones.desenhar_icone."""
import math

import pygame

INK = (43, 29, 14)
INKD = (24, 16, 10)
GOLD = (214, 170, 60)
GOLD_L = (255, 228, 140)
GOLD_D = (150, 108, 30)
PARCH = (243, 230, 196)
WHITE = (250, 248, 240)
RED = (200, 60, 56)
BLUE = (70, 120, 220)
GREEN = (80, 180, 100)
BROWN = (130, 84, 44)
STONE = (150, 142, 130)
SKIN = (238, 200, 165)


def mixc(a, b, k):
    return tuple(max(0, min(255, int(a[i] + (b[i] - a[i]) * k))) for i in range(3))


def lt(c, k=.35):
    return mixc(c, (255, 255, 255), k)


def dkc(c, k=.35):
    return mixc(c, (0, 0, 0), k)


class Grad(list):
    horiz = False


def G(*cols):
    g = Grad(cols)
    g.horiz = False
    return g


def GH(*cols):
    g = Grad(cols)
    g.horiz = True
    return g


def _c(col):
    if isinstance(col, Grad):
        return col[len(col) // 2]
    return col


def metal(c, k=1.0):
    """Gradiente 'metalico' a partir de uma cor base (claro -> base -> escuro)."""
    return G(lt(c, .55 * k), c, dkc(c, .38 * k))


OURO = G((255, 242, 176), (226, 182, 70), (164, 114, 34))
OURO_H = GH((176, 122, 36), (255, 238, 170), (222, 176, 62), (150, 104, 28))
PRATA = G((250, 252, 255), (192, 198, 212), (118, 124, 142))
BRONZE = G((240, 196, 126), (178, 128, 66), (108, 70, 34))
MADEIRA = G((176, 122, 70), (122, 78, 40), (72, 44, 22))
MADEIRA_H = GH((86, 54, 28), (170, 116, 66), (118, 76, 38), (70, 44, 22))
PEDRA = G((206, 198, 182), (150, 142, 128), (96, 88, 76))
PERG = G((252, 244, 214), (236, 220, 178), (208, 186, 136))
VERM = G((236, 96, 88), (188, 38, 44), (120, 18, 28))
AZUL = G((120, 160, 240), (54, 92, 200), (26, 46, 120))
VERDE = G((130, 204, 120), (62, 150, 80), (30, 90, 50))
ROXO = G((176, 120, 214), (110, 62, 160), (60, 30, 100))
PELE = G((250, 220, 188), (232, 190, 152), (190, 144, 108))
LINHO = G((255, 255, 252), (238, 234, 222), (196, 190, 176))
FERRO = G((190, 192, 200), (110, 112, 124), (58, 60, 70))


class Pen:
    """Caneta em coordenadas unitarias: (0,0)=centro, +-1 = metade do tamanho (u pixels)."""

    def __init__(self, S, cx, cy, u, t=0.0):
        self.S, self.cx, self.cy, self.u, self.t = S, cx, cy, u, t
        self.w = max(1, int(round(u * 0.065)))

    def q(self, x, y):
        return (self.cx + x * self.u, self.cy + y * self.u)

    # ------------------------------------------------------------ preenchimento
    def _fill_poly(self, pp, fill):
        if isinstance(fill, Grad):
            xs = [a[0] for a in pp]
            ys = [a[1] for a in pp]
            x0, y0 = int(min(xs)) - 1, int(min(ys)) - 1
            w, h = int(max(xs)) - x0 + 3, int(max(ys)) - y0 + 3
            if w < 3 or h < 3:
                pygame.draw.polygon(self.S, fill[len(fill) // 2], pp)
                return
            mask = pygame.Surface((w, h), pygame.SRCALPHA)
            pygame.draw.polygon(mask, (255, 255, 255, 255), [(a[0] - x0, a[1] - y0) for a in pp])
            from arte_kit import strip
            st = strip(tuple(fill), 24, fill.horiz)
            g = pygame.transform.smoothscale(st, (w, h))
            g.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
            self.S.blit(g, (x0, y0))
        else:
            pygame.draw.polygon(self.S, fill, pp)

    def poly(self, pts, fill, ol=INK, wd=None):
        pp = [self.q(*a) for a in pts]
        if fill is not None:
            self._fill_poly(pp, fill)
        if ol:
            pygame.draw.polygon(self.S, ol, pp, wd or self.w)

    def circ(self, x, y, r, fill, ol=INK):
        if isinstance(fill, Grad):
            self.ell(x, y, 2 * r, 2 * r, fill, ol)
            return
        c = self.q(x, y)
        rr = max(1, int(r * self.u))
        if fill is not None:
            pygame.draw.circle(self.S, fill, c, rr)
        if ol:
            pygame.draw.circle(self.S, ol, c, rr, self.w)

    def ring(self, x, y, r, col, wd=0.12):
        col = _c(col)
        pygame.draw.circle(self.S, col, self.q(x, y), max(1, int(r * self.u)), max(1, int(wd * self.u)))

    def ell(self, x, y, w, h, fill, ol=INK):
        """Elipse por CENTRO (x,y) e tamanho total (w,h)."""
        if isinstance(fill, Grad):
            pts = [(x + math.cos(math.tau * i / 28) * w / 2, y + math.sin(math.tau * i / 28) * h / 2) for i in range(28)]
            self.poly(pts, fill, ol)
            return
        r = pygame.Rect(0, 0, max(2, int(w * self.u)), max(2, int(h * self.u)))
        r.center = (int(self.cx + x * self.u), int(self.cy + y * self.u))
        if fill is not None:
            pygame.draw.ellipse(self.S, fill, r)
        if ol:
            pygame.draw.ellipse(self.S, ol, r, self.w)

    def rect(self, x, y, w, h, fill, ol=INK, rad=0.06):
        if isinstance(fill, Grad):
            r = min(rad, w / 2, h / 2)
            if r > 0.01:
                pts = []
                for cx_, cy_, a0 in ((x + w - r, y + r, -90), (x + w - r, y + h - r, 0), (x + r, y + h - r, 90), (x + r, y + r, 180)):
                    for k in range(5):
                        a = math.radians(a0 + 90 * k / 4)
                        pts.append((cx_ + r * math.cos(a), cy_ + r * math.sin(a)))
            else:
                pts = [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]
            self.poly(pts, fill, ol)
            return
        r = pygame.Rect(0, 0, max(1, int(w * self.u)), max(1, int(h * self.u)))
        r.topleft = (int(self.cx + x * self.u), int(self.cy + y * self.u))
        br = max(0, int(rad * self.u))
        if fill is not None:
            pygame.draw.rect(self.S, fill, r, 0, br)
        if ol:
            pygame.draw.rect(self.S, ol, r, self.w, br)

    def ln(self, x1, y1, x2, y2, col, wd=0.1):
        col = _c(col)
        a, b = self.q(x1, y1), self.q(x2, y2)
        w = max(1, int(wd * self.u))
        pygame.draw.line(self.S, col, a, b, w)
        if w > 3:
            pygame.draw.circle(self.S, col, a, w / 2)
            pygame.draw.circle(self.S, col, b, w / 2)

    def pl(self, pts, col, wd=0.1, closed=False):
        col = _c(col)
        pp = [self.q(*a) for a in pts]
        w = max(1, int(wd * self.u))
        pygame.draw.lines(self.S, col, closed, pp, w)
        if w > 3:
            for a in pp:
                pygame.draw.circle(self.S, col, a, w / 2)

    def arc(self, x, y, w, h, a0, a1, col, wd=0.1):
        col = _c(col)
        pts = []
        for i in range(25):
            a = a0 + (a1 - a0) * i / 24
            pts.append((x + math.cos(a) * w / 2, y - math.sin(a) * h / 2))
        self.pl(pts, col, wd)

    def curva(self, pts, fill, ol=INK, n=6, closed=True):
        from arte_kit import catmull
        self.poly(catmull(pts, n, closed), fill, ol)

    def tubo(self, pts, w0, w1, fill, ol=INK):
        from arte_kit import catmull
        c = catmull(pts, 6) if len(pts) > 2 else list(pts)
        L, R = [], []
        n = len(c)
        for i, (x, y) in enumerate(c):
            a, b = c[max(0, i - 1)], c[min(n - 1, i + 1)]
            dx, dy = b[0] - a[0], b[1] - a[1]
            d = math.hypot(dx, dy) or 1
            w = (w0 + (w1 - w0) * i / max(1, n - 1)) / 2
            L.append((x - dy / d * w, y + dx / d * w))
            R.append((x + dy / d * w, y - dx / d * w))
        self.poly(L + R[::-1], fill, ol)
        self.circ(c[0][0], c[0][1], w0 / 2, fill if not isinstance(fill, Grad) else fill[len(fill) // 2], ol)
        self.circ(c[-1][0], c[-1][1], w1 / 2, fill if not isinstance(fill, Grad) else fill[len(fill) // 2], ol)

    def text(self, s, x, y, size, col):
        col = _c(col)
        im = _font(size * self.u).render(s, True, col)
        self.S.blit(im, im.get_rect(center=self.q(x, y)))

    # ------------------------------------------------------------- acabamentos
    def hl(self, pts, a=90, col=(255, 255, 255)):
        """Realce translucido (poligono)."""
        pp = [self.q(*p) for p in pts]
        xs = [a_[0] for a_ in pp]
        ys = [a_[1] for a_ in pp]
        x0, y0 = int(min(xs)) - 1, int(min(ys)) - 1
        w, h = int(max(xs)) - x0 + 3, int(max(ys)) - y0 + 3
        if w < 2 or h < 2:
            return
        s = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.polygon(s, col + (a,), [(p[0] - x0, p[1] - y0) for p in pp])
        self.S.blit(s, (x0, y0))

    def hln(self, x1, y1, x2, y2, wd=0.05, a=150, col=(255, 255, 255)):
        a_, b_ = self.q(x1, y1), self.q(x2, y2)
        w = max(1, int(wd * self.u))
        x0, y0 = int(min(a_[0], b_[0])) - w, int(min(a_[1], b_[1])) - w
        W, H = int(abs(a_[0] - b_[0])) + 2 * w + 2, int(abs(a_[1] - b_[1])) + 2 * w + 2
        s = pygame.Surface((W, H), pygame.SRCALPHA)
        pygame.draw.line(s, col + (a,), (a_[0] - x0, a_[1] - y0), (b_[0] - x0, b_[1] - y0), w)
        self.S.blit(s, (x0, y0))

    def gema(self, x, y, r, col):
        self.circ(x, y, r, G(lt(col, .5), col, dkc(col, .4)), dkc(col, .6))
        self.circ(x - r * .3, y - r * .3, r * .28, (255, 255, 255), None)

    def estrela(self, x, y, ro, ri, n, fill, ol=INK, rot=-math.pi / 2):
        pts = []
        for i in range(n * 2):
            r = ro if i % 2 == 0 else ri
            a = rot + math.pi * i / n
            pts.append((x + r * math.cos(a), y + r * math.sin(a)))
        self.poly(pts, fill, ol)

    def sub(self, x, y, k):
        """Nova caneta deslocada para (x,y) e com escala k (para compor icones dentro de icones)."""
        cx, cy = self.q(x, y)
        return Pen(self.S, cx, cy, self.u * k, self.t)


_fonts = {}


def _font(sz):
    sz = max(8, int(sz))
    if sz not in _fonts:
        f = pygame.font.Font(None, sz)
        f.set_bold(True)
        _fonts[sz] = f
    return _fonts[sz]


def star_pts(n, ro, ri, rot=-math.pi / 2):
    return [((ro if i % 2 == 0 else ri) * math.cos(rot + math.pi * i / n), (ro if i % 2 == 0 else ri) * math.sin(rot + math.pi * i / n))
            for i in range(n * 2)]


def flame(p, x, y, k, t, col=(255, 140, 30)):
    f = 1 + math.sin(t * 15 + x * 7) * 0.12 + math.sin(t * 27) * 0.07
    h = .7 * k * f
    p.poly([(x, y - h), (x + .17 * k, y - h * .35), (x + .2 * k, y), (x, y + .12 * k), (x - .2 * k, y), (x - .17 * k, y - h * .35)],
           G((255, 200, 60), col, (214, 70, 24)), (150, 40, 14))
    p.ell(x, y - .06 * k, .18 * k, .34 * k * f, (255, 244, 190), None)
