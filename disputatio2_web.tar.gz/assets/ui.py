# -*- coding: utf-8 -*-
"""Interface (960x540): base de cenas, grades roliveis, titulo, tutorial, codex, cartoes, dialogos, ficha, fim de jogo."""
import math
import random

import pygame

import audio
import conteudo as C
import estado as E
from desenho import *
from textos import curto_txt, obj_curto, obj_opcoes, obj_expl, romano
import ui_extra as X
from ui_extra import FocoMixin

CMD_ICONES = [("Argumentar", "balao"), ("Autoridade", "pergaminho"), ("Item", "frasco"), ("Defender", "escudo"), ("Fugir", "seta_fuga")]
BARRA_HP = ((240, 100, 100), (170, 40, 50))
BARRA_TINTA = ((110, 150, 250), (50, 70, 170))
BARRA_XP = ((230, 200, 90), (170, 130, 40))


def clamp(v, a, b):
    return max(a, min(b, v))


# ------------------------------------------------------------------ componentes
class GradeRolavel:
    """Grade de cartoes (cols colunas) com rolagem vertical por arraste/roda. draw_item(S, rect, i)."""

    def __init__(self, rect, n, cols, ch, gap, draw_item, on_tap=None):
        self.rect = pygame.Rect(rect)
        self.n, self.cols, self.ch, self.gap = n, cols, ch, gap
        self.draw_item, self.on_tap = draw_item, on_tap
        self.cw = (self.rect.w - gap * (cols - 1)) // cols
        self.off = 0.0
        self.drag = None
        self.moved = 0

    def total(self):
        rows = (self.n + self.cols - 1) // self.cols
        return max(0, rows * (self.ch + self.gap) - self.gap)

    def maxoff(self):
        return max(0, self.total() - self.rect.h)

    def cell(self, i):
        r, c = divmod(i, self.cols)
        return pygame.Rect(self.rect.x + c * (self.cw + self.gap), int(self.rect.y + r * (self.ch + self.gap) - self.off), self.cw, self.ch)

    def hit(self, pos):
        for i in range(self.n):
            if self.cell(i).collidepoint(pos):
                return i
        return None

    def scroll_to(self, i):
        r = i // self.cols
        self.off = clamp(r * (self.ch + self.gap) - (self.rect.h - self.ch) // 2, 0, self.maxoff())

    def down(self, i, pos):
        if self.rect.collidepoint(pos):
            self.drag = [i, pos[1], self.off]
            self.moved = 0

    def move(self, i, pos):
        d = self.drag
        if d and d[0] == i:
            dy = pos[1] - d[1]
            self.moved = max(self.moved, abs(dy))
            self.off = clamp(d[2] - dy, 0, self.maxoff())

    def up(self, i, pos):
        d = self.drag
        if d and d[0] == i:
            self.drag = None
            if self.moved < 14 and self.rect.collidepoint(pos) and self.on_tap:
                k = self.hit(pos)
                if k is not None:
                    audio.sfx("clique")
                    self.on_tap(k)
            return True
        return False

    def wheel(self, d):
        self.off = clamp(self.off + d * (self.ch + self.gap) * 0.7, 0, self.maxoff())

    def draw(self, S):
        old = S.get_clip()
        S.set_clip(self.rect)
        for i in range(self.n):
            r = self.cell(i)
            if r.bottom < self.rect.top or r.top > self.rect.bottom:
                continue
            self.draw_item(S, r, i)
        S.set_clip(old)
        if self.maxoff() > 0:
            tr = pygame.Rect(self.rect.right - 6, self.rect.y + 4, 5, self.rect.h - 8)
            pygame.draw.rect(S, (60, 44, 24), tr, 0, 2)
            hh = max(30, int(tr.h * self.rect.h / max(1, self.total())))
            yy = tr.y + int((tr.h - hh) * self.off / self.maxoff())
            pygame.draw.rect(S, GOLD, (tr.x, yy, 5, hh), 0, 2)


_bgc = {}


def tela_escura(S, topc=(24, 14, 8), botc=(8, 4, 2)):
    k = ("escura", topc, botc)
    if k not in _bgc:
        _bgc[k] = cvt(vgrad(W, H, topc, botc))
    S.blit(_bgc[k], (0, 0))


def barra_icone(S, x, y, w, h, icone, frac, cores, texto=None, t=0.0):
    """Icone a esquerda + barra fina com numero opcional."""
    desenhar_icone(S, icone, (x + h // 2 + 2, y + h // 2), int(h * 1.35), None, t)
    r = pygame.Rect(x + h + 10, y + 2, w - h - 10, h - 4)
    draw_bar(S, r, frac, cores[0], cores[1])
    if texto:
        draw_text(S, texto, 22, (255, 255, 255), r.center, sh=1)
    return r


def desenhar_item(S, cx, cy, it, size=44, t=0.0):
    """Icone de item: usa o campo 'simbolo' se existir; senao o desenho antigo (livro/frasco)."""
    s = E.icone(it, None)
    if s:
        col = item_cor(it)
        add_glow(S, (cx, cy), int(size * 0.8), mix(col, (0, 0, 0), .6))
        from icones import desenhar_item_icone
        desenhar_item_icone(S, None, (cx, cy + math.sin(t * 2.4) * 2), size * .9, t, it)
    else:
        draw_item_icon(S, cx, cy, it, size, t)


def desenhar_cartoes_resposta(cena, S, textos, estados, y, h=150, fn=None, t=0.0):
    """3 cartoes lado a lado (A/B/C) com icone e texto curto. estados: normal|ok|bad|dim."""
    n = len(textos)
    gap = 12
    w = (W - 48 - gap * (n - 1)) // max(1, n)
    icones = ("livro", "balanca", "pena")
    for i, tx in enumerate(textos):
        r = pygame.Rect(24 + i * (w + gap), y, w, h)
        st = estados[i]
        pr = fn is not None and st == "normal" and cena.is_pressed(r)
        rr = r.move(0, 3 if pr else 0)
        col = {"normal": (250, 238, 208), "ok": (184, 236, 156), "bad": (244, 166, 154), "dim": (150, 138, 112)}[st]
        import arte_ui
        arte_ui.cartao(S, rr, col, st == "dim")
        bc = (rr.x + 28, rr.y + 28)
        pygame.draw.circle(S, (60, 40, 12), bc, 20)
        pygame.draw.circle(S, GOLD, bc, 17)
        draw_text(S, "ABC"[i % 3], 28, INK, bc, bold=True, shadow=None)
        ic = {"ok": "check", "bad": "x"}.get(st, icones[i % 3])
        desenhar_icone(S, ic, (rr.centerx, rr.y + 50), 56, None if st in ("ok", "bad") else mix(COR_ICO.get(ic, GOLD), (0, 0, 0), .15), t)
        sz, lines, lh = fit_text(tx, rr.w - 28, lh_max(26) * 2 + 4, 26, 22)
        draw_lines(S, lines[:2], sz, INK if st != "dim" else (70, 60, 44), rr.centerx, rr.y + 90, lh, center=True)
        if fn is not None and st == "normal":
            cena.reg(r, lambda i=i: fn(i))


COR_ICO = {"livro": (150, 40, 44), "balanca": (190, 140, 40), "pena": (80, 90, 140)}


def lh_max(sz):
    return font(sz).get_linesize()


def desenhar_feedback(cena, S, ok, frase, extras, fn_cont, fn_mais, t, y, h, cont_label="Continuar"):
    """Icone grande de acerto/erro + 1 frase curta + 'Saber mais' opcional + Continuar."""
    panel(S, pygame.Rect(16, y, 928, h), 246)
    cx, cy = 96, y + h // 2 - 6
    pop = min(1.0, t * 4)
    r = int(52 * (0.5 + 0.5 * math.sin(pop * math.pi / 2) + 0.12 * math.sin(pop * math.pi)))
    col = (70, 180, 90) if ok else (200, 70, 64)
    add_glow(S, (cx, cy), int(r * 1.8), mix(col, (0, 0, 0), .45))
    pygame.draw.circle(S, (30, 20, 10), (cx, cy), r + 5)
    pygame.draw.circle(S, mix(col, (255, 255, 255), .15), (cx, cy), r)
    desenhar_icone(S, "check" if ok else "x", (cx, cy), int(r * 1.3), (255, 255, 255))
    draw_text(S, "Optime!" if ok else "Sophisma!", 40, GOLD_L if ok else (255, 140, 130), (190, y + 28), anchor="midleft", bold=True)
    sz, lines, lh = fit_text(frase, 740, lh_max(30) * 2 + 4, 30, 22)
    draw_lines(S, lines[:2], sz, PARCH, 190, y + 56, lh)
    ex = 190
    for ic, tx, cc in extras:
        desenhar_icone(S, ic, (ex + 16, y + h - 36), 34)
        im = draw_text(S, tx, 26, cc, (ex + 38, y + h - 36), anchor="midleft", bold=True)
        ex = im.right + 20
    bx = 940 - 200
    cena.btn(S, (bx, y + h - 66, 200, 56), cont_label, fn_cont, "gold", 30)
    if fn_mais:
        cena.btn(S, (bx - 216, y + h - 66, 200, 56), "Saber mais", fn_mais, "normal", 28, icone="interrogacao")


def desenhar_dica(S, texto, t, y=74):
    """Balao curtissimo do mestre guia (<= 1 linha)."""
    a = clamp(t * 4, 0, 1)
    f = font(24)
    w = f.size(texto)[0] + 100
    r = pygame.Rect(0, 0, w, 56)
    r.midtop = (W // 2, int(y - (1 - a) * 20))
    import arte_ui
    arte_ui.caixa_balao(S, r)
    S.blit(npc_portrait("mestre_guia", 46), (r.x + 5, r.y + 5))
    draw_text(S, texto, 24, INK, (r.x + 62, r.centery), anchor="midleft", shadow=None)


def desenhar_gire(S, t):
    """Dica animada 'Gire o celular' (celular girando)."""
    r = pygame.Rect(0, 0, 330, 104)
    r.midtop = (W // 2, 10)
    panel(S, r, 235)
    k = (t * 0.55) % 1.0
    e = 0.0 if k < 0.2 else (1.0 if k > 0.7 else (k - 0.2) / 0.5)
    e = e * e * (3 - 2 * e)
    ang = 90 * e
    ph = pygame.Surface((46, 80), pygame.SRCALPHA)
    pygame.draw.rect(ph, (230, 226, 214), (0, 0, 46, 80), 0, 9)
    pygame.draw.rect(ph, (50, 40, 30), (4, 8, 38, 60), 0, 3)
    pygame.draw.circle(ph, (50, 40, 30), (23, 74), 3)
    pygame.draw.rect(ph, (110, 150, 230), (4, 8, 38, 60), 0, 3)
    pygame.draw.polygon(ph, (255, 228, 140), [(23, 20), (30, 38), (16, 38)])
    im = pygame.transform.rotozoom(ph, ang, 1.0)
    S.blit(im, im.get_rect(center=(r.x + 60, r.centery)))
    pygame.draw.arc(S, GOLD_L, (r.x + 24, r.centery - 36, 72, 72), 0.3, 2.2, 4)
    draw_arrow(S, r.x + 38, r.centery - 36, "l", GOLD_L, 8)
    draw_text(S, "Gire o celular", 30, GOLD_L, (r.x + 215, r.centery), bold=True)


# ------------------------------------------------------------------ base
class Cena(FocoMixin):
    opaque = True

    def __init__(self, game):
        self.game = game
        self.hits = []
        self.pressed = None
        self.dpos = None
        self.pid = None
        self.lists = []
        self.t = 0.0

    def reg(self, rect, fn):
        self.hits.append((pygame.Rect(rect), fn))

    def is_pressed(self, rect):
        return bool(self.pressed and self.dpos and rect.collidepoint(self.pressed) and rect.collidepoint(self.dpos))

    def btn(self, S, rect, label, fn, state="normal", sz=28, letter=None, accent=None, icone=None):
        rect = pygame.Rect(rect)
        draw_button(S, rect, label, state, sz, self.is_pressed(rect) and state != "dim", letter, accent, icone)
        if fn:
            self.reg(rect, fn)

    def rbtn(self, S, c, r, icone, label, fn, state="normal", pulse=False, cor=None):
        rect = pygame.Rect(c[0] - r, c[1] - r, 2 * r, 2 * r + (30 if label else 0))
        draw_round(S, c, r, icone, label, state, self.is_pressed(rect) and state != "dim", pulse, self.t, cor)
        if fn and state != "dim":
            self.reg(rect, fn)

    def enter(self):
        pass

    def resume(self):
        self.pid = None
        self.pressed = None
        self.dpos = None

    def update(self, dt):
        self.t += dt

    def draw(self, S):
        pass

    def key(self, k):
        pass

    def wheel(self, d):
        for l in self.lists:
            l.wheel(d)

    def down(self, i, pos):
        if self.pid is None:
            self.pid = i
            self.pressed = pos
            self.dpos = pos
        for l in self.lists:
            l.down(i, pos)

    def move(self, i, pos):
        if i == self.pid:
            self.pressed = pos
        for l in self.lists:
            l.move(i, pos)

    def up(self, i, pos):
        used = False
        for l in self.lists:
            used = l.up(i, pos) or used
        if i != self.pid:
            return
        dpos = self.dpos
        self.pid = None
        self.pressed = None
        self.dpos = None
        if used or dpos is None:
            return
        for r, fn in reversed(self.hits):
            if r.collidepoint(pos) and r.collidepoint(dpos):
                if r.w * r.h < W * H * 0.3:
                    audio.sfx("clique")
                fn()
                break


def _menu_online(g):
    from ui_online import MenuOnline
    return MenuOnline(g)


# ------------------------------------------------------------------ titulo
class Titulo(Cena):
    def __init__(self, game):
        super().__init__(game)
        rnd = random.Random(5)
        self.dust = [[rnd.uniform(0, W), rnd.uniform(0, H), rnd.uniform(5, 14), rnd.uniform(.5, 2)] for _ in range(26)]

    ok_direto = True

    def enter(self):
        audio.musica("titulo")

    def resume(self):
        super().resume()
        audio.musica("titulo")

    def key(self, k):
        if k == pygame.K_ESCAPE and self.game.fs_ativo():
            self.game.tela_cheia()

    def update(self, dt):
        super().update(dt)
        for d in self.dust:
            d[1] -= d[2] * dt
            d[0] += math.sin(self.t + d[3]) * 6 * dt
            if d[1] < 0:
                d[1] = H
                d[0] = random.uniform(0, W)

    def draw(self, S):
        self.hits = []
        g = self.game
        t = self.t
        import arte_capa
        arte_capa.desenhar_capa(S, t)
        self.btn(S, (320, 372, 320, 68), "Jogar", g.novo_jogo, "gold", 44, icone="play")
        self.btn(S, (220, 452, 150, 56), "Como jogar", lambda: g.push(Tutorial(g)), "normal", 26)
        self.btn(S, (380, 452, 150, 56), "Códex", lambda: g.push(Codex(g)), "normal", 28)
        self.btn(S, (540, 452, 200, 56), "Jogar online", lambda: g.push(_menu_online(g)), "normal", 26)
        draw_text(S, "Argumente. Distinga. Vença a disputa.", 22, (214, 190, 140), (480, 526))
        mu = audio.estado()["mudo"]
        X.rbtn_glifo(self, S, (836, 38), 26, lambda S_, c, sz, tom: X.glifo_som_b(S_, c, sz, tom, mu), audio.alternar_mudo)
        rf = X.rbtn_glifo(self, S, (900, 38), 26, X.glifo_expandir_b, g.tela_cheia)
        self.fs_rect = tuple(rf)


# ---------------------------------------------------------------- tutorial
ILUSTRACOES = ("joystick", "interagir", "comandos", "cartoes", "loja", "chefe", "minimapa")


def cartoes_tutorial():
    tc = getattr(E, "TUTORIAL_CARTOES", None)
    if tc:
        out = []
        for c in tc:
            if isinstance(c, dict):
                out.append(dict(simbolo=c.get("simbolo", "estrela"), titulo=curto_txt(c.get("titulo", ""), 28), texto=curto_txt(c.get("texto", ""), 90)))
        if out:
            return out
    passos = list(getattr(C, "TUTORIAL", [])) or [dict(titulo="Bem-vindo", texto="Explore as salas, vença as disputas e suba os andares.")]
    chaves = [("joystick", ("movimento", "mover", "andar")), ("interagir", ("sala", "porta", "interag")),
              ("comandos", ("combate", "disputa")), ("cartoes", ("objeç", "objec")), ("loja", ("livraria", "loja", "item")),
              ("chefe", ("chefe",))]
    out = []
    usados = set()
    for sim, kws in chaves:
        achado = None
        for i, p in enumerate(passos):
            tt = (p.get("titulo", "") + " " + p.get("texto", "")).lower()
            if i not in usados and any(k in p.get("titulo", "").lower() for k in kws):
                achado = i
                break
        if achado is None:
            n = len(passos)
            achado = min(n - 1, int(round(len(out) * (n - 1) / 5.0)))
        usados.add(achado)
        p = passos[achado]
        out.append(dict(simbolo=sim, titulo=curto_txt(p.get("titulo", ""), 28), texto=curto_txt(p.get("texto", ""), 90)))
    return out


def ilustracao(S, sim, rect, t):
    cx, cy = rect.center
    if sim == "joystick":
        add_glow(S, (cx, cy), 150, (60, 44, 20))
        pygame.draw.circle(S, (14, 9, 5), (cx, cy), 110)
        pygame.draw.circle(S, (90, 66, 30), (cx, cy), 110, 5)
        for d, (ox, oy) in {"u": (0, -84), "d": (0, 84), "l": (-84, 0), "r": (84, 0)}.items():
            draw_arrow(S, cx + ox, cy + oy, d, (150, 116, 56), 11)
        kx, ky = cx + math.cos(t * 1.6) * 52, cy + math.sin(t * 1.6) * 52
        pygame.draw.circle(S, GOLD, (int(kx), int(ky)), 40)
        pygame.draw.circle(S, GOLD_L, (int(kx) - 10, int(ky) - 12), 14)
        pygame.draw.circle(S, (120, 84, 24), (int(kx), int(ky)), 40, 4)
        desenhar_icone(S, "mao", (int(kx) + 26, int(ky) + 38), 64)
    elif sim == "interagir":
        draw_round(S, (cx + 30, cy + 20), 80, "mao", None, "gold", False, True, t, isz=96)
        draw_text(S, "A", 36, INK, (cx + 30 + 54, cy + 20 - 56), bold=True, shadow=None)
        bob = math.sin(t * 5) * 6
        pygame.draw.circle(S, (250, 242, 220), (cx - 100, int(cy - 70 + bob)), 34)
        pygame.draw.circle(S, (90, 60, 20), (cx - 100, int(cy - 70 + bob)), 34, 3)
        desenhar_icone(S, "ponto_de_exclamacao", (cx - 100, int(cy - 70 + bob)), 40)
        desenhar_icone(S, "bau", (cx - 100, cy + 10), 70)
    elif sim == "comandos":
        for k, (lab, ic) in enumerate(CMD_ICONES):
            a = k % 3 if k < 3 else k - 3
            x = cx - 100 + a * 100 - (50 if k >= 3 else 0) + (50 if k >= 3 else 0)
            x = (cx - 100 + k * 100) if k < 3 else (cx - 50 + (k - 3) * 100)
            y = cy - 60 if k < 3 else cy + 60
            draw_round(S, (x, y), 40, ic, lab, "normal", False, k == int(t * 1.2) % 5, t, lsz=22)
    elif sim == "cartoes":
        for k in range(3):
            r = pygame.Rect(cx - 150 + k * 102, cy - 70, 96, 130)
            ok = k == int(t * 0.8) % 3
            pygame.draw.rect(S, (184, 236, 156) if ok else (250, 238, 208), r, 0, 12)
            pygame.draw.rect(S, (120, 84, 24), r, 3, 12)
            pygame.draw.circle(S, GOLD, (r.x + 20, r.y + 20), 15)
            draw_text(S, "ABC"[k], 24, INK, (r.x + 20, r.y + 20), bold=True, shadow=None)
            desenhar_icone(S, "check" if ok else ["livro", "balanca", "pena"][k], r.center, 44)
        desenhar_icone(S, "balao", (cx, cy - 110), 56)
    elif sim == "loja":
        pygame.draw.rect(S, (112, 70, 36), (cx - 130, cy + 40, 260, 50), 0, 8)
        pygame.draw.rect(S, (60, 34, 14), (cx - 130, cy + 40, 260, 50), 3, 8)
        for k, ic in enumerate(("livro", "frasco", "pergaminho")):
            desenhar_icone(S, ic, (cx - 80 + k * 80, cy - 10 + math.sin(t * 2 + k) * 3), 64)
        draw_coin(S, cx - 30, cy + 66, 14)
        draw_coin(S, cx + 4, cy + 66, 14)
        draw_text(S, "x10", 28, GOLD_L, (cx + 40, cy + 66), anchor="midleft", bold=True)
    elif sim == "chefe":
        add_glow(S, (cx, cy), 160, (110, 20, 20), 1 + .1 * math.sin(t * 3))
        desenhar_icone(S, "mitra", (cx, cy - 10), 150, None, t)
        desenhar_icone(S, "balanca", (cx - 110, cy + 60), 60)
        desenhar_icone(S, "livro", (cx + 110, cy + 60), 60)
    elif sim == "minimapa":
        for gx in range(3):
            for gy in range(3):
                col = (214, 170, 60) if (gx, gy) == (1, 1) else (120, 90, 50)
                pygame.draw.rect(S, col, (cx - 84 + gx * 60, cy - 84 + gy * 60, 50, 50), 0, 6)
        desenhar_icone(S, "estrela", (cx, cy), 36)
    else:
        add_glow(S, (cx, cy), 130, (70, 50, 20))
        desenhar_icone(S, sim, (cx, cy + math.sin(t * 2) * 4), 170, None, t)


class Tutorial(Cena):
    def __init__(self, game):
        super().__init__(game)
        self.cards = cartoes_tutorial()
        self.i = 0
        self.sw = None
        self.aba_cmd = X.aba_comandos_padrao(game.inp)

    def set_aba_cmd(self, k):
        self.aba_cmd = k

    def foco_inicial(self, cs):
        return cs[-1]

    def nav(self, d):
        if d == "left":
            self._ant()
        elif d == "right":
            self._prox(False)
        else:
            super().nav(d)

    def abas(self, d):
        if self.i >= len(self.cards):
            self.aba_cmd = (self.aba_cmd + d) % 3
        elif d < 0:
            self._ant()
        else:
            self._prox(False)

    def down(self, i, pos):
        super().down(i, pos)
        self.sw = (i, pos[0], pos[1])

    def up(self, i, pos):
        if self.sw and self.sw[0] == i:
            dx, dy = pos[0] - self.sw[1], pos[1] - self.sw[2]
            self.sw = None
            if abs(dx) > 70 and abs(dx) > abs(dy) * 1.5:
                self.pid = None
                self.dpos = None
                self.pressed = None
                if dx < 0:
                    self._prox(False)
                else:
                    self._ant()
                return
        super().up(i, pos)

    def key(self, k):
        if k in (pygame.K_RIGHT, pygame.K_SPACE, pygame.K_RETURN):
            self._prox(True)
        elif k == pygame.K_LEFT:
            self._ant()
        elif k == pygame.K_ESCAPE:
            self.game.pop(self)

    def _draw_cmd(self, S):
        g = self.game
        n = len(self.cards)
        draw_text(S, "COMANDOS", 40, GOLD_L, (28, 38), anchor="midleft", bold=True)
        draw_text(S, "Entrada: " + g.inp.nome_modo(), 22, (214, 190, 140), (360, 38), anchor="midleft", shadow=None)
        self.btn(S, (790, 12, 150, 56), "Pular", lambda: g.pop(self), "normal", 28)
        X.desenhar_comandos(self, S, self.aba_cmd, self.t)
        self._rodape(S, n + 1, True)

    def _rodape(self, S, tot, ult):
        for k in range(tot):
            x = 480 + (k - (tot - 1) / 2) * 26
            pygame.draw.circle(S, GOLD if k == self.i else (90, 70, 40), (int(x), 452), 8 if k == self.i else 6)
        self.rbtn(S, (46, 254), 36, "seta_esq", None, self._ant, "normal" if self.i > 0 else "dim")
        self.rbtn(S, (914, 254), 36, "seta_dir", None, lambda: self._prox(True), "gold" if not ult else "dim")
        self.btn(S, (360, 470, 240, 58), "Entendi!" if ult else "Próximo", lambda: self._prox(True), "gold", 30, icone="check" if ult else None)

    def draw(self, S):
        self.hits = []
        g = self.game
        tela_escura(S, (34, 22, 14), (10, 6, 3))
        n = len(self.cards)
        if self.i >= n:
            self._draw_cmd(S)
            return
        c = self.cards[self.i]
        draw_text(S, "COMO JOGAR", 40, GOLD_L, (28, 38), anchor="midleft", bold=True)
        self.btn(S, (790, 12, 150, 56), "Pular", lambda: g.pop(self), "normal", 28)
        self.btn(S, (600, 12, 180, 56), "Comandos", lambda: setattr(self, "i", len(self.cards)), "normal", 26)
        card = pygame.Rect(100, 84, 760, 340)
        panel(S, card, 246)
        ill = pygame.Rect(card.x + 12, card.y + 12, 340, 316)
        pygame.draw.rect(S, (22, 14, 8), ill, 0, 14)
        pygame.draw.rect(S, (110, 80, 24), ill, 2, 14)
        old = S.get_clip()
        S.set_clip(ill)
        sim = c.get("simbolo", "estrela")
        if sim not in ILUSTRACOES and not icone_existe(sim):
            sim = ILUSTRACOES[min(self.i, 5)]
        ilustracao(S, sim, ill, self.t)
        S.set_clip(old)
        sz, lines, lh = fit_text(c["titulo"], 370, lh_max(44) * 2, 44, 30, True)
        y = draw_lines(S, lines, sz, GOLD_L, card.x + 372, card.y + 30, lh, shadow=(0, 0, 0), bold=True)
        sz, lines, lh = fit_text(c["texto"], 370, lh_max(30) * 4, 30, 24)
        draw_lines(S, lines, sz, PARCH, card.x + 372, y + 14, lh)
        draw_text(S, "%d / %d" % (self.i + 1, n + 1), 24, (190, 160, 110), (card.right - 20, card.bottom - 22), anchor="midright", shadow=None)
        self._rodape(S, n + 1, False)

    def _ant(self):
        self.i = max(0, self.i - 1)

    def _prox(self, fim_fecha):
        if self.i >= len(self.cards):
            if fim_fecha:
                self.game.pop(self)
        else:
            self.i += 1


# ------------------------------------------------------------------- codex
class Codex(Cena):
    ABAS = ("Símbolos", "Glossário", "Biografias")
    ICO_ABA = ("estrela", "pergaminho", "pessoa")

    def __init__(self, game, aba=0):
        super().__init__(game)
        self.aba = aba
        self.det = None
        self.dados = [self._simbolos(), self._glossario(), self._bios()]
        self.mk_lists()

    def _simbolos(self):
        return [dict(ic=k, titulo=v.get("nome", k), sub="", curto=v.get("curto", ""), longo=v.get("significado", "")) for k, v in E.SIMBOLOS.items()]

    def _glossario(self):
        return [dict(ic="pergaminho", titulo=d.get("termo", ""), sub="", curto=d.get("curto") or curto_txt(d.get("definicao", ""), 90),
                     longo=d.get("definicao", "")) for d in getattr(C, "GLOSSARIO", [])]

    def _bios(self):
        out = []
        for d in getattr(C, "BIOGRAFIAS", []):
            longo = d.get("texto", "")
            if d.get("obras"):
                longo += "\nObras: " + "; ".join(d["obras"])
            out.append(dict(ic=E.icone(d, "pessoa"), titulo=d.get("nome", ""), sub=d.get("anos", ""),
                            curto=d.get("curto") or d.get("titulo", ""), longo=longo))
        return out

    def mk_lists(self):
        data = self.dados[self.aba]
        self.lst = GradeRolavel((20, 150, 920, 376), len(data), 2, 104, 10, self.item, self.abrir)
        self.lists = [self.lst]
        self.det = None

    def item(self, S, r, i):
        d = self.dados[self.aba][i]
        pygame.draw.rect(S, (44, 28, 14), r, 0, 14)
        pygame.draw.rect(S, (120, 88, 30), r, 2, 14)
        c = (r.x + 44, r.centery)
        pygame.draw.circle(S, (24, 15, 8), c, 34)
        pygame.draw.circle(S, GOLD, c, 34, 2)
        desenhar_icone(S, d["ic"], c, 50, None, self.t)
        tx = r.x + 90
        w = r.w - 100
        draw_text(S, trunc(d["titulo"], 26, w - (110 if d["sub"] else 0)), 26, GOLD_L, (tx, r.y + 22), anchor="midleft", bold=True)
        if d["sub"]:
            draw_text(S, trunc(d["sub"], 22, 108), 22, (200, 170, 110), (r.right - 12, r.y + 22), anchor="midright", shadow=None)
        sz, lines, lh = fit_text(d["curto"], w, lh_max(22) * 2, 22, 22)
        draw_lines(S, lines[:2], 22, PARCH, tx, r.y + 40, lh)
        draw_text(S, "ver mais", 22, GOLD, (r.right - 14, r.bottom - 14), anchor="bottomright", shadow=None)

    def abrir(self, i):
        d = self.dados[self.aba][i]
        f = font(26)
        linhas = [(ln, False) for ln in wrap(d["longo"], f, 760)]
        self.det = (d, linhas)
        self.dl = GradeRolavel((100, 214, 780, 244), len(linhas), 1, 32, 0, self.item_det)
        self.lists = [self.dl]

    def item_det(self, S, r, i):
        ln, b = self.det[1][i]
        if ln:
            S.blit(txt(ln, 26, PARCH), (r.x + 4, r.y + 3))

    def fechar_det(self):
        self.det = None
        self.lists = [self.lst]

    def trocar(self, a):
        if a != self.aba:
            self.aba = a
            self.mk_lists()

    def key(self, k):
        if k == pygame.K_ESCAPE:
            if self.det:
                self.fechar_det()
            else:
                self.game.pop(self)

    def abas(self, d):
        if self.det is None:
            self.trocar((self.aba + d) % len(self.ABAS))

    def codex_(self):
        if self.det is None:
            self.game.pop(self)

    def nav(self, d):
        if self.det is not None and d in ("up", "down"):
            self.dl.wheel(1 if d == "down" else -1)
        else:
            super().nav(d)

    def draw(self, S):
        self.hits = []
        tela_escura(S, (30, 20, 12), (10, 6, 3))
        if self.det is None:
            draw_text(S, "CÓDEX", 44, GOLD_L, (28, 38), anchor="midleft", bold=True)
            self.rbtn(S, (916, 40), 30, "x", None, lambda: self.game.pop(self), "normal")
            for k, nm in enumerate(self.ABAS):
                self.btn(S, (190 + k * 218, 12, 210, 56), nm, (lambda k=k: self.trocar(k)), "gold" if self.aba == k else "normal", 28, icone=self.ICO_ABA[k])
            draw_text(S, "Arraste para rolar, toque para abrir", 22, (160, 134, 90), (480, 128), shadow=None)
            self.lst.draw(S)
        else:
            d, _ = self.det
            panel(S, pygame.Rect(60, 24, 840, 492), 248)
            c = (150, 100)
            add_glow(S, c, 90, (70, 50, 20))
            pygame.draw.circle(S, (24, 15, 8), c, 62)
            pygame.draw.circle(S, GOLD, c, 62, 3)
            desenhar_icone(S, d["ic"], c, 92, None, self.t)
            sz, lines, lh = fit_text(d["titulo"], 640, lh_max(44) * 2, 44, 30, True)
            y = draw_lines(S, lines, sz, GOLD_L, 240, 56, lh, shadow=(0, 0, 0), bold=True)
            if d["sub"]:
                draw_text(S, d["sub"], 26, (200, 170, 110), (240, y + 4), anchor="topleft", shadow=None)
            pygame.draw.line(S, GOLD, (90, 190), (870, 190), 2)
            self.dl.draw(S)
            self.rbtn(S, (868, 52), 28, "x", None, self.fechar_det, "normal")
            self.btn(S, (340, 460, 280, 52), "Voltar à lista", self.fechar_det, "gold", 28, icone="seta_esq")


# ----------------------------------------------------------------- cartao
class Cartao(Cena):
    """Cartao modal (item, habilidade, aviso). corpo curto + 'Saber mais' (mais) opcional.
    botoes: [(rotulo, estado, fn)]."""
    opaque = False

    def key(self, k):
        if k == pygame.K_ESCAPE:
            if self.botoes and self.botoes[-1][2] is None:
                self.game.pop(self)

    def foco_inicial(self, cs):
        k = 1 if (self.mais and not self.long and len(cs) > 1) else 0
        return cs[min(k, len(cs) - 1)]

    def __init__(self, game, titulo, sub="", corpo="", item=None, botoes=(), extra=None, cor=GOLD, cat=None, mais=None, icone=None, longo=False):
        super().__init__(game)
        self.titulo, self.sub, self.item = titulo, sub, item
        if longo:
            mais, corpo = corpo, ""
        self.corpo = curto_txt(corpo, 120) if mais is None else corpo
        self.mais = mais
        self.long = bool(longo)
        self.icone = icone
        self.botoes = list(botoes) or [("Fechar", "gold", None)]
        self.extra = extra or []
        self.cor = cor
        self.cat = cat
        self.w = 740

    def draw(self, S):
        self.hits = []
        S.blit(dim_surface(190), (0, 0))
        texto = self.mais if self.long else self.corpo
        bsz, blines, blh = fit_text(texto, self.w - 60, lh_max(26) * (7 if self.long else 3), 28 if not self.long else 26, 22)
        hh = 128 + len(blines) * blh + 12 + len(self.extra) * 34 + 86
        r = pygame.Rect(0, 0, self.w, min(hh, 520))
        r.center = (W // 2, H // 2)
        panel(S, r, 248)
        y = r.y + 16
        tx = r.x + 28
        if self.item is not None:
            desenhar_item(S, r.x + 62, y + 48, self.item, 72, self.t)
            tx = r.x + 118
        elif self.icone or self.cat:
            ic = self.icone or CAT_ICONE.get(self.cat, "ratio")
            c = (r.x + 62, y + 48)
            pygame.draw.circle(S, (24, 15, 8), c, 44)
            pygame.draw.circle(S, CAT_COR.get(self.cat, GOLD), c, 44, 3)
            desenhar_icone(S, ic, c, 64, None, self.t)
            tx = r.x + 118
        sz, lines, lh = fit_text(self.titulo, r.right - 24 - tx, lh_max(38) * 2, 38, 26, True)
        draw_lines(S, lines, sz, GOLD_L, tx, y + 2, lh, shadow=(0, 0, 0), bold=True)
        yy = y + 2 + len(lines) * lh
        if self.sub:
            sz2, l2, lh2 = fit_text(self.sub, r.right - 24 - tx, lh_max(24) * 2, 24, 22)
            draw_lines(S, l2[:2], sz2, (206, 180, 120), tx, yy + 2, lh2)
        y0 = r.y + 112
        pygame.draw.line(S, GOLD, (r.x + 24, y0 - 6), (r.right - 24, y0 - 6), 2)
        y0 = draw_lines(S, blines, bsz, PARCH, r.x + 30, y0 + 4, blh)
        y0 += 6
        for ic, ln, col in [(e[0], e[1], e[2]) if len(e) == 3 else (None, e[0], e[1]) for e in self.extra]:
            if ic:
                desenhar_icone(S, ic, (r.x + 44, y0 + 14), 30)
            draw_text(S, ln, 26, col, (r.x + (66 if ic else 30), y0 + 14), anchor="midleft", bold=True)
            y0 += 34
        bots = list(self.botoes)
        if self.mais and not self.long:
            bots = [("Saber mais", "normal", "mais")] + bots
        n = len(bots)
        w = (r.w - 48 - 14 * (n - 1)) // n
        bx = r.x + 24
        for lab, st, fn in bots:
            if fn == "mais":
                self.btn(S, (bx, r.bottom - 76, w, 60), lab, self._mais, st, 28, icone="interrogacao")
            else:
                self.btn(S, (bx, r.bottom - 76, w, 60), lab, self._mk(fn, st), st, 30)
            bx += w + 14

    def _mais(self):
        self.long = True

    def _mk(self, fn, st):
        if st == "dim":
            return None

        def go():
            self.game.pop(self)
            if fn:
                fn()
        return go


# ---------------------------------------------------------------- dialogo
class Dialogo(Cena):
    """Fala curta de NPC (ate 2 linhas). Toque/Espaco continua."""
    opaque = False

    def __init__(self, game, npc, paginas, cb=None):
        super().__init__(game)
        self.npc = npc
        pag = [paginas] if isinstance(paginas, str) else list(paginas)
        self.pag = [curto_txt(p, 110) for p in pag]
        self.cb = cb
        self.i = 0
        self.typed = 0.0
        self.nome = E.npc(npc)["nome"] if npc else "Narrador"
        self._calc()

    def _calc(self):
        self.tx = 168 if self.npc else 48
        self.sz, self.lines, self.lh = fit_text(self.pag[self.i], 960 - self.tx - 70, lh_max(30) * 2 + 4, 30, 24)
        self.lines = self.lines[:2]
        self.total = sum(len(l) for l in self.lines)
        self.typed = 0.0

    def update(self, dt):
        super().update(dt)
        self.typed = min(self.total, self.typed + dt * 80)

    def tap(self):
        if self.typed < self.total:
            self.typed = self.total
        elif self.i < len(self.pag) - 1:
            self.i += 1
            self._calc()
        else:
            self.game.pop(self)
            if self.cb:
                self.cb()

    def key(self, k):
        if k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_z, pygame.K_e):
            self.tap()

    def draw(self, S):
        self.hits = []
        pr = pygame.Rect(30, 372, 900, 150)
        panel(S, pr, 246)
        if self.npc:
            S.blit(npc_portrait(self.npc, 120), (46, 386))
        plate = pygame.Rect(self.tx - 4, 380, 300, 38)
        pygame.draw.rect(S, (120, 22, 28), plate, 0, 10)
        pygame.draw.rect(S, GOLD, plate, 3, 10)
        draw_text(S, self.nome, 26, GOLD_L, plate.center, bold=True)
        n = int(self.typed)
        y = 428
        for ln in self.lines:
            part = ln[:max(0, n)]
            n -= len(ln)
            if part:
                S.blit(txt(part, self.sz, PARCH), (self.tx, y))
            y += self.lh
            if n <= 0:
                break
        if self.typed >= self.total:
            bob = math.sin(self.t * 6) * 3
            draw_arrow(S, 900, int(500 + bob), "d", GOLD_L, 10)
        self.reg(pygame.Rect(0, 0, W, H), self.tap)


# ------------------------------------------------------------------ pausa
class Pausa(Cena):
    opaque = False

    def dono(self):
        return (0,)           # coop: so o anfitriao mexe na pausa

    def key(self, k):
        if k in (pygame.K_ESCAPE, pygame.K_p):
            self.game.pop(self)

    def menu(self):
        self.game.pop(self)

    def draw(self, S):
        self.hits = []
        g = self.game
        S.blit(dim_surface(200), (0, 0))
        r = pygame.Rect(250, 8, 460, 526)
        panel(S, r, 250)
        draw_text(S, "PAUSA", 44, GOLD_L, (480, 40), bold=True)
        items = [("Continuar", "play", lambda: g.pop(self), "gold"),
                 ("Ficha e itens", "pessoa", lambda: g.push(Inventario(g)), "normal"),
                 ("Como jogar", "interrogacao", lambda: g.push(Tutorial(g)), "normal"),
                 ("Códex", "livro", lambda: g.push(Codex(g)), "normal")]
        if g.sessao is None and not g.inp.web:
            items.append(("Jogar online", "estrela", lambda: g.push(_menu_online(g)), "normal"))
        items.append(("Menu principal", "porta", self.sair, "normal"))
        y = 62
        for lab, ic, fn, st in items:
            self.btn(S, (280, y, 400, 46), lab, fn, st, 28, icone=ic)
            y += 50
        est = audio.estado()
        X.linha_volume(self, S, 364, "Música", est["musica"], lambda v: audio.volume(musica=v))
        X.linha_volume(self, S, 410, "Efeitos", est["efeitos"], lambda v: (audio.volume(efeitos=v), audio.sfx("moeda")))
        self.btn(S, (270, 462, 200, 56), "Som ligado" if not est["mudo"] else "Som mudo", audio.alternar_mudo, "normal", 26)
        X.btn_tela_cheia(self, S, (490, 462, 200, 56), g.tela_cheia)

    def sair(self):
        g = self.game
        g.push(Cartao(g, "Voltar ao menu?", "", "A partida atual será perdida.", icone="porta",
                      botoes=[("Sim, sair", "bad", g.ir_titulo), ("Cancelar", "gold", None)]))


# ------------------------------------------------------------------ ficha
class Inventario(Cena):
    def __init__(self, game, aba=0):
        super().__init__(game)
        self.aba = aba
        self.mk()

    def mk(self):
        j = self.game.run.j
        if self.aba == 1:
            self.itens = [(i, "c") for i in j.consumiveis] + [(i, "p") for i in j.passivos]
            self.lst = GradeRolavel((20, 84, 920, 440), len(self.itens), 3, 92, 10, self.card_item, self.tap_item)
            self.lists = [self.lst]
        elif self.aba == 2:
            self.habs = list(j.habilidades)
            self.lst = GradeRolavel((20, 84, 920, 440), len(self.habs), 3, 92, 10, self.card_hab, self.tap_hab)
            self.lists = [self.lst]
        else:
            self.lists = []

    def trocar(self, a):
        self.aba = a
        self.mk()

    def key(self, k):
        if k in (pygame.K_ESCAPE, pygame.K_i, pygame.K_TAB):
            self.game.pop(self)

    def abas(self, d):
        self.trocar((self.aba + d) % 3)

    def ficha(self):
        self.game.pop(self)

    def card_item(self, S, r, i):
        iid, tp = self.itens[i]
        it = E.ITENS.get(iid, {})
        j = self.game.run.j
        pygame.draw.rect(S, (44, 28, 14), r, 0, 14)
        pygame.draw.rect(S, (120, 88, 30), r, 2, 14)
        desenhar_item(S, r.x + 46, r.centery, it, 56, self.t + i)
        nome = it.get("nome", iid)
        sz, lines, lh = fit_text(nome, r.w - 110, lh_max(24) * 2, 24, 22, True)
        draw_lines(S, lines[:2], sz, GOLD_L, r.x + 86, r.y + 14, lh, bold=True)
        if tp == "c":
            draw_text(S, "x%d" % j.consumiveis.get(iid, 0), 26, PARCH, (r.right - 14, r.bottom - 16), anchor="midright", bold=True)
        else:
            desenhar_icone(S, "estrela", (r.x + 100, r.bottom - 20), 24)

    def tap_item(self, i):
        iid, tp = self.itens[i]
        it = E.ITENS.get(iid, {})
        g = self.game
        j = g.run.j
        bot = []
        if tp == "c":
            def usar():
                r = j.usar(iid)
                self.mk()
                g.toast(r or "", "frasco")
            bot.append(("Usar", "gold", usar))
            bot.append(("Fechar", "normal", None))
        g.push(Cartao(g, it.get("nome", iid), E.efeito_texto(it.get("efeito")), it.get("desc", ""), item=it, botoes=bot,
                      mais=mais_item(it)))

    def card_hab(self, S, r, i):
        carta_hab(S, r, E.HAB.get(self.habs[i], {}), True, self.t)

    def tap_hab(self, i):
        h = E.HAB.get(self.habs[i], {})
        self.game.push(Cartao(self.game, h.get("nome", ""), "Tinta %d   Poder %d" % (h.get("custo_tinta", 0), h.get("poder", 0)),
                              h.get("desc", ""), cat=h.get("categoria"), icone=E.icone_hab(h), mais=mais_hab(h)))

    def draw(self, S):
        self.hits = []
        g = self.game
        j = g.run.j
        tela_escura(S, (30, 20, 12), (10, 6, 3))
        for k, (nm, ic) in enumerate((("Ficha", "pessoa"), ("Itens", "mochila"), ("Habilidades", "livro"))):
            self.btn(S, (20 + k * 232, 12, 224, 60), nm, (lambda k=k: self.trocar(k)), "gold" if self.aba == k else "normal", 28, icone=ic)
        self.rbtn(S, (916, 42), 30, "x", None, lambda: g.pop(self), "normal")
        if self.aba == 0:
            self.draw_ficha(S, j)
        else:
            if (self.aba == 1 and not self.itens) or (self.aba == 2 and not self.habs):
                draw_text(S, "Nada por aqui ainda.", 32, (176, 150, 104), (480, 300))
            self.lst.draw(S)

    def draw_ficha(self, S, j):
        r = g_run(self)
        st = r.stats
        panel(S, pygame.Rect(16, 84, 290, 444), 230)
        hs = hero_sprite(0, j.nivel)
        add_glow(S, (161, 280), 110, (50, 38, 20))
        S.blit(pygame.transform.smoothscale(hs, (180, 240)), (71, 130))
        draw_text(S, j.nome, 32, GOLD_L, (161, 112), bold=True)
        draw_text(S, "Nível %d - %s" % (j.nivel, j.titulo), 24, PARCH, (161, 392))
        if j.nivel >= E.NIVEL_MAX:
            draw_bar(S, pygame.Rect(36, 412, 250, 26), 1.0, *BARRA_XP, "Nível máximo")
        else:
            draw_bar(S, pygame.Rect(36, 412, 250, 26), j.xp / j.xp_prox(), *BARRA_XP, "%d/%d" % (j.xp, j.xp_prox()))
        desenhar_icone(S, "florim", (50, 478), 34)
        draw_text(S, "%d" % j.florins, 32, GOLD_L, (74, 478), anchor="midleft", bold=True)
        panel(S, pygame.Rect(318, 84, 330, 444), 230)
        barra_icone(S, 336, 102, 296, 32, "animo", j.hp / j.hp_max, BARRA_HP, "%d/%d" % (j.hp, j.hp_max))
        barra_icone(S, 336, 146, 296, 32, "tinta", j.tinta / j.tinta_max, BARRA_TINTA, "%d/%d" % (j.tinta, j.tinta_max))
        y = 204
        for a, ic in zip(E.ATRS, ("ratio", "auctoritas", "distinguo", "apoio")):
            b = j.bonus("bonus_" + a)
            desenhar_icone(S, ic, (352, y + 20), 40)
            draw_text(S, E.ATR_NOME[a], 28, PARCH, (384, y + 20), anchor="midleft")
            draw_text(S, "%d" % j.atr(a) + ("+%d" % b if b else ""), 30, GOLD_L, (630, y + 20), anchor="midright", bold=True)
            pygame.draw.line(S, (90, 66, 30), (336, y + 44), (632, y + 44), 1)
            y += 54
        ex = []
        for k, lab in (("bonus_dano_pct", "dano"), ("bonus_critico_pct", "crít."), ("reduz_dano_pct", "def."), ("bonus_florins_pct", "flor.")):
            v = j.bonus(k)
            if v:
                ex.append("%s%d%% %s" % ("-" if k == "reduz_dano_pct" else "+", v, lab))
        if ex:
            sz, lines, lh = fit_text(", ".join(ex), 296, lh_max(22) * 2, 22, 22)
            draw_lines(S, lines[:2], sz, (206, 180, 120), 336, 430, lh)
        panel(S, pygame.Rect(660, 84, 284, 444), 230)
        linhas = [("escada", "%d/%d" % (r.andar_i + 1, r.n_andares)), ("duelo", "%d" % st["inimigos"]), ("porta", "%d" % st["salas"]),
                  ("check", "%d" % st["acertos"]), ("x", "%d" % st["erros"]), ("livro", "%d" % len(j.habilidades)),
                  ("estrela", "%d" % len(j.passivos))]
        y = 104
        for ic, tx in linhas:
            desenhar_icone(S, ic, (700, y + 22), 42)
            draw_text(S, tx, 34, PARCH, (900, y + 22), anchor="midright", bold=True)
            pygame.draw.line(S, (90, 66, 30), (680, y + 48), (924, y + 48), 1)
            y += 58


def g_run(c):
    return c.game.run


def carta_hab(S, r, h, ok=True, t=0.0, marca=False, nome_fallback=""):
    """Cartao de habilidade (icone da categoria/simbolo + nome curto + custo de tinta)."""
    cat = h.get("categoria", "ratio")
    cc = CAT_COR.get(cat, GOLD)
    pygame.draw.rect(S, (0, 0, 0), r.move(2, 4), 0, 14)
    pygame.draw.rect(S, (250, 238, 208) if ok else (120, 108, 90), r, 0, 14)
    pygame.draw.rect(S, cc if ok else (80, 72, 58), r, 4, 14)
    c = (r.x + 36, r.centery)
    pygame.draw.circle(S, mix(cc, (0, 0, 0), .55) if ok else (60, 54, 44), c, 27)
    pygame.draw.circle(S, cc if ok else (90, 80, 66), c, 27, 3)
    desenhar_icone(S, E.icone_hab(h), c, 40, None if ok else (120, 110, 96), t)
    tc = INK if ok else (50, 44, 34)
    sz, lines, lh = fit_text(h.get("nome", nome_fallback), r.w - 80, lh_max(24) * 2, 24, 22, True)
    draw_lines(S, lines[:2], sz, tc, r.x + 70, r.y + 8, lh, bold=True)
    desenhar_icone(S, "tinta", (r.x + 82, r.bottom - 18), 24, None if ok else (110, 100, 90))
    draw_text(S, "%d" % h.get("custo_tinta", 0), 24, tc, (r.x + 98, r.bottom - 18), anchor="midleft", bold=True, shadow=None)
    desenhar_icone(S, "estrela", (r.x + 150, r.bottom - 18), 22, None if ok else (110, 100, 90))
    draw_text(S, "%d" % h.get("poder", 0), 24, tc, (r.x + 166, r.bottom - 18), anchor="midleft", bold=True, shadow=None)
    if marca:
        desenhar_icone(S, "ponto_de_exclamacao", (r.right - 20, r.y + 20), 28)


def mais_item(it):
    s = it.get("desc", "")
    if it.get("ref"):
        s += "\nFonte: " + it["ref"]
    return s if len(s) > 120 or it.get("ref") else None


def mais_hab(h):
    s = h.get("desc", "")
    if h.get("ref"):
        s += "\nFonte: " + h["ref"]
    return s if len(s) > 120 or h.get("ref") else None


# ---------------------------------------------------------------- pergunta
class Pergunta(Cena):
    """Enigma 'Sed contra': enunciado curto + 3 cartoes + feedback curto."""
    opaque = False

    def __init__(self, game, tema, enunciado, opcoes, correta, explicacao, cb, titulo="Sed contra", dados=None):
        super().__init__(game)
        d = dict(dados or {})
        d.setdefault("enunciado", enunciado)
        d.setdefault("opcoes", opcoes)
        d.setdefault("explicacao", explicacao)
        self.d = d
        self.tema, self.cb, self.titulo = tema, cb, titulo
        self.enun = obj_curto(d)
        self.expl = obj_expl(d)
        self.expl_long = explicacao
        cur = obj_opcoes(d)
        idx = list(range(len(opcoes)))
        random.shuffle(idx)
        self.ops = [(cur[i], i == correta) for i in idx]
        self.esc = None
        self.ok = False

    def resp(self, i):
        if self.esc is None:
            self.esc = i
            self.ok = self.ops[i][1]
            self.t = 0.0
            audio.sfx("certa" if self.ok else "errada")

    def saber_mais(self):
        g = self.game
        g.push(Cartao(g, "Sed contra", self.tema, self.expl_long, icone="interrogacao", longo=True))

    def draw(self, S):
        self.hits = []
        S.blit(dim_surface(205), (0, 0))
        panel(S, pygame.Rect(16, 12, 928, 516), 250)
        desenhar_icone(S, "interrogacao", (60, 52), 46)
        draw_text(S, self.titulo.upper(), 38, GOLD_L, (96, 40), anchor="midleft", bold=True)
        if self.tema:
            draw_text(S, trunc(self.tema, 22, 420), 22, (206, 180, 120), (96, 70), anchor="midleft", shadow=None)
        sz, lines, lh = fit_text(self.enun, 840, lh_max(34) * 2 + 4, 34, 26)
        draw_lines(S, lines[:2], sz, PARCH, 480, 98, lh, center=True, shadow=(0, 0, 0))
        est = ["normal"] * 3
        if self.esc is not None:
            est = ["ok" if ok else ("bad" if i == self.esc else "dim") for i, (tx, ok) in enumerate(self.ops)]
        desenhar_cartoes_resposta(self, S, [tx for tx, _ in self.ops], est, 176, 138, self.resp if self.esc is None else None, self.t)
        if self.esc is not None:
            desenhar_feedback(self, S, self.ok, self.expl, [], self._fim, self.saber_mais, self.t, 330, 190)

    def _fim(self):
        self.game.pop(self)
        self.cb(self.ok)


# ------------------------------------------------------------- cartao de andar
class CartaoAndar(Cena):
    def __init__(self, game, idx, dados, cb):
        super().__init__(game)
        self.idx, self.d, self.cb = idx, dados, cb
        self.done = False

    def enter(self):
        audio.musica("andar%d" % min(self.idx, 3))

    def draw(self, S):
        self.hits = []
        cf = self.d.get("cor_fundo", (70, 54, 42))
        tela_escura(S, mix(cf, (0, 0, 0), .6), (6, 3, 2))
        a = clamp(self.t / 0.6, 0, 1)
        add_glow(S, (480, 270), 260, mix(cf, (0, 0, 0), .5))
        desenhar_icone(S, E.icone(self.d, "arco_ogival"), (480, 88), 84, None, self.t)
        draw_text(S, "ANDAR " + romano(self.idx), 36, (200, 170, 110), (480, 160))
        sz, lines, lh = fit_text(self.d.get("nome", ""), 860, lh_max(72) * 2, 72, 40, True)
        for k, ln in enumerate(lines):
            outlined(S, ln, sz, GOLD, (480, 220 + k * lh), th=3, hi=GOLD_L)
        yy = 220 + len(lines) * lh
        pygame.draw.line(S, GOLD, (260, yy + 6), (700, yy + 6), 2)
        draw_text(S, trunc(self.d.get("subtitulo", ""), 32, 860), 32, (240, 214, 150), (480, yy + 36))
        fala = curto_txt(self.d.get("fala_chegada", "") or self.d.get("descricao", ""), 120)
        sz, lines, lh = fit_text(fala, 760, lh_max(28) * 2 + 4, 28, 24)
        draw_lines(S, lines[:2], sz, PARCH, 480, yy + 68, lh, center=True, shadow=(0, 0, 0))
        if self.t > 0.8:
            bob = math.sin(self.t * 5) * 4
            self.rbtn(S, (480, 486), 32, "play", None, self.fim, "gold", True)
        if a < 1:
            ov = pygame.Surface((W, H))
            ov.set_alpha(int(255 * (1 - a)))
            S.blit(ov, (0, 0))
        self.reg(pygame.Rect(0, 0, W, H), self.fim)

    def key(self, k):
        if k in (pygame.K_RETURN, pygame.K_SPACE, pygame.K_e):
            self.fim()

    def fim(self):
        if self.t > 0.7 and not self.done:
            self.done = True
            self.game.pop(self)
            self.cb()


# --------------------------------------------------------------- fim de jogo
def resumo_linhas(run):
    st = run.stats
    j = run.j
    return [("escada", "Andar %d/%d" % (run.andar_i + 1, run.n_andares)),
            ("estrela", "Nível %d  %s" % (j.nivel, j.titulo)),
            ("duelo", "%d derrotados" % st["inimigos"]),
            ("porta", "%d salas" % st["salas"]),
            ("check", "%d certas  /  %d erradas" % (st["acertos"], st["erros"])),
            ("florim", "%d florins" % st["florins"])]


def _resumo(S, run, x, y, w):
    panel(S, pygame.Rect(x, y, w, 300), 236)
    yy = y + 14
    for ic, tx in resumo_linhas(run):
        desenhar_icone(S, ic, (x + 40, yy + 21), 38)
        draw_text(S, tx, 28, PARCH, (x + 76, yy + 21), anchor="midleft")
        yy += 46


class GameOver(Cena):
    def __init__(self, game, run):
        super().__init__(game)
        self.run = run
        self.parts = Particulas(40)

    def enter(self):
        audio.musica("derrota", False)

    def update(self, dt):
        super().update(dt)
        if random.random() < dt * 3:
            self.parts.burst(random.uniform(40, 920), 400, 1, [(90, 90, 100), (60, 60, 70)], v=(5, 20), g=-30, life=(1.5, 2.5), size=(3, 6), up=0)
        self.parts.update(dt)

    def draw(self, S):
        self.hits = []
        g = self.game
        tela_escura(S, (40, 10, 10), (4, 2, 2))
        for i in range(5):
            draw_candle(S, 120 + i * 180, 150, self.t + i, False, 44)
        self.parts.draw(S)
        outlined(S, "REPROVADO", 92, (230, 100, 90), (480, 70), th=4, hi=(255, 170, 160))
        _resumo(S, self.run, 70, 190, 420)
        self.btn(S, (560, 220, 330, 84), "Recomeçar", g.novo_jogo, "gold", 38, icone="play")
        self.btn(S, (560, 330, 330, 72), "Menu", g.ir_titulo, "normal", 32, icone="porta")
        draw_text(S, "Todo bom mestre já foi reprovado alguma vez.", 24, (200, 176, 130), (480, 500), shadow=None)


class Vitoria(Cena):
    def __init__(self, game, run):
        super().__init__(game)
        self.run = run
        self.parts = Particulas(150)

    def enter(self):
        audio.musica("vitoria", False)

    def update(self, dt):
        super().update(dt)
        if random.random() < dt * 14:
            self.parts.burst(random.uniform(20, 940), -10, 1, [GOLD_L, GOLD, (255, 255, 255), (230, 90, 80), (90, 150, 240)],
                             v=(10, 50), g=160, life=(2.5, 4), size=(3, 6), up=-20)
        self.parts.update(dt)

    def draw(self, S):
        self.hits = []
        g = self.game
        tela_escura(S, (70, 50, 14), (20, 12, 4))
        add_glow(S, (480, 110), 260, (140, 100, 30))
        self.parts.draw(S)
        outlined(S, "MAGISTER", 96, GOLD, (480, 70), th=4, hi=GOLD_L)
        for i in range(3):
            desenhar_icone(S, "estrela", (400 + i * 80, 142 + (8 if i == 1 else 0) * -1), 64 if i != 1 else 76)
        _resumo(S, self.run, 70, 200, 420)
        self.btn(S, (560, 230, 330, 84), "Jogar de novo", g.novo_jogo, "gold", 36, icone="play")
        self.btn(S, (560, 340, 330, 72), "Menu", g.ir_titulo, "normal", 32, icone="porta")
        draw_text(S, "A graça não destrói a natureza, mas a aperfeiçoa.", 24, (220, 196, 150), (480, 500), shadow=None)
