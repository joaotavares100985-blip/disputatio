# -*- coding: utf-8 -*-
"""
DISPUTATIO - Uma Questao em Paris (1256)
Jogo curto sobre a Escolastica, feito em Python + Pygame.
Roda no PC (python main.py) e no celular via navegador (pygbag).
"""
import asyncio
import math
import random
import sys

import pygame

W, H = 540, 960          # resolucao logica (retrato, ideal pro celular)
SCENE_H = 430            # altura da cena (salao) no topo

GOLD = (214, 170, 60)
GOLD_L = (255, 228, 140)
INK = (43, 29, 14)
PARCH = (243, 230, 196)

pygame.init()

# ----------------------------------------------------------------- utilidades
_fc = {}


def font(sz, bold=False):
    k = (sz, bold)
    if k not in _fc:
        f = pygame.font.Font(None, sz)
        f.set_bold(bold)
        _fc[k] = f
    return _fc[k]


def draw_text(S, text, sz, col, pos, anchor="center", bold=False,
              shadow=(0, 0, 0), sh=2):
    f = font(sz, bold)
    img = f.render(text, True, col)
    r = img.get_rect()
    setattr(r, anchor, pos)
    if shadow:
        S.blit(f.render(text, True, shadow), (r.x + sh, r.y + sh))
    S.blit(img, r)
    return r


def outlined(S, text, sz, col, pos, th=3, anchor="center", hi=None,
             outline=(30, 14, 4)):
    f = font(sz, True)
    img = f.render(text, True, col)
    r = img.get_rect()
    setattr(r, anchor, pos)
    edge = f.render(text, True, outline)
    for a in range(0, 360, 30):
        dx = round(math.cos(math.radians(a)) * th)
        dy = round(math.sin(math.radians(a)) * th)
        S.blit(edge, (r.x + dx, r.y + dy))
    S.blit(img, r)
    if hi:
        clip = pygame.Rect(r.x, r.y, r.w, int(r.h * 0.5))
        S.set_clip(clip)
        S.blit(f.render(text, True, hi), r)
        S.set_clip(None)
    return r


def wrap(text, f, width):
    words = text.split()
    lines, cur = [], ""
    for w in words:
        t = (cur + " " + w).strip()
        if f.size(t)[0] <= width:
            cur = t
        else:
            lines.append(cur)
            cur = w
    lines.append(cur)
    return lines


def lerp(a, b, t):
    return a + (b - a) * t


def mix(c1, c2, t):
    return tuple(int(lerp(c1[i], c2[i], t)) for i in range(3))


def vgrad(w, h, c1, c2):
    s = pygame.Surface((w, h))
    for y in range(h):
        pygame.draw.line(s, mix(c1, c2, y / max(1, h - 1)), (0, y), (w, y))
    return s


def make_glow(r, col):
    """Brilho para blit aditivo (RGB, preto fora)."""
    s = pygame.Surface((2 * r, 2 * r))
    s.fill((0, 0, 0))
    for rr in range(r, 0, -2):
        k = (1 - rr / r) ** 2
        pygame.draw.circle(s, (int(col[0] * k), int(col[1] * k), int(col[2] * k)), (r, r), rr)
    return s


def make_vignette(w, h):
    s = pygame.Surface((w, h), pygame.SRCALPHA)
    n = 70
    for i in range(n):
        a = int(150 * (1 - i / n) ** 2.2)
        pygame.draw.rect(s, (0, 0, 0, a), (i, i, w - 2 * i, h - 2 * i), 1)
    return s


# ------------------------------------------------------- cenario (estatico)
def arch_pts(cx, top, w, h):
    spring = top + w * 0.866
    pts = [(cx - w / 2, top + h), (cx - w / 2, spring)]
    for i in range(1, 13):
        a = math.radians(180 - 60 * i / 12)
        pts.append((cx + w / 2 + w * math.cos(a), spring - w * math.sin(a)))
    for i in range(1, 13):
        a = math.radians(60 - 60 * i / 12)
        pts.append((cx - w / 2 + w * math.cos(a), spring - w * math.sin(a)))
    pts.append((cx + w / 2, top + h))
    return pts


PAL = [(196, 44, 44), (44, 96, 200), (226, 176, 44), (54, 156, 84),
       (128, 66, 170), (236, 124, 44)]


def make_window(w, h, seed):
    rnd = random.Random(seed)
    pad = 8
    S = pygame.Surface((w + 2 * pad, h + pad), pygame.SRCALPHA)
    cx = S.get_width() / 2
    pts = arch_pts(cx, pad, w, h)
    glass = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    glass.fill((20, 14, 10, 255))
    cw, ch = 24, 34
    for row in range(-1, int(h / (ch / 2)) + 3):
        for col in range(-1, int(w / cw) + 3):
            x = pad + col * cw + (cw / 2 if row % 2 else 0)
            y = pad + row * ch / 2
            base = rnd.choice(PAL)
            f = 1.2 - 0.55 * min(1, max(0, y / h))
            c = tuple(min(255, int(v * f)) for v in base)
            d = [(x, y - ch / 2), (x + cw / 2, y), (x, y + ch / 2), (x - cw / 2, y)]
            pygame.draw.polygon(glass, c, d)
            pygame.draw.polygon(glass, (26, 18, 12), d, 2)
    mask = pygame.Surface(S.get_size(), pygame.SRCALPHA)
    pygame.draw.polygon(mask, (255, 255, 255, 255), pts)
    glass.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
    S.blit(glass, (0, 0))
    pygame.draw.polygon(S, (118, 98, 70), pts, 8)
    pygame.draw.polygon(S, (60, 46, 30), pts, 2)
    pygame.draw.line(S, (30, 22, 14), (cx, pad + w * 0.85), (cx, h + pad - 1), 4)
    return S


def make_rose(R=84):
    S = pygame.Surface((2 * R + 10, 2 * R + 10), pygame.SRCALPHA)
    c = (R + 5, R + 5)
    n = 12
    for ring, (r0, r1) in enumerate([(R * 0.62, R), (R * 0.3, R * 0.62)]):
        for i in range(n):
            a0 = 2 * math.pi * i / n
            a1 = 2 * math.pi * (i + 1) / n
            pts = []
            for a in (a0, a1):
                pts.append((c[0] + r1 * math.cos(a), c[1] + r1 * math.sin(a)))
            for a in (a1, a0):
                pts.append((c[0] + r0 * math.cos(a), c[1] + r0 * math.sin(a)))
            pygame.draw.polygon(S, PAL[(i + ring * 2) % len(PAL)], pts)
            pygame.draw.polygon(S, (28, 20, 14), pts, 2)
    pygame.draw.circle(S, (250, 216, 110), c, int(R * 0.3))
    pygame.draw.circle(S, (28, 20, 14), c, int(R * 0.3), 3)
    for i in range(6):
        a = math.pi * 2 * i / 6
        p = (c[0] + R * 0.15 * math.cos(a), c[1] + R * 0.15 * math.sin(a))
        pygame.draw.circle(S, (190, 120, 30), p, 5)
    pygame.draw.circle(S, (118, 98, 70), c, R + 3, 8)
    return S


def make_scene():
    S = pygame.Surface((W, SCENE_H))
    S.blit(vgrad(W, SCENE_H, (80, 60, 40), (42, 29, 18)), (0, 0))
    rnd = random.Random(7)
    # blocos de pedra
    for row in range(SCENE_H // 30 + 1):
        y = row * 30
        off = (row % 2) * 36
        for x in range(-off, W, 72):
            tint = rnd.randint(-10, 10)
            pygame.draw.rect(S, (62 + tint, 46 + tint, 30 + tint // 2), (x + 1, y + 1, 70, 28), 0, 3)
    for row in range(SCENE_H // 30 + 1):
        pygame.draw.line(S, (30, 21, 13), (0, row * 30), (W, row * 30), 2)
        off = (row % 2) * 36
        for x in range(-off, W, 72):
            pygame.draw.line(S, (30, 21, 13), (x, row * 30), (x, row * 30 + 30), 2)
    # sombra da abobada
    sh = pygame.Surface((W, 160), pygame.SRCALPHA)
    for y in range(160):
        pygame.draw.line(sh, (0, 0, 0, int(170 * (1 - y / 160) ** 1.5)), (0, y), (W, y))
    S.blit(sh, (0, 0))

    # chao
    fy = 332
    floor = vgrad(W, SCENE_H - fy, (96, 66, 38), (46, 30, 17))
    vp = (270, -40)
    for x in range(-700, 1240, 64):
        pygame.draw.line(floor, (40, 26, 14), vp, (x, SCENE_H - fy), 2)
    for k in range(1, 9):
        y = (SCENE_H - fy) * (k / 8) ** 1.5
        pygame.draw.line(floor, (40, 26, 14), (0, y), (W, y), 2)
    S.blit(floor, (0, fy))
    # tapete
    carpet = [(228, fy), (312, fy), (440, SCENE_H), (100, SCENE_H)]
    pygame.draw.polygon(S, (134, 22, 24), carpet)
    pygame.draw.polygon(S, (214, 170, 60), carpet, 4)
    inner = [(236, fy + 3), (304, fy + 3), (418, SCENE_H), (122, SCENE_H)]
    pygame.draw.polygon(S, (92, 12, 16), inner, 2)
    # degraus do estrado
    pygame.draw.rect(S, (112, 92, 66), (120, 306, 300, 28))
    pygame.draw.rect(S, (146, 124, 92), (120, 306, 300, 6))
    pygame.draw.rect(S, (58, 44, 28), (120, 330, 300, 6))

    # pilares
    for px in (128, 394):
        p = pygame.Surface((22, 340))
        for x in range(22):
            k = abs(x - 8) / 14
            pygame.draw.line(p, mix((150, 128, 96), (70, 54, 36), min(1, k)), (x, 0), (x, 340))
        S.blit(p, (px, 0))
        pygame.draw.rect(S, (170, 146, 108), (px - 4, 320, 30, 14))
        pygame.draw.rect(S, (170, 146, 108), (px - 4, 0, 30, 14))
    # vitrais
    for cx, seed in ((70, 1), (470, 2)):
        win = make_window(84, 214, seed)
        S.blit(win, (cx - win.get_width() // 2, 44))
    glow_w = make_glow(120, (70, 80, 130))
    S.blit(glow_w, (70 - 120, 150 - 120), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(glow_w, (470 - 120, 150 - 120), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(make_glow(190, (120, 84, 36)), (270 - 190, 110 - 190), special_flags=pygame.BLEND_RGB_ADD)
    # estandartes
    for bx, col in ((176, (150, 30, 34)), (364, (30, 58, 130))):
        pts = [(bx - 20, 20), (bx + 20, 20), (bx + 20, 150), (bx, 130), (bx - 20, 150)]
        pygame.draw.polygon(S, col, pts)
        pygame.draw.polygon(S, GOLD, pts, 3)
        pygame.draw.line(S, GOLD_L, (bx, 40), (bx, 100), 5)
        pygame.draw.line(S, GOLD_L, (bx - 14, 58), (bx + 14, 58), 5)
        pygame.draw.line(S, (90, 70, 40), (bx - 26, 18), (bx + 26, 18), 5)
    # mancha de luz no piso
    spill = make_glow(110, (50, 44, 66))
    S.blit(pygame.transform.scale(spill, (260, 80)), (-10, 340), special_flags=pygame.BLEND_RGB_ADD)
    S.blit(pygame.transform.scale(spill, (260, 80)), (290, 340), special_flags=pygame.BLEND_RGB_ADD)
    return S


# --------------------------------------------------------------- personagens
OPPS = [
    dict(name="Frei Bertrand", robe=(112, 78, 46), under=None, trim=(214, 184, 120),
         skin=(238, 198, 162), hat="hood", beard=None, hair=(90, 60, 30)),
    dict(name="Mestre Siger", robe=(34, 96, 76), under=(200, 190, 160), trim=(232, 200, 100),
         skin=(232, 190, 154), hat="biretta", beard=(120, 112, 104), hair=(100, 96, 90)),
    dict(name="Cônego Estêvão", robe=(140, 34, 44), under=(236, 230, 214), trim=(240, 206, 110),
         skin=(240, 202, 168), hat="cap", beard=None, hair=(150, 150, 150)),
    dict(name="Monge Raul", robe=(36, 36, 44), under=None, trim=(120, 120, 130),
         skin=(236, 196, 160), hat="tonsure", beard=None, hair=(110, 70, 36)),
    dict(name="Mestre Gaspar", robe=(86, 46, 120), under=(230, 220, 190), trim=(238, 206, 110),
         skin=(228, 186, 150), hat="biretta", beard=(226, 226, 226), hair=(226, 226, 226)),
    dict(name="Reitor Aubry", robe=(176, 134, 34), under=(240, 232, 214), trim=(120, 24, 28),
         skin=(236, 196, 160), hat="cap", beard=(210, 210, 214), hair=(210, 210, 214)),
]


def draw_scholar(S, cx, by, o, t, mood, talk, shake=0.0):
    cx += shake
    bob = math.sin(t * 1.8) * 1.6
    robe = o["robe"]
    dark = tuple(int(v * 0.66) for v in robe)
    skin = o["skin"]
    top = by - 112 + bob
    hy = top - 20
    # capuz (atras da cabeca)
    if o["hat"] == "hood":
        hood = [(cx - 42, top + 30), (cx - 40, hy - 6), (cx - 22, hy - 40), (cx, hy - 50),
                (cx + 22, hy - 40), (cx + 40, hy - 6), (cx + 42, top + 30)]
        pygame.draw.polygon(S, robe, hood)
        pygame.draw.polygon(S, dark, hood, 3)
    # corpo
    body = [(cx - 82, by + 8), (cx - 68, by - 74 + bob), (cx - 38, top + 8),
            (cx + 38, top + 8), (cx + 68, by - 74 + bob), (cx + 82, by + 8)]
    pygame.draw.polygon(S, robe, body)
    pygame.draw.polygon(S, dark, body, 3)
    for dx in (-44, -22, 22, 44):
        pygame.draw.line(S, dark, (cx + dx, top + 30), (cx + dx * 1.2, by), 2)
    if o["under"]:
        pygame.draw.polygon(S, o["under"], [(cx - 20, top + 8), (cx + 20, top + 8), (cx + 28, by + 8), (cx - 28, by + 8)])
        pygame.draw.polygon(S, mix(o["under"], (0, 0, 0), .4), [(cx - 20, top + 8), (cx + 20, top + 8), (cx + 28, by + 8), (cx - 28, by + 8)], 2)
    pygame.draw.lines(S, o["trim"], False, [(cx - 38, top + 8), (cx - 16, top + 32), (cx + 16, top + 32), (cx + 38, top + 8)], 5)
    # pescoco + cabeca
    pygame.draw.rect(S, mix(skin, (0, 0, 0), .15), (cx - 11, hy + 16, 22, 26))
    if o["hat"] == "tonsure":
        pygame.draw.circle(S, o["hair"], (cx, int(hy + 2)), 33)
    pygame.draw.circle(S, skin, (cx, int(hy)), 30)
    pygame.draw.circle(S, mix(skin, (120, 60, 40), .35), (cx - 20, int(hy + 8)), 6)
    pygame.draw.circle(S, mix(skin, (120, 60, 40), .35), (cx + 20, int(hy + 8)), 6)
    if o["hat"] == "tonsure":
        pygame.draw.ellipse(S, skin, (cx - 20, hy - 31, 40, 28))
    # olhos / sobrancelhas
    ey = hy - 3
    blink = int(t * 10) % 47 == 0
    for sx in (-1, 1):
        ex = cx + sx * 11
        if mood == "hurt":
            pygame.draw.line(S, (40, 20, 10), (ex - 4, ey - 4), (ex + 4, ey + 4), 3)
            pygame.draw.line(S, (40, 20, 10), (ex + 4, ey - 4), (ex - 4, ey + 4), 3)
        elif blink:
            pygame.draw.line(S, (40, 20, 10), (ex - 5, ey), (ex + 5, ey), 2)
        else:
            pygame.draw.circle(S, (250, 250, 245), (ex, ey), 6)
            pygame.draw.circle(S, (40, 22, 12), (ex + (1 if mood != "hurt" else 0), ey + 1), 3)
        by_ = ey - 11
        if mood == "angry":
            a, b = (ex + sx * 8, by_ - 5), (ex - sx * 6, by_ + 3)
        elif mood == "hurt":
            a, b = (ex + sx * 8, by_ + 2), (ex - sx * 6, by_ - 5)
        elif mood == "happy":
            a, b = (ex + sx * 8, by_), (ex - sx * 6, by_ - 3)
        else:
            a, b = (ex + sx * 8, by_), (ex - sx * 6, by_)
        pygame.draw.line(S, o["hair"] if o["hair"][0] > 60 else (50, 30, 16), a, b, 4)
    pygame.draw.circle(S, mix(skin, (150, 80, 50), .4), (cx, int(hy + 6)), 4)
    # barba
    if o["beard"]:
        bd = [(cx - 28, hy + 4), (cx - 24, hy + 36), (cx - 8, hy + 52), (cx, hy + 56),
              (cx + 8, hy + 52), (cx + 24, hy + 36), (cx + 28, hy + 4), (cx + 14, hy + 16),
              (cx, hy + 12), (cx - 14, hy + 16)]
        pygame.draw.polygon(S, o["beard"], bd)
        pygame.draw.polygon(S, mix(o["beard"], (0, 0, 0), .35), bd, 2)
    # boca
    my = hy + 20
    if talk:
        oh = 3 + abs(math.sin(t * 16)) * 7
        pygame.draw.ellipse(S, (90, 20, 20), (cx - 8, my - oh / 2, 16, oh))
    elif mood == "hurt":
        pygame.draw.circle(S, (90, 20, 20), (cx, my + 2), 6)
    elif mood == "happy":
        pygame.draw.arc(S, (90, 20, 20), (cx - 12, my - 10, 24, 18), math.pi + .3, 2 * math.pi - .3, 3)
    else:
        pygame.draw.line(S, (110, 40, 30), (cx - 8, my), (cx + 8, my), 3)
    # chapeus
    if o["hat"] == "hood":
        pygame.draw.arc(S, dark, (cx - 36, hy - 44, 72, 92), 0.15, math.pi - 0.15, 7)
    elif o["hat"] == "biretta":
        hat = mix(o["robe"], (0, 0, 0), .35)
        pts = [(cx - 34, hy - 18), (cx - 26, hy - 36), (cx + 26, hy - 36), (cx + 34, hy - 18)]
        pygame.draw.polygon(S, hat, pts)
        pygame.draw.polygon(S, o["trim"], pts, 2)
        pygame.draw.ellipse(S, mix(hat, (255, 255, 255), .15), (cx - 28, hy - 44, 56, 16))
        pygame.draw.circle(S, o["trim"], (cx + 22, hy - 40), 5)
    elif o["hat"] == "cap":
        hat = mix(o["robe"], (0, 0, 0), .15)
        dome = [(cx + 31 * math.cos(math.pi + math.pi * i / 16), hy - 8 + 36 * math.sin(math.pi + math.pi * i / 16)) for i in range(17)]
        pygame.draw.polygon(S, hat, dome)
        pygame.draw.polygon(S, o["trim"], dome, 2)
        pygame.draw.circle(S, o["trim"], (cx, int(hy - 44)), 5)
    # bracos / maos
    gest = math.sin(t * 5) * 8 if talk else 0
    for sx in (-1, 1):
        sxp, syp = cx + sx * 62, by - 74 + bob
        hxp, hyp = cx + sx * 46, by - 6
        if talk and sx == 1:
            hxp, hyp = cx + 78, by - 46 + gest
        elif mood == "hurt":
            hxp, hyp = cx + sx * 40, by - 52
        pygame.draw.line(S, robe, (sxp, syp), (hxp, hyp), 24)
        pygame.draw.line(S, dark, (sxp, syp), (hxp, hyp), 24 if False else 2)
        pygame.draw.circle(S, robe, (int(hxp), int(hyp)), 12)
        pygame.draw.circle(S, skin, (int(hxp), int(hyp - 2)), 9)
    return hy


def draw_lectern(S, cx, by):
    pts = [(cx - 78, by + 6), (cx + 78, by + 6), (cx + 90, by + 62), (cx - 90, by + 62)]
    pygame.draw.polygon(S, (112, 70, 36), pts)
    pygame.draw.polygon(S, (46, 26, 11), pts, 3)
    pygame.draw.rect(S, (168, 116, 62), (cx - 86, by - 2, 172, 10), 0, 3)
    pygame.draw.rect(S, (46, 26, 11), (cx - 86, by - 2, 172, 10), 2, 3)
    pygame.draw.rect(S, (84, 50, 24), (cx - 52, by + 18, 104, 36), 0, 18)
    pygame.draw.rect(S, (210, 170, 80), (cx - 52, by + 18, 104, 36), 2, 18)
    pygame.draw.line(S, GOLD_L, (cx, by + 24), (cx, by + 48), 4)
    pygame.draw.line(S, GOLD_L, (cx - 9, by + 32), (cx + 9, by + 32), 4)


def draw_flame(S, x, y, t, k=1.0):
    fl = 1 + math.sin(t * 17 + x) * 0.12 + math.sin(t * 29 + x * 2) * 0.08
    h = int(20 * fl * k)
    w = int(8 * k)
    pygame.draw.ellipse(S, (255, 150, 30), (x - w, y - h, 2 * w, h + 4))
    pygame.draw.ellipse(S, (255, 226, 130), (x - w // 2, y - h // 2 - 2, w, h // 2 + 4))


def draw_candle(S, x, y, t, lit=True, hgt=30):
    pygame.draw.rect(S, (236, 224, 190), (x - 5, y - hgt, 10, hgt))
    pygame.draw.rect(S, (170, 150, 110), (x - 5, y - hgt, 10, hgt), 1)
    pygame.draw.rect(S, (170, 138, 50), (x - 9, y, 18, 5), 0, 2)
    if lit:
        draw_flame(S, x, y - hgt - 2, t)
    else:
        pygame.draw.line(S, (40, 30, 20), (x, y - hgt), (x, y - hgt - 4), 2)


def draw_back(S, x, base, robe, hair, scale=1.0, tonsure=False, cap=None, t=0.0, bob=0.0):
    """Aluno visto de costas (plateia / jogador)."""
    s = scale
    y = base + bob
    dark = tuple(int(v * 0.6) for v in robe)
    body = [(x - 34 * s, base + 40 * s), (x - 30 * s, y - 14 * s), (x - 12 * s, y - 26 * s),
            (x + 12 * s, y - 26 * s), (x + 30 * s, y - 14 * s), (x + 34 * s, base + 40 * s)]
    pygame.draw.polygon(S, robe, body)
    pygame.draw.polygon(S, dark, body, 2)
    pygame.draw.line(S, mix(robe, (255, 220, 160), .35), body[1], body[2], 2)
    pygame.draw.line(S, mix(robe, (255, 220, 160), .35), body[2], body[3], 2)
    pygame.draw.circle(S, hair, (int(x), int(y - 42 * s)), int(19 * s))
    if tonsure:
        pygame.draw.circle(S, (226, 186, 150), (int(x), int(y - 46 * s)), int(10 * s))
    if cap:
        pygame.draw.polygon(S, cap, [(x - 22 * s, y - 50 * s), (x - 16 * s, y - 64 * s),
                                     (x + 16 * s, y - 64 * s), (x + 22 * s, y - 50 * s)])
        pygame.draw.ellipse(S, mix(cap, (255, 255, 255), .12), (x - 18 * s, y - 70 * s, 36 * s, 12 * s))
    pygame.draw.arc(S, mix(hair, (255, 220, 150), .3), (x - 19 * s, y - 61 * s, 38 * s, 38 * s), 0.5, 2.6, 2)


# -------------------------------------------------------------- botoes e UI
_btn_cache = {}
BTN_COL = {
    "normal": ((250, 238, 208), (224, 202, 152)),
    "press": ((228, 210, 164), (200, 176, 120)),
    "ok": ((184, 236, 156), (112, 192, 102)),
    "bad": ((244, 166, 154), (208, 92, 82)),
    "dim": ((150, 136, 108), (116, 104, 82)),
    "gold": ((255, 224, 130), (214, 160, 50)),
}


def btn_base(w, h, state):
    k = (w, h, state)
    if k not in _btn_cache:
        c1, c2 = BTN_COL[state]
        g = vgrad(w, h, c1, c2).convert_alpha() if pygame.display.get_surface() else vgrad(w, h, c1, c2)
        g = g.copy()
        surf = pygame.Surface((w, h), pygame.SRCALPHA)
        surf.blit(g, (0, 0))
        mask = pygame.Surface((w, h), pygame.SRCALPHA)
        pygame.draw.rect(mask, (255, 255, 255, 255), (0, 0, w, h), 0, 16)
        surf.blit(mask, (0, 0), special_flags=pygame.BLEND_RGBA_MIN)
        _btn_cache[k] = surf
    return _btn_cache[k]


def draw_button(S, rect, label, letter, state="normal", alpha=255, sz=26):
    r = rect
    tmp = pygame.Surface((r.w + 10, r.h + 12), pygame.SRCALPHA)
    pygame.draw.rect(tmp, (0, 0, 0, 120), (3, 7, r.w, r.h), 0, 16)
    tmp.blit(btn_base(r.w, r.h, state), (0, 0))
    pygame.draw.rect(tmp, (120, 84, 24) if state != "dim" else (80, 70, 50), (0, 0, r.w, r.h), 3, 16)
    hl = pygame.Surface((r.w - 12, r.h // 3), pygame.SRCALPHA)
    pygame.draw.rect(hl, (255, 255, 255, 55), hl.get_rect(), 0, 12)
    tmp.blit(hl, (6, 5))
    tcol = INK if state != "dim" else (70, 60, 44)
    f = font(sz, False)
    left = 0
    if letter:
        c = (36, r.h // 2)
        pygame.draw.circle(tmp, (60, 40, 12), c, 20)
        pygame.draw.circle(tmp, GOLD if state not in ("ok", "bad") else (255, 255, 255), c, 17)
        if state == "ok":
            pygame.draw.lines(tmp, (30, 120, 40), False, [(c[0] - 8, c[1]), (c[0] - 2, c[1] + 7), (c[0] + 9, c[1] - 8)], 5)
        elif state == "bad":
            pygame.draw.line(tmp, (170, 30, 30), (c[0] - 7, c[1] - 7), (c[0] + 7, c[1] + 7), 5)
            pygame.draw.line(tmp, (170, 30, 30), (c[0] + 7, c[1] - 7), (c[0] - 7, c[1] + 7), 5)
        else:
            img = font(30, True).render(letter, True, INK)
            tmp.blit(img, img.get_rect(center=c))
        left = 64
    width = r.w - left - 16
    lines = wrap(label, f, width)
    lh = f.get_linesize() - 2
    total = lh * len(lines)
    y0 = r.h // 2 - total // 2
    for i, ln in enumerate(lines):
        img = f.render(ln, True, tcol)
        tmp.blit(img, (left + (width - img.get_width()) // 2 if not letter else left, y0 + i * lh))
    if alpha < 255:
        tmp.set_alpha(alpha)
    S.blit(tmp, (r.x, r.y))


def panel(S, rect, alpha=236):
    tmp = pygame.Surface(rect.size, pygame.SRCALPHA)
    pygame.draw.rect(tmp, (30, 18, 9, alpha), (0, 0, rect.w, rect.h), 0, 16)
    S.blit(tmp, rect.topleft)
    pygame.draw.rect(S, GOLD, rect, 3, 16)
    pygame.draw.rect(S, (110, 80, 24), rect.inflate(-12, -12), 1, 12)


# ----------------------------------------------------------------- conteudo
QUESTIONS = [
    dict(opp=0, tema="O problema do mal",
         obj="Se Deus é infinitamente bom e poderoso, o mal não poderia existir. Mas o mal existe. Logo, Deus não existe!",
         ok="O mal é falta de um bem. Deus, sendo onipotente, permite o mal para tirar dele um bem maior.",
         bad=["O mal é só uma ilusão: na verdade ele não existe de forma nenhuma.",
              "Deus existe, mas não se importa com o que acontece no mundo."],
         expl="Santo Agostinho ensinou que o mal é a falta de um bem devido. Tomás de Aquino concluiu que Deus permite males porque é tão bom e poderoso que sabe tirar deles um bem maior."),
    dict(opp=1, tema="Fé e razão",
         obj="A fé e a razão se contradizem! Quem segue uma deve abandonar a outra. Escolha logo!",
         ok="A verdade não contradiz a verdade: a graça não destrói a natureza, mas a aperfeiçoa.",
         bad=["Quando divergem, a fé deve ser jogada fora e só a razão vale.",
              "A razão é perigosa: o teólogo deve parar de raciocinar e só repetir citações."],
         expl="Para Tomás, fé e razão vêm do mesmo Deus e não podem se contradizer. Em 1277, o bispo de Paris condenou teses que pareciam defender duas verdades opostas."),
    dict(opp=2, tema="O Filósofo pagão",
         obj="Aristóteles era pagão! Estudar o Filósofo na Universidade é perigoso para a nossa fé.",
         ok="Toda verdade vem de Deus, venha de onde vier: usamos o que Aristóteles acertou e corrigimos o que errou.",
         bad=["Aristóteles acertou em tudo e deve valer mais do que a própria Bíblia.",
              "Devemos queimar todos os livros dos pagãos para proteger os alunos."],
         expl="Alberto Magno e Tomás de Aquino estudaram Aristóteles a fundo. Tomás o chamava apenas de “o Filósofo” e o usava para organizar a teologia, corrigindo o que contrariava a fé."),
    dict(opp=3, tema="O argumento de Anselmo",
         obj="Santo Anselmo prova Deus só pelo pensamento: “aquilo de que nada maior se pode pensar”. Por que não começar por aí?",
         ok="Porque não conhecemos a essência de Deus: partimos das coisas que vemos, como nas Cinco Vias de Tomás.",
         bad=["Porque Anselmo era herege e todos os seus livros foram proibidos.",
              "Porque a existência de Deus não pode ser provada de nenhuma maneira."],
         expl="Tomás admite que a existência de Deus é evidente em si mesma, mas não para nós. Por isso ele prova Deus pelos efeitos, das coisas criadas até a causa. E Anselmo é santo e Doutor da Igreja!"),
    dict(opp=4, tema="A Primeira Via",
         obj="Tudo o que se move é movido por outro, e esse por outro, e assim para sempre. Nunca chegamos a um primeiro. Logo não há Deus!",
         ok="Uma série em que cada um só move porque foi movido não pode ser infinita: precisa haver um Primeiro Motor.",
         bad=["Exatamente: como a série é infinita, Deus não é necessário.",
              "O movimento é uma ilusão, então nada precisa de causa."],
         expl="É a Primeira Via das Cinco Vias de Tomás (Suma Teológica I, q. 2, a. 3): sem um primeiro motor, ninguém moveria nada, e o movimento que vemos não existiria."),
    dict(opp=5, tema="Sed contra",
         obj="Última pergunta da banca: quem foi o grande mestre dominicano de Tomás de Aquino?",
         ok="Santo Alberto Magno, o “Doutor Universal”.",
         bad=["Pedro Abelardo, que viveu um século antes.",
              "Guilherme de Ockham, que nasceu depois da morte de Tomás."],
         expl="Alberto Magno, dominicano, foi mestre de Tomás e grande estudioso de Aristóteles e das ciências naturais. Abelardo viveu no século XII e Ockham no século XIV."),
]
N_ROUNDS = len(QUESTIONS)
MAX_LIVES = 4
CHEERS = ["OPTIME!", "BENE!", "EXIMIE!"]
JEERS = ["SOPHISMA!", "ERRASTI!"]


# -------------------------------------------------------------------- jogo
class Game:
    def __init__(self):
        self.bg = make_scene()
        self.rose = make_rose()
        self.glow_c = make_glow(64, (255, 170, 60))
        self.vig = make_vignette(W, SCENE_H)
        self.scene = pygame.Surface((W, SCENE_H))
        self.hudbar = pygame.Surface((W, 70), pygame.SRCALPHA)
        for y in range(70):
            pygame.draw.line(self.hudbar, (0, 0, 0, int(190 * (1 - y / 70))), (0, y), (W, y))
        rnd = random.Random(11)
        self.dust = [[rnd.uniform(0, W), rnd.uniform(0, SCENE_H), rnd.uniform(5, 14), rnd.uniform(0.5, 2.0)] for _ in range(28)]
        self.aud = [
            (30, (104, 40, 40), (70, 44, 24), False, None), (100, (40, 60, 110), (150, 140, 130), False, None),
            (168, (50, 50, 56), (110, 80, 40), True, None), (372, (52, 90, 70), (60, 40, 24), False, (40, 40, 50)),
            (440, (110, 78, 44), (170, 170, 170), False, None), (510, (60, 44, 90), (90, 60, 30), True, None),
        ]
        self.t = 0.0
        self.parts = []
        self.splash = None
        self.flash = 0.0
        self.flash_col = (255, 255, 255)
        self.shake = 0.0
        self.aud_anim = None
        self.trans = None
        self.down = None
        self.state = "title"
        self.state_t = 0.0
        self.typed = self.total_chars = 0
        self.mood = "idle"
        self.opp_i = 5
        self.opp_shake_t = 0.0
        self.snuff_t = 0.0
        self.reset()
        self.btn_start = pygame.Rect(90, 842, 360, 80)
        self.btn_cont = pygame.Rect(110, 872, 320, 64)
        self.btn_hint = pygame.Rect(404, 10, 124, 40)

    def reset(self):
        self.round = 0
        self.lives = MAX_LIVES
        self.score = 0
        self.hints = 1

    # ----- fluxo
    def go(self, action):
        self.trans = dict(t=0.0, action=action, done=False)

    def begin(self):
        self.reset()
        self.start_round()

    def start_round(self):
        q = QUESTIONS[self.round]
        self.q = q
        self.opp_i = q["opp"]
        opts = [(q["ok"], True)] + [(b, False) for b in q["bad"]]
        random.shuffle(opts)
        self.opts = opts
        self.hidden = set()
        self.chosen = None
        self.lines = wrap(q["obj"], font(30), 470)
        self.total_chars = sum(len(l) for l in self.lines)
        self.typed = 0.0
        self.opt_t = 0.0
        self.state = "ask"
        self.state_t = 0.0
        self.mood = "angry"
        self.opt_rects = [pygame.Rect(18, 656 + i * 100, 504, 90) for i in range(3)]

    def answer(self, i):
        text, correct = self.opts[i]
        self.chosen = i
        self.state = "answered"
        self.state_t = 0.0
        self.opp_shake_t = 0.0
        if correct:
            self.score += 1
            self.mood = "hurt"
            self.aud_anim = ("jump", 0.0)
            self.splash = dict(text=random.choice(CHEERS), col=GOLD_L, t=0.0)
            self.burst(270, 150, 36)
            self.flash, self.flash_col = 0.45, (255, 240, 180)
        else:
            self.lives -= 1
            self.snuff_t = 1.2
            self.mood = "happy"
            self.aud_anim = ("nega", 0.0)
            self.splash = dict(text=random.choice(JEERS), col=(255, 110, 100), t=0.0)
            self.shake = 0.5
            self.flash, self.flash_col = 0.5, (200, 30, 20)

    def burst(self, x, y, n):
        for _ in range(n):
            a = random.uniform(0, math.tau)
            v = random.uniform(80, 280)
            self.parts.append([x, y, math.cos(a) * v, math.sin(a) * v - 90, random.uniform(.7, 1.4),
                               random.choice([GOLD_L, GOLD, (255, 255, 255)]), random.randint(3, 6)])

    def use_hint(self):
        if self.hints <= 0 or self.state != "ask" or self.typed < self.total_chars:
            return
        wrongs = [i for i, o in enumerate(self.opts) if not o[1] and i not in self.hidden]
        if len(wrongs) >= 2:
            self.hints -= 1
            self.hidden.add(random.choice(wrongs))
            self.burst(self.btn_hint.centerx, 60, 12)

    def next_step(self):
        if self.lives <= 0 or self.round >= N_ROUNDS - 1:
            self.go(lambda: setattr(self, "state", "end") or setattr(self, "state_t", 0.0)
                    or setattr(self, "mood", "happy" if self.lives <= 0 else "hurt")
                    or setattr(self, "opp_i", 5))
        else:
            self.round += 1
            self.go(self.start_round)

    # ----- entrada
    def press(self, pos):
        self.down = pos

    def release(self, pos):
        d, self.down = self.down, None
        if self.trans:
            return
        x, y = pos
        st = self.state
        if st == "title":
            if self.btn_start.collidepoint(pos):
                self.go(self.begin)
        elif st == "ask":
            if self.btn_hint.collidepoint(pos):
                self.use_hint()
            elif self.typed < self.total_chars:
                if y > 420:
                    self.typed = self.total_chars
            else:
                for i, r in enumerate(self.opt_rects):
                    if r.collidepoint(pos) and i not in self.hidden:
                        self.answer(i)
                        break
        elif st == "answered":
            if self.state_t > 0.35:
                self.state = "feedback"
                self.state_t = 0.0
        elif st == "feedback":
            if self.btn_cont.collidepoint(pos) and self.state_t > 0.3:
                self.next_step()
        elif st == "end":
            if self.btn_start.collidepoint(pos):
                self.go(lambda: (self.reset(), setattr(self, "state", "title"), setattr(self, "opp_i", 5),
                                 setattr(self, "mood", "idle")))

    # ----- atualizacao
    def update(self, dt):
        self.t += dt
        self.state_t += dt
        if self.trans:
            self.trans["t"] += dt / 0.7
            if self.trans["t"] >= 0.5 and not self.trans["done"]:
                self.trans["done"] = True
                self.trans["action"]()
            if self.trans["t"] >= 1:
                self.trans = None
        if self.state == "ask":
            talking = self.typed < self.total_chars
            self.typed = min(self.total_chars, self.typed + dt * 55)
            if self.typed >= self.total_chars:
                self.opt_t = min(1.0, self.opt_t + dt * 3)
                self.mood = "idle" if self.mood == "angry" else self.mood
        elif self.state == "answered" and self.state_t > 1.5:
            self.state = "feedback"
            self.state_t = 0.0
        self.opp_shake_t += dt
        self.snuff_t = max(0, self.snuff_t - dt)
        self.shake = max(0, self.shake - dt)
        self.flash = max(0, self.flash - dt)
        if self.splash:
            self.splash["t"] += dt
            if self.splash["t"] > 1.4:
                self.splash = None
        if self.aud_anim:
            self.aud_anim = (self.aud_anim[0], self.aud_anim[1] + dt)
            if self.aud_anim[1] > 1.0:
                self.aud_anim = None
        for p in self.parts:
            p[0] += p[2] * dt
            p[1] += p[3] * dt
            p[3] += 420 * dt
            p[4] -= dt
        self.parts = [p for p in self.parts if p[4] > 0]
        for d in self.dust:
            d[1] -= d[2] * dt
            d[0] += math.sin(self.t + d[3]) * 6 * dt
            if d[1] < 0:
                d[1] = SCENE_H
                d[0] = random.uniform(0, W)

    # ----- desenho
    def draw_scene(self):
        S = self.scene
        t = self.t
        S.blit(self.bg, (0, 0))
        rose = pygame.transform.rotozoom(self.rose, (t * 4) % 360, 1)
        S.blit(rose, rose.get_rect(center=(270, 108)))
        talking = (self.state == "ask" and self.typed < self.total_chars) or (self.state == "title" and False)
        sh = 0
        if self.mood == "hurt" and self.state != "end":
            sh = math.sin(self.opp_shake_t * 50) * 7 * max(0, 1 - self.opp_shake_t * 1.6)
        o = OPPS[self.opp_i]
        hy = draw_scholar(S, 270, 292, o, t, self.mood, talking, sh)
        draw_lectern(S, 270, 292)
        draw_candle(S, 196, 296, t)
        draw_candle(S, 344, 296, t)
        # estrelinhas girando quando o mestre fica atordoado
        if self.mood == "hurt" and self.state in ("answered", "feedback"):
            for i in range(3):
                a = t * 4 + i * 2.09
                x = 270 + math.cos(a) * 34
                y = hy - 44 + math.sin(a) * 8
                pygame.draw.circle(S, GOLD_L, (int(x), int(y)), 5)
                pygame.draw.circle(S, (255, 255, 255), (int(x), int(y)), 2)
        # plateia + jogador
        anim = self.aud_anim
        for i, (x, robe, hair, ton, cap) in enumerate(self.aud):
            bob = math.sin(t * 1.4 + i) * 1.2
            dx = 0
            if anim:
                k = max(0, 1 - anim[1] / 1.0)
                if anim[0] == "jump":
                    bob -= abs(math.sin(anim[1] * 12 + i)) * 18 * k
                else:
                    dx = math.sin(anim[1] * 22 + i) * 6 * k
            draw_back(S, x + dx, SCENE_H - 8, robe, hair, 1.0, ton, cap, t, bob)
        pb = math.sin(t * 1.6) * 1.5
        if anim and anim[0] == "jump":
            pb -= abs(math.sin(anim[1] * 12)) * 12 * max(0, 1 - anim[1])
        draw_back(S, 270, SCENE_H - 2, (38, 62, 150), (70, 46, 26), 1.5, False, (24, 24, 32), t, pb)
        # luz das velas e janelas
        fl = 1 + math.sin(t * 13) * 0.08 + math.sin(t * 7.3) * 0.05
        for cxp in (196, 344):
            g = pygame.transform.smoothscale(self.glow_c, (int(128 * fl), int(128 * fl)))
            S.blit(g, g.get_rect(center=(cxp, 262)), special_flags=pygame.BLEND_RGB_ADD)
        for d in self.dust:
            a = int(120 + 100 * math.sin(self.t * 2 + d[3] * 5))
            pygame.draw.circle(S, (a, int(a * .9), int(a * .6)), (int(d[0]), int(d[1])), 1)
        S.blit(self.vig, (0, 0))

    def draw_hud(self, S):
        S.blit(self.hudbar, (0, 0))
        for i in range(MAX_LIVES):
            x = 28 + i * 34
            lit = i < self.lives
            draw_candle(S, x, 50, self.t + i, lit, 22)
            if not lit and i == self.lives and self.snuff_t > 0:
                k = self.snuff_t / 1.2
                for j in range(4):
                    pygame.draw.circle(S, (170, 170, 170), (int(x + math.sin(self.t * 6 + j) * 4), int(24 - (1 - k) * 18 - j * 5)), 3 + j // 2)
        draw_text(S, "QUESTÃO %d / %d" % (self.round + 1, N_ROUNDS), 28, GOLD_L, (270, 28), bold=True)
        # botao de dica
        r = self.btn_hint
        on = self.hints > 0 and self.state == "ask" and self.typed >= self.total_chars
        state = "gold" if on else "dim"
        pressed = self.down and r.collidepoint(self.down)
        draw_button(S, r.move(0, 2 if pressed else 0), "Dica  x%d" % self.hints, None, "press" if (pressed and on) else state, sz=26)

    def draw_ask_ui(self, S):
        q = self.q
        o = OPPS[q["opp"]]
        pr = pygame.Rect(12, 440, 516, 200)
        panel(S, pr)
        # placa do nome
        plate = pygame.Rect(26, 424, 252, 34)
        pygame.draw.rect(S, (120, 22, 28), plate, 0, 10)
        pygame.draw.rect(S, GOLD, plate, 3, 10)
        draw_text(S, o["name"], 28, GOLD_L, plate.center, bold=True)
        draw_text(S, q["tema"], 24, (200, 170, 110), (510, 452), anchor="topright", shadow=None)
        # texto digitado
        n = int(self.typed)
        f = font(30)
        y = 470
        for ln in self.lines:
            part = ln[:max(0, n)]
            n -= len(ln)
            if part:
                S.blit(f.render(part, True, PARCH), (28, y))
            y += f.get_linesize() - 1
            if n <= 0:
                break
        if self.typed < self.total_chars:
            draw_text(S, "toque para pular", 20, (150, 126, 84), (514, 628), anchor="bottomright", shadow=None)

    def draw_options(self, S):
        k = self.opt_t if self.state == "ask" else 1
        if k <= 0:
            return
        for i, (text, correct) in enumerate(self.opts):
            if i in self.hidden and self.state == "ask":
                continue
            r = self.opt_rects[i].copy()
            r.y += int((1 - k) * 40)
            state = "normal"
            if self.state == "ask":
                if self.down and r.collidepoint(self.down):
                    state = "press"
            else:
                if correct:
                    state = "ok"
                elif i == self.chosen:
                    state = "bad"
                else:
                    state = "dim"
                if i in self.hidden:
                    state = "dim"
            draw_button(S, r, text, "ABC"[i], state, alpha=int(255 * k), sz=28)

    def draw_feedback(self, S):
        ok = self.opts[self.chosen][1]
        rect = pygame.Rect(12, 650, 516, 290)
        panel(S, rect)
        head = "Optime! Resposta certa." if ok else "Sophisma! Não foi dessa vez."
        draw_text(S, head, 38, GOLD_L if ok else (255, 130, 120), (270, 682), bold=True)
        f = font(28)
        y = 716
        for ln in wrap(self.q["expl"], f, 480):
            S.blit(f.render(ln, True, PARCH), (30, y))
            y += f.get_linesize() - 1
        last = self.lives <= 0 or self.round >= N_ROUNDS - 1
        pressed = self.down and self.btn_cont.collidepoint(self.down)
        draw_button(S, self.btn_cont.move(0, 2 if pressed else 0),
                    "Ver resultado" if last else "Continuar", None, "press" if pressed else "gold", sz=34)

    def draw_title(self, S):
        panel(S, pygame.Rect(12, 440, 516, 508))
        outlined(S, "DISPUTATIO", 108, GOLD, (270, 520), th=4, hi=GOLD_L)
        draw_text(S, "Uma Questão em Paris · 1256", 32, (230, 200, 140), (270, 584), shadow=None)
        pygame.draw.line(S, GOLD, (60, 612), (480, 612), 2)
        pygame.draw.polygon(S, GOLD, [(270, 604), (278, 612), (270, 620), (262, 612)])
        lines = [
            "Você é um bacharel defendendo sua tese",
            "diante dos mestres da Universidade.",
            "",
            "Responda às objeções com sabedoria.",
            "Cada erro apaga uma vela.",
            "Use a Dica para eliminar uma resposta.",
            "",
            "6 questões · uns 5 minutos",
        ]
        y = 640
        for ln in lines:
            draw_text(S, ln, 29, PARCH, (270, y), shadow=(0, 0, 0))
            y += 14 if ln == "" else 29
        pressed = self.down and self.btn_start.collidepoint(self.down)
        draw_button(S, self.btn_start.move(0, 2 if pressed else 0), "Iniciar a Disputa", None, "press" if pressed else "gold", sz=40)

    def draw_end(self, S):
        win = self.lives > 0
        panel(S, pygame.Rect(12, 440, 516, 508))
        if not win:
            title, sub, stars = "REPROVADO", "As velas se apagaram...", 0
        elif self.score == N_ROUNDS:
            title, sub, stars = "MAGISTER", "Aclamado Mestre pela Universidade de Paris!", 3
        elif self.score >= N_ROUNDS - 1:
            title, sub, stars = "LICENCIADO", "Os mestres aprovaram a sua defesa.", 2
        else:
            title, sub, stars = "BACHAREL", "Aprovado, mas ainda há muito a estudar.", 1
        outlined(S, title, 76, GOLD if win else (230, 110, 100), (270, 510), th=4, hi=GOLD_L if win else (255, 170, 160))
        draw_text(S, sub, 27, (230, 200, 140), (270, 566), shadow=None)
        for i in range(3):
            cx = 190 + i * 80
            pts = []
            for j in range(10):
                a = -math.pi / 2 + j * math.pi / 5
                r = 34 if j % 2 == 0 else 15
                pts.append((cx + r * math.cos(a), 640 + r * math.sin(a)))
            pygame.draw.polygon(S, GOLD_L if i < stars else (70, 56, 38), pts)
            pygame.draw.polygon(S, (110, 76, 20) if i < stars else (40, 30, 20), pts, 3)
        draw_text(S, "Acertos: %d de %d" % (self.score, N_ROUNDS), 36, PARCH, (270, 712), bold=True)
        msg = ("Lembre-se: para Tomás de Aquino, a fé e a razão não se contradizem. "
               "A graça não destrói a natureza, mas a aperfeiçoa.") if win else \
              "Tente de novo: os mestres da Escolástica ensinaram que a razão e a fé caminham juntas."
        y = 744
        f = font(26)
        for ln in wrap(msg, f, 470):
            img = f.render(ln, True, (210, 190, 150))
            S.blit(img, ((W - img.get_width()) // 2, y))
            y += 27
        pressed = self.down and self.btn_start.collidepoint(self.down)
        draw_button(S, self.btn_start.move(0, 2 if pressed else 0), "Jogar de novo", None, "press" if pressed else "gold", sz=40)

    def draw(self, canvas):
        canvas.fill((14, 8, 4))
        self.draw_scene()
        sx = sy = 0
        if self.shake > 0:
            sx = int(math.sin(self.t * 60) * 9 * self.shake * 2)
            sy = int(math.cos(self.t * 47) * 5 * self.shake * 2)
        canvas.blit(self.scene, (sx, sy))
        pygame.draw.line(canvas, GOLD, (0, SCENE_H), (W, SCENE_H), 3)
        # particulas
        for p in self.parts:
            pygame.draw.circle(canvas, p[5], (int(p[0]), int(p[1])), max(1, int(p[6] * min(1, p[4]))))
        if self.flash > 0:
            fl = pygame.Surface((W, SCENE_H), pygame.SRCALPHA)
            fl.fill((*self.flash_col, int(150 * self.flash / 0.5)))
            canvas.blit(fl, (0, 0))
        st = self.state
        if st == "title":
            self.draw_title(canvas)
        elif st == "end":
            self.draw_end(canvas)
        else:
            self.draw_hud(canvas)
            self.draw_ask_ui(canvas)
            if st in ("ask", "answered"):
                self.draw_options(canvas)
            elif st == "feedback":
                self.draw_feedback(canvas)
        # texto grande de reacao
        if self.splash:
            sp = self.splash
            k = sp["t"]
            sc = 1 + 0.9 * max(0, 1 - k * 5)
            img = pygame.Surface((W, 140), pygame.SRCALPHA)
            outlined(img, sp["text"], 92, sp["col"], (270, 70), th=5, hi=(255, 255, 255))
            img = pygame.transform.rotozoom(img, -6, sc)
            img.set_alpha(int(255 * min(1, (1.4 - k) * 3)))
            canvas.blit(img, img.get_rect(center=(270, 215)))
        # transicao (fade)
        if self.trans:
            a = 1 - abs(2 * self.trans["t"] - 1)
            ov = pygame.Surface((W, H))
            ov.fill((8, 4, 2))
            ov.set_alpha(int(255 * min(1, a * 1.6)))
            canvas.blit(ov, (0, 0))


# --------------------------------------------------------------- laco principal
async def main():
    web = sys.platform == "emscripten"
    size = (W, H)
    if not web:
        try:
            dh = pygame.display.get_desktop_sizes()[0][1]
            k = min(1.0, (dh - 120) / H)
            size = (int(W * k), int(H * k))
        except Exception:
            pass
    pygame.display.set_caption("Disputatio - Uma Questão em Paris")
    if web:
        # no navegador/celular o pygbag escala o canvas sozinho
        win = pygame.display.set_mode((W, H), pygame.SCALED)
    else:
        win = pygame.display.set_mode(size, pygame.RESIZABLE)
    canvas = pygame.Surface((W, H))
    game = Game()
    clock = pygame.time.Clock()
    frame = 0
    plat = None
    if web:
        # O SDL do pygbag erra a posicao do toque em telas com pixel ratio 2+
        # (celulares). Entao lemos o toque direto do navegador (Pointer Events),
        # em fracoes 0..1 do canvas, e convertemos nos mesmos.
        try:
            import platform as plat
            plat.window.eval("""
            window.ptrstate = {s: ""};
            (function () {
              var c = document.getElementById('canvas');
              c.style.touchAction = 'none';
              function add(t, e) {
                var r = c.getBoundingClientRect();
                window.ptrstate.s += t + ':' + ((e.clientX - r.left) / r.width) + ':' +
                                     ((e.clientY - r.top) / r.height) + ';';
              }
              window.addEventListener('pointerdown', function (e) { add('d', e); }, true);
              window.addEventListener('pointerup', function (e) { add('u', e); }, true);
              window.addEventListener('pointercancel', function (e) { add('u', e); }, true);
            })();
            """)
        except Exception:
            plat = None
    while True:
        frame += 1
        if plat is not None:
            try:
                buf = str(plat.window.ptrstate.s)
                if buf:
                    plat.window.ptrstate.s = ""
                    for item in buf.split(";"):
                        if not item:
                            continue
                        kind, fx, fy = item.split(":")
                        pos = (float(fx) * W, float(fy) * H)
                        if kind == "d":
                            game.press(pos)
                        else:
                            game.release(pos)
            except Exception:
                pass
        if web and frame in (2, 30):
            # pede ao pygbag para reajustar o canvas ao tamanho da tela do celular
            try:
                import platform
                platform.window.window_resize()
            except Exception:
                pass
        dt = min(clock.tick(60) / 1000.0, 0.05)
        win = pygame.display.get_surface()
        ww, wh = win.get_size()
        sc = min(ww / W, wh / H)
        dw, dh = int(W * sc), int(H * sc)
        ox, oy = (ww - dw) // 2, (wh - dh) // 2

        def tolocal(p):
            return ((p[0] - ox) / sc, (p[1] - oy) / sc)

        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                return
            if web:
                continue  # no navegador o toque vem dos Pointer Events acima
            if e.type == pygame.MOUSEBUTTONDOWN and e.button == 1:
                game.press(tolocal(e.pos))
            elif e.type == pygame.MOUSEBUTTONUP and e.button == 1:
                game.release(tolocal(e.pos))
        game.update(dt)
        game.draw(canvas)
        win.fill((8, 5, 2))
        if (dw, dh) == (W, H):
            win.blit(canvas, (ox, oy))
        else:
            win.blit(pygame.transform.smoothscale(canvas, (dw, dh)), (ox, oy))
        pygame.display.flip()
        await asyncio.sleep(0)


if __name__ == "__main__":
    asyncio.run(main())
